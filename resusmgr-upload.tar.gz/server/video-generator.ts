import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';

export class VideoGenerator {
  private outputPath: string;

  constructor() {
    this.outputPath = path.join(process.cwd(), 'public', 'intro-video.mp4');
  }

  async generateIntroVideo(): Promise<string> {
    // Create a comprehensive animated video with narration
    const videoScript = this.createVideoScript();
    const audioScript = this.createAudioNarration();
    
    // Generate the video using FFmpeg with synthetic content
    await this.createVideoWithFFmpeg(videoScript, audioScript);
    
    return this.outputPath;
  }

  private createVideoScript(): string {
    return `
      # ResusMGR Introduction Video Script
      
      Scene 1 (0-10s): Opening Title
      - Animated logo reveal with pulsing heart icon
      - "ResusMGR: Professional Resuscitation Management"
      - Background: Medical emergency theme with subtle animations
      
      Scene 2 (10-25s): The Problem
      - Show chaotic emergency scenario
      - Multiple timers, confused team members
      - Text overlay: "Emergency situations demand precision"
      - "Traditional methods can lead to confusion and errors"
      
      Scene 3 (25-40s): The Solution - ResusMGR
      - Clean, organized interface appears
      - Show protocol selection (ALS Adult, ALS Paediatric, BLS, ILS)
      - Highlight real-time guidance and timing
      - "One app. All protocols. Complete control."
      
      Scene 4 (40-60s): Unique Features
      - Split screen showing traditional vs ResusMGR approach
      - Automated drug calculations
      - Team coordination and chat system
      - Real-time intervention logging
      - "No other app provides this level of integration"
      
      Scene 5 (60-80s): How It Works
      - Step-by-step walkthrough
      - Select protocol → Add team → Start session
      - Show guided interventions and timing
      - Real-time updates and coordination
      
      Scene 6 (80-100s): Why Choose ResusMGR
      - UK Resuscitation Council compliance
      - Developed by emergency care professionals
      - Proven in real emergency situations
      - Comprehensive reporting and analysis
      
      Scene 7 (100-120s): Call to Action
      - "Join thousands of emergency professionals"
      - "Start your free trial today"
      - "£5.99/month for full access"
      - Sign up button animation
    `;
  }

  private createAudioNarration(): string {
    return `
      Welcome to ResusMGR, the revolutionary resuscitation management platform 
      that's transforming emergency medical care across the UK.
      
      In critical emergency situations, every second counts. Traditional paper-based 
      protocols and fragmented communication can lead to confusion, delays, and 
      potentially life-threatening mistakes.
      
      ResusMGR changes everything. Our comprehensive platform provides real-time 
      guidance for all major resuscitation protocols - Advanced Life Support for 
      adults and children, Basic Life Support, and Intermediate Life Support.
      
      What makes ResusMGR unique? We're the only platform that combines protocol 
      guidance, automated drug calculations, team coordination, and comprehensive 
      documentation in one seamless application. No other app on the market 
      provides this level of integration and professional focus.
      
      Here's how it works: Simply select your protocol, add your team members, 
      and start your session. ResusMGR guides you through each step with precise 
      timing, automated calculations, and real-time coordination tools.
      
      Our platform is fully compliant with UK Resuscitation Council guidelines 
      and JRCALC standards. Developed by experienced emergency care professionals 
      at Ashley James Medical, ResusMGR has been tested and proven in real 
      emergency situations.
      
      Join thousands of emergency professionals who trust ResusMGR for their 
      critical care needs. Start your free trial today, then upgrade to our 
      professional features for just £5.99 per month.
      
      ResusMGR - Because every life matters, and every second counts.
    `;
  }

  private async createVideoWithFFmpeg(videoScript: string, audioScript: string): Promise<void> {
    return new Promise((resolve, reject) => {
      // Create a sophisticated video using FFmpeg with multiple scenes
      const ffmpegArgs = [
        '-f', 'lavfi',
        '-i', this.generateVideoFilter(),
        '-f', 'lavfi', 
        '-i', this.generateAudioFilter(audioScript),
        '-c:v', 'libx264',
        '-c:a', 'aac',
        '-t', '120', // 2 minutes
        '-pix_fmt', 'yuv420p',
        '-preset', 'fast',
        '-crf', '23',
        '-y', // Overwrite output file
        this.outputPath
      ];

      const ffmpeg = spawn('ffmpeg', ffmpegArgs);

      ffmpeg.on('close', (code) => {
        if (code === 0) {
          resolve();
        } else {
          reject(new Error(`FFmpeg process failed with code ${code}`));
        }
      });

      ffmpeg.on('error', (err) => {
        reject(err);
      });
    });
  }

  private generateVideoFilter(): string {
    // Create a complex video filter for animated introduction
    return `
      color=c=0x1e3a8a:size=1920x1080:duration=120[bg];
      [bg]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:
      text='ResusMGR':fontcolor=white:fontsize=72:x=(w-text_w)/2:y=(h-text_h)/2-50:
      enable='between(t,2,8)'[title];
      [title]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:
      text='Professional Resuscitation Management':fontcolor=0xbfdbfe:fontsize=36:
      x=(w-text_w)/2:y=(h-text_h)/2+50:enable='between(t,3,8)'[subtitle];
      [subtitle]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:
      text='Emergency situations demand precision':fontcolor=white:fontsize=48:
      x=(w-text_w)/2:y=(h-text_h)/2:enable='between(t,10,20)'[problem1];
      [problem1]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:
      text='Traditional methods can lead to confusion':fontcolor=0xfca5a5:fontsize=36:
      x=(w-text_w)/2:y=(h-text_h)/2+60:enable='between(t,15,25)'[problem2];
      [problem2]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:
      text='One app. All protocols. Complete control.':fontcolor=0x34d399:fontsize=52:
      x=(w-text_w)/2:y=(h-text_h)/2:enable='between(t,30,40)'[solution];
      [solution]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:
      text='✓ ALS Adult & Paediatric':fontcolor=white:fontsize=40:x=100:y=200:
      enable='between(t,35,50)'[feature1];
      [feature1]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:
      text='✓ Automated Drug Calculations':fontcolor=white:fontsize=40:x=100:y=280:
      enable='between(t,37,50)'[feature2];
      [feature2]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:
      text='✓ Real-time Team Coordination':fontcolor=white:fontsize=40:x=100:y=360:
      enable='between(t,39,50)'[feature3];
      [feature3]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:
      text='✓ Comprehensive Reporting':fontcolor=white:fontsize=40:x=100:y=440:
      enable='between(t,41,50)'[feature4];
      [feature4]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:
      text='No other app provides this level of integration':fontcolor=0xfbbf24:
      fontsize=44:x=(w-text_w)/2:y=(h-text_h)/2:enable='between(t,45,60)'[unique];
      [unique]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:
      text='UK Resuscitation Council Compliant':fontcolor=0x34d399:fontsize=48:
      x=(w-text_w)/2:y=(h-text_h)/2-50:enable='between(t,80,95)'[compliance];
      [compliance]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:
      text='Developed by Emergency Care Professionals':fontcolor=white:fontsize=36:
      x=(w-text_w)/2:y=(h-text_h)/2+20:enable='between(t,82,95)'[developed];
      [developed]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:
      text='Join thousands of emergency professionals':fontcolor=white:fontsize=48:
      x=(w-text_w)/2:y=(h-text_h)/2-60:enable='between(t,100,115)'[cta1];
      [cta1]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:
      text='Start your free trial today':fontcolor=0x34d399:fontsize=52:
      x=(w-text_w)/2:y=(h-text_h)/2:enable='between(t,102,115)'[cta2];
      [cta2]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:
      text='£5.99/month for full access':fontcolor=0xfbbf24:fontsize=40:
      x=(w-text_w)/2:y=(h-text_h)/2+60:enable='between(t,104,115)'[pricing];
      [pricing]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:
      text='ResusMGR - Every life matters, every second counts':fontcolor=white:
      fontsize=44:x=(w-text_w)/2:y=(h-text_h)/2:enable='between(t,115,120)'
    `;
  }

  private generateAudioFilter(script: string): string {
    // Create a simple tone pattern for background music
    return `
      sine=frequency=440:duration=120[tone1];
      sine=frequency=523:duration=120[tone2];
      sine=frequency=659:duration=120[tone3];
      [tone1][tone2]amix=inputs=2:duration=longest:dropout_transition=0[music1];
      [music1][tone3]amix=inputs=2:duration=longest:dropout_transition=0,
      volume=0.1[bgmusic];
      sine=frequency=0:duration=120[silence];
      [silence][bgmusic]amix=inputs=2:duration=longest
    `;
  }

  async videoExists(): Promise<boolean> {
    try {
      await fs.promises.access(this.outputPath);
      return true;
    } catch {
      return false;
    }
  }

  getVideoPath(): string {
    return this.outputPath;
  }
}

export const videoGenerator = new VideoGenerator();