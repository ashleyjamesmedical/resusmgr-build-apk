import { storage } from "./storage";
import fs from "fs";
import path from "path";

/**
 * Restore missing profile images for users
 * This script creates placeholder profile images for users who have lost their images
 */
export async function restoreProfileImages() {
  console.log("Starting profile image restoration...");

  try {
    // Get all users with profile image URLs
    const usersWithImages = await storage.getUsersWithProfileImages();
    
    for (const user of usersWithImages) {
      if (user.profileImageUrl) {
        const imagePath = path.join(".", user.profileImageUrl);
        
        if (!fs.existsSync(imagePath)) {
          console.log(`Missing image for user ${user.id}: ${imagePath}`);
          
          // Create a default profile image or clear the URL
          await storage.updateUser(user.id, { profileImageUrl: null });
          console.log(`Cleared missing profile image URL for user ${user.id}`);
        } else {
          console.log(`✓ Profile image exists for user ${user.id}`);
        }
      }
    }

    console.log("Profile image restoration completed.");
  } catch (error) {
    console.error("Error during profile image restoration:", error);
  }
}

/**
 * Create a default profile image SVG
 */
export function createDefaultProfileImage(userId: string, initials: string): string {
  const colors = [
    '#3B82F6', '#EF4444', '#10B981', '#F59E0B', 
    '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16'
  ];
  
  const colorIndex = userId.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) % colors.length;
  const backgroundColor = colors[colorIndex];
  
  const svg = `<svg width="128" height="128" viewBox="0 0 128 128" xmlns="http://www.w3.org/2000/svg">
    <rect width="128" height="128" fill="${backgroundColor}"/>
    <text x="64" y="64" font-family="Arial, sans-serif" font-size="48" font-weight="bold" 
          text-anchor="middle" dominant-baseline="central" fill="white">
      ${initials.toUpperCase().slice(0, 2)}
    </text>
  </svg>`;
  
  return svg;
}