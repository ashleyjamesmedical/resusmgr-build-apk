import {
  users,
  resuscitationSessions,
  interventions,
  reversibleCauses,
  drugDoses,
  notifications,
  resusTeamMembers,
  unauthorizedParticipationReports,
  chatConversations,
  chatParticipants,
  chatMessages,
  messageReadReceipts,
  type User,
  type InsertUser,
  type RegisterUser,
  type UpdateUser,
  type InsertResuscitationSession,
  type ResuscitationSession,
  type InsertIntervention,
  type Intervention,
  type InsertReversibleCauses,
  type ReversibleCauses,
  type InsertDrugDose,
  type DrugDose,
  type InsertNotification,
  type Notification,
  type ResusTeamMember,
  type InsertResusTeamMember,
  type InsertUnauthorizedParticipationReport,
  type UnauthorizedParticipationReport,
  type InsertChatConversation,
  type ChatConversation,
  type InsertChatParticipant,
  type ChatParticipant,
  type InsertChatMessage,
  type ChatMessage,
  type MessageReadReceipt,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, isNull, count, gt } from "drizzle-orm";

export interface IStorage {
  // User operations for secure authentication
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: RegisterUser): Promise<User>;
  updateUser(id: string, updates: UpdateUser): Promise<User>;
  updateUserPassword(id: string, hashedPassword: string): Promise<User>;
  updateUserLastLogin(id: string): Promise<User>;
  updateUserActivity(id: string): Promise<User>;
  updateUserStripeInfo(userId: number, customerId: string, subscriptionId?: string): Promise<User>;
  updateUserSubscriptionStatus(userId: number, active: boolean): Promise<User>;
  acceptDisclaimer(userId: number): Promise<User>;
  getUserCount(): Promise<number>;
  incrementRoscCount(userId: string): Promise<User>;
  incrementRoleCount(userId: string): Promise<User>;
  resetRoscCount(userId: string): Promise<User>;
  resetRoleCount(userId: string): Promise<User>;

  // Resuscitation session operations
  createResuscitationSession(session: InsertResuscitationSession): Promise<ResuscitationSession>;
  getResuscitationSession(id: number): Promise<ResuscitationSession | undefined>;
  getActiveSession(userId: string): Promise<ResuscitationSession | undefined>;
  updateResuscitationSession(id: number, updates: Partial<ResuscitationSession>): Promise<ResuscitationSession>;
  getUserSessions(userId: string, limit?: number): Promise<ResuscitationSession[]>;
  endSession(id: number, outcome: string, notes?: string): Promise<ResuscitationSession>;
  deleteResuscitationSession(id: number): Promise<void>;

  // Intervention operations
  logIntervention(intervention: InsertIntervention): Promise<Intervention>;
  getSessionInterventions(sessionId: number): Promise<Intervention[]>;

  // Reversible causes operations
  updateReversibleCauses(sessionId: number, causes: InsertReversibleCauses): Promise<ReversibleCauses>;
  getReversibleCauses(sessionId: number): Promise<ReversibleCauses | undefined>;

  // Drug dose operations
  logDrugDose(drugDose: InsertDrugDose): Promise<DrugDose>;
  getSessionDrugDoses(sessionId: number): Promise<DrugDose[]>;

  // Notification operations
  createNotification(notification: InsertNotification): Promise<Notification>;
  getUserNotifications(userId: string, limit?: number): Promise<Notification[]>;
  getUnreadNotificationCount(userId: string): Promise<number>;
  markNotificationAsRead(notificationId: number): Promise<Notification>;
  markAllNotificationsAsRead(userId: string): Promise<void>;
  deleteNotification(notificationId: number): Promise<void>;
  clearAllUserNotifications(userId: string): Promise<void>;

  // Team member operations
  addTeamMember(teamMember: InsertResusTeamMember): Promise<ResusTeamMember>;
  getSessionTeamMembers(sessionId: number): Promise<ResusTeamMember[]>;
  removeTeamMember(id: number): Promise<void>;
  searchUsersByName(query: string, limit?: number): Promise<User[]>;

  // Unauthorized participation report operations
  createUnauthorizedParticipationReport(report: InsertUnauthorizedParticipationReport): Promise<UnauthorizedParticipationReport>;
  getUnauthorizedParticipationReports(limit?: number): Promise<UnauthorizedParticipationReport[]>;
  updateUnauthorizedParticipationReportStatus(id: number, status: string, adminNotes?: string, reviewedBy?: string): Promise<UnauthorizedParticipationReport>;

  // Chat system operations
  createConversation(conversation: InsertChatConversation): Promise<ChatConversation>;
  getConversation(id: number): Promise<ChatConversation | undefined>;
  getUserConversations(userId: string): Promise<ChatConversation[]>;
  addParticipant(participant: InsertChatParticipant): Promise<ChatParticipant>;
  removeParticipant(conversationId: number, userId: string): Promise<void>;
  getConversationParticipants(conversationId: number): Promise<ChatParticipant[]>;
  sendMessage(message: InsertChatMessage): Promise<ChatMessage>;
  getConversationMessages(conversationId: number, limit?: number): Promise<ChatMessage[]>;
  markMessagesAsRead(conversationId: number, userId: string): Promise<void>;
  getUnreadMessageCount(userId: string): Promise<number>;
  markMessageAsDelivered(messageId: number): Promise<void>;
  markMessageAsRead(messageId: number, userId: string): Promise<void>;
  getMessageReadReceipts(messageId: number): Promise<MessageReadReceipt[]>;

  // Investigation outcome actions
  resolveUnauthorizedParticipation(reportId: number, action: 'keep' | 'remove', adminNotes: string, reviewedBy: string): Promise<void>;
  removeTeamMemberFromSession(sessionId: number, teamMemberId: number): Promise<void>;
  
  // Session dispute status
  isSessionDisputed(sessionId: number): Promise<boolean>;
  
  // Admin user operations
  getAdminUsers(): Promise<User[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations for secure authentication
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(userData: RegisterUser): Promise<User> {
    const userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const [user] = await db
      .insert(users)
      .values({
        id: userId,
        ...userData,
        // Explicitly ensure new users start on free plan
        subscriptionActive: false,
        stripeCustomerId: null,
        stripeSubscriptionId: null,
      })
      .returning();
    return user;
  }

  async updateUser(id: string, updates: UpdateUser): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserPassword(id: string, hashedPassword: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        password: hashedPassword,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserLastLogin(id: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        lastLoginAt: new Date(),
        lastActivityAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserActivity(id: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        lastActivityAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserStripeInfo(userId: number, customerId: string, subscriptionId?: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        stripeCustomerId: customerId,
        stripeSubscriptionId: subscriptionId,
        subscriptionActive: !!subscriptionId,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateUserSubscriptionStatus(userId: number, active: boolean): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        subscriptionActive: active,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async acceptDisclaimer(userId: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        disclaimerAccepted: true,
        disclaimerAcceptedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async getUserCount(): Promise<number> {
    const result = await db
      .select({ count: sql<number>`count(*)` })
      .from(users);
    return result[0].count;
  }

  async incrementRoscCount(userId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        roscCount: sql`${users.roscCount} + 1`,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async incrementRoleCount(userId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        roleCount: sql`${users.roleCount} + 1`,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async resetRoscCount(userId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        roscCount: 0,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async resetRoleCount(userId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        roleCount: 0,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Resuscitation session operations
  async createResuscitationSession(session: InsertResuscitationSession): Promise<ResuscitationSession> {
    const [newSession] = await db
      .insert(resuscitationSessions)
      .values(session)
      .returning();
    return newSession;
  }

  async getResuscitationSession(id: number): Promise<ResuscitationSession | undefined> {
    const [session] = await db
      .select()
      .from(resuscitationSessions)
      .where(eq(resuscitationSessions.id, id));
    return session;
  }

  async getActiveSession(userId: string): Promise<ResuscitationSession | undefined> {
    const [session] = await db
      .select()
      .from(resuscitationSessions)
      .where(
        and(
          eq(resuscitationSessions.userId, userId),
          sql`${resuscitationSessions.endTime} IS NULL`
        )
      )
      .orderBy(desc(resuscitationSessions.startTime));
    return session;
  }

  async updateResuscitationSession(id: number, updates: Partial<ResuscitationSession>): Promise<ResuscitationSession> {
    const [session] = await db
      .update(resuscitationSessions)
      .set(updates)
      .where(eq(resuscitationSessions.id, id))
      .returning();
    return session;
  }

  async getUserSessions(userId: string, limit: number = 10): Promise<ResuscitationSession[]> {
    return await db
      .select()
      .from(resuscitationSessions)
      .where(eq(resuscitationSessions.userId, userId))
      .orderBy(desc(resuscitationSessions.startTime))
      .limit(limit);
  }

  async endSession(id: number, outcome: string, notes?: string): Promise<ResuscitationSession> {
    const endTime = new Date();
    const session = await this.getResuscitationSession(id);
    if (!session) {
      throw new Error("Session not found");
    }

    const duration = Math.floor((endTime.getTime() - new Date(session.startTime).getTime()) / 1000);

    const [updatedSession] = await db
      .update(resuscitationSessions)
      .set({
        endTime,
        duration,
        outcome,
        notes,
      })
      .where(eq(resuscitationSessions.id, id))
      .returning();

    return updatedSession;
  }

  async deleteResuscitationSession(id: number): Promise<void> {
    // Delete related data first (foreign key constraints)
    await db.delete(interventions).where(eq(interventions.sessionId, id));
    await db.delete(drugDoses).where(eq(drugDoses.sessionId, id));
    await db.delete(reversibleCauses).where(eq(reversibleCauses.sessionId, id));
    await db.delete(resusTeamMembers).where(eq(resusTeamMembers.sessionId, id));
    await db.delete(unauthorizedParticipationReports).where(eq(unauthorizedParticipationReports.sessionId, id));
    
    // Delete the session
    await db.delete(resuscitationSessions).where(eq(resuscitationSessions.id, id));
  }

  // Intervention operations
  async logIntervention(intervention: InsertIntervention): Promise<Intervention> {
    const [newIntervention] = await db
      .insert(interventions)
      .values(intervention)
      .returning();
    return newIntervention;
  }

  async getSessionInterventions(sessionId: number): Promise<Intervention[]> {
    return await db
      .select()
      .from(interventions)
      .where(eq(interventions.sessionId, sessionId))
      .orderBy(interventions.timestamp);
  }

  // Reversible causes operations
  async updateReversibleCauses(sessionId: number, causes: InsertReversibleCauses): Promise<ReversibleCauses> {
    const existing = await this.getReversibleCauses(sessionId);

    if (existing) {
      const [updated] = await db
        .update(reversibleCauses)
        .set({
          ...causes,
          updatedAt: new Date(),
        })
        .where(eq(reversibleCauses.sessionId, sessionId))
        .returning();
      return updated;
    } else {
      const [newCauses] = await db
        .insert(reversibleCauses)
        .values(causes)
        .returning();
      return newCauses;
    }
  }

  async getReversibleCauses(sessionId: number): Promise<ReversibleCauses | undefined> {
    const [causes] = await db
      .select()
      .from(reversibleCauses)
      .where(eq(reversibleCauses.sessionId, sessionId));
    return causes;
  }

  // Drug dose operations
  async logDrugDose(drugDose: InsertDrugDose): Promise<DrugDose> {
    const [newDrugDose] = await db
      .insert(drugDoses)
      .values(drugDose)
      .returning();
    return newDrugDose;
  }

  async getSessionDrugDoses(sessionId: number): Promise<DrugDose[]> {
    return await db
      .select()
      .from(drugDoses)
      .where(eq(drugDoses.sessionId, sessionId))
      .orderBy(drugDoses.timestamp);
  }

  // Notification operations
  async createNotification(notification: InsertNotification): Promise<Notification> {
    console.log(`Creating notification for user ${notification.userId}:`, {
      type: notification.type,
      title: notification.title,
      message: notification.message.substring(0, 50) + '...'
    });
    
    const [newNotification] = await db
      .insert(notifications)
      .values(notification)
      .returning();
    
    console.log(`Notification created successfully with ID ${newNotification.id}`);
    return newNotification;
  }

  async getUserNotifications(userId: string, limit: number = 10): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt))
      .limit(limit);
  }

  async getUnreadNotificationCount(userId: string): Promise<number> {
    const result = await db
      .select({ count: sql<number>`count(*)` })
      .from(notifications)
      .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
    return result[0]?.count || 0;
  }

  async markNotificationAsRead(notificationId: number): Promise<Notification> {
    const [notification] = await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, notificationId))
      .returning();
    return notification;
  }

  async markAllNotificationsAsRead(userId: string): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.userId, userId));
  }

  async deleteNotification(notificationId: number): Promise<void> {
    await db
      .delete(notifications)
      .where(eq(notifications.id, notificationId));
  }

  async clearAllUserNotifications(userId: string): Promise<void> {
    await db
      .delete(notifications)
      .where(eq(notifications.userId, userId));
  }

  // Team member operations
  async addTeamMember(teamMember: InsertResusTeamMember): Promise<ResusTeamMember> {
    const [newMember] = await db
      .insert(resusTeamMembers)
      .values(teamMember)
      .returning();
    return newMember;
  }

  async getSessionTeamMembers(sessionId: number): Promise<ResusTeamMember[]> {
    return await db
      .select()
      .from(resusTeamMembers)
      .where(eq(resusTeamMembers.sessionId, sessionId))
      .orderBy(resusTeamMembers.createdAt);
  }

  async removeTeamMember(id: number): Promise<void> {
    await db
      .delete(resusTeamMembers)
      .where(eq(resusTeamMembers.id, id));
  }

  async searchUsersByName(query: string, limit: number = 10): Promise<User[]> {
    const searchTerm = `%${query.toLowerCase()}%`;
    return await db
      .select()
      .from(users)
      .where(
        sql`LOWER(${users.firstName}) LIKE ${searchTerm} OR LOWER(${users.lastName}) LIKE ${searchTerm} OR LOWER(CONCAT(${users.firstName}, ' ', ${users.lastName})) LIKE ${searchTerm}`
      )
      .limit(limit);
  }

  // Unauthorized participation report operations
  async createUnauthorizedParticipationReport(report: InsertUnauthorizedParticipationReport): Promise<UnauthorizedParticipationReport> {
    const [newReport] = await db
      .insert(unauthorizedParticipationReports)
      .values(report)
      .returning();
    return newReport;
  }

  async getUnauthorizedParticipationReports(limit: number = 50): Promise<UnauthorizedParticipationReport[]> {
    return await db
      .select()
      .from(unauthorizedParticipationReports)
      .orderBy(desc(unauthorizedParticipationReports.createdAt))
      .limit(limit);
  }

  async updateUnauthorizedParticipationReportStatus(
    id: number, 
    status: string, 
    adminNotes?: string, 
    reviewedBy?: string
  ): Promise<UnauthorizedParticipationReport> {
    const [updatedReport] = await db
      .update(unauthorizedParticipationReports)
      .set({
        status,
        adminNotes,
        reviewedBy,
        reviewedAt: new Date(),
      })
      .where(eq(unauthorizedParticipationReports.id, id))
      .returning();
    return updatedReport;
  }

  // Chat system operations
  async createConversation(conversation: InsertChatConversation): Promise<ChatConversation> {
    const [newConversation] = await db
      .insert(chatConversations)
      .values(conversation)
      .returning();
    return newConversation;
  }

  async getConversation(id: number): Promise<ChatConversation | undefined> {
    const [conversation] = await db
      .select()
      .from(chatConversations)
      .where(eq(chatConversations.id, id));
    return conversation;
  }

  async getUserConversations(userId: string): Promise<ChatConversation[]> {
    return await db
      .select({
        id: chatConversations.id,
        title: chatConversations.title,
        type: chatConversations.type,
        createdBy: chatConversations.createdBy,
        relatedReportId: chatConversations.relatedReportId,
        metadata: chatConversations.metadata,
        createdAt: chatConversations.createdAt,
        updatedAt: chatConversations.updatedAt,
      })
      .from(chatConversations)
      .innerJoin(chatParticipants, eq(chatParticipants.conversationId, chatConversations.id))
      .where(eq(chatParticipants.userId, userId))
      .orderBy(desc(chatConversations.updatedAt));
  }

  async addParticipant(participant: InsertChatParticipant): Promise<ChatParticipant> {
    const [newParticipant] = await db
      .insert(chatParticipants)
      .values(participant)
      .returning();
    return newParticipant;
  }

  async removeParticipant(conversationId: number, userId: string): Promise<void> {
    await db
      .delete(chatParticipants)
      .where(
        and(
          eq(chatParticipants.conversationId, conversationId),
          eq(chatParticipants.userId, userId)
        )
      );
  }

  async getConversationParticipants(conversationId: number): Promise<ChatParticipant[]> {
    return await db
      .select()
      .from(chatParticipants)
      .where(eq(chatParticipants.conversationId, conversationId))
      .orderBy(chatParticipants.joinedAt);
  }

  async sendMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [newMessage] = await db
      .insert(chatMessages)
      .values(message)
      .returning();
    
    // Update conversation timestamp
    await db
      .update(chatConversations)
      .set({ updatedAt: new Date() })
      .where(eq(chatConversations.id, message.conversationId));

    return newMessage;
  }

  async getConversationMessages(conversationId: number, limit: number = 50): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.conversationId, conversationId))
      .orderBy(desc(chatMessages.createdAt))
      .limit(limit);
  }

  async markMessagesAsRead(conversationId: number, userId: string): Promise<void> {
    await db
      .update(chatParticipants)
      .set({ lastReadAt: new Date() })
      .where(
        and(
          eq(chatParticipants.conversationId, conversationId),
          eq(chatParticipants.userId, userId)
        )
      );
  }

  async getUnreadMessageCount(userId: string): Promise<number> {
    const result = await db
      .select({ count: sql<number>`count(*)` })
      .from(chatMessages)
      .innerJoin(chatParticipants, eq(chatParticipants.conversationId, chatMessages.conversationId))
      .where(
        and(
          eq(chatParticipants.userId, userId),
          sql`${chatMessages.createdAt} > COALESCE(${chatParticipants.lastReadAt}, '1970-01-01')`
        )
      );

    return result[0]?.count || 0;
  }

  async markMessageAsDelivered(messageId: number): Promise<void> {
    await db.update(chatMessages)
      .set({ deliveredAt: new Date() })
      .where(eq(chatMessages.id, messageId));
  }

  async markMessageAsRead(messageId: number, userId: string): Promise<void> {
    // Update message read timestamp
    await db.update(chatMessages)
      .set({ readAt: new Date() })
      .where(eq(chatMessages.id, messageId));

    // Insert read receipt
    await db.insert(messageReadReceipts)
      .values({
        messageId,
        userId
      })
      .onConflictDoNothing();
  }

  async getMessageReadReceipts(messageId: number): Promise<MessageReadReceipt[]> {
    return await db.select()
      .from(messageReadReceipts)
      .where(eq(messageReadReceipts.messageId, messageId));
  }

  async resolveUnauthorizedParticipation(reportId: number, action: 'keep' | 'remove', adminNotes: string, reviewedBy: string): Promise<void> {
    console.log(`Storage function called with reviewedBy: ${reviewedBy}`);
    
    const report = await db.select()
      .from(unauthorizedParticipationReports)
      .where(eq(unauthorizedParticipationReports.id, reportId))
      .limit(1);

    if (!report[0]) throw new Error('Report not found');

    console.log(`About to update report with reviewedBy: ${reviewedBy}`);
    
    // Update report status
    await db.update(unauthorizedParticipationReports)
      .set({
        status: 'resolved',
        adminNotes: `${adminNotes}\n\nAction taken: ${action === 'keep' ? 'Team member kept in resuscitation records' : 'Team member removed from resuscitation records'}`,
        reviewedBy
      })
      .where(eq(unauthorizedParticipationReports.id, reportId));

    // Get the session to find who reported and who was reported
    const session = await db.select()
      .from(resuscitationSessions)
      .where(eq(resuscitationSessions.id, report[0].sessionId))
      .limit(1);

    if (session[0]) {
      if (action === 'remove' && report[0].teamMemberId) {
        // Remove the team member from session records
        await this.removeTeamMemberFromSession(report[0].sessionId, report[0].teamMemberId);
        
        // Notify session leader that team member was removed
        await this.createNotification({
          userId: session[0].userId,
          title: 'Team Member Removed from Session',
          message: `Admin has reviewed the security report for session ${report[0].sessionId} and determined that a team member was incorrectly added. They have been removed from the resuscitation records to maintain accurate clinical documentation.`,
          type: 'team_member_removed'
        });

        // Get the team member details to notify them
        if (report[0].teamMemberId) {
          const teamMember = await db.select()
            .from(resusTeamMembers)
            .where(eq(resusTeamMembers.id, report[0].teamMemberId))
            .limit(1);

          if (teamMember[0] && teamMember[0].userId) {
            await this.createNotification({
              userId: teamMember[0].userId,
              title: 'Removed from Resuscitation Records',
              message: `Following an admin investigation, you have been removed from the records of resuscitation session ${report[0].sessionId} as your participation could not be verified.`,
              type: 'participation_removed'
            });
          }
        }
      } else {
        // Notify session leader that team member was kept
        await this.createNotification({
          userId: session[0].userId,
          title: 'Security Report Resolved',
          message: `Admin has reviewed the security report for session ${report[0].sessionId} and confirmed that all team members were correctly recorded. No changes have been made to the session records.`,
          type: 'security_resolved'
        });
      }

      // Notify the person who made the report
      if (report[0].reportedByUserId) {
        await this.createNotification({
          userId: report[0].reportedByUserId,
          title: 'Security Report Update',
          message: `Your security report for session ${report[0].sessionId} has been reviewed by admin. Decision: ${action === 'keep' ? 'Team member participation confirmed' : 'Team member removed from records'}.`,
          type: 'report_resolved'
        });
      }
    }
  }

  async removeTeamMemberFromSession(sessionId: number, teamMemberId: number): Promise<void> {
    await db.delete(resusTeamMembers)
      .where(
        and(
          eq(resusTeamMembers.sessionId, sessionId),
          eq(resusTeamMembers.id, teamMemberId)
        )
      );
  }

  async isSessionDisputed(sessionId: number): Promise<boolean> {
    const reports = await db.select()
      .from(unauthorizedParticipationReports)
      .where(
        and(
          eq(unauthorizedParticipationReports.sessionId, sessionId),
          eq(unauthorizedParticipationReports.status, 'pending')
        )
      );
    return reports.length > 0;
  }

  async getAdminUsers(): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, "Administrator"));
  }

  // Chat system implementations
  async createConversation(conversation: InsertChatConversation): Promise<ChatConversation> {
    const [newConversation] = await db
      .insert(chatConversations)
      .values(conversation)
      .returning();
    return newConversation;
  }

  async getConversation(id: number): Promise<ChatConversation | undefined> {
    const [conversation] = await db
      .select()
      .from(chatConversations)
      .where(eq(chatConversations.id, id));
    return conversation;
  }

  async getUserConversations(userId: string): Promise<ChatConversation[]> {
    return await db
      .select({
        id: chatConversations.id,
        title: chatConversations.title,
        type: chatConversations.type,
        createdBy: chatConversations.createdBy,
        relatedReportId: chatConversations.relatedReportId,
        metadata: chatConversations.metadata,
        createdAt: chatConversations.createdAt,
        updatedAt: chatConversations.updatedAt,
      })
      .from(chatConversations)
      .innerJoin(chatParticipants, eq(chatParticipants.conversationId, chatConversations.id))
      .where(eq(chatParticipants.userId, userId))
      .orderBy(desc(chatConversations.updatedAt));
  }

  async addParticipant(participant: InsertChatParticipant): Promise<ChatParticipant> {
    const [newParticipant] = await db
      .insert(chatParticipants)
      .values(participant)
      .returning();
    return newParticipant;
  }

  async removeParticipant(conversationId: number, userId: string): Promise<void> {
    await db
      .delete(chatParticipants)
      .where(
        and(
          eq(chatParticipants.conversationId, conversationId),
          eq(chatParticipants.userId, userId)
        )
      );
  }

  async getConversationParticipants(conversationId: number): Promise<ChatParticipant[]> {
    return await db
      .select()
      .from(chatParticipants)
      .where(eq(chatParticipants.conversationId, conversationId));
  }

  async sendMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [newMessage] = await db
      .insert(chatMessages)
      .values(message)
      .returning();
    
    // Update conversation updatedAt timestamp
    await db
      .update(chatConversations)
      .set({ updatedAt: new Date() })
      .where(eq(chatConversations.id, message.conversationId));
    
    return newMessage;
  }

  async getConversationMessages(conversationId: number, limit: number = 50): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.conversationId, conversationId))
      .orderBy(desc(chatMessages.createdAt))
      .limit(limit);
  }

  async markMessagesAsRead(conversationId: number, userId: string): Promise<void> {
    await db
      .update(chatParticipants)
      .set({ lastReadAt: new Date() })
      .where(
        and(
          eq(chatParticipants.conversationId, conversationId),
          eq(chatParticipants.userId, userId)
        )
      );
  }

  async getUnreadMessageCount(userId: string): Promise<number> {
    const conversations = await this.getUserConversations(userId);
    let unreadCount = 0;
    
    for (const conversation of conversations) {
      const participant = await db
        .select()
        .from(chatParticipants)
        .where(
          and(
            eq(chatParticipants.conversationId, conversation.id),
            eq(chatParticipants.userId, userId)
          )
        )
        .limit(1);
      
      if (participant.length > 0) {
        const lastReadAt = participant[0].lastReadAt;
        const unreadMessages = await db
          .select({ count: count() })
          .from(chatMessages)
          .where(
            and(
              eq(chatMessages.conversationId, conversation.id),
              lastReadAt ? gt(chatMessages.createdAt, lastReadAt) : undefined
            )
          );
        
        unreadCount += unreadMessages[0].count;
      }
    }
    
    return unreadCount;
  }

  async markMessageAsDelivered(messageId: number): Promise<void> {
    await db
      .update(chatMessages)
      .set({ deliveredAt: new Date() })
      .where(eq(chatMessages.id, messageId));
  }

  async markMessageAsRead(messageId: number, userId: string): Promise<void> {
    const [receipt] = await db
      .insert(messageReadReceipts)
      .values({
        messageId,
        userId,
      })
      .onConflictDoNothing()
      .returning();
  }

  async getMessageReadReceipts(messageId: number): Promise<MessageReadReceipt[]> {
    return await db
      .select()
      .from(messageReadReceipts)
      .where(eq(messageReadReceipts.messageId, messageId));
  }
}

export const storage = new DatabaseStorage();
