import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import express from "express";
import Stripe from "stripe";
import multer from "multer";
import sharp from "sharp";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { db } from "./db";
import { users as usersTable, chatConversations, chatParticipants, chatMessages } from "@shared/schema";
import { eq, sql, desc, and } from "drizzle-orm";
import { setupAuth, requireAuth, hashPassword, comparePasswords } from "./auth-simple";
import { registerUserSchema, loginUserSchema } from "@shared/schema";
import { insertResuscitationSessionSchema, insertInterventionSchema, insertReversibleCausesSchema, insertDrugDoseSchema } from "@shared/schema";
import { videoGenerator } from "./video-generator";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("Missing required Stripe secret: STRIPE_SECRET_KEY");
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16",
});

// Create uploads directory if it doesn't exist and ensure it's persistent
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
  console.log('Created uploads directory:', uploadsDir);
  
  // Create .gitkeep file to ensure directory persists in version control
  const gitkeepPath = path.join(uploadsDir, '.gitkeep');
  fs.writeFileSync(gitkeepPath, '');
  console.log('Created .gitkeep file for uploads directory persistence');
}

// Ensure the directory is writable
try {
  fs.accessSync(uploadsDir, fs.constants.W_OK);
  console.log('Uploads directory is writable:', uploadsDir);
  
  // List existing files for debugging
  const existingFiles = fs.readdirSync(uploadsDir);
  console.log('Existing files in uploads directory:', existingFiles.length, 'files');
  
  // Check for existing profile images
  const profileImages = existingFiles.filter(file => file.startsWith('profile_'));
  console.log('Existing profile images found:', profileImages.length);
  
} catch (error) {
  console.error('Uploads directory is not writable:', error);
  // Try to fix permissions
  try {
    fs.chmodSync(uploadsDir, 0o755);
    console.log('Fixed uploads directory permissions');
  } catch (chmodError) {
    console.error('Could not fix uploads directory permissions:', chmodError);
  }
}

// Configure multer for file uploads with disk storage
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, uploadsDir);
    },
    filename: (req, file, cb) => {
      const user = req.user as any;
      const timestamp = Date.now();
      const ext = path.extname(file.originalname);
      const filename = `profile_${user.id}_${timestamp}${ext}`;
      cb(null, filename);
    }
  }),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
    fieldSize: 10 * 1024 * 1024, // 10MB field size
    fields: 10,
    files: 1,
    parts: 20
  },
  fileFilter: (req, file, cb) => {
    console.log("File filter - mimetype:", file.mimetype);
    console.log("File filter - originalname:", file.originalname);
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed!'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  setupAuth(app);

  // SEO routes - serve sitemap.xml and robots.txt with proper content type
  app.get('/sitemap.xml', (req, res) => {
    res.setHeader('Content-Type', 'application/xml');
    res.sendFile(path.join(process.cwd(), 'public', 'sitemap.xml'));
  });

  app.get('/robots.txt', (req, res) => {
    res.setHeader('Content-Type', 'text/plain');
    res.sendFile(path.join(process.cwd(), 'public', 'robots.txt'));
  });

  app.get('/google-site-verification.html', (req, res) => {
    res.setHeader('Content-Type', 'text/html');
    res.sendFile(path.join(process.cwd(), 'public', 'google-site-verification.html'));
  });

  // Domain test endpoint for debugging HTTP forwarding
  app.get("/api/domain-test", (req, res) => {
    console.log("=== DOMAIN TEST ENDPOINT ===");
    console.log("Host:", req.get('host'));
    console.log("Protocol:", req.protocol);
    console.log("X-Forwarded-Proto:", req.get('x-forwarded-proto'));
    console.log("X-Forwarded-Host:", req.get('x-forwarded-host'));
    
    const isCustomDomain = req.get('host')?.includes('resusmgr.co.uk');
    
    res.json({ 
      success: true,
      message: "Domain test successful",
      host: req.get('host'),
      protocol: req.protocol,
      isCustomDomain,
      timestamp: new Date().toISOString()
    });
  });

  // Create some sample notifications for testing (you can remove this later)
  app.post("/api/test/create-notifications", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      
      // Create a welcome notification
      await storage.createNotification({
        userId,
        type: "welcome",
        title: "Welcome to ResusMGR!",
        message: "Your account has been successfully set up. You're ready to start managing resuscitation protocols.",
        isRead: false,
        sessionId: null
      });

      // Create a session completion notification
      await storage.createNotification({
        userId,
        type: "session_completed",
        title: "BLS Protocol Completed",
        message: "Resuscitation session completed successfully. Duration: 15 minutes. Outcome: ROSC achieved.",
        isRead: false,
        sessionId: null
      });

      // Create a critical intervention notification
      await storage.createNotification({
        userId,
        type: "critical_intervention",
        title: "Adrenaline Administered",
        message: "1mg Adrenaline given IV at 12:34. Next dose due in 3-5 minutes.",
        isRead: false,
        sessionId: null
      });

      res.json({ message: "Test notifications created successfully" });
    } catch (error: any) {
      console.error("Error creating test notifications:", error);
      res.status(500).json({ message: error.message });
    }
  });
  
  // Serve uploaded images
  app.use('/uploads', express.static(uploadsDir));

  // Public user count endpoint
  app.get("/api/public/user-count", async (req, res) => {
    try {
      const count = await storage.getUserCount();
      res.json({ count });
    } catch (error) {
      console.error("Error getting user count:", error);
      res.status(500).json({ message: "Failed to get user count" });
    }
  });



  // Password reset endpoint (public)
  app.post("/api/reset-password", async (req, res) => {
    try {
      const { email, firstName, lastName, recoveryPasscode, newPassword } = req.body;
      
      if (!email || !firstName || !lastName || !recoveryPasscode || !newPassword) {
        return res.status(400).send("Email, first name, last name, recovery passcode, and new password are required");
      }

      // Find user by email
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(400).send("Invalid credentials provided");
      }

      // Check if names match
      if (user.firstName !== firstName || user.lastName !== lastName) {
        return res.status(400).send("Invalid credentials provided");
      }

      // Check if recovery passcode matches
      if (user.recoveryPasscode !== recoveryPasscode) {
        return res.status(400).send("Invalid credentials provided");
      }

      // Hash the new password and update
      const hashedPassword = await hashPassword(newPassword);
      await storage.updateUserPassword(user.id, hashedPassword);

      res.json({ message: "Password reset successful" });
    } catch (error) {
      console.error("Error resetting password:", error);
      res.status(500).send("Failed to reset password");
    }
  });

  // Public subscription cancellation endpoint
  app.post("/api/cancel-subscription-public", async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).send("Email address is required");
      }

      // Find user by email
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(404).send("No account found with this email address");
      }

      // Check if user has a Stripe subscription
      if (!user.stripeCustomerId || !user.stripeSubscriptionId) {
        return res.status(404).send("No active subscription found for this email address");
      }

      // Cancel the subscription in Stripe
      try {
        await stripe.subscriptions.cancel(user.stripeSubscriptionId);
        
        // Update user subscription status in database
        await storage.updateUserSubscriptionStatus(parseInt(user.id), false);
        
        res.json({ 
          message: "Subscription cancelled successfully. You'll retain access until your current billing period ends." 
        });
      } catch (stripeError: any) {
        console.error("Stripe cancellation error:", stripeError);
        if (stripeError.code === 'resource_missing') {
          return res.status(404).send("Subscription not found or already cancelled");
        }
        throw stripeError;
      }
    } catch (error) {
      console.error("Error cancelling subscription:", error);
      res.status(500).send("Failed to cancel subscription");
    }
  });

  // Protected routes
  app.get("/api/sessions", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const sessions = await storage.getUserSessions(userId, 10);
      res.json(sessions);
    } catch (error) {
      console.error("Error fetching sessions:", error);
      res.status(500).json({ message: "Failed to fetch sessions" });
    }
  });

  app.get("/api/sessions/active", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const activeSession = await storage.getActiveSession(userId);
      res.json(activeSession);
    } catch (error) {
      console.error("Error fetching active session:", error);
      res.status(500).json({ message: "Failed to fetch active session" });
    }
  });

  app.post("/api/sessions", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const { protocolType, patientType, customSessionId } = req.body;
      
      const sessionData = {
        userId,
        protocolType,
        patientType,
        customSessionId: customSessionId || null,
        duration: null,
        outcome: null,
        notes: null
      };

      const session = await storage.createResuscitationSession(sessionData);
      res.status(201).json(session);
    } catch (error) {
      console.error("Error creating session:", error);
      res.status(500).json({ message: "Failed to create session" });
    }
  });

  // Update session custom ID
  app.patch("/api/sessions/:id/custom-id", requireAuth, async (req: any, res) => {
    try {
      const sessionId = parseInt(req.params.id);
      const { customSessionId } = req.body;
      
      const updatedSession = await storage.updateResuscitationSession(sessionId, {
        customSessionId: customSessionId || null
      });
      res.json(updatedSession);
    } catch (error) {
      console.error("Error updating session custom ID:", error);
      res.status(500).json({ message: "Failed to update session custom ID" });
    }
  });

  // Disclaimer acceptance
  app.post("/api/accept-disclaimer", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.acceptDisclaimer(userId);
      res.json(user);
    } catch (error) {
      console.error("Error accepting disclaimer:", error);
      res.status(500).json({ message: "Failed to accept disclaimer" });
    }
  });

  // Subscription management
  app.post("/api/get-or-create-subscription", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      let user = await storage.getUser(userId);

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.stripeSubscriptionId) {
        const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
        const invoice = await stripe.invoices.retrieve(subscription.latest_invoice as string, {
          expand: ["payment_intent"],
        });

        res.json({
          subscriptionId: subscription.id,
          clientSecret: (invoice.payment_intent as any)?.client_secret,
        });
        return;
      }

      if (!user.email) {
        throw new Error("No user email on file");
      }

      const customer = await stripe.customers.create({
        email: user.email,
        name: `${user.firstName || ""} ${user.lastName || ""}`.trim(),
      });

      // Use a predefined price ID for consistency (you'll need to create this in Stripe dashboard)
      // For now, create a price dynamically - in production you should use a fixed price ID
      let priceId = process.env.STRIPE_PRICE_ID;
      
      if (!priceId) {
        // Create price dynamically if not configured
        const product = await stripe.products.create({
          name: "ResusMGR Professional",
          description: "Professional resuscitation management tools",
        });

        const price = await stripe.prices.create({
          unit_amount: 199, // £1.99 in pence
          currency: "gbp",
          recurring: { interval: "month" },
          product: product.id,
        });
        priceId = price.id;
      }

      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [{ price: priceId }],
        payment_behavior: "default_incomplete",
        expand: ["latest_invoice.payment_intent"],
        trial_period_days: 0, // No trial - immediate payment required
        // Subscriptions automatically renew monthly unless cancelled
        cancel_at_period_end: false, // Ensure automatic renewal
      });

      await storage.updateUserStripeInfo(userId, customer.id, subscription.id);

      // Note: Pro welcome notification will be created by Stripe webhook after successful payment
      // Not creating notification here to avoid duplicate notifications for unpaid subscriptions

      const invoice = subscription.latest_invoice as any;
      res.json({
        subscriptionId: subscription.id,
        clientSecret: invoice.payment_intent.client_secret,
      });
    } catch (error: any) {
      console.error("Subscription error:", error);
      res.status(400).json({ error: { message: error.message } });
    }
  });

  // Cancel subscription at period end
  app.post("/api/cancel-subscription", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const user = await storage.getUser(userId);

      if (!user?.stripeSubscriptionId) {
        return res.status(404).json({ message: "No active subscription found" });
      }

      // Cancel at period end (user keeps access until current billing period ends)
      const subscription = await stripe.subscriptions.update(user.stripeSubscriptionId, {
        cancel_at_period_end: true,
      });

      // Create cancellation notification
      try {
        const notificationData = {
          userId,
          title: "Subscription Cancelled",
          message: `Your ResusMGR Pro subscription will end on ${new Date(subscription.current_period_end * 1000).toLocaleDateString()}. You'll retain access until then.`,
          type: "subscription_cancelled" as const,
          isRead: false
        };
        await storage.createNotification(notificationData);
      } catch (notificationError) {
        console.error("Error creating cancellation notification:", notificationError);
      }

      res.json({
        status: subscription.status,
        currentPeriodEnd: new Date(subscription.current_period_end * 1000).toISOString(),
        cancelAtPeriodEnd: subscription.cancel_at_period_end,
      });
    } catch (error: any) {
      console.error("Cancel subscription error:", error);
      res.status(400).json({ error: { message: error.message } });
    }
  });

  // Reactivate cancelled subscription
  app.post("/api/reactivate-subscription", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const user = await storage.getUser(userId);

      if (!user?.stripeSubscriptionId) {
        return res.status(404).json({ message: "No subscription found" });
      }

      // Remove cancellation (reactivate automatic renewal)
      const subscription = await stripe.subscriptions.update(user.stripeSubscriptionId, {
        cancel_at_period_end: false,
      });

      // Create reactivation notification
      try {
        const notificationData = {
          userId,
          title: "Subscription Reactivated",
          message: "Your ResusMGR Pro subscription has been reactivated and will continue automatically.",
          type: "subscription_reactivated" as const,
          isRead: false
        };
        await storage.createNotification(notificationData);
      } catch (notificationError) {
        console.error("Error creating reactivation notification:", notificationError);
      }

      res.json({
        status: subscription.status,
        currentPeriodEnd: new Date(subscription.current_period_end * 1000).toISOString(),
        cancelAtPeriodEnd: subscription.cancel_at_period_end,
      });
    } catch (error: any) {
      console.error("Reactivate subscription error:", error);
      res.status(400).json({ error: { message: error.message } });
    }
  });

  // Emergency subscription cancellation (for users who lost account access)
  app.post("/api/emergency-cancel-subscription", async (req, res) => {
    try {
      const { email, last4Digits, expiryMonth, expiryYear } = req.body;

      if (!email || !last4Digits || !expiryMonth || !expiryYear) {
        return res.status(400).json({ 
          message: "Email address and card details (last 4 digits, expiry month/year) are required" 
        });
      }

      // Find user by email
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(404).json({ message: "No account found with this email address" });
      }

      if (!user.stripeCustomerId || !user.stripeSubscriptionId) {
        return res.status(404).json({ message: "No active subscription found for this account" });
      }

      // Get customer's payment methods to verify card details
      const customer = await stripe.customers.retrieve(user.stripeCustomerId);
      const paymentMethods = await stripe.paymentMethods.list({
        customer: user.stripeCustomerId,
        type: 'card',
      });

      // Verify the provided card details match any stored payment method
      const cardMatch = paymentMethods.data.find(pm => {
        const card = pm.card;
        return card &&
               card.last4 === last4Digits &&
               card.exp_month === parseInt(expiryMonth) &&
               card.exp_year === parseInt(expiryYear);
      });

      if (!cardMatch) {
        return res.status(400).json({ 
          message: "Card details do not match any payment method on file for this account" 
        });
      }

      // Cancel the subscription immediately (not at period end for emergency cancellation)
      const subscription = await stripe.subscriptions.cancel(user.stripeSubscriptionId);

      // Update user subscription status
      await storage.updateUserSubscriptionStatus(parseInt(user.id), false);

      // Create emergency cancellation notification
      try {
        const notificationData = {
          userId: user.id,
          title: "Emergency Subscription Cancellation",
          message: "Your ResusMGR Pro subscription has been cancelled via emergency cancellation. Contact support if this was not requested by you.",
          type: "subscription_emergency_cancelled" as const,
          isRead: false
        };
        await storage.createNotification(notificationData);
      } catch (notificationError) {
        console.error("Error creating emergency cancellation notification:", notificationError);
      }

      res.json({
        message: "Subscription successfully cancelled",
        status: subscription.status,
        cancelledAt: new Date().toISOString(),
      });

    } catch (error: any) {
      console.error("Emergency cancel subscription error:", error);
      res.status(500).json({ error: { message: "Failed to process emergency cancellation" } });
    }
  });

  // Get current subscription details
  app.get("/api/subscription", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const user = await storage.getUser(userId);

      // First check if user has admin-granted Pro access (database subscription)
      if (user?.subscriptionActive) {
        // Return admin-granted Pro access status
        return res.json({
          status: "active",
          currentPeriodEnd: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(), // 1 year from now
          cancelAtPeriodEnd: false,
          customerId: null,
          subscriptionId: "admin-granted",
          adminGranted: true
        });
      }

      // If no admin-granted access, check Stripe subscription
      if (!user?.stripeCustomerId || !user?.stripeSubscriptionId) {
        return res.json(null);
      }

      const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
      
      // Only return subscription data if it's actually paid/active
      if (subscription.status === 'active' || subscription.status === 'trialing') {
        res.json({
          status: subscription.status,
          currentPeriodEnd: new Date(subscription.current_period_end * 1000).toISOString(),
          cancelAtPeriodEnd: subscription.cancel_at_period_end,
          customerId: subscription.customer,
          subscriptionId: subscription.id,
          adminGranted: false
        });
      } else {
        // If subscription exists but isn't paid (incomplete, unpaid, etc.), treat as no subscription
        res.json(null);
      }
    } catch (error: any) {
      console.error("Get subscription error:", error);
      res.status(500).json({ error: { message: error.message } });
    }
  });

  // Get billing history (invoices)
  app.get("/api/subscription/invoices", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const user = await storage.getUser(userId);

      if (!user?.stripeCustomerId) {
        return res.json([]);
      }

      const invoices = await stripe.invoices.list({
        customer: user.stripeCustomerId,
        limit: 20,
      });

      const invoiceData = invoices.data.map(invoice => ({
        id: invoice.id,
        amount: invoice.amount_paid,
        currency: invoice.currency,
        status: invoice.status,
        created: new Date(invoice.created * 1000).toISOString(),
      }));

      res.json(invoiceData);
    } catch (error: any) {
      console.error("Get invoices error:", error);
      res.status(500).json({ error: { message: error.message } });
    }
  });

  // Cancel subscription
  app.post("/api/subscription/cancel", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const user = await storage.getUser(userId);

      if (!user?.stripeSubscriptionId) {
        return res.status(400).json({ error: { message: "No active subscription found" } });
      }

      // Cancel at period end (don't terminate immediately)
      const subscription = await stripe.subscriptions.update(user.stripeSubscriptionId, {
        cancel_at_period_end: true,
      });

      // Create subscription cancellation notification
      try {
        const notificationData = {
          userId,
          title: "Subscription Cancelled",
          message: `Your ResusMGR Pro subscription has been cancelled and will end on ${new Date(subscription.current_period_end * 1000).toLocaleDateString()}. You'll continue to have access to Pro features until then.`,
          type: "subscription_cancelled" as const,
          isRead: false
        };
        await storage.createNotification(notificationData);
      } catch (notificationError) {
        console.error("Error creating cancellation notification:", notificationError);
      }

      res.json({ 
        message: "Subscription will be cancelled at the end of the current billing period",
        subscription: {
          id: subscription.id,
          cancelAtPeriodEnd: subscription.cancel_at_period_end,
          currentPeriodEnd: new Date(subscription.current_period_end * 1000).toISOString(),
        }
      });
    } catch (error: any) {
      console.error("Cancel subscription error:", error);
      res.status(500).json({ error: { message: error.message } });
    }
  });

  // Profile management routes
  app.get("/api/profile", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Return user profile without sensitive data
      const { password, ...profileData } = user;
      res.json(profileData);
    } catch (error: any) {
      console.error("Get profile error:", error);
      res.status(500).json({ error: { message: error.message } });
    }
  });

  app.put("/api/profile", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const updateData = req.body;

      // Remove sensitive fields that shouldn't be updated via this endpoint
      delete updateData.password;
      delete updateData.id;
      delete updateData.stripeCustomerId;
      delete updateData.stripeSubscriptionId;

      const updatedUser = await storage.updateUser(userId, updateData);
      const { password, ...profileData } = updatedUser;
      
      res.json(profileData);
    } catch (error: any) {
      console.error("Update profile error:", error);
      res.status(500).json({ error: { message: error.message } });
    }
  });

  app.put("/api/profile/password", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const { currentPassword, newPassword } = req.body;

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Verify current password
      const isCurrentPasswordValid = await comparePasswords(currentPassword, user.password!);
      if (!isCurrentPasswordValid) {
        return res.status(400).json({ message: "Current password is incorrect" });
      }

      // Hash new password and update
      const hashedNewPassword = await hashPassword(newPassword);
      await storage.updateUser(userId, { password: hashedNewPassword });

      res.json({ message: "Password updated successfully" });
    } catch (error: any) {
      console.error("Update password error:", error);
      res.status(500).json({ error: { message: error.message } });
    }
  });

  app.patch("/api/update-recovery-code", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const { recoveryPasscode } = req.body;

      // Validate recovery passcode format
      if (!recoveryPasscode || typeof recoveryPasscode !== 'string' || recoveryPasscode.length !== 10 || !/^\d{10}$/.test(recoveryPasscode)) {
        return res.status(400).json({ message: "Recovery passcode must be exactly 10 digits" });
      }

      const updatedUser = await storage.updateUser(userId, { recoveryPasscode });
      const { password, ...profileData } = updatedUser;
      
      // Create security notification for recovery passcode change
      const notificationUserId = req.user.claims?.sub || req.user.id;
      const notificationData = {
        userId: notificationUserId,
        title: "Recovery Passcode Updated",
        message: "Your 10-digit recovery passcode has been successfully changed. Keep this secure as it's needed for password recovery if you're locked out.",
        type: "security" as const,
        isRead: false
      };
      
      await storage.createNotification(notificationData);
      
      res.json({ success: true, user: profileData });
    } catch (error: any) {
      console.error("Update recovery code error:", error);
      res.status(500).json({ error: { message: error.message } });
    }
  });

  // Update password for logged-in users
  app.put("/api/profile/password", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const { currentPassword, newPassword } = req.body;

      // Validate input
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: "Current password and new password are required" });
      }

      if (newPassword.length < 8) {
        return res.status(400).json({ message: "New password must be at least 8 characters" });
      }

      // Get current user
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Verify current password
      const { comparePasswords } = require("./auth-simple");
      const isCurrentPasswordValid = await comparePasswords(currentPassword, user.password);
      if (!isCurrentPasswordValid) {
        return res.status(400).json({ message: "Current password is incorrect" });
      }

      // Hash new password
      const { hashPassword } = require("./auth-simple");
      const hashedNewPassword = await hashPassword(newPassword);

      // Update password
      await storage.updateUserPassword(userId, hashedNewPassword);
      
      // Create security notification for password change
      try {
        // Use the correct user ID format for notifications
        const notificationUserId = req.user.claims?.sub || req.user.id;
        const notificationData = {
          userId: notificationUserId,
          title: "Password Changed",
          message: "Your account password has been successfully updated. If you didn't make this change, please contact support immediately.",
          type: "security" as const,
          isRead: false
        };
        
        console.log("Creating notification for userId:", notificationUserId);
        await storage.createNotification(notificationData);
        console.log("Notification created successfully");
      } catch (notificationError) {
        console.error("Error creating password change notification:", notificationError);
      }
      
      res.json({ success: true, message: "Password updated successfully" });
    } catch (error: any) {
      console.error("Update password error:", error);
      res.status(500).json({ error: { message: error.message } });
    }
  });

  // Simple test endpoint for debugging upload issues
  app.post("/api/test-upload", requireAuth, (req: any, res, next) => {
    console.log("=== TEST UPLOAD ENDPOINT ===");
    console.log("Content-Type:", req.get('content-type'));
    console.log("Content-Length:", req.get('content-length'));
    console.log("Headers:", req.headers);
    
    upload.single('image')(req, res, (err) => {
      if (err) {
        console.error("Test upload multer error:", err);
        return res.status(400).json({ error: `Test upload failed: ${err.message}` });
      }
      
      console.log("Test upload successful");
      console.log("File object:", req.file);
      
      res.json({ 
        success: true, 
        message: "Test upload successful",
        file: req.file ? {
          filename: req.file.filename,
          size: req.file.size,
          mimetype: req.file.mimetype
        } : null
      });
    });
  });

  app.post("/api/profile/upload-image", requireAuth, (req: any, res, next) => {
    console.log("=== IMAGE UPLOAD REQUEST ===");
    console.log("Content-Type:", req.get('content-type'));
    console.log("Content-Length:", req.get('content-length'));
    console.log("User-Agent:", req.get('user-agent'));
    console.log("Request method:", req.method);
    
    // Set longer timeout for large file uploads
    req.setTimeout(120000); // 2 minutes
    res.setTimeout(120000);
    
    const uploadHandler = upload.single('image');
    
    uploadHandler(req, res, (err) => {
      if (err) {
        console.error("=== MULTER ERROR ===");
        console.error("Error name:", err.name);
        console.error("Error message:", err.message);
        console.error("Error code:", err.code);
        console.error("Error field:", err.field);
        console.error("Storage errors:", err.storageErrors);
        console.error("Full error:", err);
        
        let errorMessage = `Upload failed: ${err.message}`;
        if (err.code === 'LIMIT_FILE_SIZE') {
          errorMessage = "File too large. Maximum size is 10MB.";
        } else if (err.code === 'LIMIT_UNEXPECTED_FILE') {
          errorMessage = "Unexpected file field. Please use 'image' field name.";
        }
        
        return res.status(400).json({ error: errorMessage });
      }
      
      console.log("=== MULTER SUCCESS ===");
      console.log("File received:", !!req.file);
      if (req.file) {
        console.log("File details:", {
          filename: req.file.filename,
          size: req.file.size,
          mimetype: req.file.mimetype,
          path: req.file.path
        });
      }
      
      next();
    });
  }, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      console.log("File object:", req.file);
      
      if (!req.file) {
        return res.status(400).json({ error: "No image file provided" });
      }
      
      console.log("File uploaded:", req.file.filename);
      console.log("File path:", req.file.path);
      
      // Process image with Sharp: resize, compress, and save optimized version
      const optimizedFilename = `profile_${userId}_${Date.now()}_optimized.jpg`;
      const optimizedPath = path.join(uploadsDir, optimizedFilename);
      
      await sharp(req.file.path)
        .resize(400, 400, { 
          fit: 'cover',
          position: 'center'
        })
        .jpeg({ 
          quality: 85,
          progressive: true
        })
        .toFile(optimizedPath);
      
      // Remove the original uploaded file to save space
      try {
        fs.unlinkSync(req.file.path);
      } catch (unlinkError) {
        console.warn("Could not delete original file:", unlinkError);
      }
      
      // Create the URL for the optimized image
      const imageUrl = `/uploads/${optimizedFilename}`;
      
      // Delete old profile image if it exists
      if (user.profileImageUrl && user.profileImageUrl.startsWith('/uploads/')) {
        const oldImagePath = path.join(process.cwd(), user.profileImageUrl);
        try {
          if (fs.existsSync(oldImagePath)) {
            fs.unlinkSync(oldImagePath);
            console.log("Deleted old profile image:", oldImagePath);
          }
        } catch (deleteError) {
          console.warn("Could not delete old profile image:", deleteError);
        }
      }
      
      // Update user profile image
      await storage.updateUser(userId, { profileImageUrl: imageUrl });
      
      console.log("Image upload successful:", imageUrl);
      
      return res.json({ 
        success: true,
        message: "Profile image uploaded successfully",
        profileImageUrl: imageUrl
      });
      
    } catch (error: any) {
      console.error("Image upload error:", error);
      return res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/profile", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Cancel Stripe subscription if exists
      if (user.stripeSubscriptionId) {
        try {
          await stripe.subscriptions.cancel(user.stripeSubscriptionId);
        } catch (stripeError) {
          console.error("Stripe cancellation error:", stripeError);
          // Continue with account deletion even if Stripe fails
        }
      }

      // Delete all user's resuscitation sessions and related data
      const sessions = await storage.getUserSessions(userId, 1000);
      for (const session of sessions) {
        await storage.deleteResuscitationSession(session.id);
      }

      // Delete user account (implement this method in storage)
      // For now, we'll update the user to mark as deleted
      await storage.updateUser(userId, { 
        email: `deleted_${Date.now()}@deleted.com`,
        firstName: "Deleted",
        lastName: "User",
        profileImageUrl: null,
        subscriptionActive: false
      });

      res.json({ message: "Account deleted successfully" });
    } catch (error: any) {
      console.error("Delete account error:", error);
      res.status(500).json({ error: { message: error.message } });
    }
  });

  // Stripe webhook for subscription status updates
  app.post("/api/webhook/stripe", async (req, res) => {
    const sig = req.headers["stripe-signature"];
    let event;

    try {
      event = stripe.webhooks.constructEvent(req.body, sig as string, process.env.STRIPE_WEBHOOK_SECRET!);
    } catch (err: any) {
      console.log(`Webhook signature verification failed.`, err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    try {
      if (event.type === "invoice.payment_succeeded") {
        const invoice = event.data.object as any;
        console.log(`💳 Invoice payment succeeded for customer: ${invoice.customer}`);
        
        // Handle successful subscription payment
        if (invoice.subscription) {
          console.log(`📋 Processing subscription payment for subscription: ${invoice.subscription}`);
          const subscription = await stripe.subscriptions.retrieve(invoice.subscription);
          const customer = await stripe.customers.retrieve(subscription.customer as string);
          
          if ("email" in customer && customer.email) {
            console.log(`📧 Customer email found: ${customer.email}`);
            // Find user by email
            const user = await storage.getUserByEmail(customer.email);
            if (user) {
              console.log(`👤 User found in database: ${user.id} (${user.firstName} ${user.lastName})`);
              // Update subscription status
              await storage.updateUser(user.id, { subscriptionActive: true });
              console.log(`✅ Subscription status updated for user ${user.id}`);
              
              // Create Pro welcome notification only after successful payment
              const notification = await storage.createNotification({
                userId: user.id,
                title: "Welcome to ResusMGR Pro!",
                message: "Your subscription is now active. You have full access to all professional features including ILS/ALS protocols, drug calculators, and advanced reporting.",
                type: "subscription_purchased" as const,
                isRead: false
              });
              
              console.log(`🎉 Welcome notification created for user ${user.id}, notification ID: ${notification.id}`);
              console.log(`Pro subscription activated for user ${user.id}`);
            } else {
              console.log(`❌ No user found in database with email: ${customer.email}`);
            }
          } else {
            console.log(`❌ No email found for customer: ${subscription.customer}`);
          }
        } else {
          console.log(`❌ No subscription found in invoice`);
        }
      } else if (event.type === "customer.subscription.updated" || event.type === "customer.subscription.deleted") {
        const subscription = event.data.object as any;
        const customer = await stripe.customers.retrieve(subscription.customer);
        
        if ("email" in customer && customer.email) {
          const user = await storage.getUserByEmail(customer.email);
          if (user) {
            const active = subscription.status === "active";
            await storage.updateUser(user.id, { subscriptionActive: active });
            
            // Create notification for subscription changes
            if (!active) {
              await storage.createNotification({
                userId: user.id,
                title: "Subscription Cancelled",
                message: "Your Pro subscription has been cancelled. You still have access until the end of your billing period.",
                type: "subscription_cancelled" as const,
                isRead: false
              });
            }
          }
        }
      }
    } catch (error) {
      console.error("Webhook processing error:", error);
      return res.status(500).send("Webhook processing failed");
    }

    res.json({ received: true });
  });




  // Notification routes
  app.get("/api/notifications", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const limit = parseInt(req.query.limit as string) || 10;
      const notifications = await storage.getUserNotifications(userId, limit);
      
      // Ensure we're sending JSON with proper headers
      res.setHeader('Content-Type', 'application/json');
      res.json(notifications);
    } catch (error: any) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/notifications/unread-count", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const count = await storage.getUnreadNotificationCount(userId);
      
      // Ensure we're sending JSON with proper headers
      res.setHeader('Content-Type', 'application/json');
      res.json({ count });
    } catch (error: any) {
      console.error("Error fetching unread count:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/notifications/:id/read", (req: any, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    try {
      const notificationId = parseInt(req.params.id);
      storage.markNotificationAsRead(notificationId)
        .then(notification => res.json(notification))
        .catch(error => {
          console.error("Error marking notification as read:", error);
          res.status(500).json({ message: error.message });
        });
    } catch (error: any) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/notifications/mark-all-read", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id || req.user.claims?.sub;
      await storage.markAllNotificationsAsRead(userId);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error marking all notifications as read:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/notifications/clear-all", requireAuth, async (req: any, res) => {
    try {
      // Handle both simple auth and Replit auth
      const userId = req.user.claims?.sub || req.user.id;
      console.log(`Clearing all notifications for user: ${userId}`);
      await storage.clearAllUserNotifications(userId);
      res.json({ success: true, message: "All notifications cleared" });
    } catch (error: any) {
      console.error("Error clearing all notifications:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/notifications/:id", requireAuth, async (req: any, res) => {
    try {
      // Handle both simple auth and Replit auth
      const userId = req.user.claims?.sub || req.user.id;
      const notificationId = parseInt(req.params.id);
      
      // First verify the notification belongs to the current user
      const notifications = await storage.getUserNotifications(userId, 100);
      const notification = notifications.find(n => n.id === notificationId);
      
      if (!notification) {
        return res.status(404).json({ message: "Notification not found" });
      }
      
      await storage.deleteNotification(notificationId);
      res.json({ message: "Notification deleted successfully" });
    } catch (error: any) {
      console.error("Error deleting notification:", error);
      res.status(500).json({ message: "Failed to delete notification" });
    }
  });

  // ROSC/ROLE counter management routes
  app.post("/api/counters/rosc/increment", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const updatedUser = await storage.incrementRoscCount(userId);
      res.json({ success: true, roscCount: updatedUser.roscCount });
    } catch (error: any) {
      console.error("Error incrementing ROSC count:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/counters/role/increment", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const updatedUser = await storage.incrementRoleCount(userId);
      res.json({ success: true, roleCount: updatedUser.roleCount });
    } catch (error: any) {
      console.error("Error incrementing ROLE count:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/counters/rosc/reset", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const updatedUser = await storage.resetRoscCount(userId);
      res.json({ success: true, roscCount: updatedUser.roscCount });
    } catch (error: any) {
      console.error("Error resetting ROSC count:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/counters/role/reset", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const updatedUser = await storage.resetRoleCount(userId);
      res.json({ success: true, roleCount: updatedUser.roleCount });
    } catch (error: any) {
      console.error("Error resetting ROLE count:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Admin routes (restricted to administrators only)
  const requireAdmin = async (req: any, res: any, next: any) => {
    try {
      const user = req.user;
      if (!user || user.role !== "Administrator") {
        return res.status(403).json({ message: "Access denied. Administrator privileges required." });
      }
      next();
    } catch (error) {
      res.status(500).json({ message: "Authorization error" });
    }
  };

  // Get server status
  app.get("/api/admin/server-status", requireAuth, requireAdmin, async (req, res) => {
    try {
      const uptime = process.uptime();
      const memoryUsage = (process.memoryUsage().heapUsed / process.memoryUsage().heapTotal) * 100;
      
      // Test database connection
      let dbConnectionStatus = "Connected";
      try {
        await storage.getUserCount();
      } catch (error) {
        dbConnectionStatus = "Error";
      }

      // Count currently logged-in users (active within last 5 minutes)
      const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
      const onlineUsersResult = await db.select({ count: sql`count(*)` })
        .from(usersTable)
        .where(sql`${usersTable.lastActivityAt} > ${fiveMinutesAgo}`);
      
      const activeConnections = Number(onlineUsersResult[0]?.count) || 0;

      res.json({
        uptime,
        memoryUsage,
        activeConnections,
        dbConnectionStatus,
      });
    } catch (error: any) {
      console.error("Error fetching server status:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Get all users for admin management
  app.get("/api/admin/users", requireAuth, requireAdmin, async (req, res) => {
    try {
      // Prevent caching for real-time status updates
      res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.set('Pragma', 'no-cache');
      res.set('Expires', '0');
      
      // Get all users with basic info (no sensitive data like passwords)
      const users = await db.select({
        id: usersTable.id,
        email: usersTable.email,
        firstName: usersTable.firstName,
        lastName: usersTable.lastName,
        profileImageUrl: usersTable.profileImageUrl,
        role: usersTable.role,
        subscriptionActive: usersTable.subscriptionActive,
        disclaimerAccepted: usersTable.disclaimerAccepted,
        lastLoginAt: usersTable.lastLoginAt,
        lastActivityAt: usersTable.lastActivityAt, // Add this for online status detection
        createdAt: usersTable.createdAt,
      }).from(usersTable);

      // For each user, get their active session if any
      const usersWithSessions = await Promise.all(users.map(async (user) => {
        const activeSession = await storage.getActiveSession(user.id);
        if (activeSession) {
          const now = new Date();
          const startTime = new Date(activeSession.startTime);
          const duration = Math.floor((now.getTime() - startTime.getTime()) / 1000);
          
          return {
            ...user,
            activeSession: {
              id: activeSession.id,
              protocolType: activeSession.protocolType,
              patientType: activeSession.patientType,
              startTime: activeSession.startTime,
              duration: duration
            }
          };
        }
        return user;
      }));

      res.json(usersWithSessions);
    } catch (error: any) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Block/Unblock user
  app.patch("/api/admin/users/:userId/block", requireAuth, requireAdmin, async (req, res) => {
    try {
      const userId = req.params.userId;
      const currentUser = req.user;
      
      if (userId === currentUser.id) {
        return res.status(400).json({ message: "Cannot block yourself" });
      }

      // Get current user to check their status
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Toggle between blocked and unblocked states
      const isCurrentlyBlocked = user.role === "Blocked";
      const newRole = isCurrentlyBlocked ? "User" : "Blocked";
      
      await storage.updateUser(userId, { role: newRole });
      
      const action = isCurrentlyBlocked ? "unblocked" : "blocked";
      res.json({ 
        success: true, 
        message: `User has been ${action}`,
        action: action,
        newRole: newRole
      });
    } catch (error: any) {
      console.error("Error updating user block status:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Delete user
  app.delete("/api/admin/users/:userId", requireAuth, requireAdmin, async (req, res) => {
    try {
      const userId = req.params.userId;
      const currentUser = req.user;
      
      if (userId === currentUser.id) {
        return res.status(400).json({ message: "Cannot delete yourself" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Delete all user's sessions and related data
      const sessions = await storage.getUserSessions(userId, 1000);
      for (const session of sessions) {
        await storage.deleteResuscitationSession(session.id);
      }

      // Clear notifications
      await storage.clearAllUserNotifications(userId);

      // Delete the user from database
      await db.delete(usersTable).where(eq(usersTable.id, userId));
      
      res.json({ success: true, message: "User has been permanently deleted" });
    } catch (error: any) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Make user Admin
  app.patch("/api/admin/users/:userId/make-admin", requireAuth, requireAdmin, async (req, res) => {
    try {
      const userId = req.params.userId;
      const currentUser = req.user;
      
      if (userId === currentUser.id) {
        return res.status(400).json({ message: "Cannot modify your own role" });
      }

      await storage.updateUser(userId, { role: "Administrator" });
      
      // Create notification for the promoted user
      await storage.createNotification({
        userId: userId,
        title: "Administrator Access Granted",
        message: "You have been promoted to Administrator! You now have access to the Admin Console and can manage system users.",
        type: "promotion",
        isRead: false
      });
      
      res.json({ success: true, message: "User has been promoted to Administrator" });
    } catch (error: any) {
      console.error("Error promoting user:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Toggle user Pro status
  app.patch("/api/admin/users/:userId/make-pro", requireAuth, requireAdmin, async (req, res) => {
    try {
      const userId = req.params.userId;
      
      // Get current user to check their subscription status
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Toggle between Pro and Free status
      const isCurrentlyPro = user.subscriptionActive;
      const newSubscriptionStatus = !isCurrentlyPro;
      
      await storage.updateUser(userId, { subscriptionActive: newSubscriptionStatus });
      
      // Create appropriate notification
      await storage.createNotification({
        userId: userId,
        title: isCurrentlyPro ? "Pro Access Revoked" : "Pro Access Granted",
        message: isCurrentlyPro 
          ? "Your Pro access has been removed. You now have access to basic protocols only."
          : "You have been given free Pro access! You now have access to all advanced protocols, comprehensive reporting, and premium features.",
        type: isCurrentlyPro ? "downgrade" : "upgrade",
        isRead: false
      });
      
      const action = isCurrentlyPro ? "downgraded" : "upgraded";
      res.json({ 
        success: true, 
        message: `User has been ${action}`,
        action: action,
        newSubscriptionStatus: newSubscriptionStatus
      });
    } catch (error: any) {
      console.error("Error updating user subscription:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Remove user Pro access
  app.patch("/api/admin/users/:userId/remove-pro", requireAuth, requireAdmin, async (req, res) => {
    try {
      const userId = req.params.userId;
      
      // Update subscription status using the string userId directly
      await storage.updateUser(userId, { subscriptionActive: false });
      
      // Create notification for the user losing pro access
      await storage.createNotification({
        userId: userId,
        title: "Pro Access Revoked",
        message: "Your Pro access has been removed. You now have access to basic protocols only.",
        type: "downgrade",
        isRead: false
      });
      
      res.json({ success: true, message: "User Pro access has been removed" });
    } catch (error: any) {
      console.error("Error removing Pro access:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Make user admin
  app.patch("/api/admin/users/:userId/make-admin", requireAuth, requireAdmin, async (req, res) => {
    try {
      const userId = req.params.userId;
      
      // Update user role to Administrator and refresh activity
      await storage.updateUser(userId, { 
        role: "Administrator",
        lastActivityAt: new Date()
      });
      
      // Create notification for the user gaining admin access
      await storage.createNotification({
        userId: userId,
        title: "Administrator Access Granted",
        message: "You have been granted administrator privileges. You can now access the admin console and manage other users.",
        type: "admin_grant",
        isRead: false
      });
      
      res.json({ success: true, message: "User has been granted administrator access" });
    } catch (error: any) {
      console.error("Error granting admin access:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Remove admin privileges
  app.patch("/api/admin/users/:userId/remove-admin", requireAuth, requireAdmin, async (req, res) => {
    try {
      const userId = req.params.userId;
      const currentUser = req.user as any;
      
      // Prevent removing admin from yourself
      if (userId === currentUser.id) {
        return res.status(400).json({ message: "Cannot remove admin privileges from yourself" });
      }
      
      // Update user role back to default and refresh activity
      await storage.updateUser(userId, { 
        role: "Emergency Medical Technician",
        lastActivityAt: new Date()
      });
      
      // Create notification for the user losing admin access
      await storage.createNotification({
        userId: userId,
        title: "Administrator Access Removed",
        message: "Your administrator privileges have been removed. You no longer have access to the admin console.",
        type: "admin_revoke",
        isRead: false
      });
      
      res.json({ success: true, message: "Administrator privileges have been removed" });
    } catch (error: any) {
      console.error("Error removing admin access:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Refresh user activity (admin only - for testing)
  app.patch("/api/admin/users/:userId/refresh-activity", requireAuth, requireAdmin, async (req, res) => {
    try {
      const userId = req.params.userId;
      
      // Update user activity timestamp
      await storage.updateUser(userId, { lastActivityAt: new Date() });
      
      res.json({ success: true, message: "User activity refreshed" });
    } catch (error: any) {
      console.error("Error refreshing user activity:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // End user's active session (admin only)
  app.post("/api/admin/users/:userId/end-session", requireAuth, requireAdmin, async (req, res) => {
    try {
      const userId = req.params.userId;
      const { sessionId } = req.body;

      if (!sessionId) {
        return res.status(400).json({ message: "Session ID is required" });
      }

      // Get the session to verify it belongs to the user
      const session = await storage.getResuscitationSession(sessionId);
      if (!session) {
        return res.status(404).json({ message: "Session not found" });
      }

      if (session.userId !== userId) {
        return res.status(403).json({ message: "Session does not belong to the specified user" });
      }

      if (session.endTime) {
        return res.status(400).json({ message: "Session is already ended" });
      }

      // End the session with admin termination
      await storage.endSession(sessionId, "Admin Terminated", "Session terminated by administrator");

      // Create notification for the user
      await storage.createNotification({
        userId: userId,
        title: "Session Terminated",
        message: "Your active resuscitation session has been terminated by an administrator.",
        type: "session_ended",
        isRead: false,
        sessionId: sessionId
      });

      res.json({ success: true, message: "Session terminated successfully" });
    } catch (error: any) {
      console.error("Error ending user session:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Team member routes
  app.get("/api/sessions/:sessionId/team-members", requireAuth, async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      const teamMembers = await storage.getSessionTeamMembers(sessionId);
      res.json(teamMembers);
    } catch (error: any) {
      console.error("Error fetching team members:", error);
      res.status(500).json({ message: "Failed to fetch team members" });
    }
  });

  app.post("/api/sessions/:sessionId/team-members", requireAuth, async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      const currentUser = req.user as any;
      // Handle both simple auth and Replit auth
      const addedBy = currentUser.claims?.sub || currentUser.id;
      
      const teamMember = await storage.addTeamMember({
        sessionId,
        addedBy,
        ...req.body
      });

      // If adding a ResusMGR user, send notification
      if (teamMember.isResusMgrUser && teamMember.userId) {
        console.log(`Creating notification for team member addition: userId=${teamMember.userId}, sessionId=${teamMember.sessionId}`);
        await storage.createNotification({
          userId: teamMember.userId,
          type: 'resuscitation_participation',
          title: 'Added to Active Resuscitation',
          message: `You have been added to an active resuscitation session as ${teamMember.role}. If this was unauthorized, please report it immediately.`,
          sessionId: teamMember.sessionId
        });
        console.log(`Notification created successfully for user ${teamMember.userId}`);
      }

      res.json(teamMember);
    } catch (error: any) {
      console.error("Error adding team member:", error);
      res.status(500).json({ message: "Failed to add team member" });
    }
  });

  app.delete("/api/team-members/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.removeTeamMember(id);
      res.sendStatus(204);
    } catch (error: any) {
      console.error("Error removing team member:", error);
      res.status(500).json({ message: "Failed to remove team member" });
    }
  });

  // Unauthorized participation report routes
  app.post("/api/unauthorized-participation-reports", requireAuth, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const report = await storage.createUnauthorizedParticipationReport({
        reportedByUserId: currentUser.id,
        ...req.body
      });
      res.status(201).json(report);
    } catch (error: any) {
      console.error("Error creating unauthorized participation report:", error);
      res.status(500).json({ message: "Failed to create report" });
    }
  });

  // Admin support conversations management
  app.get("/api/admin/support-conversations", requireAuth, requireAdmin, async (req, res) => {
    try {
      // Get all support type conversations
      const conversations = await db
        .select()
        .from(chatConversations)
        .where(eq(chatConversations.type, "support"))
        .orderBy(desc(chatConversations.createdAt));
      
      res.json(conversations);
    } catch (error: any) {
      console.error("Error fetching support conversations:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Get individual conversation details
  app.get("/api/chat/conversations/:conversationId", requireAuth, async (req, res) => {
    try {
      const conversationId = parseInt(req.params.conversationId);
      const currentUser = req.user as any;
      
      // Get conversation details
      const [conversation] = await db
        .select()
        .from(chatConversations)
        .where(eq(chatConversations.id, conversationId));
      
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      
      // Check if user has access (is admin or participant)
      if (currentUser.role !== "Administrator") {
        const participant = await db
          .select()
          .from(chatParticipants)
          .where(
            and(
              eq(chatParticipants.conversationId, conversationId),
              eq(chatParticipants.userId, currentUser.id)
            )
          );
        
        if (participant.length === 0) {
          return res.status(403).json({ message: "Access denied" });
        }
      }
      
      res.json(conversation);
    } catch (error: any) {
      console.error("Error fetching conversation:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Get messages for a conversation
  app.get("/api/chat/conversations/:conversationId/messages", requireAuth, async (req, res) => {
    try {
      const conversationId = parseInt(req.params.conversationId);
      const currentUser = req.user as any;
      
      // Check if user has access (is admin or participant)
      if (currentUser.role !== "Administrator") {
        const participant = await db
          .select()
          .from(chatParticipants)
          .where(
            and(
              eq(chatParticipants.conversationId, conversationId),
              eq(chatParticipants.userId, currentUser.id)
            )
          );
        
        if (participant.length === 0) {
          return res.status(403).json({ message: "Access denied" });
        }
      }
      
      // Get messages
      const messages = await db
        .select()
        .from(chatMessages)
        .where(eq(chatMessages.conversationId, conversationId))
        .orderBy(chatMessages.createdAt);
      
      res.json(messages);
    } catch (error: any) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Send a message to a conversation
  app.post("/api/chat/conversations/:conversationId/messages", requireAuth, async (req, res) => {
    try {
      const conversationId = parseInt(req.params.conversationId);
      const currentUser = req.user as any;
      const { content, messageType = "text" } = req.body;
      
      if (!content || content.trim() === "") {
        return res.status(400).json({ message: "Message content is required" });
      }
      
      // Check if user has access (is admin or participant)
      if (currentUser.role !== "Administrator") {
        const participant = await db
          .select()
          .from(chatParticipants)
          .where(
            and(
              eq(chatParticipants.conversationId, conversationId),
              eq(chatParticipants.userId, currentUser.id)
            )
          );
        
        if (participant.length === 0) {
          return res.status(403).json({ message: "Access denied" });
        }
      }
      
      // Create the message
      const [newMessage] = await db
        .insert(chatMessages)
        .values({
          conversationId,
          senderId: currentUser.id,
          content: content.trim(),
          messageType
        })
        .returning();
      
      // Update conversation timestamp
      await db
        .update(chatConversations)
        .set({ updatedAt: new Date() })
        .where(eq(chatConversations.id, conversationId));
      
      res.status(201).json(newMessage);
    } catch (error: any) {
      console.error("Error sending message:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/unauthorized-participation-reports", requireAuth, async (req, res) => {
    try {
      // Check if user is admin
      const currentUser = req.user as any;
      if (!currentUser || currentUser.role !== "Administrator") {
        return res.status(403).json({ message: "Admin access required" });
      }

      // Prevent caching to ensure fresh data
      res.set({
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      });

      const limit = parseInt(req.query.limit as string) || 50;
      const reports = await storage.getUnauthorizedParticipationReports(limit);
      
      // Enrich reports with user information
      const enrichedReports = await Promise.all(
        reports.map(async (report) => {
          const reportingUser = await storage.getUser(report.reportedByUserId);
          return {
            ...report,
            reporterDisplayName: reportingUser 
              ? (reportingUser.username || 
                 (reportingUser.firstName && reportingUser.lastName 
                  ? `${reportingUser.firstName} ${reportingUser.lastName}` 
                  : reportingUser.email))
              : 'Unknown User'
          };
        })
      );
      
      res.json(enrichedReports);
    } catch (error: any) {
      console.error("Error fetching unauthorised participation reports:", error);
      res.status(500).json({ message: "Failed to fetch reports" });
    }
  });

  app.patch("/api/admin/unauthorized-participation-reports/:id", requireAuth, requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const currentUser = req.user as any;
      const { status, adminNotes, action } = req.body;
      
      console.log(`Admin updating report ${id} - status: ${status}, action: ${action}, admin: ${currentUser.username || currentUser.id}`);
      console.log(`Request body:`, req.body);
      console.log(`Current user object:`, currentUser);
      console.log(`User ID being passed:`, currentUser.id);
      
      // Handle keep/remove actions for investigation resolution
      if (action && (action === 'keep' || action === 'remove')) {
        console.log(`Processing ${action} action for report ${id}`);
        console.log(`About to call resolveUnauthorizedParticipation with ID: ${currentUser.id}`);
        
        try {
          await storage.resolveUnauthorizedParticipation(
            id, 
            action, 
            adminNotes || '', 
            currentUser.id
          );
          console.log(`Successfully resolved unauthorised participation with action: ${action}`);
        } catch (resolveError) {
          console.error(`Error in resolveUnauthorisedParticipation:`, resolveError);
          throw resolveError;
        }
        
        // Update the report status to resolved
        try {
          const updatedReport = await storage.updateUnauthorizedParticipationReportStatus(
            id, 
            'resolved', 
            adminNotes || `Investigation completed with action: ${action}`, 
            currentUser.id
          );
          console.log(`Investigation resolved with action: ${action}`);
          res.json(updatedReport);
        } catch (updateError) {
          console.error(`Error updating report status:`, updateError);
          throw updateError;
        }
      } else {
        // Regular status update
        const updatedReport = await storage.updateUnauthorizedParticipationReportStatus(
          id, 
          status, 
          adminNotes, 
          currentUser.id
        );
        console.log(`Report updated successfully, notifications should be created`);
        res.json(updatedReport);
      }
    } catch (error: any) {
      console.error("Error updating unauthorized participation report:", error);
      console.error("Error stack:", error.stack);
      res.status(500).json({ message: "Failed to update report", error: error.message });
    }
  });

  app.get("/api/users/search", requireAuth, async (req, res) => {
    try {
      const { q, limit = "10" } = req.query;
      if (!q || typeof q !== "string") {
        return res.status(400).json({ message: "Query parameter 'q' is required" });
      }
      const users = await storage.searchUsersByName(q, parseInt(limit as string));
      res.json(users);
    } catch (error: any) {
      console.error("Error searching users:", error);
      res.status(500).json({ message: "Failed to search users" });
    }
  });

  // Resuscitation session routes
  app.post("/api/sessions", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sessionData = insertResuscitationSessionSchema.parse({
        ...req.body,
        userId,
      });

      const session = await storage.createResuscitationSession(sessionData);
      res.json(session);
    } catch (error: any) {
      console.error("Error creating session:", error);
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/sessions/active", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const session = await storage.getActiveSession(userId);
      console.log(`Active session query for user ${userId}:`, session ? `Found session ${session.id} with endTime: ${session.endTime}` : 'No active session');
      res.json(session);
    } catch (error) {
      console.error("Error fetching active session:", error);
      res.status(500).json({ message: "Failed to fetch active session" });
    }
  });

  app.get("/api/sessions/:id", requireAuth, async (req, res) => {
    try {
      const sessionId = parseInt(req.params.id);
      const session = await storage.getResuscitationSession(sessionId);
      
      if (!session) {
        return res.status(404).json({ message: "Session not found" });
      }

      // Debug logging to check customSessionId field
      console.log(`Session ${sessionId} data:`, {
        id: session.id,
        customSessionId: session.customSessionId,
        protocolType: session.protocolType,
        patientType: session.patientType
      });

      res.json(session);
    } catch (error) {
      console.error("Error fetching session:", error);
      res.status(500).json({ message: "Failed to fetch session" });
    }
  });

  app.put("/api/sessions/:id/end", requireAuth, async (req, res) => {
    try {
      const sessionId = parseInt(req.params.id);
      const { outcome, notes } = req.body;
      
      // Handle different auth structures safely
      let userId;
      if (req.user) {
        userId = req.user.id;
      }
      
      if (!userId) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      
      console.log(`Ending session ${sessionId} with outcome: ${outcome}`);
      const session = await storage.endSession(sessionId, outcome, notes);
      console.log(`Session ended successfully. EndTime: ${session.endTime}, Outcome: ${session.outcome}`);
      
      // Automatically increment ROSC/ROLE counters based on outcome
      if (outcome === "ROSC") {
        console.log(`Automatically incrementing ROSC count for user ${userId}`);
        await storage.incrementRoscCount(userId);
      } else if (outcome === "ROLE") {
        console.log(`Automatically incrementing ROLE count for user ${userId}`);
        await storage.incrementRoleCount(userId);
      }
      
      res.json(session);
    } catch (error: any) {
      console.error("Error ending session:", error);
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/sessions", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const sessions = await storage.getUserSessions(userId, limit);
      
      // Add dispute status to each session
      const sessionsWithDisputeStatus = await Promise.all(
        sessions.map(async (session) => ({
          ...session,
          isDisputed: await storage.isSessionDisputed(session.id)
        }))
      );
      
      res.json(sessionsWithDisputeStatus);
    } catch (error) {
      console.error("Error fetching sessions:", error);
      res.status(500).json({ message: "Failed to fetch sessions" });
    }
  });

  // Intervention routes
  app.post("/api/interventions", requireAuth, async (req, res) => {
    try {
      const interventionData = insertInterventionSchema.parse(req.body);
      const intervention = await storage.logIntervention(interventionData);
      res.json(intervention);
    } catch (error: any) {
      console.error("Error logging intervention:", error);
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/sessions/:id/interventions", requireAuth, async (req, res) => {
    try {
      const sessionId = parseInt(req.params.id);
      const interventions = await storage.getSessionInterventions(sessionId);
      res.json(interventions);
    } catch (error) {
      console.error("Error fetching interventions:", error);
      res.status(500).json({ message: "Failed to fetch interventions" });
    }
  });

  // Reversible causes routes
  app.put("/api/sessions/:id/reversible-causes", requireAuth, async (req, res) => {
    try {
      const sessionId = parseInt(req.params.id);
      const causesData = insertReversibleCausesSchema.parse({
        ...req.body,
        sessionId,
      });
      
      const causes = await storage.updateReversibleCauses(sessionId, causesData);
      res.json(causes);
    } catch (error: any) {
      console.error("Error updating reversible causes:", error);
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/sessions/:id/reversible-causes", requireAuth, async (req, res) => {
    try {
      const sessionId = parseInt(req.params.id);
      const causes = await storage.getReversibleCauses(sessionId);
      res.json(causes);
    } catch (error) {
      console.error("Error fetching reversible causes:", error);
      res.status(500).json({ message: "Failed to fetch reversible causes" });
    }
  });

  // Drug dose routes
  app.post("/api/drug-doses", requireAuth, async (req, res) => {
    try {
      const drugDoseData = insertDrugDoseSchema.parse(req.body);
      const drugDose = await storage.logDrugDose(drugDoseData);
      res.json(drugDose);
    } catch (error: any) {
      console.error("Error logging drug dose:", error);
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/sessions/:id/drug-doses", requireAuth, async (req, res) => {
    try {
      const sessionId = parseInt(req.params.id);
      const drugDoses = await storage.getSessionDrugDoses(sessionId);
      res.json(drugDoses);
    } catch (error) {
      console.error("Error fetching drug doses:", error);
      res.status(500).json({ message: "Failed to fetch drug doses" });
    }
  });

  // Delete session
  app.delete("/api/sessions/:id", requireAuth, async (req, res) => {
    try {
      const sessionId = parseInt(req.params.id);
      console.log(`Attempting to delete session ID: ${sessionId}`);
      
      // Check if session is disputed
      const isDisputed = await storage.isSessionDisputed(sessionId);
      if (isDisputed) {
        return res.status(409).json({ 
          message: "This report cannot be deleted or changed whilst it is disputed and actively being reviewed by ResusMGR administration." 
        });
      }
      
      console.log(`Session ${sessionId} is not disputed, proceeding with deletion`);
      await storage.deleteResuscitationSession(sessionId);
      console.log(`Session ${sessionId} deleted successfully`);
      res.json({ message: "Session deleted successfully" });
    } catch (error) {
      console.error("Error deleting session:", error);
      console.error("Error stack:", error.stack);
      res.status(500).json({ message: "Failed to delete session", error: error.message });
    }
  });

  // Chat system API routes
  app.get("/api/chat/conversations", requireAuth, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const conversations = await storage.getUserConversations(currentUser.id);
      res.json(conversations);
    } catch (error: any) {
      console.error("Error fetching conversations:", error);
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });

  app.post("/api/chat/conversations", requireAuth, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const { name, type = "direct", relatedReportId, participantIds } = req.body;

      // Create conversation
      const conversation = await storage.createConversation({
        name,
        type,
        createdBy: currentUser.id,
        relatedReportId
      });

      // Add creator as participant
      await storage.addParticipant({
        conversationId: conversation.id,
        userId: currentUser.id
      });

      // Add other participants if provided
      if (participantIds && Array.isArray(participantIds)) {
        for (const userId of participantIds) {
          await storage.addParticipant({
            conversationId: conversation.id,
            userId
          });
        }
      }

      res.json(conversation);
    } catch (error: any) {
      console.error("Error creating conversation:", error);
      res.status(500).json({ message: "Failed to create conversation" });
    }
  });

  app.get("/api/chat/conversations/:id/messages", requireAuth, async (req, res) => {
    try {
      const conversationId = parseInt(req.params.id);
      const messages = await storage.getConversationMessages(conversationId);
      res.json(messages);
    } catch (error: any) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Send message to conversation (supports both URL patterns)
  app.post("/api/chat/conversations/:conversationId/messages", requireAuth, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const conversationId = parseInt(req.params.conversationId);
      const { content, messageType = "text" } = req.body;
      
      if (!content || content.trim() === "") {
        return res.status(400).json({ message: "Message content is required" });
      }
      
      // Check if user has access (is admin or participant)
      if (currentUser.role !== "Administrator") {
        const participant = await db
          .select()
          .from(chatParticipants)
          .where(
            and(
              eq(chatParticipants.conversationId, conversationId),
              eq(chatParticipants.userId, currentUser.id)
            )
          );
        
        if (participant.length === 0) {
          return res.status(403).json({ message: "Access denied" });
        }
      }
      
      // Create the message
      const [newMessage] = await db
        .insert(chatMessages)
        .values({
          conversationId,
          senderId: currentUser.id,
          content: content.trim(),
          messageType
        })
        .returning();
      
      // Update conversation timestamp
      await db
        .update(chatConversations)
        .set({ updatedAt: new Date() })
        .where(eq(chatConversations.id, conversationId));
      
      // Broadcast message to WebSocket clients
      console.log(`📡 Broadcasting message to conversation ${conversationId}:`, newMessage);
      broadcastMessage(conversationId, newMessage);
      
      res.status(201).json(newMessage);
    } catch (error: any) {
      console.error("Error sending message:", error);
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  app.post("/api/chat/conversations/:id/messages", requireAuth, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const conversationId = parseInt(req.params.id);
      const { content, message, messageType = "text" } = req.body;

      // Accept both 'content' and 'message' parameters for compatibility
      const messageContent = content || message;

      if (!messageContent || messageContent.trim() === "") {
        return res.status(400).json({ message: "Message content is required" });
      }

      const newMessage = await storage.sendMessage({
        conversationId,
        senderId: currentUser.id,
        content: messageContent.trim(),
        messageType
      });

      // Broadcast message to WebSocket clients
      console.log(`📡 Broadcasting message to conversation ${conversationId}:`, newMessage);
      broadcastMessage(conversationId, newMessage);

      res.json(newMessage);
    } catch (error: any) {
      console.error("Error sending message:", error);
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  app.patch("/api/chat/conversations/:id/read", requireAuth, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const conversationId = parseInt(req.params.id);
      
      await storage.markMessagesAsRead(conversationId, currentUser.id);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error marking messages as read:", error);
      res.status(500).json({ message: "Failed to mark messages as read" });
    }
  });

  // Delete individual message
  app.delete("/api/chat/messages/:id", requireAuth, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const messageId = parseInt(req.params.id);
      
      await storage.deleteMessage(messageId, currentUser.id);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error deleting message:", error);
      res.status(500).json({ message: "Failed to delete message" });
    }
  });

  // Clear all messages in a conversation
  app.delete("/api/chat/conversations/:id/messages", requireAuth, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const conversationId = parseInt(req.params.id);
      
      await storage.clearConversationMessages(conversationId, currentUser.id);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error clearing conversation messages:", error);
      res.status(500).json({ message: "Failed to clear conversation messages" });
    }
  });

  // Delete entire conversation
  app.delete("/api/chat/conversations/:id", requireAuth, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const conversationId = parseInt(req.params.id);
      
      await storage.deleteConversation(conversationId, currentUser.id);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error deleting conversation:", error);
      res.status(500).json({ message: "Failed to delete conversation" });
    }
  });

  // Mark individual message as delivered
  app.patch("/api/chat/messages/:id/delivered", requireAuth, async (req, res) => {
    try {
      const messageId = parseInt(req.params.id);
      await storage.markMessageAsDelivered(messageId);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error marking message as delivered:", error);
      res.status(500).json({ message: "Failed to mark message as delivered" });
    }
  });

  // Mark individual message as read
  app.patch("/api/chat/messages/:id/read", requireAuth, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const messageId = parseInt(req.params.id);
      await storage.markMessageAsRead(messageId, currentUser.id);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error marking message as read:", error);
      res.status(500).json({ message: "Failed to mark message as read" });
    }
  });

  // Get message read receipts
  app.get("/api/chat/messages/:id/receipts", requireAuth, async (req, res) => {
    try {
      const messageId = parseInt(req.params.id);
      const receipts = await storage.getMessageReadReceipts(messageId);
      res.json(receipts);
    } catch (error: any) {
      console.error("Error fetching message receipts:", error);
      res.status(500).json({ message: "Failed to fetch message receipts" });
    }
  });

  // Investigation outcome actions for unauthorized participation reports
  app.post("/api/admin/unauthorized-participation-reports/:id/resolve", requireAuth, requireAdmin, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const reportId = parseInt(req.params.id);
      const { action, adminNotes } = req.body; // action: 'keep' | 'remove'
      
      if (!['keep', 'remove'].includes(action)) {
        return res.status(400).json({ message: "Invalid action. Must be 'keep' or 'remove'" });
      }

      await storage.resolveUnauthorizedParticipation(
        reportId, 
        action, 
        adminNotes || `Investigation completed. User ${action === 'keep' ? 'kept in' : 'removed from'} resuscitation records.`,
        currentUser.id
      );

      res.json({ 
        success: true, 
        message: `Report resolved successfully. User ${action === 'keep' ? 'kept in records' : 'removed from records'}.` 
      });
    } catch (error: any) {
      console.error("Error resolving unauthorised participation:", error);
      res.status(500).json({ message: "Failed to resolve report" });
    }
  });

  // Update unauthorized participation report status
  app.patch("/api/admin/unauthorized-participation-reports/:id", requireAuth, requireAdmin, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const reportId = parseInt(req.params.id);
      const { status, adminNotes } = req.body;

      // Get the report first to find the reporting user
      const reports = await storage.getUnauthorizedParticipationReports(100);
      const report = reports.find(r => r.id === reportId);
      
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }

      // Update the report status
      const updatedReport = await storage.updateUnauthorizedParticipationReportStatus(
        reportId,
        status,
        adminNotes,
        currentUser.username || currentUser.claims.sub
      );

      // Create notification for the reporting user
      let notificationTitle = "Security Report Updated";
      let notificationMessage = `Your security report #${reportId} has been updated by an administrator.`;
      
      switch (status) {
        case 'reviewed':
          notificationTitle = "Security Report Under Review";
          notificationMessage = `Your security report #${reportId} is now under investigation. An administrator is reviewing the details and will provide updates as the investigation progresses.`;
          break;
        case 'resolved':
          notificationTitle = "Security Report Resolved";
          notificationMessage = `Your security report #${reportId} has been resolved. The investigation is complete and appropriate actions have been taken.`;
          break;
        case 'dismissed':
          notificationTitle = "Security Report Closed";
          notificationMessage = `Your security report #${reportId} has been reviewed and dismissed. No further action is required.`;
          break;
        default:
          notificationMessage = `Your security report #${reportId} status has been updated to: ${status}`;
      }

      // Add admin notes to notification if provided
      if (adminNotes && adminNotes.trim()) {
        notificationMessage += ` Administrator notes: ${adminNotes}`;
      }

      await storage.createNotification({
        userId: report.reportedByUserId,
        title: notificationTitle,
        message: notificationMessage,
        type: 'report_status_update'
      });

      res.json(updatedReport);
    } catch (error: any) {
      console.error("Error updating unauthorized participation report:", error);
      res.status(500).json({ message: "Failed to update report" });
    }
  });

  // WebSocket implementation for real-time chat
  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Store active WebSocket connections
  const clients = new Map<string, WebSocket[]>();

  function broadcastMessage(conversationId: number, message: any) {
    console.log(`🔄 Broadcasting message to conversation ${conversationId}`);
    console.log(`📱 Active clients: ${clients.size} users connected`);
    console.log(`📧 Message details:`, { id: message.id, senderId: message.senderId, content: message.content?.substring(0, 50) });
    
    // Get participants for this conversation
    storage.getConversationParticipants(conversationId).then(participants => {
      console.log(`👥 Found ${participants.length} participants for conversation ${conversationId}`);
      
      participants.forEach(participant => {
        console.log(`🔍 Checking participant: ${participant.userId}`);
        const userClients = clients.get(participant.userId);
        
        if (userClients) {
          console.log(`📡 Found ${userClients.length} WebSocket clients for user ${participant.userId}`);
          userClients.forEach((client, index) => {
            if (client.readyState === WebSocket.OPEN) {
              const payload = {
                type: 'new_message',
                conversationId,
                message
              };
              client.send(JSON.stringify(payload));
              console.log(`✅ Message sent to client ${index} for user ${participant.userId}`);
            } else {
              console.log(`❌ Client ${index} for user ${participant.userId} not ready (state: ${client.readyState})`);
            }
          });
        } else {
          console.log(`❌ No WebSocket clients found for user ${participant.userId}`);
        }
      });
    }).catch(error => {
      console.error(`💥 Error broadcasting message:`, error);
    });
  }

  wss.on('connection', (ws, req) => {
    let userId: string | null = null;

    ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'authenticate') {
          userId = message.userId;
          
          // Add client to the map
          if (!clients.has(userId)) {
            clients.set(userId, []);
          }
          clients.get(userId)!.push(ws);
          
          ws.send(JSON.stringify({ type: 'authenticated', success: true }));
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      if (userId) {
        const userClients = clients.get(userId);
        if (userClients) {
          const index = userClients.indexOf(ws);
          if (index > -1) {
            userClients.splice(index, 1);
          }
          if (userClients.length === 0) {
            clients.delete(userId);
          }
        }
      }
    });
  });

  // Support messaging endpoint for help system
  app.post("/api/support-messages", requireAuth, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const { subject, content } = req.body;

      if (!subject || !content) {
        return res.status(400).json({ message: "Subject and content are required" });
      }

      // Get admin users and create notifications for each
      const adminUsers = await storage.getAdminUsers();
      
      // Create a chat conversation for direct communication
      const conversation = await storage.createConversation({
        title: `Support: ${subject}`,
        type: "support",
        createdBy: currentUser.id,
        metadata: {
          supportTicket: true,
          subject,
          priority: "normal"
        }
      });

      // Add the user and admin as participants
      await storage.addParticipant({
        conversationId: conversation.id,
        userId: currentUser.id,
        role: "user"
      });

      // Add admin participants (users with role "Administrator")
      for (const admin of adminUsers) {
        await storage.addParticipant({
          conversationId: conversation.id,
          userId: admin.id,
          role: "admin"
        });
      }

      // Send the initial message
      await storage.sendMessage({
        conversationId: conversation.id,
        senderId: currentUser.id,
        content,
        messageType: "text"
      });

      res.status(201).json({ 
        success: true, 
        conversationId: conversation.id,
        message: "Support message sent successfully" 
      });
    } catch (error) {
      console.error("Error sending support message:", error);
      res.status(500).json({ message: "Failed to send support message" });
    }
  });

  // Admin: Test welcome notification
  app.post("/api/admin/test-welcome-notification", requireAuth, async (req, res) => {
    try {
      const currentUser = req.user;
      if (currentUser?.role !== 'Administrator') {
        return res.status(403).json({ message: "Access denied. Administrator role required." });
      }

      const { userId } = req.body;
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }

      // Create test welcome notification
      const notification = await storage.createNotification({
        userId: userId,
        title: "Welcome to ResusMGR Pro!",
        message: "Your subscription is now active. You have full access to all professional features including ILS/ALS protocols, drug calculators, and advanced reporting.",
        type: "subscription_purchased" as const,
        isRead: false
      });

      console.log(`🧪 Test welcome notification created for user ${userId}, notification ID: ${notification.id}`);

      res.json({
        success: true,
        message: `Test welcome notification created for user ${userId}`,
        notificationId: notification.id
      });
    } catch (error) {
      console.error("Error creating test welcome notification:", error);
      res.status(500).json({ 
        message: "Failed to create test notification",
        error: error.message 
      });
    }
  });

  // Admin: Profile image cleanup
  app.post("/api/admin/restore-profile-images", requireAuth, async (req, res) => {
    try {
      const currentUser = req.user;
      if (currentUser?.role !== 'Administrator') {
        return res.status(403).json({ message: "Access denied. Administrator role required." });
      }

      console.log("Starting profile image restoration...");
      
      // Get all users with profile image URLs
      const usersWithImages = await storage.getUsersWithProfileImages();
      let cleanedCount = 0;
      let validCount = 0;
      
      for (const user of usersWithImages) {
        if (user.profileImageUrl) {
          const imagePath = path.join(".", user.profileImageUrl);
          
          if (!fs.existsSync(imagePath)) {
            console.log(`Missing image for user ${user.id}: ${imagePath}`);
            
            // Clear the missing profile image URL
            await storage.updateUser(user.id, { profileImageUrl: null });
            
            console.log(`✓ Cleared missing profile image URL for user ${user.id} (${user.firstName} ${user.lastName})`);
            cleanedCount++;
          } else {
            console.log(`✓ Profile image exists for user ${user.id} (${user.firstName} ${user.lastName})`);
            validCount++;
          }
        }
      }

      // Also check users without profile images and log them
      const usersWithoutImages = await storage.getUsersWithoutProfileImages();
      let usersWithoutImagesCount = 0;
      
      for (const user of usersWithoutImages) {
        console.log(`📷 User without profile image: ${user.id} (${user.firstName} ${user.lastName})`);
        usersWithoutImagesCount++;
      }

      res.json({
        success: true,
        message: `Profile image restoration completed. Cleaned ${cleanedCount} broken references, ${validCount} valid images found, ${usersWithoutImagesCount} users without profile images.`,
        cleanedCount,
        validCount,
        usersWithoutImagesCount,
        totalProcessed: usersWithImages.length + usersWithoutImagesCount
      });
    } catch (error) {
      console.error("Error during profile image restoration:", error);
      res.status(500).json({ 
        message: "Failed to restore profile images",
        error: error.message 
      });
    }
  });

  return httpServer;
}
