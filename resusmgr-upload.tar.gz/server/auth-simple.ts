import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User } from "@shared/schema";
import createMemoryStore from "memorystore";
import connectPg from "connect-pg-simple";

const scryptAsync = promisify(scrypt);

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

export async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  // Trust proxy for custom domain forwarding
  app.set('trust proxy', 1);
  
  // Use database session store for better persistence across domains
  const PostgresSessionStore = connectPg(session);
  const sessionStore = new PostgresSessionStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: true,
    tableName: "sessions"
  });
  
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "dev-secret-key-change-in-production",
    resave: true, // Force session save for cross-domain compatibility
    saveUninitialized: true, // Save uninitialized sessions for domain forwarding
    store: sessionStore,
    cookie: {
      secure: false, // Allow HTTP sessions for CNAME domains without SSL
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
      sameSite: false, // Most permissive setting for cross-protocol compatibility
      httpOnly: false, // Allow JavaScript access for maximum compatibility
      domain: undefined, // Don't restrict to specific domain
    },
  };

  app.set("trust proxy", 1); // Trust first proxy for accurate protocol detection
  
  // Middleware to handle custom domain forwarding
  app.use((req, res, next) => {
    const host = req.get('host');
    const isCustomDomain = host && (host.includes('resusmgr.co.uk') || host.includes('www.resusmgr.co.uk'));
    
    if (isCustomDomain) {
      console.log("Request from custom domain:", host, "Protocol:", req.protocol);
      
      // If it's HTTP from custom domain, redirect to HTTPS Replit version
      if (req.protocol === 'http') {
        const replitUrl = `https://${process.env.REPLIT_DOMAIN || process.env.REPL_SLUG + '.' + process.env.REPLIT_CLUSTER + '.replit.dev'}${req.originalUrl}`;
        console.log("Redirecting HTTP custom domain to HTTPS:", replitUrl);
        return res.redirect(301, replitUrl);
      }
      
      // For HTTPS requests, set custom domain headers
      req.headers['x-forwarded-proto'] = req.protocol;
      req.headers['x-custom-domain'] = 'true';
    }
    
    next();
  });
  
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(
      { usernameField: "email" },
      async (email, password, done) => {
        try {
          console.log("Looking up user:", email);
          const user = await storage.getUserByEmail(email);
          
          if (!user) {
            console.log("User not found:", email);
            return done(null, false);
          }
          
          console.log("User found, checking password...");
          if (!user.password) {
            console.log("User has no password set:", email);
            return done(null, false);
          }
          
          const passwordMatch = await comparePasswords(password, user.password);
          
          if (!passwordMatch) {
            console.log("Password does not match for user:", email);
            return done(null, false);
          }
          
          console.log("Password matches, authentication successful");
          // Update last login time
          await storage.updateUserLastLogin(user.id);
          return done(null, user);
        } catch (error) {
          console.error("Authentication error:", error);
          return done(error);
        }
      }
    )
  );

  passport.serializeUser((user: any, done) => done(null, user.id));
  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      const { email, password, recoveryPasscode, firstName, lastName, role } = req.body;
      
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already exists" });
      }

      // Generate unique user ID
      const userId = `user_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
      console.log("Generated user ID:", userId);
      
      const userData = {
        id: userId,
        email,
        password: await hashPassword(password),
        recoveryPasscode,
        firstName,
        lastName,
        role: role || "Emergency Medicine",
      };
      console.log("User data to insert:", userData);
      
      const user = await storage.createUser(userData);

      req.login(user, async (err: any) => {
        if (err) return next(err);
        
        // Create free plan welcome notification for new registrations
        const welcomeNotification = {
          userId: user.id,
          type: "welcome_free" as const,
          title: "Welcome to ResusMGR Free Plan",
          message: "Your account is ready! You have access to BLS protocols. Upgrade to Pro for £5.99/month to unlock ILS and ALS advanced features.",
          isRead: false,
          sessionId: null
        };
        
        try {
          console.log("Creating welcome notification for user:", user.id);
          await storage.createNotification(welcomeNotification);
          console.log("Welcome notification created successfully");
        } catch (notificationError) {
          console.error("Failed to create welcome notification:", notificationError);
        }
        
        res.status(201).json(user);
      });
    } catch (error: any) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Registration failed", error: error.message });
    }
  });

  app.post("/api/login", (req, res, next) => {
    console.log("Login attempt for email:", req.body.email);
    console.log("Request protocol:", req.protocol);
    console.log("Request host:", req.get('host'));
    
    const host = req.get('host');
    const isCustomDomain = host && (host.includes('resusmgr.co.uk') || host.includes('www.resusmgr.co.uk'));
    
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) {
        console.error("Login error:", err);
        return res.status(500).json({ message: "Login failed", error: err.message });
      }
      
      if (!user) {
        console.log("Login failed - invalid credentials for:", req.body.email);
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      req.login(user, async (loginErr) => {
        if (loginErr) {
          console.error("Session login error:", loginErr);
          return res.status(500).json({ message: "Session creation failed" });
        }
        
        // Update last login time and activity
        try {
          await storage.updateUserLastLogin(user.id);
          await storage.updateUserActivity(user.id);
          const updatedUser = await storage.getUser(user.id);
          console.log("Login successful for user:", user.email, "- session created");
          
          // For custom domain, force session to be saved and add extra headers
          if (isCustomDomain) {
            console.log("Custom domain login - forcing session save");
            req.session.save((saveErr) => {
              if (saveErr) console.error("Session save error:", saveErr);
            });
            
            // Set additional cookies for cross-protocol compatibility
            res.cookie('auth_user_id', user.id, { 
              maxAge: 24 * 60 * 60 * 1000, 
              httpOnly: false, 
              secure: false,
              sameSite: 'lax'
            });
          }
          
          res.status(200).json(updatedUser);
        } catch (updateError) {
          console.error("Error updating user data:", updateError);
          // Still return success even if update fails
          res.status(200).json(user);
        }
      });
    })(req, res, next);
  });

  app.post("/api/logout", async (req, res, next) => {
    try {
      // Clear user activity on logout to show them as offline
      if (req.user && req.user.id) {
        await storage.updateUser(req.user.id, { lastActivityAt: new Date('1970-01-01') });
      }
      
      req.logout((err) => {
        if (err) return next(err);
        res.status(200).json({ success: true, message: "Logged out successfully" });
      });
    } catch (error) {
      console.error("Error during logout:", error);
      res.status(500).json({ message: "Logout failed" });
    }
  });

  app.get("/api/user-test", (req, res) => {
    console.log("GET /api/user-test - isAuthenticated:", req.isAuthenticated());
    console.log("GET /api/user-test - session:", req.session?.passport?.user);
    console.log("GET /api/user-test - user:", req.user);
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });

  app.get("/api/user", async (req, res) => {
    console.log("=== GET /api/user authentication check ===");
    console.log("Protocol:", req.protocol);
    console.log("Host:", req.get('host'));
    console.log("Session ID:", req.sessionID);
    console.log("Is authenticated:", req.isAuthenticated());
    console.log("Session passport:", req.session?.passport);
    console.log("User object:", req.user);
    console.log("Custom domain header:", req.headers['x-custom-domain']);
    
    const host = req.get('host');
    const isCustomDomain = host && (host.includes('resusmgr.co.uk') || host.includes('www.resusmgr.co.uk'));
    
    // Special handling for custom domain authentication issues
    if (isCustomDomain && !req.isAuthenticated()) {
      console.log("Custom domain authentication check - trying fallback methods");
      
      // Try session recovery first
      if (req.session?.passport?.user) {
        console.log("Custom domain fix: Found user in session but not authenticated, attempting to restore");
        try {
          const userId = req.session.passport.user;
          const user = await storage.getUser(userId);
          if (user) {
            req.user = user;
            console.log("Custom domain fix: Successfully restored user session");
            res.json(user);
            return;
          }
        } catch (error) {
          console.error("Custom domain fix failed:", error);
        }
      }
      
      // Try backup cookie method
      const backupUserId = req.cookies?.auth_user_id;
      if (backupUserId) {
        console.log("Custom domain fix: Trying backup cookie authentication");
        try {
          const user = await storage.getUser(backupUserId);
          if (user) {
            // Restore the session
            req.session.passport = { user: user.id };
            req.user = user;
            console.log("Custom domain fix: Successfully restored from backup cookie");
            res.json(user);
            return;
          }
        } catch (error) {
          console.error("Backup cookie authentication failed:", error);
        }
      }
    }
    
    if (!req.isAuthenticated()) {
      console.log("Authentication failed - returning 401");
      return res.sendStatus(401);
    }
    
    // Update user activity
    try {
      if (req.user?.id) {
        await storage.updateUserActivity(req.user.id);
      }
    } catch (error) {
      console.error("Error updating user activity:", error);
    }
    
    console.log("Authentication successful - returning user data");
    res.json(req.user);
  });
}

export function requireAuth(req: any, res: any, next: any) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Authentication required" });
  }
  
  // Update user activity when they make authenticated requests
  if (req.user && req.user.id) {
    // Use a non-blocking update so we don't slow down requests
    storage.updateUserActivity(req.user.id).catch(err => {
      console.error('Error updating user activity:', err);
    });
  }
  
  next();
}