import {
  users,
  resuscitationSessions,
  interventions,
  reversibleCauses,
  drugDoses,
  notifications,
  resusTeamMembers,
  unauthorizedParticipationReports,
  chatConversations,
  chatParticipants,
  chatMessages,
  messageReadReceipts,
  type User,
  type InsertUser,
  type RegisterUser,
  type UpdateUser,
  type InsertResuscitationSession,
  type ResuscitationSession,
  type InsertIntervention,
  type Intervention,
  type InsertReversibleCauses,
  type ReversibleCauses,
  type InsertDrugDose,
  type DrugDose,
  type InsertNotification,
  type Notification,
  type ResusTeamMember,
  type InsertResusTeamMember,
  type InsertUnauthorizedParticipationReport,
  type UnauthorizedParticipationReport,
  type InsertChatConversation,
  type ChatConversation,
  type InsertChatParticipant,
  type ChatParticipant,
  type InsertChatMessage,
  type ChatMessage,
  type MessageReadReceipt,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, isNull, count, gt } from "drizzle-orm";

export interface IStorage {
  // User operations for secure authentication
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: RegisterUser): Promise<User>;
  updateUser(id: string, updates: UpdateUser): Promise<User>;
  updateUserPassword(id: string, hashedPassword: string): Promise<User>;
  updateUserLastLogin(id: string): Promise<User>;
  updateUserActivity(id: string): Promise<User>;
  updateUserStripeInfo(userId: number, customerId: string, subscriptionId?: string): Promise<User>;
  updateUserSubscriptionStatus(userId: number, active: boolean): Promise<User>;
  acceptDisclaimer(userId: number): Promise<User>;
  getUserCount(): Promise<number>;
  incrementRoscCount(userId: string): Promise<User>;
  incrementRoleCount(userId: string): Promise<User>;
  resetRoscCount(userId: string): Promise<User>;
  resetRoleCount(userId: string): Promise<User>;

  // Resuscitation session operations
  createResuscitationSession(session: InsertResuscitationSession): Promise<ResuscitationSession>;
  getResuscitationSession(id: number): Promise<ResuscitationSession | undefined>;
  getActiveSession(userId: string): Promise<ResuscitationSession | undefined>;
  updateResuscitationSession(id: number, updates: Partial<ResuscitationSession>): Promise<ResuscitationSession>;
  getUserSessions(userId: string, limit?: number): Promise<ResuscitationSession[]>;
  endSession(id: number, outcome: string, notes?: string): Promise<ResuscitationSession>;
  deleteResuscitationSession(id: number): Promise<void>;

  // Intervention operations
  logIntervention(intervention: InsertIntervention): Promise<Intervention>;
  getSessionInterventions(sessionId: number): Promise<Intervention[]>;

  // Reversible causes operations
  updateReversibleCauses(sessionId: number, causes: InsertReversibleCauses): Promise<ReversibleCauses>;
  getReversibleCauses(sessionId: number): Promise<ReversibleCauses | undefined>;

  // Drug dose operations
  logDrugDose(drugDose: InsertDrugDose): Promise<DrugDose>;
  getSessionDrugDoses(sessionId: number): Promise<DrugDose[]>;

  // Notification operations
  createNotification(notification: InsertNotification): Promise<Notification>;
  getUserNotifications(userId: string, limit?: number): Promise<Notification[]>;
  getUnreadNotificationCount(userId: string): Promise<number>;
  markNotificationAsRead(notificationId: number): Promise<Notification>;
  markAllNotificationsAsRead(userId: string): Promise<void>;
  deleteNotification(notificationId: number): Promise<void>;
  clearAllUserNotifications(userId: string): Promise<void>;

  // Team member operations
  addTeamMember(teamMember: InsertResusTeamMember): Promise<ResusTeamMember>;
  getSessionTeamMembers(sessionId: number): Promise<ResusTeamMember[]>;
  removeTeamMember(id: number): Promise<void>;
  searchUsersByName(query: string, limit?: number): Promise<User[]>;

  // Unauthorized participation report operations
  createUnauthorizedParticipationReport(report: InsertUnauthorizedParticipationReport): Promise<UnauthorizedParticipationReport>;
  getUnauthorizedParticipationReports(limit?: number): Promise<UnauthorizedParticipationReport[]>;
  updateUnauthorizedParticipationReportStatus(id: number, status: string, adminNotes?: string, reviewedBy?: string): Promise<UnauthorizedParticipationReport>;

  // Chat system operations
  createConversation(conversation: InsertChatConversation): Promise<ChatConversation>;
  getConversation(id: number): Promise<ChatConversation | undefined>;
  getUserConversations(userId: string): Promise<ChatConversation[]>;
  addParticipant(participant: InsertChatParticipant): Promise<ChatParticipant>;
  removeParticipant(conversationId: number, userId: string): Promise<void>;
  getConversationParticipants(conversationId: number): Promise<ChatParticipant[]>;
  sendMessage(message: InsertChatMessage): Promise<ChatMessage>;
  getConversationMessages(conversationId: number, limit?: number): Promise<ChatMessage[]>;
  markMessagesAsRead(conversationId: number, userId: string): Promise<void>;
  getUnreadMessageCount(userId: string): Promise<number>;
  markMessageAsDelivered(messageId: number): Promise<void>;
  markMessageAsRead(messageId: number, userId: string): Promise<void>;
  getMessageReadReceipts(messageId: number): Promise<MessageReadReceipt[]>;
  deleteMessage(messageId: number, userId: string): Promise<void>;
  clearConversationMessages(conversationId: number, userId: string): Promise<void>;
  deleteConversation(conversationId: number, userId: string): Promise<void>;

  // Investigation outcome actions
  resolveUnauthorizedParticipation(reportId: number, action: 'keep' | 'remove', adminNotes: string, reviewedBy: string): Promise<void>;
  removeTeamMemberFromSession(sessionId: number, teamMemberId: number): Promise<void>;
  
  // Session dispute status
  isSessionDisputed(sessionId: number): Promise<boolean>;
  
  // Admin user operations
  getAdminUsers(): Promise<User[]>;
  
  // Profile image operations
  getUsersWithProfileImages(): Promise<User[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(userData: RegisterUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .returning();
    return user;
  }

  async updateUser(id: string, updates: UpdateUser): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserPassword(id: string, hashedPassword: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ password: hashedPassword, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserLastLogin(id: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ lastLoginAt: new Date(), updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserActivity(id: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ lastActivityAt: new Date(), updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserStripeInfo(userId: number, customerId: string, subscriptionId?: string): Promise<User> {
    const updates: any = { stripeCustomerId: customerId };
    if (subscriptionId) updates.stripeSubscriptionId = subscriptionId;
    
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, userId.toString()))
      .returning();
    return user;
  }

  async updateUserSubscriptionStatus(userId: number, active: boolean): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ subscriptionActive: active, updatedAt: new Date() })
      .where(eq(users.id, userId.toString()))
      .returning();
    return user;
  }

  async acceptDisclaimer(userId: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        disclaimerAccepted: true,
        disclaimerAcceptedAt: new Date(),
        updatedAt: new Date()
      })
      .where(eq(users.id, userId.toString()))
      .returning();
    return user;
  }

  async getUserCount(): Promise<number> {
    const [result] = await db.select({ count: count() }).from(users);
    return result.count;
  }

  async incrementRoscCount(userId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        roscCount: sql`${users.roscCount} + 1`,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async incrementRoleCount(userId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        roleCount: sql`${users.roleCount} + 1`,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async resetRoscCount(userId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        roscCount: 0,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async resetRoleCount(userId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        roleCount: 0,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async createResuscitationSession(session: InsertResuscitationSession): Promise<ResuscitationSession> {
    const [newSession] = await db
      .insert(resuscitationSessions)
      .values(session)
      .returning();
    return newSession;
  }

  async getResuscitationSession(id: number): Promise<ResuscitationSession | undefined> {
    const [session] = await db
      .select()
      .from(resuscitationSessions)
      .where(eq(resuscitationSessions.id, id));
    return session;
  }

  async getActiveSession(userId: string): Promise<ResuscitationSession | undefined> {
    const [session] = await db
      .select()
      .from(resuscitationSessions)
      .where(
        and(
          eq(resuscitationSessions.userId, userId),
          isNull(resuscitationSessions.endTime)
        )
      )
      .orderBy(desc(resuscitationSessions.startTime))
      .limit(1);
    return session;
  }

  async updateResuscitationSession(id: number, updates: Partial<ResuscitationSession>): Promise<ResuscitationSession> {
    const [session] = await db
      .update(resuscitationSessions)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(resuscitationSessions.id, id))
      .returning();
    return session;
  }

  async getUserSessions(userId: string, limit: number = 10): Promise<ResuscitationSession[]> {
    return await db
      .select()
      .from(resuscitationSessions)
      .where(eq(resuscitationSessions.userId, userId))
      .orderBy(desc(resuscitationSessions.startTime))
      .limit(limit);
  }

  async endSession(id: number, outcome: string, notes?: string): Promise<ResuscitationSession> {
    const [session] = await db
      .update(resuscitationSessions)
      .set({
        endTime: new Date(),
        outcome,
        notes,
        updatedAt: new Date()
      })
      .where(eq(resuscitationSessions.id, id))
      .returning();
    return session;
  }

  async deleteResuscitationSession(id: number): Promise<void> {
    // First get unauthorized participation reports related to this session
    const relatedReports = await db
      .select({ id: unauthorizedParticipationReports.id })
      .from(unauthorizedParticipationReports)
      .where(eq(unauthorizedParticipationReports.sessionId, id));

    // Delete chat data related to these reports
    for (const report of relatedReports) {
      // Delete message read receipts for conversations related to this report
      const relatedConversations = await db
        .select({ id: chatConversations.id })
        .from(chatConversations)
        .where(eq(chatConversations.relatedReportId, report.id));

      for (const conversation of relatedConversations) {
        // Delete message read receipts
        const messages = await db
          .select({ id: chatMessages.id })
          .from(chatMessages)
          .where(eq(chatMessages.conversationId, conversation.id));

        for (const message of messages) {
          await db.delete(messageReadReceipts).where(eq(messageReadReceipts.messageId, message.id));
        }

        // Delete messages
        await db.delete(chatMessages).where(eq(chatMessages.conversationId, conversation.id));
        
        // Delete participants
        await db.delete(chatParticipants).where(eq(chatParticipants.conversationId, conversation.id));
      }

      // Delete conversations
      await db.delete(chatConversations).where(eq(chatConversations.relatedReportId, report.id));
    }

    // Delete related data (foreign key constraints)
    await db.delete(interventions).where(eq(interventions.sessionId, id));
    await db.delete(drugDoses).where(eq(drugDoses.sessionId, id));
    await db.delete(reversibleCauses).where(eq(reversibleCauses.sessionId, id));
    await db.delete(resusTeamMembers).where(eq(resusTeamMembers.sessionId, id));
    await db.delete(unauthorizedParticipationReports).where(eq(unauthorizedParticipationReports.sessionId, id));
    
    // Delete the session
    await db.delete(resuscitationSessions).where(eq(resuscitationSessions.id, id));
  }

  async logIntervention(intervention: InsertIntervention): Promise<Intervention> {
    const [newIntervention] = await db
      .insert(interventions)
      .values(intervention)
      .returning();
    return newIntervention;
  }

  async getSessionInterventions(sessionId: number): Promise<Intervention[]> {
    return await db
      .select()
      .from(interventions)
      .where(eq(interventions.sessionId, sessionId))
      .orderBy(interventions.timestamp);
  }

  async updateReversibleCauses(sessionId: number, causes: InsertReversibleCauses): Promise<ReversibleCauses> {
    const [updatedCauses] = await db
      .insert(reversibleCauses)
      .values({ ...causes, sessionId })
      .onConflictDoUpdate({
        target: reversibleCauses.sessionId,
        set: { ...causes, updatedAt: new Date() }
      })
      .returning();
    return updatedCauses;
  }

  async getReversibleCauses(sessionId: number): Promise<ReversibleCauses | undefined> {
    const [causes] = await db
      .select()
      .from(reversibleCauses)
      .where(eq(reversibleCauses.sessionId, sessionId));
    return causes;
  }

  async logDrugDose(drugDose: InsertDrugDose): Promise<DrugDose> {
    const [newDose] = await db
      .insert(drugDoses)
      .values(drugDose)
      .returning();
    return newDose;
  }

  async getSessionDrugDoses(sessionId: number): Promise<DrugDose[]> {
    return await db
      .select()
      .from(drugDoses)
      .where(eq(drugDoses.sessionId, sessionId))
      .orderBy(drugDoses.timestamp);
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db
      .insert(notifications)
      .values(notification)
      .returning();
    return newNotification;
  }

  async getUserNotifications(userId: string, limit: number = 10): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt))
      .limit(limit);
  }

  async getUnreadNotificationCount(userId: string): Promise<number> {
    const result = await db
      .select({ count: count() })
      .from(notifications)
      .where(
        and(
          eq(notifications.userId, userId),
          eq(notifications.isRead, false)
        )
      );
    return result[0]?.count || 0;
  }

  async markNotificationAsRead(notificationId: number): Promise<Notification> {
    const [notification] = await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, notificationId))
      .returning();
    return notification;
  }

  async markAllNotificationsAsRead(userId: string): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(
        and(
          eq(notifications.userId, userId),
          eq(notifications.isRead, false)
        )
      );
  }

  async deleteNotification(notificationId: number): Promise<void> {
    await db.delete(notifications).where(eq(notifications.id, notificationId));
  }

  async clearAllUserNotifications(userId: string): Promise<void> {
    await db.delete(notifications).where(eq(notifications.userId, userId));
  }

  async addTeamMember(teamMember: InsertResusTeamMember): Promise<ResusTeamMember> {
    const [newMember] = await db
      .insert(resusTeamMembers)
      .values(teamMember)
      .returning();
    return newMember;
  }

  async getSessionTeamMembers(sessionId: number): Promise<ResusTeamMember[]> {
    return await db
      .select()
      .from(resusTeamMembers)
      .where(eq(resusTeamMembers.sessionId, sessionId))
      .orderBy(resusTeamMembers.createdAt);
  }

  async removeTeamMember(id: number): Promise<void> {
    await db.delete(resusTeamMembers).where(eq(resusTeamMembers.id, id));
  }

  async searchUsersByName(query: string, limit: number = 10): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .where(
        sql`LOWER(${users.firstName} || ' ' || ${users.lastName}) LIKE LOWER('%' || ${query} || '%')`
      )
      .limit(limit);
  }

  async createUnauthorizedParticipationReport(report: InsertUnauthorizedParticipationReport): Promise<UnauthorizedParticipationReport> {
    const [newReport] = await db
      .insert(unauthorizedParticipationReports)
      .values(report)
      .returning();
    return newReport;
  }

  async getUnauthorizedParticipationReports(limit: number = 50): Promise<UnauthorizedParticipationReport[]> {
    return await db
      .select()
      .from(unauthorizedParticipationReports)
      .orderBy(desc(unauthorizedParticipationReports.createdAt))
      .limit(limit);
  }

  async updateUnauthorizedParticipationReportStatus(
    id: number,
    status: string,
    adminNotes?: string,
    reviewedBy?: string
  ): Promise<UnauthorizedParticipationReport> {
    const updatedReport = await db
      .update(unauthorizedParticipationReports)
      .set({
        status,
        adminNotes,
        reviewedBy,
        reviewedAt: new Date(),
        updatedAt: new Date()
      })
      .where(eq(unauthorizedParticipationReports.id, id))
      .returning();
    return updatedReport;
  }

  async resolveUnauthorizedParticipation(reportId: number, action: 'keep' | 'remove', adminNotes: string, reviewedBy: string): Promise<void> {
    await this.updateUnauthorizedParticipationReportStatus(reportId, 'resolved', adminNotes, reviewedBy);
  }

  async removeTeamMemberFromSession(sessionId: number, teamMemberId: number): Promise<void> {
    await db
      .delete(resusTeamMembers)
      .where(
        and(
          eq(resusTeamMembers.sessionId, sessionId),
          eq(resusTeamMembers.id, teamMemberId)
        )
      );
  }

  async isSessionDisputed(sessionId: number): Promise<boolean> {
    const reports = await db
      .select()
      .from(unauthorizedParticipationReports)
      .where(
        and(
          eq(unauthorizedParticipationReports.sessionId, sessionId),
          eq(unauthorizedParticipationReports.status, 'pending')
        )
      );
    return reports.length > 0;
  }

  async getAdminUsers(): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, "Administrator"));
  }

  // Chat system operations
  async createConversation(conversation: InsertChatConversation): Promise<ChatConversation> {
    const [newConversation] = await db
      .insert(chatConversations)
      .values(conversation)
      .returning();
    return newConversation;
  }

  async getConversation(id: number): Promise<ChatConversation | undefined> {
    const [conversation] = await db
      .select()
      .from(chatConversations)
      .where(eq(chatConversations.id, id));
    return conversation;
  }

  async getUserConversations(userId: string): Promise<ChatConversation[]> {
    return await db
      .select({
        id: chatConversations.id,
        title: chatConversations.title,
        type: chatConversations.type,
        createdBy: chatConversations.createdBy,
        relatedReportId: chatConversations.relatedReportId,
        metadata: chatConversations.metadata,
        createdAt: chatConversations.createdAt,
        updatedAt: chatConversations.updatedAt,
      })
      .from(chatConversations)
      .innerJoin(chatParticipants, eq(chatParticipants.conversationId, chatConversations.id))
      .where(eq(chatParticipants.userId, userId))
      .orderBy(desc(chatConversations.updatedAt));
  }

  async addParticipant(participant: InsertChatParticipant): Promise<ChatParticipant> {
    const [newParticipant] = await db
      .insert(chatParticipants)
      .values(participant)
      .returning();
    return newParticipant;
  }

  async removeParticipant(conversationId: number, userId: string): Promise<void> {
    await db
      .delete(chatParticipants)
      .where(
        and(
          eq(chatParticipants.conversationId, conversationId),
          eq(chatParticipants.userId, userId)
        )
      );
  }

  async getConversationParticipants(conversationId: number): Promise<ChatParticipant[]> {
    return await db
      .select()
      .from(chatParticipants)
      .where(eq(chatParticipants.conversationId, conversationId));
  }

  async sendMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [newMessage] = await db
      .insert(chatMessages)
      .values(message)
      .returning();
    
    // Update conversation updatedAt timestamp
    await db
      .update(chatConversations)
      .set({ updatedAt: new Date() })
      .where(eq(chatConversations.id, message.conversationId));
    
    return newMessage;
  }

  async getConversationMessages(conversationId: number, limit: number = 50): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.conversationId, conversationId))
      .orderBy(desc(chatMessages.createdAt))
      .limit(limit);
  }

  async markMessagesAsRead(conversationId: number, userId: string): Promise<void> {
    await db
      .update(chatParticipants)
      .set({ lastReadAt: new Date() })
      .where(
        and(
          eq(chatParticipants.conversationId, conversationId),
          eq(chatParticipants.userId, userId)
        )
      );
  }

  async getUnreadMessageCount(userId: string): Promise<number> {
    const conversations = await this.getUserConversations(userId);
    let unreadCount = 0;
    
    for (const conversation of conversations) {
      const participant = await db
        .select()
        .from(chatParticipants)
        .where(
          and(
            eq(chatParticipants.conversationId, conversation.id),
            eq(chatParticipants.userId, userId)
          )
        )
        .limit(1);
      
      if (participant.length > 0) {
        const lastReadAt = participant[0].lastReadAt;
        const unreadMessages = await db
          .select({ count: count() })
          .from(chatMessages)
          .where(
            and(
              eq(chatMessages.conversationId, conversation.id),
              lastReadAt ? gt(chatMessages.createdAt, lastReadAt) : undefined
            )
          );
        
        unreadCount += unreadMessages[0].count;
      }
    }
    
    return unreadCount;
  }

  async markMessageAsDelivered(messageId: number): Promise<void> {
    await db
      .update(chatMessages)
      .set({ deliveredAt: new Date() })
      .where(eq(chatMessages.id, messageId));
  }

  async markMessageAsRead(messageId: number, userId: string): Promise<void> {
    const [receipt] = await db
      .insert(messageReadReceipts)
      .values({
        messageId,
        userId,
      })
      .onConflictDoNothing()
      .returning();
  }

  async getMessageReadReceipts(messageId: number): Promise<MessageReadReceipt[]> {
    return await db
      .select()
      .from(messageReadReceipts)
      .where(eq(messageReadReceipts.messageId, messageId));
  }

  async deleteMessage(messageId: number, userId: string): Promise<void> {
    // First, get the message to check if user is authorized to delete it
    const [message] = await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.id, messageId));

    if (!message) {
      throw new Error("Message not found");
    }

    // Check if user is the sender or an admin
    const user = await this.getUser(userId);
    if (message.senderId !== userId && user?.role !== 'Administrator') {
      throw new Error("Not authorized to delete this message");
    }

    // Delete read receipts first
    await db
      .delete(messageReadReceipts)
      .where(eq(messageReadReceipts.messageId, messageId));

    // Delete the message
    await db
      .delete(chatMessages)
      .where(eq(chatMessages.id, messageId));
  }

  async clearConversationMessages(conversationId: number, userId: string): Promise<void> {
    // Check if user is a participant or admin
    const user = await this.getUser(userId);
    const participants = await this.getConversationParticipants(conversationId);
    const isParticipant = participants.some(p => p.userId === userId);
    
    if (!isParticipant && user?.role !== 'Administrator') {
      throw new Error("Not authorized to clear messages in this conversation");
    }

    // Get all message IDs for this conversation
    const messageIds = await db
      .select({ id: chatMessages.id })
      .from(chatMessages)
      .where(eq(chatMessages.conversationId, conversationId));

    if (messageIds.length === 0) {
      return; // No messages to delete
    }

    // Delete all read receipts for these messages
    for (const { id } of messageIds) {
      await db
        .delete(messageReadReceipts)
        .where(eq(messageReadReceipts.messageId, id));
    }

    // Delete all messages in the conversation
    await db
      .delete(chatMessages)
      .where(eq(chatMessages.conversationId, conversationId));
  }

  async deleteConversation(conversationId: number, userId: string): Promise<void> {
    // Check if user is a participant or admin
    const user = await this.getUser(userId);
    const participants = await this.getConversationParticipants(conversationId);
    const isParticipant = participants.some(p => p.userId === userId);
    
    if (!isParticipant && user?.role !== 'Administrator') {
      throw new Error("Not authorized to delete this conversation");
    }

    // First clear all messages (which also deletes read receipts)
    await this.clearConversationMessages(conversationId, userId);

    // Remove all participants
    await db
      .delete(chatParticipants)
      .where(eq(chatParticipants.conversationId, conversationId));

    // Delete the conversation itself
    await db
      .delete(chatConversations)
      .where(eq(chatConversations.id, conversationId));
  }

  async getUsersWithProfileImages(): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .where(sql`${users.profileImageUrl} IS NOT NULL AND ${users.profileImageUrl} != ''`);
  }

  async getUsersWithoutProfileImages(): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .where(sql`${users.profileImageUrl} IS NULL OR ${users.profileImageUrl} = ''`);
  }
}

export const storage = new DatabaseStorage();