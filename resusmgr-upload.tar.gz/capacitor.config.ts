import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.ashleyjamesmedical.resumsgr',
  appName: 'ResusMGR',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    allowNavigation: [
      '*.replit.app',
      '*.replit.dev',
      'localhost',
      '127.0.0.1'
    ]
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      launchAutoHide: true,
      backgroundColor: "#3b82f6",
      androidSplashResourceName: "splash",
      showSpinner: false
    },
    StatusBar: {
      style: 'dark'
    },
    App: {
      androidScheme: 'https'
    }
  },
  android: {
    allowMixedContent: true,
    webContentsDebuggingEnabled: true,
    appendUserAgent: 'ResusMGR-Android'
  }
};

export default config;
