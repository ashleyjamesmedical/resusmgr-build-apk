# ResusMGR Android APK - Download Instructions

## 📱 For End Users (Download & Install)

### Quick Install (Recommended)
1. **Download APK**: Get the `ResusMGR-v1.0.0.apk` file
2. **Enable Unknown Sources**: 
   - Android 8.0+: Settings → Apps → Special Access → Install Unknown Apps → Chrome/Downloads → Allow
   - Android 7.0-: Settings → Security → Unknown Sources → Enable
3. **Install**: Tap the downloaded APK file and follow prompts
4. **Launch**: Find "ResusMGR" in your app drawer

### What This App Does
- Opens https://www.resusmgr.co.uk in a native Android wrapper
- Works offline detection and error handling
- Pull-to-refresh functionality
- Full-screen experience without browser UI
- Secure HTTPS-only communication

---

## 🔧 For Developers (Build APK)

### Prerequisites
- Android Studio installed
- Java Development Kit (JDK) 8+
- Android SDK with API level 24+

### Build Steps

#### Option 1: Android Studio (Recommended)
1. Open Android Studio
2. Import the `resusmgr-android` folder
3. Build → Generate Signed Bundle/APK → APK
4. Choose debug or release variant
5. APK created in `app/build/outputs/apk/`

#### Option 2: Command Line
```bash
cd resusmgr-android
./gradlew assembleDebug    # Creates debug APK
./gradlew assembleRelease  # Creates release APK
```

### Distribution
- Debug APK: For testing, automatically signed
- Release APK: For production, requires proper signing

### App Configuration
- **Package**: com.ashleyjamesmedical.resusmgr
- **Version**: 1.0.0 (code: 1)
- **Min SDK**: 24 (Android 7.0)
- **Target SDK**: 34 (Android 14)
- **Server**: https://www.resusmgr.co.uk

### Security Notes
- APK files should be distributed through secure channels
- Users should verify APK authenticity before installation  
- Production releases should use proper code signing
- Consider distributing through Google Play Store for automatic updates

### Troubleshooting

**Installation Issues:**
- Ensure "Install from Unknown Sources" is enabled
- Clear Downloads app cache if installation fails
- Use file manager to install if direct download fails

**Runtime Issues:**
- Check internet connection
- Verify server URL is accessible
- Clear app cache and data in Android settings

**Build Issues:**
- Ensure Android SDK is properly installed
- Verify ANDROID_HOME environment variable
- Check Java version compatibility (JDK 8+)