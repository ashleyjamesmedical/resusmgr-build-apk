# ResusMGR - Professional Resuscitation Management

[![Build Android APK](https://github.com/username/resusmgr/actions/workflows/build-android-apk.yml/badge.svg)](https://github.com/username/resusmgr/actions/workflows/build-android-apk.yml)

Professional resuscitation training platform for UK emergency ambulance crews and healthcare professionals.

## 📱 Android APK Download

**Direct Download:** [ResusMGR-v1.0.0.apk](https://github.com/username/resusmgr/releases/latest/download/ResusMGR-v1.0.0.apk)

### Installation Steps
1. Download the APK file to your Android device
2. Enable "Install from Unknown Sources" in Settings
3. Tap the APK file to install
4. Launch ResusMGR from your app drawer

## 🚀 Features

- **Advanced Life Support (ALS)** - Adult and Paediatric protocols
- **Basic Life Support (BLS)** - Adult and Paediatric protocols  
- **Intermediate Life Support (ILS)** - Adult and Paediatric protocols
- **Real-time Session Management** - Track interventions and timings
- **Team Chat System** - Communication during resuscitation
- **Audit Reports** - Comprehensive session summaries
- **Subscription Management** - £1.99/month for advanced features

## 🔧 Technical Details

- **Web App:** https://www.resusmgr.co.uk
- **Package:** com.ashleyjamesmedical.resusmgr
- **Min SDK:** Android 7.0 (API 24)
- **Target SDK:** Android 14 (API 34)
- **Size:** ~5-10MB

## 🏥 Professional Use

Developed by Ashley James Medical for UK emergency services. Aligned with UK Resuscitation Council guidelines.

## 📄 Documentation

- [APK Download Instructions](APK-DOWNLOAD-INSTRUCTIONS.md)
- [Android Build Summary](ANDROID-APK-SUMMARY.md)
- [Installation Package Guide](INSTALLATION-PACKAGE.md)

## 🔐 Authentication

Default credentials for testing:
- Email: info@ashleyjamesmedical.org.uk
- Password: ResusMGR2024

## 🛠️ Development

Built with React, TypeScript, Express.js, PostgreSQL, and Stripe integration.

### Local Development
```bash
npm install
npm run dev
```

### Building APK
APKs are automatically built via GitHub Actions on every push to main branch.

## 📞 Support

For technical support or professional inquiries, contact Ashley James Medical.