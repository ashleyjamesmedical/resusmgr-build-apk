import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth, AuthProvider } from "@/hooks/use-auth";
import Landing from "@/pages/landing";
import HowItWorks from "@/pages/how-it-works";
import Dashboard from "@/pages/dashboard";
import BLSAdult from "@/pages/bls-adult";
import BLSPaediatric from "@/pages/bls-paediatric";
import ILSAdult from "@/pages/ils-adult";
import ILSPaediatric from "@/pages/ils-paediatric";
import ALSAdult from "@/pages/als-adult";
import ALSPaediatricComingSoon from "@/pages/als-paediatric-coming-soon";
import Subscribe from "@/pages/subscribe";
import Subscription from "@/pages/subscription";
import Profile from "@/pages/profile";
import ResetPassword from "@/pages/reset-password";
import CancelSubscription from "@/pages/cancel-subscription";
import EmergencyCancel from "@/pages/emergency-cancel";
import Reports from "@/pages/reports";
import ResusSummary from "@/pages/resus-summary";
import AuthPage from "@/pages/auth-page-fixed";
import AuthPageWorking from "@/pages/auth-page-working";
import AdminConsole from "@/pages/admin-console-fixed";
import NotFound from "@/pages/not-found";
import HelpPage from "@/pages/help";
import ChatConversationPage from "@/pages/chat-conversation";
import TestUpload from "@/pages/test-upload";
import LoadingScreen from "@/components/loading-screen";
import DisclaimerModal from "@/components/disclaimer-modal";
import { useState, useEffect } from "react";

function Router() {
  const { user, isLoading } = useAuth();
  const isAuthenticated = !!user;
  const [showDisclaimer, setShowDisclaimer] = useState(false);

  useEffect(() => {
    if (isAuthenticated && user && !user.disclaimerAccepted) {
      setShowDisclaimer(true);
    }
  }, [isAuthenticated, user]);

  // Show loading screen while authentication state is being determined
  if (isLoading) {
    return <LoadingScreen />;
  }

  if (showDisclaimer) {
    return <DisclaimerModal onAccept={() => setShowDisclaimer(false)} />;
  }

  return (
    <Switch>
      {!isAuthenticated ? (
        <>
          <Route path="/" component={Landing} />
          <Route path="/how-it-works" component={HowItWorks} />
          <Route path="/auth" component={AuthPageWorking} />
          <Route path="/signup-test" component={AuthPageWorking} />
          <Route path="/reset-password" component={ResetPassword} />
          <Route path="/cancel-subscription" component={CancelSubscription} />
          <Route path="/emergency-cancel" component={EmergencyCancel} />
        </>
      ) : (
        <>
          <Route path="/" component={Dashboard} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/how-it-works" component={HowItWorks} />
          <Route path="/bls-adult" component={BLSAdult} />
          <Route path="/bls-adult/:sessionId" component={BLSAdult} />
          <Route path="/bls-paediatric" component={BLSPaediatric} />
          <Route path="/bls-paediatric/:sessionId" component={BLSPaediatric} />
          <Route path="/ils-adult" component={ILSAdult} />
          <Route path="/ils-adult/:sessionId" component={ILSAdult} />
          <Route path="/ils-paediatric" component={ILSPaediatric} />
          <Route path="/ils-paediatric/:sessionId" component={ILSPaediatric} />
          <Route path="/als-adult" component={ALSAdult} />
          <Route path="/als-adult/:sessionId" component={ALSAdult} />
          <Route path="/als-paediatric" component={ALSPaediatricComingSoon} />
          <Route path="/als-paediatric/:sessionId" component={ALSPaediatricComingSoon} />
          <Route path="/resus-summary/:id" component={ResusSummary} />
          <Route path="/reports" component={Reports} />
          <Route path="/subscribe" component={Subscribe} />
          <Route path="/subscription" component={Subscription} />
          <Route path="/profile" component={Profile} />
          <Route path="/admin" component={AdminConsole} />
          <Route path="/admin-console" component={AdminConsole} />
          <Route path="/chat/:conversationId" component={ChatConversationPage} />
          <Route path="/help" component={HelpPage} />
          <Route path="/test-upload" component={TestUpload} />
          <Route path="/reset-password" component={ResetPassword} />
        </>
      )}
      <Route component={isAuthenticated ? NotFound : Landing} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
