import { useState, useEffect, useCallback, useRef } from "react";

export function useTimer() {
  const [elapsedTime, setElapsedTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number>(0);
  const offsetRef = useRef<number>(0);

  const startTimer = useCallback((initialOffset = 0) => {
    if (!isRunning) {
      startTimeRef.current = Date.now();
      offsetRef.current = initialOffset;
      setIsRunning(true);
    }
  }, [isRunning]);

  const stopTimer = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsRunning(false);
  }, []);

  const resetTimer = useCallback(() => {
    stopTimer();
    setElapsedTime(0);
    offsetRef.current = 0;
  }, [stopTimer]);

  const pauseTimer = useCallback(() => {
    if (isRunning) {
      offsetRef.current = elapsedTime;
      stopTimer();
    }
  }, [isRunning, elapsedTime, stopTimer]);

  const resumeTimer = useCallback(() => {
    if (!isRunning) {
      startTimer(elapsedTime);
    }
  }, [isRunning, elapsedTime, startTimer]);

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        const now = Date.now();
        const elapsed = Math.floor((now - startTimeRef.current) / 1000) + offsetRef.current;
        setElapsedTime(elapsed);
      }, 1000);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning]);

  return {
    elapsedTime,
    isRunning,
    startTimer,
    stopTimer,
    resetTimer,
    pauseTimer,
    resumeTimer,
  };
}
