import { useState, useEffect, useCallback, useRef } from "react";
import { createMetronomeClick } from "@/lib/audio";

export function useMetronome() {
  const [bpm, setBpm] = useState(120);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentBeat, setCurrentBeat] = useState(0);
  
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const beatCallbackRef = useRef<((beat: number) => void) | null>(null);

  // Initialize audio context
  useEffect(() => {
    if (typeof window !== "undefined") {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    
    return () => {
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  const playBeat = useCallback(() => {
    if (!isMuted && audioContextRef.current) {
      // Play sharp metronome click - accent every 4th beat
      const isAccent = currentBeat === 0;
      createMetronomeClick(audioContextRef.current, isAccent);
    }
    
    // Update beat counter
    setCurrentBeat(prev => (prev + 1) % 4);
    
    // Call beat callback if provided
    if (beatCallbackRef.current) {
      beatCallbackRef.current(currentBeat);
    }
  }, [isMuted, currentBeat]);

  const start = useCallback(() => {
    if (!isPlaying) {
      setIsPlaying(true);
      
      // Resume audio context if suspended
      if (audioContextRef.current?.state === 'suspended') {
        audioContextRef.current.resume();
      }
      
      const interval = 60000 / bpm; // Convert BPM to milliseconds
      
      // Play first beat immediately
      playBeat();
      
      // Set up interval for subsequent beats
      intervalRef.current = setInterval(playBeat, interval);
    }
  }, [isPlaying, bpm, playBeat]);

  const stop = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsPlaying(false);
    setCurrentBeat(0);
  }, []);

  const toggle = useCallback(() => {
    if (isPlaying) {
      stop();
    } else {
      start();
    }
  }, [isPlaying, start, stop]);

  const toggleMute = useCallback(() => {
    setIsMuted(prev => !prev);
  }, []);

  const setBpmValue = useCallback((newBpm: number) => {
    const clampedBpm = Math.max(100, Math.min(120, newBpm));
    setBpm(clampedBpm);
    
    // If playing, update interval immediately without stopping
    if (isPlaying && intervalRef.current) {
      clearInterval(intervalRef.current);
      const interval = 60000 / clampedBpm;
      intervalRef.current = setInterval(playBeat, interval);
    }
  }, [isPlaying, playBeat]);

  const setBeatCallback = useCallback((callback: (beat: number) => void) => {
    beatCallbackRef.current = callback;
  }, []);

  // Clean up interval on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  // Update interval when BPM changes
  useEffect(() => {
    if (isPlaying && intervalRef.current) {
      clearInterval(intervalRef.current);
      const interval = 60000 / bpm;
      intervalRef.current = setInterval(playBeat, interval);
    }
  }, [bpm, isPlaying, playBeat]);

  return {
    bpm,
    isPlaying,
    isMuted,
    currentBeat,
    start,
    stop,
    toggle,
    toggleMute,
    setBpm: setBpmValue,
    setBeatCallback,
  };
}
