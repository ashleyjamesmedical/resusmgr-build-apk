import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeft, 
  Download, 
  Search, 
  FileText, 
  Clock, 
  User, 
  Calendar,
  Activity,
  CheckCircle,
  XCircle,
  Trash2,
  Share,
  MoreVertical
} from "lucide-react";
import { Link } from "wouter";
import { Checkbox } from "@/components/ui/checkbox";
import type { ResuscitationSession } from "@shared/schema";

export default function Reports() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedReports, setSelectedReports] = useState<Set<number>>(new Set());
  const { toast } = useToast();

  // Delete mutation for single reports
  const deleteMutation = useMutation({
    mutationFn: async (sessionId: number) => {
      const response = await apiRequest("DELETE", `/api/sessions/${sessionId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      toast({
        title: "Resus Deleted",
        description: "The resuscitation report has been successfully deleted.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Delete Failed",
        description: error.message || "Unable to delete the report. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Bulk delete mutation
  const bulkDeleteMutation = useMutation({
    mutationFn: async (sessionIds: number[]) => {
      // Delete sessions in parallel
      const deletePromises = sessionIds.map(id => 
        apiRequest("DELETE", `/api/sessions/${id}`)
      );
      await Promise.all(deletePromises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      setSelectedReports(new Set());
      toast({
        title: "Reports Deleted",
        description: `${selectedReports.size} resuscitation reports have been successfully deleted.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Bulk Delete Failed",
        description: error.message || "Unable to delete selected reports. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Fetch all sessions
  const { data: sessions = [], isLoading } = useQuery({
    queryKey: ["/api/sessions"],
  });

  // Filter sessions based on search term
  const filteredSessions = Array.isArray(sessions) ? sessions.filter((session: any) => 
    session.outcome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    session.patientType?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    new Date(session.createdAt).toLocaleDateString().includes(searchTerm)
  ) : [];

  const formatDuration = (start: string, end: string | null) => {
    if (!end) return "Ongoing";
    const duration = new Date(end).getTime() - new Date(start).getTime();
    const minutes = Math.floor(duration / 60000);
    const seconds = Math.floor((duration % 60000) / 1000);
    return `${minutes}m ${seconds}s`;
  };

  const getOutcomeBadge = (outcome: string | null) => {
    if (!outcome) return <Badge variant="secondary">Ongoing</Badge>;
    
    switch (outcome) {
      case "ROSC":
        return <Badge className="bg-green-100 text-green-800 border-green-200"><CheckCircle className="w-3 h-3 mr-1" />ROSC</Badge>;
      case "ROLE":
        return <Badge className="bg-red-100 text-red-800 border-red-200"><XCircle className="w-3 h-3 mr-1" />ROLE</Badge>;
      default:
        return <Badge variant="secondary">{outcome}</Badge>;
    }
  };

  const downloadReport = async (sessionId: number) => {
    console.log("Downloading report for resus", sessionId);
    try {
      // Fetch detailed session data including interventions
      const sessionResponse = await apiRequest("GET", `/api/sessions/${sessionId}`);
      const sessionData = await sessionResponse.json();
      
      const interventionsResponse = await apiRequest("GET", `/api/sessions/${sessionId}/interventions`);
      const interventions = await interventionsResponse.json();
      
      const drugDosesResponse = await apiRequest("GET", `/api/sessions/${sessionId}/drug-doses`);
      const drugDoses = await drugDosesResponse.json();
      
      const reversibleCausesResponse = await apiRequest("GET", `/api/sessions/${sessionId}/reversible-causes`);
      const reversibleCauses = await reversibleCausesResponse.json();
      
      // Generate PDF content
      generatePDF(sessionData, interventions, drugDoses, reversibleCauses);
    } catch (error) {
      console.error("Error downloading report:", error);
      toast({
        title: "Download Failed",
        description: "Unable to download the report. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  const generatePDF = (session: any, interventions: any[], drugDoses: any[], reversibleCauses: any) => {
    // Create a new window for PDF content
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    
    const duration = session.endTime && session.startTime 
      ? Math.round((new Date(session.endTime).getTime() - new Date(session.startTime).getTime()) / 60000)
      : 0;
    
    const html = `
<!DOCTYPE html>
<html>
<head>
    <title>Resuscitation Report - Resus #${session.id}</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 20px; 
            color: #333;
        }
        .header { 
            text-align: center; 
            border-bottom: 2px solid #2563eb; 
            padding-bottom: 20px; 
            margin-bottom: 30px;
        }
        .header h1 { 
            color: #2563eb; 
            margin: 0;
        }
        .section { 
            margin-bottom: 25px; 
            page-break-inside: avoid;
        }
        .section h2 { 
            color: #1e40af; 
            border-bottom: 1px solid #e5e7eb; 
            padding-bottom: 5px;
        }
        .info-grid { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 15px; 
            margin-bottom: 20px;
        }
        .info-item { 
            background: #f8fafc; 
            padding: 10px; 
            border-radius: 5px;
        }
        .info-label { 
            font-weight: bold; 
            color: #374151;
        }
        .intervention-item { 
            background: #f0f9ff; 
            border-left: 4px solid #2563eb; 
            padding: 10px; 
            margin-bottom: 10px;
        }
        .drug-item { 
            background: #f0fdf4; 
            border-left: 4px solid #059669; 
            padding: 10px; 
            margin-bottom: 10px;
        }
        .causes-grid { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 10px;
        }
        .cause-item { 
            padding: 8px; 
            border-radius: 5px;
        }
        .cause-checked { 
            background: #fee2e2; 
            color: #dc2626;
        }
        .cause-unchecked { 
            background: #f3f4f6; 
            color: #6b7280;
        }
        .footer { 
            margin-top: 40px; 
            padding-top: 20px; 
            border-top: 1px solid #e5e7eb; 
            text-align: center; 
            color: #6b7280; 
            font-size: 12px;
        }
        @media print {
            body { margin: 0; }
            .header { page-break-after: avoid; }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>ResusMGR - Resuscitation Report</h1>
        <h2>Resus #${session.id}</h2>
        <p>Generated: ${new Date().toLocaleString('en-GB')}</p>
    </div>
    
    <div class="section">
        <h2>Session Overview</h2>
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label">Patient Type:</div>
                <div>${session.patientType || 'Not specified'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Outcome:</div>
                <div>${session.outcome || 'Ongoing'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Start Time:</div>
                <div>${session.startTime ? new Date(session.startTime).toLocaleString('en-GB') : 'Not recorded'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">End Time:</div>
                <div>${session.endTime ? new Date(session.endTime).toLocaleString('en-GB') : 'Ongoing'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Duration:</div>
                <div>${duration > 0 ? `${duration} minutes` : 'Ongoing'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Weight:</div>
                <div>${session.patientWeight ? `${session.patientWeight} kg` : 'Not recorded'}</div>
            </div>
        </div>
        ${session.notes ? `
        <div class="info-item">
            <div class="info-label">Notes:</div>
            <div>${session.notes}</div>
        </div>
        ` : ''}
    </div>
    
    ${interventions.length > 0 ? `
    <div class="section">
        <h2>Interventions (${interventions.length})</h2>
        ${interventions.map(intervention => `
        <div class="intervention-item">
            <strong>${intervention.type}</strong> - ${intervention.description}<br>
            <small>Time: ${new Date(intervention.timestamp).toLocaleString('en-GB')}</small>
        </div>
        `).join('')}
    </div>
    ` : ''}
    
    ${drugDoses.length > 0 ? `
    <div class="section">
        <h2>Drug Administration (${drugDoses.length})</h2>
        ${drugDoses.map(drug => `
        <div class="drug-item">
            <strong>${drug.drugName}</strong><br>
            Dose: ${drug.dose} | Volume: ${drug.volume} | Route: ${drug.route}<br>
            <small>Administered: ${new Date(drug.timestamp).toLocaleString('en-GB')}</small>
            ${drug.notes ? `<br><em>Notes: ${drug.notes}</em>` : ''}
        </div>
        `).join('')}
    </div>
    ` : ''}
    
    ${reversibleCauses ? `
    <div class="section">
        <h2>Reversible Causes (4Hs & 4Ts)</h2>
        <div class="causes-grid">
            <div class="cause-item ${reversibleCauses.hypoxia ? 'cause-checked' : 'cause-unchecked'}">
                ${reversibleCauses.hypoxia ? '✓' : '○'} Hypoxia
            </div>
            <div class="cause-item ${reversibleCauses.hypovolaemia ? 'cause-checked' : 'cause-unchecked'}">
                ${reversibleCauses.hypovolaemia ? '✓' : '○'} Hypovolaemia
            </div>
            <div class="cause-item ${reversibleCauses.hypoHyperkalaemia ? 'cause-checked' : 'cause-unchecked'}">
                ${reversibleCauses.hypoHyperkalaemia ? '✓' : '○'} Hypo/Hyperkalaemia
            </div>
            <div class="cause-item ${reversibleCauses.hypothermia ? 'cause-checked' : 'cause-unchecked'}">
                ${reversibleCauses.hypothermia ? '✓' : '○'} Hypothermia
            </div>
            <div class="cause-item ${reversibleCauses.thrombosis ? 'cause-checked' : 'cause-unchecked'}">
                ${reversibleCauses.thrombosis ? '✓' : '○'} Thrombosis
            </div>
            <div class="cause-item ${reversibleCauses.tensionPneumothorax ? 'cause-checked' : 'cause-unchecked'}">
                ${reversibleCauses.tensionPneumothorax ? '✓' : '○'} Tension Pneumothorax
            </div>
            <div class="cause-item ${reversibleCauses.tamponade ? 'cause-checked' : 'cause-unchecked'}">
                ${reversibleCauses.tamponade ? '✓' : '○'} Tamponade
            </div>
            <div class="cause-item ${reversibleCauses.toxins ? 'cause-checked' : 'cause-unchecked'}">
                ${reversibleCauses.toxins ? '✓' : '○'} Toxins
            </div>
        </div>
    </div>
    ` : ''}
    
    <div class="footer">
        <p>This report was generated by ResusMGR - Professional Resuscitation Management System</p>
        <p>For UK Emergency Services - Following Resuscitation Council UK Guidelines</p>
    </div>
</body>
</html>
    `;
    
    printWindow.document.write(html);
    printWindow.document.close();
    
    // Wait for content to load then trigger print
    printWindow.onload = () => {
      printWindow.print();
      printWindow.close();
    };
  };

  const shareReport = (sessionId: number) => {
    // Share functionality - could copy link or open share dialog
    const shareUrl = `${window.location.origin}/resus-summary/${sessionId}`;
    navigator.clipboard.writeText(shareUrl).then(() => {
      alert('Report link copied to clipboard!');
    }).catch(() => {
      alert(`Share this report: ${shareUrl}`);
    });
  };

  const deleteReport = (sessionId: number, isDisputed: boolean = false) => {
    console.log("Deleting resus", sessionId);
    
    if (isDisputed) {
      alert("This report cannot be deleted or changed whilst it is disputed and actively being reviewed by ResusMGR administration.");
      return;
    }
    
    if (confirm("Are you sure you want to delete this resus report? This action cannot be undone.")) {
      deleteMutation.mutate(sessionId);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <main className="container mx-auto px-4 py-6 max-w-7xl">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="outline" size="sm" className="mobile-touch-target">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Dashboard
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">
                Resuscitation Reports
              </h1>
              <p className="text-gray-600 dark:text-gray-400 mt-1">
                View, download, share or delete all resus reports
              </p>
            </div>
          </div>
        </div>

        {/* Search */}
        <Card className="medical-card mb-6">
          <CardContent className="pt-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search by outcome, patient type, or date..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Bulk Actions */}
        {filteredSessions.length > 0 && (
          <Card className="medical-card mb-6">
            <CardContent className="pt-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="select-all"
                      checked={selectedReports.size === filteredSessions.length && filteredSessions.length > 0}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setSelectedReports(new Set(filteredSessions.map((s: any) => s.id)));
                        } else {
                          setSelectedReports(new Set());
                        }
                      }}
                    />
                    <label
                      htmlFor="select-all"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Select All ({filteredSessions.length})
                    </label>
                  </div>
                  {selectedReports.size > 0 && (
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {selectedReports.size} report{selectedReports.size !== 1 ? 's' : ''} selected
                    </span>
                  )}
                </div>
                
                {selectedReports.size > 0 && (
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedReports(new Set())}
                    >
                      Clear Selection
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        const selectedSessionIds = Array.from(selectedReports);
                        const disputedSessions = filteredSessions.filter((session: any) => 
                          selectedSessionIds.includes(session.id) && session.isDisputed
                        );
                        
                        if (disputedSessions.length > 0) {
                          alert(`${disputedSessions.length} of the selected reports cannot be deleted as they are disputed and actively being reviewed by ResusMGR administration.`);
                          return;
                        }
                        
                        if (confirm(`Are you sure you want to delete ${selectedReports.size} selected report${selectedReports.size !== 1 ? 's' : ''}?`)) {
                          bulkDeleteMutation.mutate(selectedSessionIds);
                        }
                      }}
                      disabled={bulkDeleteMutation.isPending}
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete Selected
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Reports List */}
        <div className="space-y-4">
          {filteredSessions.length === 0 ? (
            <Card className="medical-card">
              <CardContent className="text-center py-12">
                <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {searchTerm ? "No Reports Found" : "No Reports Yet"}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  {searchTerm 
                    ? "Try adjusting your search terms" 
                    : "Complete a resuscitation protocol to see final summary reports here."
                  }
                </p>

              </CardContent>
            </Card>
          ) : (
            filteredSessions.map((session: any) => (
              <Card key={session.id} className={`medical-card hover:shadow-md transition-shadow ${session.isDisputed ? 'border-red-500 bg-red-50 dark:bg-red-950' : ''}`}>
                <CardContent className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                    <div className="flex items-start gap-4 flex-1">
                      <Checkbox
                        checked={selectedReports.has(session.id)}
                        onCheckedChange={(checked) => {
                          const newSelected = new Set(selectedReports);
                          if (checked) {
                            newSelected.add(session.id);
                          } else {
                            newSelected.delete(session.id);
                          }
                          setSelectedReports(newSelected);
                        }}
                        className="mt-1"
                        disabled={session.isDisputed}
                      />
                      <div className="flex-1 space-y-3">
                        <div className="flex flex-wrap items-center gap-3">
                        <h3 className={`text-lg font-semibold ${session.isDisputed ? 'text-red-700 dark:text-red-300' : 'text-gray-900 dark:text-white'}`}>
                          {session.customSessionId ? session.customSessionId : `Resus #${session.id}`}
                        </h3>
                        {session.isDisputed && (
                          <Badge variant="destructive" className="text-xs">
                            Disputed
                          </Badge>
                        )}
                        {getOutcomeBadge(session.outcome)}
                        <Badge variant="outline" className="text-xs">
                          <User className="w-3 h-3 mr-1" />
                          {session.patientType || "Unknown"}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                        <div className="flex items-center text-gray-600 dark:text-gray-400">
                          <Calendar className="w-4 h-4 mr-2" />
                          {session.createdAt ? new Date(session.createdAt).toLocaleDateString('en-GB', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric'
                          }) : 'Unknown date'}
                        </div>
                        <div className="flex items-center text-gray-600 dark:text-gray-400">
                          <Clock className="w-4 h-4 mr-2" />
                          {session.createdAt ? new Date(session.createdAt).toLocaleTimeString('en-GB', {
                            hour: '2-digit',
                            minute: '2-digit'
                          }) : 'Unknown time'}
                        </div>
                        <div className="flex items-center text-gray-600 dark:text-gray-400">
                          <Activity className="w-4 h-4 mr-2" />
                          {session.createdAt ? formatDuration(session.createdAt, session.endTime) : 'Unknown duration'}
                        </div>
                      </div>

                      {session.notes && (
                        <div className="text-sm text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-800 rounded p-3">
                          <strong>Notes:</strong> {session.notes}
                        </div>
                      )}
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-2">
                      <Link href={`/resus-summary/${session.id}`}>
                        <Button variant="outline" size="sm" className="w-full sm:w-auto">
                          <FileText className="w-4 h-4 mr-2" />
                          View Details
                        </Button>
                      </Link>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full sm:w-auto"
                        onClick={() => downloadReport(session.id)}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full sm:w-auto btn-medical-blue"
                        onClick={() => shareReport(session.id)}
                      >
                        <Share className="w-4 h-4 mr-2" />
                        Share
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className={`w-full sm:w-auto ${session.isDisputed ? 'text-gray-400 cursor-not-allowed' : 'text-red-600 hover:text-red-700 hover:bg-red-50'}`}
                        onClick={() => deleteReport(session.id, session.isDisputed)}
                        disabled={session.isDisputed}
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </main>
    </div>
  );
}