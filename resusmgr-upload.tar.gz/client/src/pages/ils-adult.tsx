import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import Navigation from "@/components/navigation";
import Timer from "@/components/timer";
import Metronome from "@/components/metronome";
import InterventionLogger from "@/components/intervention-logger";
import ResusTeamManager from "@/components/resus-team-manager";
import PreSessionTeamManager from "@/components/pre-session-team-manager";
import InterventionConfirmationDialog from "@/components/intervention-confirmation-dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Heart, 
  Clock, 
  Volume2, 
  VolumeX, 
  Stethoscope, 
  Syringe, 
  Pill, 
  Zap,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Home,
  FileText,
  Users,
  Plus,
  X,
  Activity
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useTimer } from "@/hooks/useTimer";
import type { ResuscitationSession, Intervention } from "@shared/schema";
import FooterLinks from "@/components/footer-links";

export default function ILSAdult() {
  const [, params] = useRoute("/ils-adult/:sessionId?");
  const sessionId = params?.sessionId ? parseInt(params.sessionId) : null;
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [showEndSessionDialog, setShowEndSessionDialog] = useState(false);
  const [sessionOutcome, setSessionOutcome] = useState<"ROSC" | "ROLE" | "">("");
  const [showInterventionDialog, setShowInterventionDialog] = useState(false);
  const [selectedIntervention, setSelectedIntervention] = useState<{
    type: string;
    description: string;
  } | null>(null);
  const [selectedTeamMember, setSelectedTeamMember] = useState<string>("");
  const [sessionNotes, setSessionNotes] = useState("");
  const [blsStarted, setBlsStarted] = useState(false);
  const [ilsStarted, setIlsStarted] = useState(false);
  const [alsStarted, setAlsStarted] = useState(false);
  const [blsStartTime, setBlsStartTime] = useState<Date | null>(null);
  const [metronomeEnabled, setMetronomeEnabled] = useState(false);
  const [currentBpm, setCurrentBpm] = useState(120);
  const [twoMinuteTimer, setTwoMinuteTimer] = useState(120); // 2 minutes in seconds
  const [showTwoMinutePrompt, setShowTwoMinutePrompt] = useState(false);
  const [selectedIgelSize, setSelectedIgelSize] = useState<string>("");
  const [showIgelSelection, setShowIgelSelection] = useState(false);
  const [showSavingPage, setShowSavingPage] = useState(false);
  const [showReadyDialog, setShowReadyDialog] = useState(false);
  const [selectedInterventionType, setSelectedInterventionType] = useState<string>("");
  const [selectedInterventionName, setSelectedInterventionName] = useState<string>("");
  const [showConfirmationDialog, setShowConfirmationDialog] = useState(false);
  const [customSessionId, setCustomSessionId] = useState("");
  
  // Reversible causes tracking state
  const [loggedReversibleCauses, setLoggedReversibleCauses] = useState<Set<string>>(new Set());
  const [reversibleCauseReadings, setReversibleCauseReadings] = useState<Record<string, {
    reading: string;
    isAbnormal: boolean;
  }>>({});
  
  // Reversible cause dialog state
  const [showReversibleCauseDialog, setShowReversibleCauseDialog] = useState(false);
  const [selectedReversibleCause, setSelectedReversibleCause] = useState<string>("");
  
  // Intervention confirmation popup state
  const [showInterventionConfirm, setShowInterventionConfirm] = useState(false);
  const [confirmationMessage, setConfirmationMessage] = useState('');
  
  // Enhanced intervention dialog state
  const [pendingIntervention, setPendingIntervention] = useState<{
    type: string;
    name: string;
  } | null>(null);
  const [showInterventionConfirmDialog, setShowInterventionConfirmDialog] = useState(false);
  
  // Additional notes state
  const [additionalNotes, setAdditionalNotes] = useState("");
  
  // Rhythm tracking state
  const [hasInitialRhythm, setHasInitialRhythm] = useState(false);
  const [showRhythmRequiredDialog, setShowRhythmRequiredDialog] = useState(false);
  const [showPostShockRhythmDialog, setShowPostShockRhythmDialog] = useState(false);
  const [pendingShockType, setPendingShockType] = useState<string>("");
  
  // Rhythm check dialog state
  const [showRhythmCheckDialog, setShowRhythmCheckDialog] = useState(false);
  const [selectedRhythm, setSelectedRhythm] = useState("");

  // EtCO2 monitoring state
  const [etco2Value, setEtco2Value] = useState<string>("");
  const [showEtco2Dialog, setShowEtco2Dialog] = useState(false);
  const [etco2Unit, setEtco2Unit] = useState<"mmHg" | "kPa">("mmHg");

  // Enhanced Adrenaline Timer System
  const [adrenalineTimer, setAdrenalineTimer] = useState(300); // 5 minutes in seconds
  const [adrenalineTimerRunning, setAdrenalineTimerRunning] = useState(false);

  // LUCAS Device state
  const [lucasActive, setLucasActive] = useState(false);
  const [showLucasConfirmDialog, setShowLucasConfirmDialog] = useState(false);
  const [lucasOperator, setLucasOperator] = useState("");
  const [adrenalineCount, setAdrenalineCount] = useState(0);
  const [lastAdrenalineTime, setLastAdrenalineTime] = useState<Date | null>(null);
  const [showAdrenalinePrompt, setShowAdrenalinePrompt] = useState(false);
  const [showImmediateAdrenalinePrompt, setShowImmediateAdrenalinePrompt] = useState(false);
  const [showThreeShockPrompt, setShowThreeShockPrompt] = useState(false);
  const [showShockAdrenalinePrompt, setShowShockAdrenalinePrompt] = useState(false);
  const [shockCount, setShockCount] = useState(0);



  // Auto-hide confirmation popup after 1 second
  useEffect(() => {
    if (showInterventionConfirm) {
      const timer = setTimeout(() => {
        setShowInterventionConfirm(false);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [showInterventionConfirm]);

  // Fetch current user data for scope checking
  const { data: user } = useQuery({
    queryKey: ["/api/user"],
    staleTime: 1000 * 60 * 5, // Cache for 5 minutes
  });

  // Fetch session data - always get fresh data for protocol escalations
  const { data: session, isLoading } = useQuery({
    queryKey: ["/api/sessions", sessionId],
    enabled: !!sessionId,
    staleTime: 0, // Always fetch fresh data
    gcTime: 0, // Don't cache data
  });

  // Fetch interventions
  const { data: interventions = [], refetch: refetchInterventions, isError } = useQuery({
    queryKey: [`/api/sessions/${sessionId}/interventions`],
    enabled: !!sessionId && !!session,
    refetchInterval: 2000, // Real-time updates
    staleTime: 0, // Always fetch fresh data
    gcTime: 0, // Don't cache data
    retry: false, // Don't retry failed requests
  });

  // Filter out any malformed interventions and ensure we only show valid data
  const validInterventions = Array.isArray(interventions) 
    ? interventions.filter((intervention: any) => 
        intervention && 
        intervention.id && 
        intervention.description && 
        intervention.description !== 'No description available' &&
        intervention.type && 
        intervention.type !== 'Unknown'
      ) 
    : [];

  // Local state for team members before session is created
  const [localTeamMembers, setLocalTeamMembers] = useState<any[]>([
    { name: "", role: "", isResusMgrUser: false }
  ]);
  const [searchQueries, setSearchQueries] = useState<{[key: number]: string}>({});

  // User search for adding ResusMGR users to team
  const getSearchQuery = (index: number) => searchQueries[index] || "";
  const activeQuery = Object.values(searchQueries).find(q => q && q.length > 1) || "";
  
  const { data: searchUsers = [] } = useQuery({
    queryKey: ["/api/users/search", activeQuery],
    queryFn: async () => {
      if (!activeQuery) return [];
      const response = await fetch(`/api/users/search?q=${encodeURIComponent(activeQuery)}`);
      if (!response.ok) throw new Error('Failed to search users');
      return response.json();
    },
    enabled: activeQuery.length > 1,
    staleTime: 1000,
  });
  
  // Fetch team members for existing session
  const { data: sessionTeamMembers = [] } = useQuery({
    queryKey: [`/api/sessions/${sessionId}/team-members`],
    enabled: !!sessionId && !!session,
    retry: false,
  });

  // Sync session team members with local state when they're loaded
  useEffect(() => {
    if (sessionId && Array.isArray(sessionTeamMembers) && sessionTeamMembers.length > 0) {
      console.log("Loading saved team members from database:", sessionTeamMembers);
      // Transform database team members to match the expected format
      const transformedMembers = sessionTeamMembers.map((member: any) => ({
        name: member.name,
        role: member.role,
        userId: member.userId,
        isResusMgrUser: member.isResusMgrUser || false
      }));
      console.log("Transformed team members for UI:", transformedMembers);
      setLocalTeamMembers(transformedMembers);
    } else if (sessionId && Array.isArray(sessionTeamMembers)) {
      console.log("No saved team members found for session:", sessionId);
    }
  }, [sessionTeamMembers, sessionId]);
  
  // Use local team members (which includes transformed session data)
  const teamMembers = localTeamMembers;
  
  // Count valid team members (those with both name and role filled)
  const validTeamMembers = Array.isArray(teamMembers) ? teamMembers.filter((member: any) => {
    if (!member) return false;
    
    // Check if member has valid name and role
    const hasName = member.name && typeof member.name === 'string' && member.name.trim().length > 0;
    const hasRole = member.role && typeof member.role === 'string' && member.role.trim().length > 0;
    
    return hasName && hasRole;
  }) : [];



  // Force refetch interventions when session changes
  useEffect(() => {
    if (sessionId && refetchInterventions) {
      refetchInterventions();
    }
  }, [sessionId, refetchInterventions]);

  // Timer hook
  const { elapsedTime, startTimer, stopTimer, isRunning } = useTimer();

  // 2-minute timer countdown effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if ((blsStarted || ilsStarted || alsStarted) && !showTwoMinutePrompt) {
      interval = setInterval(() => {
        setTwoMinuteTimer(prev => {
          if (prev <= 1) {
            setShowTwoMinutePrompt(true);
            if (isAudioEnabled) {
              // Play metronome beep first, then voice prompt
              const audioContext = new AudioContext();
              
              // Play current metronome beep
              const oscillator = audioContext.createOscillator();
              const gainNode = audioContext.createGain();
              oscillator.connect(gainNode);
              gainNode.connect(audioContext.destination);
              oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
              gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
              oscillator.start();
              oscillator.stop(audioContext.currentTime + 0.2);
              
              // Play voice prompt after beep
              setTimeout(() => {
                const utterance = new SpeechSynthesisUtterance("Two minutes complete - Check rhythm and swap compressions now");
                utterance.rate = 1.0;
                utterance.volume = 1.0;
                utterance.pitch = 1.1;
                speechSynthesis.speak(utterance);
              }, 300);
            }
            
            // Automatically show rhythm check dialog after 2 minutes
            setTimeout(() => {
              setShowRhythmCheckDialog(true);
            }, 1000);
            
            return 120; // Reset to 2 minutes
          }
          return prev - 1;
        });

        // Update adrenaline timer if running
        if (adrenalineTimerRunning && adrenalineTimer > 0) {
          setAdrenalineTimer(prev => prev - 1);
        } else if (adrenalineTimerRunning && adrenalineTimer === 0) {
          // Adrenaline due
          setShowAdrenalinePrompt(true);
          if (isAudioEnabled) {
            const utterance = new SpeechSynthesisUtterance("Adrenaline due now - Five minutes elapsed");
            utterance.rate = 1.0;
            utterance.volume = 1.0;
            utterance.pitch = 1.2;
            speechSynthesis.speak(utterance);
          }
          setAdrenalineTimer(300); // Reset to 5 minutes
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [blsStarted, ilsStarted, alsStarted, showTwoMinutePrompt, adrenalineTimer, adrenalineTimerRunning, isAudioEnabled]);

  // Update custom session ID mutation
  const updateCustomSessionIdMutation = useMutation({
    mutationFn: async (customSessionId: string) => {
      if (!sessionId) throw new Error("No session ID");
      return apiRequest("PATCH", `/api/sessions/${sessionId}/custom-id`, { customSessionId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions", sessionId] });
      toast({
        title: "Session Updated",
        description: "CAD number/patient initials saved successfully",
      });
    },
  });

  // Load custom session ID from existing session
  useEffect(() => {
    if (session && session.customSessionId && !customSessionId) {
      setCustomSessionId(session.customSessionId);
    }
  }, [session, customSessionId]);

  // Create session mutation
  const createSessionMutation = useMutation({
    mutationFn: async (sessionData: any) => {
      const response = await apiRequest("POST", "/api/sessions", sessionData);
      return response.json();
    },
    onSuccess: async (newSession) => {
      const newSessionId = newSession.id;
      console.log("New session created:", newSessionId);
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/sessions/active"] });
      
      // Navigate to the new session - team members will be handled by PreSessionTeamManager
      setLocation(`/ils-adult/${newSessionId}`);
    },
  });

  // Auto-save team member mutation
  const saveTeamMemberMutation = useMutation({
    mutationFn: async (member: { name: string; role: string; userId?: string; isResusMgrUser: boolean }) => {
      const response = await apiRequest("POST", `/api/sessions/${sessionId}/team-members`, member);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/sessions/${sessionId}/team-members`] });
      toast({
        title: "Team Member Added",
        description: "Team member has been saved to the session",
        duration: 2000,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: "Failed to save team member",
        variant: "destructive",
      });
    },
  });

  // BLS Start function
  const handleStartBLS = async () => {
    // If already showing ready dialog, this is the second click - actually start resus
    if (showReadyDialog) {
      setShowReadyDialog(false);
      
      const now = new Date();
      setBlsStarted(true);
      setBlsStartTime(now);
      setMetronomeEnabled(true);
      setTwoMinuteTimer(120); // Reset 2-minute timer
      if (!isRunning) {
        startTimer(0);
      }
      
      // Play loud audio announcement for ILS start
      if (isAudioEnabled) {
        const utterance = new SpeechSynthesisUtterance("Intermediate Life Support Resus started - Commence CPR");
        utterance.rate = 1.0;
        utterance.volume = 1.0;
        utterance.pitch = 1.1;
        speechSynthesis.speak(utterance);
      }

      // Log ILS start intervention with CAD number
      logInterventionMutation.mutate({
        type: "ILS_START",
        description: "ILS resuscitation protocol initiated",
        details: { 
          metronomeRate: 120,
          cadNumber: customSessionId.trim(),
          customSessionId: customSessionId.trim(),
          protocolType: "ILS",
          patientType: "Adult"
        }
      });
      
      toast({
        title: "ILS Started",
        description: "Timer and metronome active at 120 BPM",
        duration: 3000,
      });
      return;
    }

    // First click - validate and show saving process
    
    // Validate both CAD number and team member requirements
    if (!customSessionId || !customSessionId.trim()) {
      toast({
        title: "CAD Number Required",
        description: "Please enter a CAD number or patient identifier before starting resuscitation",
        variant: "destructive",
      });
      return;
    }

    // Validate team member requirement
    if (validTeamMembers.length === 0) {
      toast({
        title: "Team Member Required", 
        description: "Please add at least one team member with both name and role before starting resuscitation",
        variant: "destructive",
      });
      return;
    }

    try {
      // Show saving page
      setShowSavingPage(true);

      // Create session if needed
      if (!sessionId) {
        await createSessionMutation.mutateAsync({
          protocolType: "ILS",
          patientType: "Adult",
          startTime: new Date().toISOString(),
          customSessionId: customSessionId.trim() || undefined,
        });
      }

      // Save all team members
      for (const member of validTeamMembers) {
        try {
          await saveTeamMemberMutation.mutateAsync({
            name: member.name,
            role: member.role,
            userId: member.userId,
            isResusMgrUser: member.isResusMgrUser || false
          });
        } catch (error) {
          console.error("Failed to save team member:", error);
        }
      }

      // Hide saving page and show ready dialog
      setTimeout(() => {
        setShowSavingPage(false);
        setShowReadyDialog(true);
      }, 2000);

    } catch (error) {
      setShowSavingPage(false);
      toast({
        title: "Error",
        description: "Failed to start ILS protocol",
        variant: "destructive",
      });
    }
  };

  // ILS Start function
  const handleStartILS = () => {
    // Check scope of practice - ILS requires EMT, Nurse, Doctor, or Paramedic
    const qualifiedRoles = ['emt', 'emergency medical technician', 'nurse', 'doctor', 'paramedic', 'registered nurse', 'rn', 'consultant', 'physician', 'gp'];
    const hasQualifiedTeamMember = validTeamMembers.some(member => 
      qualifiedRoles.includes(member.role.toLowerCase())
    );
    const userIsQualified = user && qualifiedRoles.includes(((user as any).role || '').toLowerCase());

    if (!hasQualifiedTeamMember && !userIsQualified) {
      // Create notification for scope violation
      createNotificationMutation.mutate({
        type: "scope_violation",
        title: "ILS Protocol Access Denied",
        message: "ILS protocols require at least one EMT, Nurse, Doctor, or Paramedic on the team. Add a qualified team member or ensure your role qualifications are correct.",
        priority: "high"
      });
      
      toast({
        title: "Access Denied",
        description: "ILS requires EMT, Nurse, Doctor, or Paramedic qualification",
        variant: "destructive",
        duration: 5000,
      });
      return;
    }

    setIlsStarted(true);
    setTwoMinuteTimer(120); // Reset 2-minute timer
    if (!isRunning) {
      startTimer(0);
      setMetronomeEnabled(true);
    }
    // Log ILS start intervention
    logInterventionMutation.mutate({
      type: "ILS_START",
      description: "Intermediate Life Support protocol initiated",
      details: { escalatedFrom: blsStarted ? "BLS" : "Direct" }
    });
    toast({
      title: "ILS Started",
      description: "Intermediate Life Support protocol active",
      duration: 3000,
    });
  };

  // ALS Start function - Navigate to ALS Adult page with session continuity
  const handleStartALS = async () => {
    // Check scope of practice - ALS requires Nurse, Doctor, or Paramedic
    const qualifiedRoles = ['nurse', 'doctor', 'paramedic', 'registered nurse', 'rn', 'consultant', 'physician', 'gp'];
    const hasQualifiedTeamMember = validTeamMembers.some(member => 
      qualifiedRoles.includes(member.role.toLowerCase())
    );
    const userIsQualified = user && qualifiedRoles.includes(((user as any).role || '').toLowerCase());

    if (!hasQualifiedTeamMember && !userIsQualified) {
      // Create notification for scope violation
      createNotificationMutation.mutate({
        type: "scope_violation",
        title: "ALS Protocol Access Denied",
        message: "ALS protocols require at least one Nurse, Doctor, or Paramedic on the team. Add a qualified team member or ensure your role qualifications are correct.",
        priority: "high"
      });
      
      toast({
        title: "Access Denied",
        description: "ALS requires Nurse, Doctor, or Paramedic qualification",
        variant: "destructive",
        duration: 5000,
      });
      return;
    }

    if (sessionId) {
      try {
        // FORCE SAVE ALL CURRENT TEAM MEMBERS BEFORE ESCALATION
        // This ensures both ResusMGR users and manually entered team members are preserved
        console.log("Saving all team members before ALS escalation:", validTeamMembers);
        
        for (const member of validTeamMembers) {
          if (member.name && member.role) {
            // Check if this member is already saved in the database
            const isAlreadySaved = sessionTeamMembers.some((existing: any) => 
              existing.name === member.name.trim() && existing.role === member.role.trim()
            );
            
            if (!isAlreadySaved) {
              console.log("Saving team member before escalation:", member);
              await saveTeamMemberMutation.mutateAsync({
                name: member.name.trim(),
                role: member.role.trim(),
                userId: member.userId,
                isResusMgrUser: member.isResusMgrUser || false
              });
            }
          }
        }
        
        // Wait for all saves to complete
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Update session with current CAD number before escalation
        if (customSessionId && customSessionId.trim()) {
          await updateCustomSessionIdMutation.mutateAsync(customSessionId.trim());
          // Wait for the session to be updated in the cache
          await new Promise(resolve => setTimeout(resolve, 500));
        }
        
        // Log ALS start intervention to continue the session
        console.log("ILS page - Logging ALS start intervention with data:", {
          sessionId,
          customSessionId,
          sessionCustomSessionId: session?.customSessionId,
          elapsedTime: formatTime(elapsedTime),
          sessionStartTime: session?.startTime,
          isRunning,
          teamMembersCount: validTeamMembers.length
        });
        
        await logInterventionMutation.mutateAsync({
          type: "ALS_START",
          description: "ALS protocol initiated - continuing from ILS",
          details: { 
            previousProtocol: "ILS",
            transitionTime: new Date().toISOString(),
            customSessionId: customSessionId || session?.customSessionId,
            cadNumber: customSessionId || session?.customSessionId,
            elapsedTime: formatTime(elapsedTime),
            originalStartTime: session?.startTime,
            teamMembersCount: validTeamMembers.length
          }
        });
        
        // Wait for intervention to be logged before navigation
        await new Promise(resolve => setTimeout(resolve, 300));
        
        // Force refresh session data before navigation
        queryClient.invalidateQueries({ queryKey: ['/api/sessions', sessionId] });
        queryClient.invalidateQueries({ queryKey: [`/api/sessions/${sessionId}/team-members`] });
        await queryClient.refetchQueries({ queryKey: ['/api/sessions', sessionId] });
        await new Promise(resolve => setTimeout(resolve, 200));
        
        // Navigate to ALS page with same session ID - session data will be preserved
        setLocation(`/als-adult/${sessionId}`);
        
        // Scroll to top after navigation
        setTimeout(() => window.scrollTo(0, 0), 100);
      } catch (error) {
        console.error("Failed to escalate to ALS:", error);
        toast({
          title: "Escalation Error",
          description: "Failed to update session during escalation",
          variant: "destructive",
        });
      }
    } else {
      // Create new session for ALS Adult if no existing session
      createSessionMutation.mutate({
        protocolType: "ALS",
        patientType: "Adult",
        customSessionId: customSessionId.trim() || undefined,
      });
    }
  };

  // iGel Size Selection Function
  const handleIgelSelection = (size: string) => {
    setSelectedIgelSize(size);
    setShowIgelSelection(false);
    // Log iGel intervention
    logInterventionMutation.mutate({
      type: "AIRWAY_SECURED",
      description: `Supraglottic Airway (iGel) & Airway Circuit - Size ${size}`,
      details: { igelSize: size, airwayType: "Supraglottic" }
    });
    toast({
      title: "Airway Secured",
      description: `iGel Size ${size} inserted successfully`,
      duration: 3000,
    });
    if (isAudioEnabled) {
      // Play confirmation beep
      const audioContext = new AudioContext();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      oscillator.frequency.setValueAtTime(600, audioContext.currentTime);
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      oscillator.start();
      oscillator.stop(audioContext.currentTime + 0.3);
    }
  };

  // Intervention selection handler
  const handleInterventionSelect = (type: string, description: string) => {
    setSelectedIntervention({ type, description });
    setShowInterventionDialog(true);
  };

  // Confirm intervention handler
  const handleInterventionConfirm = () => {
    if (!selectedIntervention || !selectedTeamMember || !sessionId) return;

    const currentIntervention = selectedIntervention;
    const currentTeamMember = selectedTeamMember;

    logInterventionMutation.mutate({
      type: selectedIntervention.type.toUpperCase().replace(/\s+/g, '_'),
      description: `${selectedIntervention.description} - Performed by ${selectedTeamMember}`,
      details: { 
        performedBy: selectedTeamMember,
        interventionType: selectedIntervention.type 
      }
    });

    // Update reversible causes state if this is a reversible cause
    if (selectedIntervention.type === 'reversible_cause') {
      setLoggedReversibleCauses(prev => new Set([...prev, selectedIntervention.description]));
    }
  };

  // New intervention confirmation handler for InterventionConfirmationDialog
  const handleInterventionConfirmationDialog = (details: any) => {
    if (!sessionId) return;

    const interventionData = {
      type: selectedInterventionType.toUpperCase().replace(/\s+/g, '_'),
      description: selectedInterventionName + (details.size ? ` - Size ${details.size}` : '') + ` - Performed by ${details.teamMember}`,
      details: {
        performedBy: details.teamMember,
        interventionType: selectedInterventionType,
        size: details.size,
        location: details.location,
        dose: details.dose,
        notes: details.notes
      }
    };

    logInterventionMutation.mutate(interventionData);

    toast({
      title: "Intervention Logged",
      description: `${selectedInterventionName} recorded successfully`,
      duration: 3000,
    });

    // Close dialog and reset states
    setShowConfirmationDialog(false);
    setSelectedInterventionType('');
    setSelectedInterventionName('');
  };

  // 2-minute prompt handling
  const handle2MinutePrompt = (action: 'compressions' | 'rhythm_check') => {
    setShowTwoMinutePrompt(false);
    setTwoMinuteTimer(120); // Reset timer
    
    if (action === 'compressions') {
      logInterventionMutation.mutate({
        type: "COMPRESSION_SWAP",
        description: "Team member rotation - compressions swapped",
        details: { protocol: blsStarted ? "BLS" : (ilsStarted ? "ILS" : "ALS") }
      });
      toast({
        title: "Compressions Swapped",
        description: "Team rotation completed",
        duration: 2000,
      });
    } else if (action === 'rhythm_check') {
      logInterventionMutation.mutate({
        type: "RHYTHM_CHECK",
        description: "2-minute rhythm analysis performed",
        details: { protocol: ilsStarted ? "ILS" : "ALS", timestamp: new Date().toISOString() }
      });
      toast({
        title: "Rhythm Check",
        description: "2-minute analysis completed",
        duration: 2000,
      });
    }
  };

  // EtCO2 monitoring handler
  const handleEtco2Log = () => {
    if (!etco2Value || !sessionId) return;
    
    const co2Value = parseFloat(etco2Value);
    if (isNaN(co2Value) || co2Value < 0) {
      toast({
        title: "Invalid Value",
        description: "Please enter a valid CO2 measurement",
        variant: "destructive",
      });
      return;
    }

    // Convert kPa to mmHg for status determination (1 kPa = 7.5 mmHg)
    const valueInMmHg = etco2Unit === "kPa" ? co2Value * 7.5 : co2Value;
    let status = "Normal";
    
    if (valueInMmHg < 35) {
      status = "Low";
    } else if (valueInMmHg > 40) {
      status = "High";
    }

    logInterventionMutation.mutate({
      type: "ETCO2_READING",
      description: `End Tidal CO2: ${etco2Value} ${etco2Unit} (${status})`,
      details: { 
        value: co2Value,
        unit: etco2Unit,
        status,
        timestamp: new Date().toISOString(),
        protocol: ilsStarted ? "ILS" : "ALS"
      }
    });
    
    setShowEtco2Dialog(false);
    setEtco2Value("");
    
    // Audio feedback
    if (isAudioEnabled) {
      const unitSpoken = etco2Unit === "mmHg" ? "millimeters of mercury" : "kilopascals";
      const utterance = new SpeechSynthesisUtterance(`End Tidal CO2 logged: ${etco2Value} ${unitSpoken}, status ${status}`);
      utterance.rate = 1.0;
      utterance.volume = 1.0;
      speechSynthesis.speak(utterance);
    }
    
    toast({
      title: "EtCO2 Logged",
      description: `CO2 reading: ${etco2Value} ${etco2Unit} (${status}) recorded`,
      duration: 3000,
    });
  };

  // Reversible cause handler with clinical readings
  const handleReversibleCauseSelect = (cause: string) => {
    setSelectedReversibleCause(cause);
    setShowReversibleCauseDialog(true);
  };

  // Process reversible cause with clinical reading
  const handleReversibleCauseSubmit = (reading: string) => {
    if (!reading || !selectedReversibleCause) return;

    let isAbnormal = false;
    let normalRange = "";
    let clinicalInterpretation = "";

    // Determine normal ranges and assess readings
    switch (selectedReversibleCause) {
      case 'Hypoxia':
        const spo2 = parseInt(reading);
        isAbnormal = spo2 < 95;
        normalRange = "95-100%";
        clinicalInterpretation = spo2 < 95 ? "CRITICALLY LOW - Immediate oxygen therapy required" : "Normal range";
        break;
      case 'Hypo/Hyperkalaemia':
        const glucose = parseFloat(reading);
        isAbnormal = glucose < 4.0 || glucose > 11.0;
        normalRange = "4.0-11.0 mmol/L";
        clinicalInterpretation = glucose < 4.0 ? "HYPOGLYCEMIC - Consider glucose administration" : 
                               glucose > 11.0 ? "HYPERGLYCEMIC - Monitor ketones" : "Normal range";
        break;
      case 'Hypothermia':
        const temp = parseFloat(reading);
        isAbnormal = temp < 35.0;
        normalRange = "36.0-37.5°C";
        clinicalInterpretation = temp < 35.0 ? "HYPOTHERMIC - Active rewarming required" : 
                               temp < 36.0 ? "Mild hypothermia - Monitor closely" : "Normal range";
        break;
      default:
        isAbnormal = false;
        clinicalInterpretation = "Reading logged";
    }

    // Store the reading and assessment
    setReversibleCauseReadings(prev => ({
      ...prev,
      [selectedReversibleCause]: { reading, isAbnormal }
    }));

    // Log the intervention with clinical details
    logInterventionMutation.mutate({
      type: "REVERSIBLE_CAUSE",
      description: `${selectedReversibleCause} assessed - ${clinicalInterpretation}`,
      details: { 
        cause: selectedReversibleCause,
        reading,
        normalRange,
        isAbnormal,
        interpretation: clinicalInterpretation,
        timestamp: new Date().toISOString(),
        protocol: ilsStarted ? "ILS" : "ALS"
      }
    });

    // Add to logged causes
    setLoggedReversibleCauses(prev => new Set(prev.add(selectedReversibleCause)));

    setShowReversibleCauseDialog(false);
    setSelectedReversibleCause("");

    toast({
      title: "Reversible Cause Assessed",
      description: `${selectedReversibleCause}: ${reading} - ${clinicalInterpretation}`,
      duration: 4000,
      variant: isAbnormal ? "destructive" : "default",
    });
  };

  // Check if protocol was already started in this session
  useEffect(() => {
    // Handle case where session might be an array (from wrong endpoint)
    const sessionObj = Array.isArray(session) ? session.find(s => s.id === sessionId) : session;
    
    if (sessionObj && !sessionObj.endTime) {
      // Check if any protocol was already started based on session interventions
      const hasBlsStart = interventions?.some((intervention: Intervention) => 
        intervention.type === "BLS_START"
      );
      const hasIlsStart = interventions?.some((intervention: Intervention) => 
        intervention.type === "ILS_START"
      );
      const hasAlsStart = interventions?.some((intervention: Intervention) => 
        intervention.type === "ALS_START"
      );
      
      if (hasBlsStart) setBlsStarted(true);
      if (hasIlsStart) setIlsStarted(true);
      if (hasAlsStart) setAlsStarted(true);
      
      // If any protocol was started, enable metronome and start timer
      if (hasBlsStart || hasIlsStart || hasAlsStart) {
        setMetronomeEnabled(true);
        setIsAudioEnabled(true); // Ensure audio is enabled for metronome to work
        if (!isRunning && sessionObj?.startTime) {
          const sessionStart = new Date(sessionObj.startTime).getTime();
          const now = Date.now();
          if (!isNaN(sessionStart) && sessionStart > 0) {
            const elapsed = Math.floor((now - sessionStart) / 1000);
            startTimer(elapsed);
          } else {
            startTimer(0);
          }
        }
      }
    }
  }, [session, interventions, isRunning, startTimer]);



  // Log intervention mutation
  const logInterventionMutation = useMutation({
    mutationFn: async (intervention: { type: string; description: string; details?: any }) => {
      if (!sessionId) {
        throw new Error("No session ID available");
      }
      

      
      const response = await apiRequest("POST", "/api/interventions", {
        sessionId,
        ...intervention,
        timeFromStart: elapsedTime,
      });
      return response.json();
    },
    onSuccess: (data) => {
      // Invalidate and refetch intervention data immediately
      queryClient.invalidateQueries({ queryKey: [`/api/sessions/${sessionId}/interventions`] });
      queryClient.refetchQueries({ queryKey: [`/api/sessions/${sessionId}/interventions`] });
      
      // Also trigger the refetch function
      if (refetchInterventions) {
        refetchInterventions();
      }

      // Handle dialog closing and audio feedback for intervention confirmations
      if (selectedIntervention && selectedTeamMember) {
        // Audio confirmation is now handled by InterventionConfirmationDialog

        // Show brief confirmation popup
        setConfirmationMessage(`${selectedIntervention.description} logged for ${selectedTeamMember}`);
        setShowInterventionConfirm(true);

        // Reset intervention dialog state
        setShowInterventionDialog(false);
        setSelectedIntervention(null);
        setSelectedTeamMember("");
      }
      
      toast({
        title: "Intervention Logged",
        description: "Intervention has been recorded with timestamp",
        duration: 3000,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: `Failed to log intervention: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // End session mutation
  const endSessionMutation = useMutation({
    mutationFn: async ({ outcome, notes }: { outcome: string; notes?: string }) => {
      const response = await apiRequest("PUT", `/api/sessions/${sessionId}/end`, {
        outcome,
        notes,
      });
      return response.json();
    },
    onSuccess: () => {
      stopTimer();
      toast({
        title: "Session Ended",
        description: `Resuscitation session completed with outcome: ${sessionOutcome}`,
      });
      // Redirect to dashboard
      window.location.href = "/";
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to end session",
        variant: "destructive",
      });
    },
  });

  // Notification creation mutation for scope violations
  const createNotificationMutation = useMutation({
    mutationFn: async (notification: { type: string; title: string; message: string; priority: string }) => {
      const response = await fetch("/api/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(notification),
      });
      if (!response.ok) throw new Error("Failed to create notification");
      return response.json();
    },
    onError: (error: any) => {
      console.error("Failed to create notification:", error);
    },
  });

  const handleIntervention = (type: string, description: string, details?: any) => {
    logInterventionMutation.mutate({ type, description, details });
    
    // Play audio confirmation if enabled
    if (isAudioEnabled) {
      const audio = new Audio();
      audio.src = `data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmEaBSuPzfPQfesEKH/L7dQzAAM=`; // Simple beep sound
      audio.play().catch(() => {}); // Ignore errors if audio fails
    }
  };

  const handleEndSession = () => {
    if (!sessionOutcome) {
      toast({
        title: "Select Outcome",
        description: "Please select ROSC or ROLE outcome before ending session",
        variant: "destructive",
      });
      return;
    }
    
    // Combine session notes with additional notes from the card
    const combinedNotes = [
      sessionNotes,
      additionalNotes && `Additional Notes: ${additionalNotes}`
    ].filter(Boolean).join('\n\n');
    
    endSessionMutation.mutate({ outcome: sessionOutcome, notes: combinedNotes });
    setShowEndSessionDialog(false);
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`;
  };

  // Skip loading screen for faster emergency response

  // Only show "Session Not Found" if we have a sessionId but can't find the session
  if (sessionId && !session && !isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="max-w-md w-full mx-4">
          <CardContent className="pt-6 text-center">
            <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Session Not Found</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              The resuscitation session could not be found or has been ended.
            </p>
            <Button onClick={() => setLocation("/")}>
              Return to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (session && session.endTime) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="max-w-md w-full mx-4">
          <CardContent className="pt-6 text-center">
            <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Session Completed</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              This resuscitation session has been completed with outcome: <strong>{session.outcome}</strong>
            </p>
            <Button onClick={() => window.location.href = "/"}>
              Return to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navigation />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Session Header */}
        <Card className="mb-8 border-orange-200 bg-orange-50 dark:bg-orange-900/20">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-orange-900 dark:text-orange-100 mb-2">
                  {alsStarted ? "ALS Adult Resus" : "ILS Adult Resus"}
                </h1>
                {(blsStarted || ilsStarted || alsStarted) && (
                  <p className="text-orange-700 dark:text-orange-300">
                    Resus Started: {(blsStartTime || (session && new Date(session.startTime))).toLocaleString("en-GB", { 
                      year: "numeric",
                      month: "2-digit",
                      day: "2-digit",
                      hour: "2-digit", 
                      minute: "2-digit",
                      second: "2-digit",
                      timeZone: "GMT"
                    })} GMT
                  </p>
                )}

              </div>
              <div className="flex space-x-4">
                <Button
                  variant="outline"
                  onClick={() => setLocation("/")}
                  className="border-blue-300 text-blue-700 hover:bg-blue-100"
                >
                  <Home className="w-4 h-4 mr-2" />
                  Return to Dashboard
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setIsAudioEnabled(!isAudioEnabled)}
                  className="border-orange-300 text-orange-700 hover:bg-orange-100"
                >
                  {isAudioEnabled ? <Volume2 className="w-4 h-4 mr-2" /> : <VolumeX className="w-4 h-4 mr-2" />}
                  {isAudioEnabled ? "Mute" : "Unmute"}
                </Button>
                <Button 
                  onClick={() => setShowEndSessionDialog(true)}
                  disabled={!blsStarted && !ilsStarted}
                  className={`${
                    (blsStarted || ilsStarted)
                      ? "bg-red-600 text-white hover:bg-red-700" 
                      : "bg-gray-400 text-gray-200 cursor-not-allowed"
                  }`}
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  End Resuscitation
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CAD Number / Patient Initials Section - Always visible */}
        <Card className="mb-8 border-purple-200 bg-purple-50 dark:bg-purple-900/20">
          <CardHeader>
            <CardTitle className="text-lg text-purple-900 dark:text-purple-100 flex items-center">
              <FileText className="w-5 h-5 mr-2" />
              Session Information (Required)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">
                  Enter CAD Number or Patient Initials
                </label>
                <Input
                  type="text"
                  placeholder="e.g., CAD12345 or AB"
                  value={customSessionId}
                  onChange={(e) => {
                    const newValue = e.target.value;
                    setCustomSessionId(newValue);
                    
                    // If we have an active session, save the custom ID instantly
                    if (sessionId && newValue.trim()) {
                      // Clear any existing timeout
                      clearTimeout((window as any).customSessionIdTimeout);
                      // Save immediately for instant availability during escalations
                      updateCustomSessionIdMutation.mutate(newValue.trim());
                    }
                  }}
                  maxLength={50}
                  className="border-purple-300 focus:border-purple-500 focus:ring-purple-500"
                />
              </div>
              <Alert className="border-amber-300 bg-amber-50 dark:bg-amber-900/20">
                <AlertTriangle className="h-4 w-4 text-amber-600" />
                <AlertDescription className="text-amber-700 dark:text-amber-300 text-sm">
                  <strong>Patient Data Warning:</strong> Do not enter any personal identifiable information (PII) 
                  such as full names, NHS numbers, or addresses. Use CAD numbers or initials only for clinical tracking purposes.
                </AlertDescription>
              </Alert>
            </div>
          </CardContent>
        </Card>

        {/* Enhanced Team Management - always visible */}
        <div className="mb-8">
          <PreSessionTeamManager 
            onTeamMembersChange={(members) => {
              setLocalTeamMembers(members);
            }}
            initialMembers={teamMembers}
          />
        </div>



        {/* Protocol Start Buttons */}
        {!blsStarted && !ilsStarted && !alsStarted && (
          <Card className="mb-8 border-red-200 bg-red-50 dark:bg-red-900/20">
            <CardContent className="pt-8 pb-8 text-center">
              {validTeamMembers.length === 0 && (
                <Alert className="mb-6 border-amber-300 bg-amber-50 dark:bg-amber-900/20">
                  <AlertTriangle className="h-4 w-4 text-amber-600" />
                  <AlertDescription className="text-amber-700 dark:text-amber-300">
                    You must add at least one team member before starting resuscitation
                  </AlertDescription>
                </Alert>
              )}
              <div className="space-y-4">
                <Button
                  onClick={handleStartBLS}
                  disabled={validTeamMembers.length === 0}
                  size="lg"
                  className={`px-12 py-6 text-xl font-bold shadow-xl transition-all duration-200 w-full ${
                    validTeamMembers.length === 0 
                      ? "bg-gray-400 text-gray-600 cursor-not-allowed"
                      : "bg-red-600 hover:bg-red-700 text-white hover:shadow-2xl transform hover:scale-105"
                  }`}
                >
                  <Zap className="w-8 h-8 mr-4 animate-pulse" />
                  START ADULT ILS
                </Button>
              </div>
              <p className="text-red-600 dark:text-red-400 mt-2 text-base font-medium">
                Users must work to their level of training and scope of practice
              </p>
            </CardContent>
          </Card>
        )}



        {/* Protocol Escalation Button - ALS only since this is already ILS */}
        {!alsStarted && (
          <Card className={`mb-8 ${
            blsStarted 
              ? "border-red-200 bg-red-50 dark:bg-red-900/20" 
              : "border-gray-200 bg-gray-50 dark:bg-gray-900/20 opacity-60"
          }`}>
            <CardContent className="pt-6 pb-6 text-center">
              <div className="flex justify-center">
                <Button
                  onClick={(blsStarted || ilsStarted) ? handleStartALS : undefined}
                  disabled={!(blsStarted || ilsStarted)}
                  size="lg"
                  className={
                    (blsStarted || ilsStarted)
                      ? "bg-purple-600 hover:bg-purple-700 text-white px-8 py-4 text-lg font-bold shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105"
                      : "bg-gray-400 text-gray-600 px-8 py-4 text-lg font-bold cursor-not-allowed"
                  }
                >
                  <Zap className="w-6 h-6 mr-3" />
                  CHANGE TO ALS
                  {!(blsStarted || ilsStarted) && (
                    <span className="ml-2 text-xs bg-gray-200 dark:bg-gray-700 px-2 py-1 rounded">
                      Start resus first
                    </span>
                  )}
                </Button>
              </div>
              <p className={`mt-3 text-base ${
                blsStarted 
                  ? "text-red-700 dark:text-red-300" 
                  : "text-gray-500 dark:text-gray-400"
              }`}>
                Escalate to Advanced Life Support when additional resources arrive
              </p>
            </CardContent>
          </Card>
        )}



        {/* Main Protocol Layout - Standardized Design */}
        <div className="grid grid-cols-1 xl:grid-cols-9 gap-6">
          {/* Left Sidebar - Timer & Metronome */}
          <div className="xl:col-span-3 space-y-6">
            {/* Primary Timer Card */}
            <Card className="medical-card border-blue-200 bg-blue-50 dark:bg-blue-900/20">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center text-lg font-semibold text-blue-800 dark:text-blue-200">
                  <Clock className="w-5 h-5 mr-2" />
                  Resuscitation Timer
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Timer elapsedTime={elapsedTime} />
                
                {/* 2-Minute Countdown Timer */}
                {(blsStarted || ilsStarted || alsStarted) && (
                  <div className="border-t border-blue-300 pt-4">
                    <div className="flex items-center justify-center mb-2">
                      <AlertTriangle className="w-4 h-4 mr-2 text-orange-600" />
                      <span className="font-medium text-orange-700 dark:text-orange-300">2-Minute Timer</span>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-orange-700 dark:text-orange-300 mb-1">
                        {Math.floor(twoMinuteTimer / 60)}:{(twoMinuteTimer % 60).toString().padStart(2, '0')}
                      </div>
                      <p className="text-sm text-orange-600 dark:text-orange-400">
                        {blsStarted && !ilsStarted && !alsStarted ? "Next: Swap compressions" : "Next: Check rhythm & swap"}
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>



            {/* Metronome Card */}
            <Card className="medical-card border-red-200 bg-red-50 dark:bg-red-900/20">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center text-lg font-semibold text-red-800 dark:text-red-200">
                  <Heart className="w-5 h-5 mr-2" />
                  CPR Metronome 
                  {blsStarted && !lucasActive && (
                    <Badge className={`ml-2 ${
                      currentBpm === 120 ? 'bg-green-600' : 
                      currentBpm === 110 ? 'bg-orange-600' : 
                      'bg-red-600'
                    }`}>
                      {currentBpm} BPM
                    </Badge>
                  )}
                  {lucasActive && (
                    <Badge className="ml-2 bg-purple-600">
                      LUCAS Device Active
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {(blsStarted || ilsStarted) ? (
                  <div className="space-y-4">
                    {lucasActive ? (
                      <div className="text-center py-8">
                        <Activity className="w-12 h-12 mx-auto mb-4 text-purple-600" />
                        <p className="text-purple-700 dark:text-purple-300 font-semibold">
                          LUCAS device in use by {lucasOperator}
                        </p>
                        <p className="text-sm text-purple-600 dark:text-purple-400 mt-2">
                          Mechanical compressions active
                        </p>
                        <Button
                          onClick={() => {
                            setLucasActive(false);
                            setMetronomeEnabled(true);
                            
                            // Log intervention for stopping LUCAS
                            logInterventionMutation.mutate({
                              type: "LUCAS_DEVICE",
                              description: `LUCAS device stopped - Resumed manual CPR`,
                              details: { 
                                operator: lucasOperator,
                                action: "stopped",
                                resumedManualCPR: true,
                                timestamp: new Date().toISOString()
                              }
                            });

                            toast({
                              title: "LUCAS Device Stopped",
                              description: "Manual CPR resumed - Metronome reactivated",
                              duration: 3000,
                            });

                            setLucasOperator("");
                          }}
                          className="mt-4 bg-red-600 hover:bg-red-700 text-white"
                          size="sm"
                        >
                          Stop LUCAS & Resume Manual CPR
                        </Button>
                      </div>
                    ) : (
                      <Metronome 
                        isEnabled={metronomeEnabled && isAudioEnabled && !lucasActive}
                        onBeatChange={(beat) => {
                          if (beat && metronomeEnabled && isAudioEnabled && !lucasActive) {
                            document.body.style.backgroundColor = "rgba(239, 68, 68, 0.1)";
                            setTimeout(() => {
                              document.body.style.backgroundColor = "";
                            }, 100);
                          }
                        }}
                        onBpmChange={(bpm) => {
                          setCurrentBpm(bpm);
                        }}
                      />
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    <Heart className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Metronome starts when BLS begins</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* EtCO2 Monitoring Card */}
            <Card className={`medical-card ${
              (ilsStarted || alsStarted)
                ? "border-blue-200 bg-blue-50 dark:bg-blue-900/20"
                : "border-gray-200 bg-gray-50 dark:bg-gray-900/20 opacity-60"
            }`}>
              <CardHeader className="pb-3">
                <CardTitle className={`flex items-center text-lg font-semibold ${
                  (ilsStarted || alsStarted)
                    ? "text-blue-800 dark:text-blue-200"
                    : "text-gray-500 dark:text-gray-400"
                }`}>
                  <Activity className="w-5 h-5 mr-2" />
                  End Tidal CO2 (EtCO2)
                  {!(ilsStarted || alsStarted) && (
                    <Badge variant="secondary" className="ml-2 bg-gray-200 text-gray-600 text-xs">
                      ILS/ALS only
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {(ilsStarted || alsStarted) ? (
                  <div className="space-y-4">
                    <Button
                      onClick={() => setShowEtco2Dialog(true)}
                      size="lg"
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      <Activity className="w-5 h-5 mr-2" />
                      Log CO2 Reading
                    </Button>
                    <div className="text-center text-sm text-blue-700 dark:text-blue-300">
                      <p>Normal Range: 35-45 mmHg</p>
                      <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                        Capnography provides continuous monitoring
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    <Activity className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>EtCO2 monitoring available in ILS/ALS</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Center Content - Main Protocol Actions */}
          <div className="xl:col-span-6 space-y-6">




            {/* Emergency Interventions Card */}
            <Card className={`medical-card ${
              (blsStarted || ilsStarted || alsStarted)
                ? "border-green-200 bg-green-50 dark:bg-green-900/20"
                : "border-gray-200 bg-gray-50 dark:bg-gray-900/20"
            }`}>
              <CardHeader className="pb-3">
                <CardTitle className={`flex items-center text-lg font-semibold ${
                  (blsStarted || ilsStarted || alsStarted)
                    ? "text-green-800 dark:text-green-200"
                    : "text-gray-500 dark:text-gray-400"
                }`}>
                  <Activity className="w-5 h-5 mr-2" />
                  Emergency Interventions
                  {!(blsStarted || ilsStarted || alsStarted) && (
                    <Badge variant="secondary" className="ml-2 bg-gray-200 text-gray-600 text-xs">
                      Available after protocol start
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Record Airway Intervention */}
                <div className="space-y-2">
                  <label className={`text-sm font-medium ${
                    (blsStarted || ilsStarted || alsStarted)
                      ? "text-green-700 dark:text-green-300"
                      : "text-gray-500 dark:text-gray-400"
                  }`}>
                    Record Airway Intervention
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      onClick={() => {
                        if (blsStarted || ilsStarted || alsStarted) {
                          setSelectedInterventionType('OP Airway');
                          setSelectedInterventionName('Oropharyngeal Airway');
                          setShowConfirmationDialog(true);
                        }
                      }}
                      variant="outline"
                      disabled={!(blsStarted || ilsStarted || alsStarted)}
                      className={
                        (blsStarted || ilsStarted || alsStarted)
                          ? "border-green-300 text-green-700 hover:bg-green-100 dark:hover:bg-green-900/30"
                          : "border-gray-300 text-gray-500 cursor-not-allowed"
                      }
                    >
                      OP Airway
                    </Button>
                    <Button
                      onClick={() => {
                        if (blsStarted || ilsStarted || alsStarted) {
                          setSelectedInterventionType('NP Airway');
                          setSelectedInterventionName('Nasopharyngeal Airway');
                          setShowConfirmationDialog(true);
                        }
                      }}
                      variant="outline"
                      disabled={!(blsStarted || ilsStarted || alsStarted)}
                      className={
                        (blsStarted || ilsStarted || alsStarted)
                          ? "border-green-300 text-green-700 hover:bg-green-100 dark:hover:bg-green-900/30"
                          : "border-gray-300 text-gray-500 cursor-not-allowed"
                      }
                    >
                      NP Airway
                    </Button>
                    <Button
                      onClick={() => {
                        if (blsStarted || ilsStarted || alsStarted) {
                          setSelectedInterventionType('iGel Airway');
                          setSelectedInterventionName('iGel Airway');
                          setShowConfirmationDialog(true);
                        }
                      }}
                      variant="outline"
                      disabled={!(blsStarted || ilsStarted || alsStarted)}
                      className={
                        (blsStarted || ilsStarted || alsStarted)
                          ? "border-green-300 text-green-700 hover:bg-green-100 dark:hover:bg-green-900/30"
                          : "border-gray-300 text-gray-500 cursor-not-allowed"
                      }
                    >
                      iGel Airway
                    </Button>
                  </div>
                </div>

                {/* Record Drug Intervention */}
                <div className="space-y-2">
                  <label className={`text-sm font-medium ${
                    (blsStarted || ilsStarted || alsStarted)
                      ? "text-green-700 dark:text-green-300"
                      : "text-gray-500 dark:text-gray-400"
                  }`}>
                    Record Drug Intervention
                  </label>
                  <div className="grid grid-cols-1 gap-2">
                    <Button
                      onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('drug', 'Oxygen 15ltr/min')}
                      variant="outline"
                      disabled={!(blsStarted || ilsStarted || alsStarted)}
                      className={
                        (blsStarted || ilsStarted || alsStarted)
                          ? "border-green-300 text-green-700 hover:bg-green-100 dark:hover:bg-green-900/30"
                          : "border-gray-300 text-gray-500 cursor-not-allowed"
                      }
                    >
                      <Pill className="w-4 h-4 mr-2" />
                      Oxygen 15ltr/min
                    </Button>
                  </div>
                </div>

                {/* Record Shock Delivery */}
                <div className="space-y-2">
                  <label className={`text-sm font-medium ${
                    (blsStarted || ilsStarted || alsStarted)
                      ? "text-green-700 dark:text-green-300"
                      : "text-gray-500 dark:text-gray-400"
                  }`}>
                    Record Shock Delivery
                  </label>
                  <div className="grid grid-cols-1 gap-2">
                    <Button
                      onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('shock', 'Shock Delivered')}
                      variant="outline"
                      disabled={!(blsStarted || ilsStarted || alsStarted)}
                      className={
                        (blsStarted || ilsStarted || alsStarted)
                          ? "border-green-300 text-green-700 hover:bg-green-100 dark:hover:bg-green-900/30"
                          : "border-gray-300 text-gray-500 cursor-not-allowed"
                      }
                    >
                      <Zap className="w-4 h-4 mr-2" />
                      Shock Delivered
                    </Button>
                  </div>
                </div>

                {/* LUCAS Device - ILS/ALS Only */}
                {(ilsStarted || alsStarted) && (
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-purple-700 dark:text-purple-300">
                      LUCAS Device (ILS/ALS)
                    </label>
                    <div className="grid grid-cols-1 gap-2">
                      <Button
                        onClick={() => setShowLucasConfirmDialog(true)}
                        variant="outline"
                        disabled={lucasActive}
                        className={
                          lucasActive
                            ? "border-gray-300 text-gray-500 cursor-not-allowed"
                            : "border-purple-300 text-purple-700 hover:bg-purple-100 dark:hover:bg-purple-900/30"
                        }
                      >
                        <Activity className="w-4 h-4 mr-2" />
                        {lucasActive ? "LUCAS Device Active" : "Deploy LUCAS Device"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Sidebar - Moved intervention log to bottom */}
          <div className="xl:col-span-3 space-y-6">

            {/* Reversible Causes Checklist - Always visible but greyed out until session starts */}
            <Card className={`medical-card ${
              (blsStarted || ilsStarted || alsStarted)
                ? "border-red-200 bg-red-50 dark:bg-red-900/20"
                : "border-gray-200 bg-gray-50 dark:bg-gray-900/20 opacity-60"
            }`}>
              <CardHeader className="pb-3">
                <CardTitle className={`flex items-center text-lg font-semibold ${
                  (blsStarted || ilsStarted || alsStarted)
                    ? "text-red-800 dark:text-red-200"
                    : "text-gray-500 dark:text-gray-400"
                }`}>
                  <AlertTriangle className="w-5 h-5 mr-2" />
                  Reversible Causes (4 Hs & 4 Ts)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className={`font-semibold mb-2 ${
                      (blsStarted || ilsStarted || alsStarted)
                        ? "text-red-700 dark:text-red-300"
                        : "text-gray-500 dark:text-gray-400"
                    }`}>4 Hs</h4>
                    <div className="space-y-2">
                      {['Hypoxia', 'Hypovolaemia', 'Hypo/Hyperkalaemia', 'Hypothermia'].map((cause) => (
                        <Button
                          key={cause}
                          variant="outline"
                          size="sm"
                          onClick={() => (blsStarted || ilsStarted || alsStarted) && handleReversibleCauseSelect(cause)}
                          disabled={!(blsStarted || ilsStarted || alsStarted)}
                          className={`w-full text-left justify-start ${
                            loggedReversibleCauses.has(cause)
                              ? reversibleCauseReadings[cause]?.isAbnormal
                                ? "border-red-400 bg-red-100 text-red-800 hover:bg-red-200 dark:bg-red-900/30 dark:text-red-300 dark:border-red-600 shadow-md ring-2 ring-red-300"
                                : "border-green-400 bg-green-100 text-green-800 hover:bg-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-600"
                              : (blsStarted || ilsStarted || alsStarted)
                              ? "border-red-300 text-red-700 hover:bg-red-100 dark:hover:bg-red-900/30"
                              : "border-gray-300 text-gray-500 cursor-not-allowed"
                          }`}
                        >
                          {cause}
                          {loggedReversibleCauses.has(cause) && reversibleCauseReadings[cause] && (
                            <span className="ml-1 text-xs">
                              ({reversibleCauseReadings[cause].reading})
                            </span>
                          )}
                        </Button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className={`font-semibold mb-2 ${
                      (blsStarted || ilsStarted || alsStarted)
                        ? "text-red-700 dark:text-red-300"
                        : "text-gray-500 dark:text-gray-400"
                    }`}>4 Ts</h4>
                    <div className="space-y-2">
                      {['Thrombosis', 'Tension Pneumothorax', 'Tamponade', 'Toxins'].map((cause) => (
                        <Button
                          key={cause}
                          variant="outline"
                          size="sm"
                          onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('reversible_cause', cause)}
                          disabled={!(blsStarted || ilsStarted || alsStarted)}
                          className={`w-full text-left justify-start ${
                            loggedReversibleCauses.has(cause)
                              ? "border-green-400 bg-green-100 text-green-800 hover:bg-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-600"
                              : (blsStarted || ilsStarted || alsStarted)
                              ? "border-red-300 text-red-700 hover:bg-red-100 dark:hover:bg-red-900/30"
                              : "border-gray-300 text-gray-500 cursor-not-allowed"
                          }`}
                        >
                          {cause}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Rhythm Analysis Card - Always visible but greyed out until session starts */}
            <Card className={`medical-card ${
              (blsStarted || ilsStarted || alsStarted)
                ? "border-blue-200 bg-blue-50 dark:bg-blue-900/20"
                : "border-gray-200 bg-gray-50 dark:bg-gray-900/20 opacity-60"
            }`}>
              <CardHeader className="pb-3">
                <CardTitle className={`flex items-center text-lg font-semibold ${
                  (blsStarted || ilsStarted || alsStarted)
                    ? "text-blue-800 dark:text-blue-200"
                    : "text-gray-500 dark:text-gray-400"
                }`}>
                  <Activity className="w-5 h-5 mr-2" />
                  Rhythm Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {/* Shockable Rhythms */}
                  <div>
                    <h4 className={`text-sm font-semibold mb-2 ${
                      (blsStarted || ilsStarted || alsStarted)
                        ? "text-red-700 dark:text-red-300"
                        : "text-gray-500 dark:text-gray-400"
                    }`}>
                      Shockable Rhythms
                    </h4>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('rhythm', 'VF (Ventricular Fibrillation)')}
                        variant="outline"
                        disabled={!(blsStarted || ilsStarted || alsStarted)}
                        className={
                          (blsStarted || ilsStarted || alsStarted)
                            ? "border-red-300 text-red-700 hover:bg-red-100 dark:hover:bg-red-900/30 text-xs"
                            : "border-gray-300 text-gray-500 cursor-not-allowed text-xs"
                        }
                      >
                        <Zap className="w-4 h-4 mr-1" />
                        VF
                      </Button>
                      <Button
                        onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('rhythm', 'VT (Ventricular Tachycardia)')}
                        variant="outline"
                        disabled={!(blsStarted || ilsStarted || alsStarted)}
                        className={
                          (blsStarted || ilsStarted || alsStarted)
                            ? "border-red-300 text-red-700 hover:bg-red-100 dark:hover:bg-red-900/30 text-xs"
                            : "border-gray-300 text-gray-500 cursor-not-allowed text-xs"
                        }
                      >
                        <Zap className="w-4 h-4 mr-1" />
                        VT
                      </Button>
                    </div>
                  </div>

                  {/* Non-Shockable Rhythms */}
                  <div>
                    <h4 className={`text-sm font-semibold mb-2 ${
                      (blsStarted || ilsStarted || alsStarted)
                        ? "text-blue-700 dark:text-blue-300"
                        : "text-gray-500 dark:text-gray-400"
                    }`}>
                      Non-Shockable Rhythms
                    </h4>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('rhythm', 'PEA (Pulseless Electrical Activity)')}
                        variant="outline"
                        disabled={!(blsStarted || ilsStarted || alsStarted)}
                        className={
                          (blsStarted || ilsStarted || alsStarted)
                            ? "border-blue-300 text-blue-700 hover:bg-blue-100 dark:hover:bg-blue-900/30 text-xs"
                            : "border-gray-300 text-gray-500 cursor-not-allowed text-xs"
                        }
                      >
                        <Heart className="w-4 h-4 mr-1" />
                        PEA
                      </Button>
                      <Button
                        onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('rhythm', 'Asystole')}
                        variant="outline"
                        disabled={!(blsStarted || ilsStarted || alsStarted)}
                        className={
                          (blsStarted || ilsStarted || alsStarted)
                            ? "border-blue-300 text-blue-700 hover:bg-blue-100 dark:hover:bg-blue-900/30 text-xs"
                            : "border-gray-300 text-gray-500 cursor-not-allowed text-xs"
                        }
                      >
                        <Heart className="w-4 h-4 mr-1" />
                        Asystole
                      </Button>
                    </div>
                  </div>

                  {/* ROSC Button */}
                  <div className="pt-2">
                    <Button
                      onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('rhythm', 'ROSC Achieved')}
                      variant="outline"
                      disabled={!(blsStarted || ilsStarted || alsStarted)}
                      className={`w-full ${
                        (blsStarted || ilsStarted || alsStarted)
                          ? "border-green-300 text-green-700 hover:bg-green-100 dark:hover:bg-green-900/30"
                          : "border-gray-300 text-gray-500 cursor-not-allowed"
                      }`}
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      ROSC Achieved
                    </Button>
                  </div>

                </div>
              </CardContent>
            </Card>

            {/* Additional Notes Card */}
            <Card className="border-2 border-blue-200 bg-blue-50 dark:bg-blue-900/20 dark:border-blue-800">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center text-blue-700 dark:text-blue-300">
                  <FileText className="w-5 h-5 mr-2" />
                  Additional Notes
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-blue-700 dark:text-blue-300">
                    Notes for Summary Report
                  </label>
                  <textarea
                    value={additionalNotes}
                    onChange={(e) => setAdditionalNotes(e.target.value)}
                    placeholder="Add any additional notes about the resuscitation (clinical observations, team performance, equipment issues, etc.)"
                    className="w-full p-3 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 dark:border-blue-600"
                    rows={4}
                  />
                  <p className="text-xs text-blue-600 dark:text-blue-400">
                    These notes will be included in the final summary report
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* CPR Rhythm Check Alert */}
        {elapsedTime > 0 && elapsedTime % 120 === 0 && (
          <Alert className="fixed bottom-4 right-4 w-80 border-orange-200 bg-orange-50 animate-pulse">
            <Heart className="w-4 h-4" />
            <AlertDescription className="font-semibold">
              2-minute CPR cycle complete - Check rhythm and swap team members
            </AlertDescription>
          </Alert>
        )}
      </main>

      {/* 2-Minute Prompt Modal */}
      {showTwoMinutePrompt && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <Card className="max-w-md w-full border-orange-200 bg-orange-50 dark:bg-orange-900/20">
            <CardHeader>
              <CardTitle className="text-xl text-center text-orange-700 dark:text-orange-300">
                <AlertTriangle className="w-6 h-6 mx-auto mb-2" />
                2-Minute Timer Alert
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-center text-orange-700 dark:text-orange-300 font-semibold">
                {blsStarted && !ilsStarted && !alsStarted 
                  ? "Time to swap compressions!" 
                  : "Time to check rhythm and swap compressions!"}
              </p>
              
              <div className="space-y-3">
                <Button
                  onClick={() => handle2MinutePrompt('compressions')}
                  className="w-full bg-orange-600 hover:bg-orange-700 text-white"
                  size="lg"
                >
                  <Heart className="w-5 h-5 mr-2" />
                  Compressions Swapped
                </Button>
                
                {(ilsStarted || alsStarted) && (
                  <Button
                    onClick={() => handle2MinutePrompt('rhythm_check')}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                    size="lg"
                  >
                    <Stethoscope className="w-5 h-5 mr-2" />
                    Rhythm Check Completed
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* iGel Size Selection Modal */}
      {showIgelSelection && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <Card className="max-w-md w-full">
            <CardHeader>
              <CardTitle className="text-xl text-center">
                Select iGel Size
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-center text-gray-600 dark:text-gray-400 mb-4">
                Choose appropriate iGel supraglottic airway size:
              </p>
              
              <div className="grid grid-cols-2 gap-3">
                {["Size 3", "Size 4", "Size 5"].map((size) => (
                  <Button
                    key={size}
                    onClick={() => handleIgelSelection(size)}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                    size="lg"
                  >
                    {size}
                  </Button>
                ))}
              </div>
              
              <Button
                onClick={() => setShowIgelSelection(false)}
                variant="outline"
                className="w-full mt-4"
              >
                Cancel
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* End Session Dialog */}
      {showEndSessionDialog && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <Card className="max-w-md w-full">
            <CardHeader>
              <CardTitle className="text-xl text-center">End Resuscitation Session</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Session Outcome
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    variant={sessionOutcome === "ROSC" ? "default" : "outline"}
                    onClick={() => setSessionOutcome("ROSC")}
                    className={sessionOutcome === "ROSC" ? "btn-medical-green" : ""}
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    ROSC
                  </Button>
                  <Button
                    variant={sessionOutcome === "ROLE" ? "default" : "outline"}
                    onClick={() => setSessionOutcome("ROLE")}
                    className={sessionOutcome === "ROLE" ? "btn-medical-red" : ""}
                  >
                    <XCircle className="w-4 h-4 mr-2" />
                    ROLE
                  </Button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                  Additional Notes (Optional)
                </label>
                <textarea
                  value={sessionNotes}
                  onChange={(e) => setSessionNotes(e.target.value)}
                  placeholder="Enter any additional notes about the resuscitation..."
                  className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  rows={3}
                />
              </div>

              <Separator />

              <div className="flex space-x-3">
                <Button
                  variant="outline"
                  onClick={() => setShowEndSessionDialog(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleEndSession}
                  disabled={!sessionOutcome || endSessionMutation.isPending}
                  className="flex-1 btn-medical-red"
                >
                  {endSessionMutation.isPending ? "Ending..." : "End Session"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Intervention Confirmation Dialog */}
      <Dialog open={showInterventionDialog} onOpenChange={setShowInterventionDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm Intervention</DialogTitle>
            <DialogDescription>
              Please confirm the intervention details and select which team member performed it.
            </DialogDescription>
          </DialogHeader>
          
          {selectedIntervention && (
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <h4 className="font-semibold text-blue-900 dark:text-blue-100">
                  {selectedIntervention.type}
                </h4>
                <p className="text-blue-700 dark:text-blue-300 text-sm">
                  {selectedIntervention.description}
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Performed by:
                </label>
                <Select value={selectedTeamMember} onValueChange={setSelectedTeamMember}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select team member" />
                  </SelectTrigger>
                  <SelectContent>
                    {sessionTeamMembers.map((member: any, index: number) => (
                      <SelectItem key={index} value={member.name}>
                        {member.name} ({member.role})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowInterventionDialog(false);
                setSelectedIntervention(null);
                setSelectedTeamMember("");
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleInterventionConfirm}
              disabled={!selectedTeamMember || logInterventionMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {logInterventionMutation.isPending ? "Recording..." : "Confirm & Record"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* EtCO2 Input Dialog */}
      <Dialog open={showEtco2Dialog} onOpenChange={setShowEtco2Dialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Log End Tidal CO2 (EtCO2)</DialogTitle>
            <DialogDescription>
              Enter the CO2 measurement from capnography monitoring.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
                Normal Range: 35-40 mmHg or 4.0-5.7 kPa
              </h4>
              <p className="text-blue-700 dark:text-blue-300 text-sm">
                EtCO2 monitoring provides continuous feedback on patient circulation and ventilation effectiveness.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  CO2 Reading:
                </label>
                <input
                  type="number"
                  value={etco2Value}
                  onChange={(e) => setEtco2Value(e.target.value)}
                  placeholder={`Enter CO2 value in ${etco2Unit}`}
                  min="0"
                  max={etco2Unit === "mmHg" ? "200" : "30"}
                  step={etco2Unit === "mmHg" ? "0.1" : "0.01"}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">
                  Unit:
                </label>
                <select
                  value={etco2Unit}
                  onChange={(e) => setEtco2Unit(e.target.value as "mmHg" | "kPa")}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="mmHg">mmHg</option>
                  <option value="kPa">kPa</option>
                </select>
              </div>
            </div>
          </div>

          <DialogFooter className="flex space-x-2">
            <Button
              variant="outline"
              onClick={() => {
                setShowEtco2Dialog(false);
                setEtco2Value("");
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleEtco2Log}
              disabled={!etco2Value || logInterventionMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {logInterventionMutation.isPending ? "Logging..." : "Log Reading"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Intervention Confirmation Popup */}
      {showInterventionConfirm && (
        <div className="fixed top-4 right-4 z-50">
          <Card className="bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
            <CardContent className="p-4 flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
              <span className="text-green-800 dark:text-green-200 font-medium">
                {confirmationMessage}
              </span>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Rhythm Check Dialog */}
      <Dialog open={showRhythmCheckDialog} onOpenChange={setShowRhythmCheckDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center text-blue-600">
              <Activity className="w-5 h-5 mr-2" />
              Rhythm Check
            </DialogTitle>
            <DialogDescription>
              Please select the observed cardiac rhythm and log it for clinical documentation.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Select Rhythm:</label>
              <Select value={selectedRhythm} onValueChange={setSelectedRhythm}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose observed rhythm" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="VF">VF (Ventricular Fibrillation)</SelectItem>
                  <SelectItem value="VT">VT (Ventricular Tachycardia)</SelectItem>
                  <SelectItem value="PEA">PEA (Pulseless Electrical Activity)</SelectItem>
                  <SelectItem value="Asystole">Asystole</SelectItem>
                  <SelectItem value="Sinus Rhythm">Sinus Rhythm</SelectItem>
                  <SelectItem value="Atrial Fibrillation">Atrial Fibrillation</SelectItem>
                  <SelectItem value="SVT">SVT (Supraventricular Tachycardia)</SelectItem>
                  <SelectItem value="Bradycardia">Bradycardia</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowRhythmCheckDialog(false);
                setSelectedRhythm("");
              }}
            >
              Skip
            </Button>
            <Button
              onClick={() => {
                if (selectedRhythm && sessionId) {
                  logInterventionMutation.mutate({
                    sessionId: sessionId,
                    type: "rhythm_check",
                    description: `Rhythm observed: ${selectedRhythm}`,
                    performedBy: "Team",
                    details: { rhythm: selectedRhythm }
                  });
                  setShowRhythmCheckDialog(false);
                  setSelectedRhythm("");
                  setConfirmationMessage(`Rhythm logged: ${selectedRhythm}`);
                  setShowInterventionConfirm(true);
                }
              }}
              disabled={!selectedRhythm || logInterventionMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {logInterventionMutation.isPending ? "Logging..." : "Log Rhythm"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Intervention Confirmation Dialog */}
      <InterventionConfirmationDialog
        isOpen={showConfirmationDialog}
        onClose={() => {
          setShowConfirmationDialog(false);
          setSelectedInterventionType('');
          setSelectedInterventionName('');
        }}
        onConfirm={handleInterventionConfirmationDialog}
        interventionType={selectedInterventionType}
        interventionName={selectedInterventionName}
        isAudioEnabled={isAudioEnabled}
        sessionId={sessionId}
        teamMembers={validTeamMembers}
      />

      {/* Intervention Log - Bottom positioned */}
      {(blsStarted || ilsStarted) && (
        <div className="mt-8 mb-24">
          <Card className="medical-card border-purple-200 bg-purple-50 dark:bg-purple-900/20">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center text-lg font-semibold text-purple-800 dark:text-purple-200">
                <FileText className="w-5 h-5 mr-2" />
                Intervention Log
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {validInterventions.length > 0 ? (
                  validInterventions.slice(0, 15).map((intervention: any) => (
                    <div key={intervention.id} className="p-3 bg-white dark:bg-gray-800 rounded-lg border border-purple-200 dark:border-purple-700 shadow-sm">
                      <div className="font-medium text-gray-900 dark:text-gray-100 text-sm mb-1">
                        {intervention.description || 'No description available'}
                      </div>
                      <div className="text-xs text-gray-500 dark:text-gray-400 space-y-1">
                        <div className="flex justify-between items-start">
                          <span className="font-medium text-purple-700 dark:text-purple-300">
                            {intervention.type || 'Unknown'}
                          </span>
                          <span className="text-right text-xs">
                            {intervention.timestamp ? 
                              new Date(intervention.timestamp).toLocaleTimeString('en-GB', {
                                hour: '2-digit',
                                minute: '2-digit',
                                second: '2-digit'
                              }) : 
                              intervention.createdAt ? 
                                new Date(intervention.createdAt).toLocaleTimeString('en-GB', {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                  second: '2-digit'
                                }) : 
                                'No time'
                            }
                          </span>
                        </div>
                        {intervention.details && (
                          <div className="text-gray-600 dark:text-gray-400 text-xs">
                            {(() => {
                              try {
                                const details = typeof intervention.details === 'string' 
                                  ? JSON.parse(intervention.details) 
                                  : intervention.details;
                                
                                if (details?.performedBy) {
                                  return <span>By: {details.performedBy}</span>;
                                }
                                return null;
                              } catch (e) {
                                return null;
                              }
                            })()}
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <FileText className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                    <p className="text-sm text-gray-500 dark:text-gray-400">No interventions logged yet</p>
                    <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">Start the protocol to begin logging interventions</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Fixed Bottom End Resuscitation Button */}
      {(blsStarted || ilsStarted) && (
        <div className="mt-8 mb-8 flex justify-center">
          <Button
            onClick={() => setShowEndSessionDialog(true)}
            className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 text-lg font-semibold shadow-lg"
            size="lg"
          >
            <XCircle className="w-5 h-5 mr-2" />
            End Resuscitation
          </Button>
        </div>
      )}

      {/* Saving Page */}
      {showSavingPage && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-8 max-w-md w-full mx-4">
            <div className="text-center">
              <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-purple-600 mx-auto mb-4"></div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                Saving Team Setup
              </h3>
              <p className="text-gray-600 dark:text-gray-300">
                Saving team members and CAD number...
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Ready to Start Dialog */}
      <Dialog open={showReadyDialog} onOpenChange={() => {}}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-green-700 dark:text-green-400">
              Team Setup Complete
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p className="text-center text-gray-700 dark:text-gray-300">
              Team members and CAD number saved successfully. You are now ready to begin your resuscitation.
            </p>
            <p className="text-center text-sm text-gray-600 dark:text-gray-400 mt-2">
              Click the Start button when ready.
            </p>
          </div>
          <DialogFooter className="flex justify-center">
            <Button 
              onClick={handleStartBLS}
              className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 text-lg font-semibold"
            >
              <Zap className="w-5 h-5 mr-2" />
              START ILS ADULT RESUS
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reversible Cause Clinical Reading Dialog */}
      <Dialog open={showReversibleCauseDialog} onOpenChange={setShowReversibleCauseDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-red-700 dark:text-red-400">
              Assess {selectedReversibleCause}
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <ReversibleCauseForm 
              cause={selectedReversibleCause}
              onSubmit={handleReversibleCauseSubmit}
              onCancel={() => setShowReversibleCauseDialog(false)}
            />
          </div>
        </DialogContent>
      </Dialog>

      {/* LUCAS Device Confirmation Dialog */}
      <Dialog open={showLucasConfirmDialog} onOpenChange={setShowLucasConfirmDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center text-purple-600">
              <Activity className="w-5 h-5 mr-2" />
              Deploy LUCAS Device
            </DialogTitle>
            <DialogDescription>
              Confirm LUCAS device deployment and operator details
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Team Member Operating LUCAS:</label>
              <Select value={lucasOperator} onValueChange={setLucasOperator}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select team member" />
                </SelectTrigger>
                <SelectContent>
                  {sessionTeamMembers?.map((member: any, index: number) => (
                    <SelectItem key={index} value={member.name}>
                      {member.name} - {member.role}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Alert className="border-purple-200 bg-purple-50 dark:bg-purple-900/20">
              <Activity className="h-4 w-4" />
              <AlertDescription className="text-purple-800 dark:text-purple-200">
                <strong>LUCAS Device Deployment:</strong>
                <ul className="mt-2 space-y-1 text-sm">
                  <li>• Stops manual CPR metronome</li>
                  <li>• Provides consistent mechanical compressions</li>
                  <li>• 2-minute rhythm check timer continues</li>
                  <li>• Can be stopped to resume manual CPR</li>
                </ul>
              </AlertDescription>
            </Alert>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setShowLucasConfirmDialog(false);
              setLucasOperator("");
            }}>
              Cancel
            </Button>
            <Button 
              onClick={() => {
                if (!lucasOperator.trim()) {
                  toast({
                    title: "Team Member Required",
                    description: "Please enter the name of the team member operating the LUCAS device",
                    variant: "destructive",
                  });
                  return;
                }

                setLucasActive(true);
                setMetronomeEnabled(false);
                
                // Log LUCAS deployment intervention
                logInterventionMutation.mutate({
                  type: "LUCAS_DEVICE",
                  description: `LUCAS device deployed by ${lucasOperator}`,
                  details: { 
                    operator: lucasOperator,
                    action: "deployed",
                    stoppedManualCPR: true,
                    timestamp: new Date().toISOString()
                  }
                });

                // Audio confirmation if enabled
                if (isAudioEnabled) {
                  const msg = new SpeechSynthesisUtterance(
                    `LUCAS device deployed by ${lucasOperator}. Mechanical compressions active.`
                  );
                  window.speechSynthesis.speak(msg);
                }

                toast({
                  title: "LUCAS Device Deployed",
                  description: `Operator: ${lucasOperator} - Mechanical compressions active`,
                  duration: 5000,
                });

                setShowLucasConfirmDialog(false);
              }}
              disabled={!lucasOperator.trim()}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              Deploy LUCAS Device
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <FooterLinks />
    </div>
  );
}

// Reversible Cause Form Component
function ReversibleCauseForm({ 
  cause, 
  onSubmit, 
  onCancel 
}: { 
  cause: string; 
  onSubmit: (reading: string) => void; 
  onCancel: () => void; 
}) {
  const [reading, setReading] = useState("");

  const getPromptInfo = () => {
    switch (cause) {
      case 'Hypoxia':
        return {
          prompt: "Enter patient's current SpO2 level:",
          placeholder: "e.g. 92",
          unit: "%",
          normalRange: "95-100%",
          description: "Oxygen saturation measurement"
        };
      case 'Hypo/Hyperkalaemia':
        return {
          prompt: "Enter patient's blood glucose (BM) level:",
          placeholder: "e.g. 6.5",
          unit: "mmol/L",
          normalRange: "4.0-11.0 mmol/L",
          description: "Blood glucose measurement"
        };
      case 'Hypothermia':
        return {
          prompt: "Enter patient's core temperature:",
          placeholder: "e.g. 34.2",
          unit: "°C",
          normalRange: "36.0-37.5°C",
          description: "Core body temperature"
        };
      default:
        return {
          prompt: `Enter clinical reading for ${cause}:`,
          placeholder: "Enter value",
          unit: "",
          normalRange: "See clinical guidelines",
          description: "Clinical assessment"
        };
    }
  };

  const info = getPromptInfo();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (reading.trim()) {
      onSubmit(reading.trim());
      setReading("");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          {info.prompt}
        </label>
        <div className="relative">
          <input
            type="text"
            value={reading}
            onChange={(e) => setReading(e.target.value)}
            placeholder={info.placeholder}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            autoFocus
          />
          {info.unit && (
            <span className="absolute right-3 top-2 text-sm text-gray-500 dark:text-gray-400">
              {info.unit}
            </span>
          )}
        </div>
        <div className="mt-2 text-xs text-gray-600 dark:text-gray-400">
          <p>Normal range: {info.normalRange}</p>
          <p className="text-gray-500">{info.description}</p>
        </div>
      </div>
      
      <div className="flex gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} className="flex-1">
          Cancel
        </Button>
        <Button 
          type="submit" 
          disabled={!reading.trim()}
          className="flex-1 bg-red-600 hover:bg-red-700 text-white"
        >
          Record Assessment
        </Button>
      </div>
    </form>
  );
}


