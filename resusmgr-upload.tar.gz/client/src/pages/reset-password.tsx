import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { Shield, ArrowLeft } from "lucide-react";

// Schema for logged-out users (requires email, full name, and recovery code)
const loggedOutResetSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  recoveryPasscode: z.string().length(10, "Recovery passcode must be exactly 10 digits").regex(/^\d+$/, "Recovery passcode must contain only numbers"),
  newPassword: z.string()
    .min(8, "Password must be at least 8 characters")
    .regex(/[A-Z]/, "Password must contain at least one capital letter")
    .regex(/[0-9]/, "Password must contain at least one number")
    .regex(/[^A-Za-z0-9]/, "Password must contain at least one special character"),
  confirmPassword: z.string().min(8, "Password must be at least 8 characters"),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

// Schema for logged-in users (only needs current and new password)
const loggedInResetSchema = z.object({
  currentPassword: z.string().min(1, "Current password is required"),
  newPassword: z.string()
    .min(8, "Password must be at least 8 characters")
    .regex(/[A-Z]/, "Password must contain at least one capital letter")
    .regex(/[0-9]/, "Password must contain at least one number")
    .regex(/[^A-Za-z0-9]/, "Password must contain at least one special character"),
  confirmPassword: z.string().min(8, "Password must be at least 8 characters"),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type LoggedOutResetForm = z.infer<typeof loggedOutResetSchema>;
type LoggedInResetForm = z.infer<typeof loggedInResetSchema>;

export default function ResetPassword() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const isLoggedIn = !!user;

  const loggedOutForm = useForm<LoggedOutResetForm>({
    resolver: zodResolver(loggedOutResetSchema),
    defaultValues: {
      email: "",
      firstName: "",
      lastName: "",
      recoveryPasscode: "",
      newPassword: "",
      confirmPassword: "",
    },
  });

  const loggedInForm = useForm<LoggedInResetForm>({
    resolver: zodResolver(loggedInResetSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });

  const handleLoggedOutReset = async (data: LoggedOutResetForm) => {
    setIsLoading(true);
    try {
      const response = await apiRequest("POST", "/api/reset-password", {
        email: data.email,
        firstName: data.firstName,
        lastName: data.lastName,
        recoveryPasscode: data.recoveryPasscode,
        newPassword: data.newPassword,
      });

      if (response.ok) {
        toast({
          title: "Password Reset Successful",
          description: "Your password has been reset. You can now sign in with your new password.",
        });
        setLocation("/auth");
      } else {
        const errorData = await response.json();
        toast({
          title: "Reset Failed",
          description: errorData.message || "Failed to reset password. Please check your details.",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      toast({
        title: "Reset Failed",
        description: error.message || "An error occurred while resetting your password.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoggedInReset = async (data: LoggedInResetForm) => {
    setIsLoading(true);
    try {
      const response = await apiRequest("PUT", "/api/profile/password", {
        currentPassword: data.currentPassword,
        newPassword: data.newPassword,
      });

      if (response.ok) {
        toast({
          title: "Password Changed Successfully",
          description: "Your password has been updated successfully.",
        });
        setLocation("/profile");
      } else {
        const errorData = await response.json();
        toast({
          title: "Password Change Failed",
          description: errorData.message || "Current password is incorrect.",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      toast({
        title: "Password Change Failed",
        description: error.message || "An error occurred while changing your password.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-4">
            <div className="flex items-center mb-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLocation(isLoggedIn ? "/profile" : "/auth")}
                className="mr-2 text-gray-600 hover:text-gray-800"
              >
                <ArrowLeft className="w-4 h-4 mr-1" />
                Back
              </Button>
            </div>
            <div className="flex items-center justify-center mb-4">
              <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-3 rounded-full">
                <Shield className="w-8 h-8 text-white" />
              </div>
            </div>
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent text-center">
              {isLoggedIn ? "Change Password" : "Reset Password"}
            </CardTitle>
            <CardDescription className="text-gray-600 text-center">
              {isLoggedIn 
                ? "Enter your current password and choose a new one"
                : "Enter your full name, email address, and 10-digit recovery passcode to reset your password"
              }
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            {isLoggedIn ? (
              <form onSubmit={loggedInForm.handleSubmit(handleLoggedInReset)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="currentPassword">Current Password</Label>
                  <Input
                    id="currentPassword"
                    type="password"
                    placeholder="Enter your current password"
                    {...loggedInForm.register("currentPassword")}
                  />
                  {loggedInForm.formState.errors.currentPassword && (
                    <p className="text-sm text-red-600">{loggedInForm.formState.errors.currentPassword.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="newPassword">New Password</Label>
                  <Input
                    id="newPassword"
                    type="password"
                    placeholder="Enter new password (min 8 characters)"
                    {...loggedInForm.register("newPassword")}
                  />
                  {loggedInForm.formState.errors.newPassword && (
                    <p className="text-sm text-red-600">{loggedInForm.formState.errors.newPassword.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm New Password</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="Confirm your new password"
                    {...loggedInForm.register("confirmPassword")}
                  />
                  {loggedInForm.formState.errors.confirmPassword && (
                    <p className="text-sm text-red-600">{loggedInForm.formState.errors.confirmPassword.message}</p>
                  )}
                </div>
                
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  disabled={isLoading}
                >
                  {isLoading ? "Changing Password..." : "Change Password"}
                </Button>
              </form>
            ) : (
              <form onSubmit={loggedOutForm.handleSubmit(handleLoggedOutReset)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@hospital.nhs.uk"
                    {...loggedOutForm.register("email")}
                  />
                  {loggedOutForm.formState.errors.email && (
                    <p className="text-sm text-red-600">{loggedOutForm.formState.errors.email.message}</p>
                  )}
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      type="text"
                      placeholder="John"
                      {...loggedOutForm.register("firstName")}
                    />
                    {loggedOutForm.formState.errors.firstName && (
                      <p className="text-sm text-red-600">{loggedOutForm.formState.errors.firstName.message}</p>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      type="text"
                      placeholder="Smith"
                      {...loggedOutForm.register("lastName")}
                    />
                    {loggedOutForm.formState.errors.lastName && (
                      <p className="text-sm text-red-600">{loggedOutForm.formState.errors.lastName.message}</p>
                    )}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="recoveryPasscode">10-Digit Recovery Passcode</Label>
                  <Input
                    id="recoveryPasscode"
                    type="text"
                    placeholder="1234567890"
                    maxLength={10}
                    {...loggedOutForm.register("recoveryPasscode")}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '');
                      e.target.value = value;
                      loggedOutForm.setValue("recoveryPasscode", value);
                    }}
                  />
                  {loggedOutForm.formState.errors.recoveryPasscode && (
                    <p className="text-sm text-red-600">{loggedOutForm.formState.errors.recoveryPasscode.message}</p>
                  )}
                  <p className="text-xs text-gray-500">This is the 10-digit passcode you set during registration</p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="newPassword">New Password</Label>
                  <Input
                    id="newPassword"
                    type="password"
                    placeholder="Enter new password (min 8 characters)"
                    {...loggedOutForm.register("newPassword")}
                  />
                  {loggedOutForm.formState.errors.newPassword && (
                    <p className="text-sm text-red-600">{loggedOutForm.formState.errors.newPassword.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm New Password</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="Confirm your new password"
                    {...loggedOutForm.register("confirmPassword")}
                  />
                  {loggedOutForm.formState.errors.confirmPassword && (
                    <p className="text-sm text-red-600">{loggedOutForm.formState.errors.confirmPassword.message}</p>
                  )}
                </div>
                
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  disabled={isLoading}
                >
                  {isLoading ? "Resetting Password..." : "Reset Password"}
                </Button>
              </form>
            )}

            {!user && (
              <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                <div className="text-center space-y-3">
                  <h4 className="text-sm font-medium text-gray-900 dark:text-white">
                    Need to cancel your subscription?
                  </h4>
                  <p className="text-xs text-gray-600 dark:text-gray-400">
                    If you can't access your account but need to cancel your subscription
                  </p>
                  <Button variant="outline" size="sm" asChild className="w-full text-red-600 border-red-200 hover:bg-red-50">
                    <a href="/emergency-cancel">Emergency Subscription Cancellation</a>
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}