import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Shield, Activity, Clock, Heart } from "lucide-react";

const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

const registerSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  recoveryPasscode: z.string().length(10, "Recovery passcode must be exactly 10 digits").regex(/^\d+$/, "Recovery passcode must contain only numbers"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  role: z.string().min(1, "Please select your role"),
});

type LoginForm = z.infer<typeof loginSchema>;
type RegisterForm = z.infer<typeof registerSchema>;

export default function AuthPageSimple() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user, loginMutation, registerMutation } = useAuth();
  const [isLogin, setIsLogin] = useState(true);

  // Redirect if already logged in
  if (user) {
    setLocation("/");
    return null;
  }

  const loginForm = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const registerForm = useForm<RegisterForm>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      email: "",
      password: "",
      recoveryPasscode: "",
      firstName: "",
      lastName: "",
      role: "Emergency Medicine",
    },
  });

  const handleLogin = (data: LoginForm) => {
    loginMutation.mutate(data, {
      onSuccess: () => {
        toast({
          title: "Welcome back!",
          description: "Successfully logged in to ResusMGR",
        });
        setLocation("/");
      },
    });
  };

  const handleRegister = (data: RegisterForm) => {
    console.log("Registration data:", data);
    registerMutation.mutate(data, {
      onSuccess: () => {
        toast({
          title: "Welcome to ResusMGR!",
          description: "Your account has been created successfully",
        });
        setLocation("/");
      },
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8 items-center min-h-[calc(100vh-4rem)]">
          
          {/* Hero Section */}
          <div className="space-y-6">
            <div className="flex items-center space-x-3 mb-8">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">ResusMGR</h1>
                <p className="text-gray-600">Professional Resuscitation Management</p>
              </div>
            </div>

            <div className="space-y-6">
              <h2 className="text-4xl font-bold text-gray-900 leading-tight">
                Advanced Emergency<br />
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Protocol Management
                </span>
              </h2>
              
              <p className="text-xl text-gray-600 leading-relaxed">
                Secure access to UK Resuscitation Council guidelines, intervention logging, 
                and comprehensive case management for emergency medical professionals.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-8">
                <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-gray-100">
                  <Shield className="w-8 h-8 text-blue-600 mb-3" />
                  <h3 className="font-semibold text-gray-900 mb-1">Secure Data</h3>
                  <p className="text-sm text-gray-600">Encrypted storage and secure authentication</p>
                </div>
                
                <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-gray-100">
                  <Activity className="w-8 h-8 text-purple-600 mb-3" />
                  <h3 className="font-semibold text-gray-900 mb-1">Real-time Logging</h3>
                  <p className="text-sm text-gray-600">Live intervention and timing tracking</p>
                </div>
                
                <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-gray-100">
                  <Clock className="w-8 h-8 text-green-600 mb-3" />
                  <h3 className="font-semibold text-gray-900 mb-1">Quick Access</h3>
                  <p className="text-sm text-gray-600">Instant protocol access from any device</p>
                </div>
              </div>
            </div>
          </div>

          {/* Auth Form */}
          <div className="lg:pl-8">
            <div className="w-full max-w-lg mx-auto bg-white rounded-lg shadow-xl p-6">
              <div className="pb-4">
                <h2 className="text-2xl font-bold text-center text-gray-900">
                  Access ResusMGR
                </h2>
                <p className="text-center text-gray-600">
                  Secure login for emergency medical professionals
                </p>
              </div>
              
              {/* Reset Password Link */}
              <div className="mb-6 bg-yellow-100 border-2 border-yellow-400 rounded-lg p-4 text-center">
                <p className="text-lg font-bold text-yellow-800 mb-2">FORGOT PASSWORD?</p>
                <button
                  type="button"
                  onClick={() => setLocation("/reset-password")}
                  className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-bold text-lg"
                >
                  RESET PASSWORD HERE
                </button>
              </div>

              {/* Toggle Buttons */}
              <div className="flex mb-6 bg-gray-100 rounded-lg p-1">
                <button
                  type="button"
                  onClick={() => setIsLogin(true)}
                  className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
                    isLogin 
                      ? 'bg-white text-gray-900 shadow-sm' 
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => setIsLogin(false)}
                  className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
                    !isLogin 
                      ? 'bg-white text-gray-900 shadow-sm' 
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Sign Up
                </button>
              </div>

              {isLogin ? (
                /* Login Form */
                <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
                  <div>
                    <Label htmlFor="login-email">Email Address</Label>
                    <Input
                      id="login-email"
                      type="email"
                      placeholder="your.email@hospital.nhs.uk"
                      {...loginForm.register("email")}
                    />
                    {loginForm.formState.errors.email && (
                      <p className="text-sm text-red-600">{loginForm.formState.errors.email.message}</p>
                    )}
                  </div>
                  
                  <div>
                    <Label htmlFor="login-password">Password</Label>
                    <Input
                      id="login-password"
                      type="password"
                      placeholder="Enter your password"
                      {...loginForm.register("password")}
                    />
                    {loginForm.formState.errors.password && (
                      <p className="text-sm text-red-600">{loginForm.formState.errors.password.message}</p>
                    )}
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? "Signing In..." : "Sign In"}
                  </Button>
                </form>
              ) : (
                /* Register Form */
                <form onSubmit={registerForm.handleSubmit(handleRegister)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        placeholder="John"
                        {...registerForm.register("firstName")}
                      />
                      {registerForm.formState.errors.firstName && (
                        <p className="text-sm text-red-600">{registerForm.formState.errors.firstName.message}</p>
                      )}
                    </div>
                    
                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        placeholder="Smith"
                        {...registerForm.register("lastName")}
                      />
                      {registerForm.formState.errors.lastName && (
                        <p className="text-sm text-red-600">{registerForm.formState.errors.lastName.message}</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your.email@hospital.nhs.uk"
                      {...registerForm.register("email")}
                    />
                    {registerForm.formState.errors.email && (
                      <p className="text-sm text-red-600">{registerForm.formState.errors.email.message}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="recoveryPasscode">10-Digit Recovery Passcode</Label>
                    <Input
                      id="recoveryPasscode"
                      type="text"
                      placeholder="Enter 10 digits (e.g., 1234567890)"
                      maxLength={10}
                      {...registerForm.register("recoveryPasscode")}
                    />
                    <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mt-2">
                      <p className="text-xs text-amber-800 font-medium">
                        Important: Choose and remember your recovery passcode
                      </p>
                      <p className="text-xs text-amber-700 mt-1">
                        This 10-digit code will be needed to reset your password if you forget it. Make sure to write it down safely.
                      </p>
                    </div>
                    {registerForm.formState.errors.recoveryPasscode && (
                      <p className="text-sm text-red-600">{registerForm.formState.errors.recoveryPasscode.message}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="role">Professional Role</Label>
                    <select 
                      {...registerForm.register("role")}
                      className="w-full p-2 border border-gray-300 rounded"
                    >
                      <option value="Emergency Medicine">Emergency Medicine</option>
                      <option value="Paramedic">Paramedic</option>
                      <option value="Critical Care Paramedic">Critical Care Paramedic</option>
                      <option value="Emergency Care Assistant">Emergency Care Assistant</option>
                      <option value="Student Paramedic">Student Paramedic</option>
                      <option value="Emergency Medical Technician">Emergency Medical Technician</option>
                      <option value="Other Healthcare Professional">Other Healthcare Professional</option>
                    </select>
                    {registerForm.formState.errors.role && (
                      <p className="text-sm text-red-600">{registerForm.formState.errors.role.message}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="Create a secure password"
                      {...registerForm.register("password")}
                    />
                    {registerForm.formState.errors.password && (
                      <p className="text-sm text-red-600">{registerForm.formState.errors.password.message}</p>
                    )}
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                    disabled={registerMutation.isPending}
                  >
                    {registerMutation.isPending ? "Creating Account..." : "Create Account"}
                  </Button>
                </form>
              )}

              <div className="mt-6 text-center">
                <p className="text-xs text-gray-500">
                  By signing in, you agree to our terms of service and privacy policy.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
