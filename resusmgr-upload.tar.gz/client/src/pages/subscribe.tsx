import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Heart, FileText, Shield, Users, Crown, X } from "lucide-react";
import Navigation from "@/components/navigation";
import { useLocation } from "wouter";

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const SubscribeForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [, setLocation] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.origin,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Payment Successful",
        description: "Welcome to ResusMGR Professional!",
      });
      // Redirect to dashboard using proper routing
      setTimeout(() => {
        setLocation("/");
      }, 2000);
    }

    setIsProcessing(false);
  };

  return (
    <Card className="max-w-md w-full">
      <CardHeader className="text-center">
        <div className="w-16 h-16 medical-gradient rounded-full flex items-center justify-center mx-auto mb-4">
          <Crown className="w-8 h-8 text-white" />
        </div>
        <CardTitle className="text-2xl">Complete Your Subscription</CardTitle>
        <p className="text-gray-600 dark:text-gray-400">
          Enter your payment details to activate ResusMGR Professional
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <PaymentElement />
          <div className="space-y-3">
            <Button 
              type="submit" 
              disabled={!stripe || isProcessing}
              className="w-full btn-medical-blue py-3"
            >
              {isProcessing ? "Processing..." : "Subscribe for £1.99/month"}
            </Button>
            <Button 
              type="button"
              variant="outline"
              onClick={() => setLocation("/")}
              className="w-full py-3"
            >
              No thanks, continue with free plan
            </Button>
          </div>
        </form>
        
        <div className="mt-6 text-center">
          <p className="text-xs text-gray-500">
            Secure payment powered by Stripe • Cancel anytime
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default function Subscribe() {
  const [clientSecret, setClientSecret] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Create subscription as soon as the page loads
    apiRequest("POST", "/api/get-or-create-subscription")
      .then((res) => res.json())
      .then((data) => {
        setClientSecret(data.clientSecret);
        setIsLoading(false);
      })
      .catch((error) => {
        console.error("Subscription error:", error);
        setIsLoading(false);
      });
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navigation />
      
      {/* Close Button */}
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setLocation("/")}
        className="fixed top-4 right-4 z-50 w-10 h-10 rounded-full bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border border-gray-200 dark:border-gray-700 hover:bg-white dark:hover:bg-gray-800 shadow-lg"
      >
        <X className="w-5 h-5" />
      </Button>
      
      <main className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
          {/* Features Section */}
          <div>
            <div className="mb-8">
              <Badge className="medical-gradient text-white mb-4">PROFESSIONAL PLAN</Badge>
              <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
                Unlock Professional Resuscitation Management
              </h1>
              <p className="text-xl text-gray-600 dark:text-gray-400">
                Get access to advanced protocols, unlimited sessions, and comprehensive reporting tools.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-xl flex items-center justify-center mt-1">
                  <Heart className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    Advanced Life Support Protocols
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Access to ILS and ALS protocols with complete drug calculations and advanced interventions.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center mt-1">
                  <FileText className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    Unlimited Sessions & Reports
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Run unlimited resuscitation sessions with detailed reporting and audit trails.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-xl flex items-center justify-center mt-1">
                  <Shield className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    Secure Cross-Device Sync
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Access your data securely across all devices with end-to-end encryption.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-teal-100 dark:bg-teal-900/30 rounded-xl flex items-center justify-center mt-1">
                  <Users className="w-6 h-6 text-teal-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    Priority Support
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    24/7 priority support from our medical technology specialists.
                  </p>
                </div>
              </div>
            </div>

            {/* Pricing Features */}
            <div className="mt-12 p-6 bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700">
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                What's Included:
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  "BLS, ILS & ALS Protocols",
                  "Adult & Paediatric Support",
                  "Real-time Audio Guidance",
                  "Drug Dose Calculator",
                  "Intervention Logging",
                  "Reversible Causes Checklist",
                  "Session Timer & Metronome",
                  "Complete Report Generation",
                  "Secure Data Storage",
                  "Cross-device Access",
                  "Priority Support",
                  "Regular Updates"
                ].map((feature, index) => (
                  <div key={index} className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2 flex-shrink-0" />
                    <span className="text-sm text-gray-700 dark:text-gray-300">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Payment Section */}
          <div className="flex justify-center">
            {isLoading ? (
              <Card className="max-w-md w-full">
                <CardContent className="pt-12 pb-12 text-center">
                  <Heart className="w-12 h-12 text-blue-600 mx-auto mb-4 animate-pulse" />
                  <p className="text-lg text-gray-600 dark:text-gray-400">Setting up your subscription...</p>
                </CardContent>
              </Card>
            ) : clientSecret ? (
              <Elements stripe={stripePromise} options={{ clientSecret }}>
                <SubscribeForm />
              </Elements>
            ) : (
              <Card className="max-w-md w-full">
                <CardContent className="pt-12 pb-12 text-center">
                  <Shield className="w-12 h-12 text-red-500 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    Setup Error
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    Unable to initialize subscription. Please try again.
                  </p>
                  <Button onClick={() => window.location.reload()}>
                    Retry
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Trust Section */}
        <div className="mt-20 text-center">
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">
            Trusted by Emergency Medicine Professionals
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-3xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">2021</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">UK RC Guidelines</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">100%</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Secure & Encrypted</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">24/7</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Available Support</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-teal-600 mb-2">NHS</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Trusted Standards</div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
