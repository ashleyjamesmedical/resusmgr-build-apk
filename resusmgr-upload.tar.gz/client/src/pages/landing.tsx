import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Shield, Users, Clock, FileText, Award, Smartphone, Download, QrCode } from "lucide-react";
import FooterLinks from "@/components/footer-links";
import IntroVideo from "@/components/intro-video";
import { SEOHead } from "@/components/seo-head";
import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import QRCode from "qrcode";

export default function Landing() {
  const { data: userCount } = useQuery({
    queryKey: ["/api/public/user-count"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const [currentUrl, setCurrentUrl] = useState("");
  const [showInstallPrompt, setShowInstallPrompt] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showFallbackInstall, setShowFallbackInstall] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState("");
  const [showInstallBanner, setShowInstallBanner] = useState(false);

  useEffect(() => {
    const url = window.location.origin;
    setCurrentUrl(url);

    // Generate QR code for app download URL
    const downloadUrl = `${url}/api/download-apk`;
    QRCode.toDataURL(downloadUrl, {
      width: 192,
      margin: 2,
      color: {
        dark: '#1f2937',
        light: '#ffffff'
      }
    }).then(setQrCodeUrl);

    // Check if app is already installed
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
    const isInWebAppiOS = (window.navigator as any).standalone === true;
    const isInstalled = isStandalone || isInWebAppiOS;

    // Check if user came via QR code with install parameter
    const urlParams = new URLSearchParams(window.location.search);
    const installType = urlParams.get('install');
    
    if (installType === 'true') {
      setShowInstallBanner(true);
    } else if (installType === 'apk') {
      // Show APK installation instructions
      const isAndroid = /Android/i.test(navigator.userAgent);
      if (isAndroid) {
        alert(
          'For Android users:\n\n' +
          '1. Open Chrome browser\n' +
          '2. Visit this website\n' +
          '3. Tap the menu (3 dots) → "Add to Home screen"\n' +
          '4. Confirm installation\n\n' +
          'This will install ResusMGR as a native app on your device.'
        );
      } else {
        alert(
          'This link is designed for Android devices.\n\n' +
          'On iOS: Use Safari and tap "Share" → "Add to Home Screen"\n' +
          'On Desktop: Look for the install icon in your browser address bar'
        );
      }
    }

    if (!isInstalled) {
      // Show fallback install button for all devices
      setShowFallbackInstall(true);

      // Listen for the beforeinstallprompt event (Chrome/Edge)
      const handleBeforeInstallPrompt = (e: Event) => {
        e.preventDefault();
        setDeferredPrompt(e);
        setShowInstallPrompt(true);
        
        // If user came via QR code, automatically trigger install prompt
        if (installType === 'true') {
          setTimeout(() => {
            if (confirm('Install ResusMGR as an app on your device?\n\nThis will add ResusMGR to your home screen for quick access during emergencies.')) {
              (e as any).prompt().then((result: any) => {
                if (result.outcome === 'accepted') {
                  alert('ResusMGR has been installed! Look for it on your home screen.');
                } else {
                  alert('Installation cancelled. You can still use ResusMGR in your browser or try installing later from the download section.');
                }
              });
            }
          }, 500);
        }
      };

      window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

      // For QR code users, always show confirmation regardless of browser support
      if (installType === 'true') {
        setTimeout(() => {
          if (confirm('Install ResusMGR as an app on your device\'s home screen?\n\nThis will give you quick access during emergencies and allow offline use.')) {
            // Scroll to download section
            const installSection = document.getElementById('download-section');
            if (installSection) {
              installSection.scrollIntoView({ behavior: 'smooth' });
            }
            
            // If we have a deferred prompt, use it
            if (deferredPrompt) {
              (deferredPrompt as any).prompt().then((result: any) => {
                if (result.outcome === 'accepted') {
                  alert('ResusMGR has been installed! Look for it on your home screen.');
                } else {
                  alert('Installation cancelled. You can still use ResusMGR in your browser.');
                }
              });
            } else {
              // Show device-specific instructions for manual installation
              const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
              const isAndroid = /Android/.test(navigator.userAgent);
              const isChrome = /Chrome/.test(navigator.userAgent);
              
              let instructions = '';
              if (isIOS) {
                instructions = 'To install ResusMGR:\n\n1. Tap the Share button (⬆️) at the bottom of Safari\n2. Scroll down and tap "Add to Home Screen"\n3. Tap "Add" to install the app\n\nThe app will appear on your home screen!';
              } else if (isAndroid && isChrome) {
                instructions = 'To install ResusMGR:\n\n1. Look for the "Install" banner at the top\n2. OR tap the menu (⋮) → "Add to Home screen"\n3. Tap "Install" to confirm\n\nThe app will appear on your home screen!';
              } else if (isAndroid) {
                instructions = 'To install ResusMGR:\n\n1. Tap the browser menu (⋮)\n2. Look for "Add to Home screen" or "Install app"\n3. Tap to install\n\nThe app will appear on your home screen!';
              } else {
                instructions = 'To install ResusMGR:\n\n• Chrome/Edge: Look for install icon in address bar\n• Firefox: Use menu → "Install this site as an app"\n• Safari: Share → "Add to Home Screen"';
              }
              
              alert(instructions);
            }
          }
        }, 1000);
      }



      return () => {
        window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      };
    }
  }, [deferredPrompt]);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setShowInstallPrompt(false);
        setShowFallbackInstall(false);
      }
      setDeferredPrompt(null);
    } else {
      // Force install attempt - show device-specific instructions
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
      const isAndroid = /Android/.test(navigator.userAgent);
      const isChrome = /Chrome/.test(navigator.userAgent);
      const isSafari = /Safari/.test(navigator.userAgent) && !/Chrome/.test(navigator.userAgent);
      
      let instructions = '';
      let title = 'Install ResusMGR App';
      
      if (isIOS && isSafari) {
        instructions = 'To install ResusMGR on your iPhone/iPad:\n\n1. Tap the Share button (⬆️) at the bottom of Safari\n2. Scroll down and tap "Add to Home Screen"\n3. Tap "Add" to install the app\n\nThe ResusMGR app will appear on your home screen for instant emergency access!';
      } else if (isAndroid && isChrome) {
        instructions = 'To install ResusMGR on your Android device:\n\n1. Look for the "Install" banner at the top of this page\n2. OR tap the menu (⋮) → "Add to Home screen"\n3. Tap "Install" to confirm\n\nThe ResusMGR app will be added to your home screen!';
      } else if (isAndroid) {
        instructions = 'To install ResusMGR on your Android device:\n\n1. Tap your browser menu (⋮)\n2. Look for "Add to Home screen" or "Install app"\n3. Tap to install\n\nThe ResusMGR app will be added to your home screen!';
      } else {
        instructions = 'To install ResusMGR as an app:\n\n• Chrome/Edge: Look for the install icon (⬇️) in the address bar\n• Firefox: Menu → "Install this site as an app"\n• Safari: Share → "Add to Home Screen"\n\nOnce installed, ResusMGR will be available from your desktop or applications menu!';
      }
      
      alert(`${title}\n\n${instructions}`);
      
      // Scroll to download section for additional guidance
      const downloadSection = document.querySelector('#download-section');
      if (downloadSection) {
        downloadSection.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const handleDownloadButtonClick = () => {
    // Try to trigger install prompt immediately
    if (deferredPrompt) {
      handleInstallClick();
    } else {
      // Force browser to show install prompt or provide instructions
      const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
      const isInWebAppiOS = (window.navigator as any).standalone === true;
      const isInstalled = isStandalone || isInWebAppiOS;
      
      if (isInstalled) {
        alert('ResusMGR is already installed on this device!\n\nLook for the ResusMGR icon on your home screen or in your applications.');
        return;
      }
      
      // Trigger install instructions immediately
      handleInstallClick();
    }
  };

  return (
    <>
      <SEOHead
        title="ResusMGR - Professional Resuscitation Management for UK Emergency Services"
        description="Advanced resuscitation management platform for UK emergency medicine professionals. Real-time ALS/BLS protocol guidance, team collaboration, and comprehensive audit reporting tools for ambulance crews and healthcare professionals."
        keywords="resuscitation management, ALS protocols, BLS protocols, emergency medicine, UK ambulance service, resuscitation council guidelines, cardiac arrest management, emergency protocols, healthcare professionals, paramedic tools, ResusMGR, Ashley James Medical"
        canonicalUrl="https://www.resusmgr.co.uk/"
        ogImage="https://www.resusmgr.co.uk/icon-512.svg"
        schemaType="MedicalApplication"
        additionalSchema={{
          applicationCategory: "MedicalApplication",
          operatingSystem: "Web Browser, Android, iOS",
          offers: {
            "@type": "Offer",
            price: "1.99",
            priceCurrency: "GBP"
          },
          featureList: [
            "Advanced Life Support (ALS) Protocols",
            "Basic Life Support (BLS) Protocols", 
            "Real-time Team Collaboration",
            "Comprehensive Audit Reports",
            "UK Resuscitation Council Guidelines Compliance",
            "Emergency Drug Calculations",
            "Session Recording and Analysis"
          ]
        }}
      />
      <div className="min-h-screen bg-gradient-to-br from-blue-600 to-purple-700">
      {/* Header */}
      <nav className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 medical-gradient rounded-full flex items-center justify-center">
              <Heart className="w-5 h-5 text-white" />
            </div>
            <div className="text-white">
              <h1 className="text-xl font-bold">ResusMGR</h1>
              <p className="text-blue-100 text-xs">Resuscitation Manager</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Button 
              onClick={handleDownloadButtonClick}
              className="bg-green-600 text-white hover:bg-green-700 px-4 py-2 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-200 mobile-touch-target flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              {showInstallPrompt ? 'Install App' : 'Download App'}
            </Button>
            <Button 
              onClick={() => window.location.href = '/auth'}
              className="bg-white text-blue-600 hover:bg-blue-50 px-6 py-2 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-200 mobile-touch-target"
            >
              Sign In
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center text-white max-w-4xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-bold mb-6">
            Professional Resuscitation
            <span className="block text-blue-200">Management Tool</span>
          </h2>
          <p className="text-xl md:text-2xl text-blue-100 mb-8 leading-relaxed">
            ResusMGR is a powerful all-in-one adult and paediatric resuscitation assistant for pre-hospital emergency care professionals such as First Aiders, Responders and Ambulance Staff. Fully compliant with UK Resuscitation Council and JRCALC Guidelines, developed by the experienced front-line emergency care professionals at Ashley James Medical. ResusMGR is available for free access to BLS use and can be easily upgraded to the advanced features for just £1.99 per month.
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
            <Button 
              onClick={() => window.location.href = '/how-it-works'}
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white hover:text-blue-600 px-8 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 mobile-touch-target"
            >
              How It Works
            </Button>
            <Button 
              onClick={() => window.location.href = '/auth'}
              size="lg"
              className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 mobile-touch-target"
            >
              Get Started
            </Button>
          </div>

          {/* Trust indicators */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16">
            <div className="text-center">
              <div className="text-2xl font-bold">2021</div>
              <div className="text-blue-200 text-xs">UK RC Guidelines</div>
              <div className="text-blue-200 text-xs">(Reviewed & updated 2023)</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">2024</div>
              <div className="text-blue-200 text-xs">JRCALC Guidelines</div>
              <div className="text-blue-200 text-xs">Compliant</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">100%</div>
              <div className="text-blue-200 text-sm">Encrypted & Secure</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">{(userCount as any)?.count || '---'}</div>
              <div className="text-blue-200 text-sm">Registered Users</div>
            </div>
          </div>
        </div>
      </div>

      {/* Introduction Video Section */}
      <div className="bg-gradient-to-br from-blue-900 via-purple-900 to-red-900 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <h3 className="text-4xl font-bold text-white mb-4">
              See ResusMGR in Action
            </h3>
            <p className="text-xl text-blue-200 max-w-3xl mx-auto">
              Watch our comprehensive introduction to understand how ResusMGR transforms emergency medical care through innovative technology and evidence-based protocols.
            </p>
          </div>
          <IntroVideo />
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-white py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-gray-900 mb-4">
              Everything You Need for Emergency Resuscitation
            </h3>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive tools designed specifically for UK emergency services, 
              fully compliant with UK Resuscitation Council (2021) and JRCALC (2024) guidelines.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* BLS/ILS/ALS Protocols */}
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-0">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-4">
                  <Heart className="w-6 h-6 text-blue-600" />
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">
                  Complete Protocols
                </h4>
                <p className="text-gray-600 mb-4">
                  BLS, ILS, and ALS protocols for both adult and paediatric patients. 
                  Real-time guidance through critical procedures with reversible causes tracking.
                </p>
                <ul className="text-sm text-gray-500 space-y-1">
                  <li>• Adult & Paediatric BLS</li>
                  <li>• Intermediate Life Support</li>
                  <li>• Advanced Life Support</li>
                  <li>• Reversible Causes (4Hs/4Ts)</li>
                </ul>
              </CardContent>
            </Card>

            {/* Timer & Metronome */}
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-0">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-4">
                  <Clock className="w-6 h-6 text-green-600" />
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">
                  Timing & Audio Cues
                </h4>
                <p className="text-gray-600 mb-4">
                  Precise timing tools with adjustable metronome, automated 
                  audio prompts for rhythm checks and medication administration reminders.
                </p>
                <ul className="text-sm text-gray-500 space-y-1">
                  <li>• 100-120 BPM metronome</li>
                  <li>• 2-minute swap alerts</li>
                  <li>• Rhythm check reminders</li>
                  <li>• Medication reminders (e.g. Adrenaline 1:10,000)</li>
                </ul>
              </CardContent>
            </Card>

            {/* Intervention Logging */}
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-0">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-4">
                  <FileText className="w-6 h-6 text-purple-600" />
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">
                  Intervention Logging
                </h4>
                <p className="text-gray-600 mb-4">
                  Comprehensive logging of all interventions with precise timestamps 
                  and drug dose calculations for complete audit trails.
                </p>
                <ul className="text-sm text-gray-500 space-y-1">
                  <li>• Airway management</li>
                  <li>• IV/IO access logging</li>
                  <li>• Medication administration</li>
                  <li>• Shock delivery logging</li>
                  <li>• Easily access, download and share reports</li>
                </ul>
              </CardContent>
            </Card>

            {/* Drug Calculator */}
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-0">
                <div className="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center mb-4">
                  <Award className="w-6 h-6 text-teal-600" />
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">
                  Paediatric Calculator
                </h4>
                <p className="text-gray-600 mb-4">
                  Weight-based drug dose calculations for paediatric patients 
                  with instant volume conversions and safety checks.
                </p>
                <ul className="text-sm text-gray-500 space-y-1">
                  <li>• Weight-based dosing</li>
                  <li>• Multiple drug library</li>
                  <li>• Safety dose limits</li>
                </ul>
              </CardContent>
            </Card>

            {/* Security & Compliance */}
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-0">
                <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-red-600" />
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">
                  Secure & Compliant
                </h4>
                <p className="text-gray-600 mb-4">
                  End-to-end encryption for patient data with GDPR compliance 
                  and secure cross-device synchronization.
                </p>
                <ul className="text-sm text-gray-500 space-y-1">
                  <li>• GDPR compliant</li>
                  <li>• Encrypted storage</li>
                  <li>• Audit trail logging</li>
                </ul>
              </CardContent>
            </Card>

            {/* Team Collaboration */}
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-0">
                <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-yellow-600" />
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">
                  Team Ready
                </h4>
                <p className="text-gray-600 mb-4">
                  Designed for multi-disciplinary teams with clear role guidance 
                  and shared session management capabilities.
                </p>
                <ul className="text-sm text-gray-500 space-y-1">
                  <li>• Multi-user sessions</li>
                  <li>• Role-based access</li>
                  <li>• Team notifications</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gray-50 py-20">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-4xl font-bold text-gray-900 mb-4">
            Ready to Transform Your Emergency Response?
          </h3>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Join thousands of emergency medicine professionals who trust ResusMGR 
            for critical resuscitation management.
          </p>
          
          <div className="bg-white rounded-2xl p-8 max-w-md mx-auto shadow-lg">
            <div className="text-center mb-6">
              <div className="text-4xl font-bold text-gray-900 mb-2">
                £1.99<span className="text-lg font-normal text-gray-600">/month</span>
              </div>
              <p className="text-gray-600">Professional resuscitation tools</p>
            </div>
            


            <Button 
              onClick={() => window.location.href = '/auth'}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 px-6 rounded-xl font-semibold hover:from-blue-700 hover:to-purple-700 transition-all"
            >
              Subscribe Today
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile App Download Section */}
      <div id="download-section" className="bg-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Download ResusMGR to Your Mobile Device
              </h3>
              <p className="text-xl text-gray-600 mb-8">
                Install ResusMGR as a Progressive Web App for instant access during emergencies. 
                Works offline and provides app-like experience on your mobile device.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-12 items-center">
              {/* Left side - Download options */}
              <div className="space-y-6">
                <Card className="p-6 border-2 border-blue-200 bg-blue-50">
                  <CardContent className="p-0">
                    <div className="flex items-center mb-4">
                      <Smartphone className="w-8 h-8 text-blue-600 mr-3" />
                      <h4 className="text-xl font-semibold text-gray-900">Mobile Installation</h4>
                    </div>
                    <p className="text-gray-700 mb-6">
                      ResusMGR works as a Progressive Web App (PWA) providing native app-like experience 
                      with offline capability for critical emergency situations.
                    </p>
                    
                    <div className="space-y-4">
                      <Button 
                        onClick={handleDownloadButtonClick}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-6 rounded-xl font-semibold flex items-center justify-center gap-2"
                      >
                        <Download className="w-5 h-5" />
                        Install ResusMGR App
                      </Button>
                      
                      <div className="border-t pt-4">
                        <h5 className="font-semibold text-gray-900 mb-2">Manual Installation:</h5>
                        <div className="text-sm text-gray-600 space-y-1">
                          <p><strong>iOS:</strong> Open in Safari → Share → Add to Home Screen</p>
                          <p><strong>Android:</strong> Open in Chrome → Menu → Add to Home Screen</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <Shield className="w-8 h-8 text-green-600 mx-auto mb-2" />
                    <h6 className="font-semibold text-gray-900">Offline Ready</h6>
                    <p className="text-sm text-gray-600">Works without internet</p>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <Clock className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                    <h6 className="font-semibold text-gray-900">Instant Access</h6>
                    <p className="text-sm text-gray-600">Launch from home screen</p>
                  </div>
                </div>
              </div>

              {/* Right side - QR Code */}
              <div className="text-center">
                <Card className="p-8 bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200">
                  <CardContent className="p-0">
                    <div className="flex items-center justify-center mb-6">
                      <QrCode className="w-8 h-8 text-blue-600 mr-3" />
                      <h4 className="text-xl font-semibold text-gray-900">Quick Install ResusMGR</h4>
                    </div>
                    
                    {/* QR Code - Real QR code for PWA installation */}
                    <div className="bg-white p-6 rounded-xl shadow-lg mb-6 inline-block">
                      {qrCodeUrl ? (
                        <img 
                          src={qrCodeUrl} 
                          alt="QR Code for ResusMGR PWA" 
                          className="w-48 h-48 mx-auto rounded-lg"
                        />
                      ) : (
                        <div className="w-48 h-48 mx-auto bg-gray-200 rounded-lg flex items-center justify-center">
                          <div className="text-gray-500">Loading QR Code...</div>
                        </div>
                      )}
                    </div>
                    
                    <p className="text-gray-600 mb-4">
                      Scan with your mobile device camera to install ResusMGR on your device
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                <Heart className="w-5 h-5 text-white" />
              </div>
              <div>
                <h4 className="text-lg font-bold">ResusMGR</h4>
                <p className="text-gray-400 text-sm">Developed by Ashley James Medical</p>
              </div>
            </div>
            
            <div className="text-center md:text-right">
              <p className="text-gray-400 text-sm">
                © 2024 Ashley James Medical. All rights reserved.
              </p>
              <p className="text-gray-500 text-xs mt-1">
                UK Resuscitation Council Guidelines 2021 Compliant
              </p>
            </div>
          </div>
          <FooterLinks />
        </div>
      </footer>
    </div>
    </>
  );
}
