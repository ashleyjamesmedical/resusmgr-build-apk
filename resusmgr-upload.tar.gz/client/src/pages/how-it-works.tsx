import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Heart, 
  Shield, 
  Users, 
  Clock, 
  FileText, 
  Award, 
  Smartphone, 
  Play, 
  CheckCircle2,
  Timer,
  Calculator,
  Stethoscope,
  Target,
  AlertTriangle,
  UserCheck,
  Download,
  ArrowRight,
  Zap,
  BarChart3,
  Lock,
  BookOpen,
  Headphones
} from "lucide-react";
import FooterLinks from "@/components/footer-links";

export default function HowItWorks() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="container mx-auto px-4 py-16">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              How ResusMGR Works
            </h1>
            <p className="text-xl md:text-2xl text-blue-100 mb-8 leading-relaxed">
              The complete guide to using ResusMGR for professional emergency resuscitation management. 
              Discover why NHS healthcare professionals trust our platform.
            </p>
            
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button 
                onClick={() => window.location.href = '/auth'}
                size="lg"
                className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-200"
              >
                Sign Up Now
              </Button>
              <Button 
                onClick={() => window.location.href = '/'}
                size="lg"
                variant="outline"
                className="bg-transparent text-white border-white hover:bg-white hover:text-blue-600 px-8 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-200"
              >
                Back to Home
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Overview */}
      <div className="bg-white py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              Built for NHS Emergency Professionals
            </h2>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto mb-8">
              ResusMGR is specifically designed for UK pre-hospital emergency care professionals including 
              First Aiders, Emergency Medical Technicians, Paramedics, and Ambulance Staff. Every feature 
              is built around real-world emergency scenarios.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">NHS Compliant</h3>
                <p className="text-gray-600">UK RC Guidelines (2021) & JRCALC (2024) compliant</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Time-Saving</h3>
                <p className="text-gray-600">Reduce documentation time by 70% with automated logging</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Lock className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Secure</h3>
                <p className="text-gray-600">100% encrypted patient data with NHS-grade security</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Core Features Walkthrough */}
      <div className="bg-gray-50 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Complete Resuscitation Protocol Suite
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Three comprehensive protocol levels covering every cardiac arrest scenario you may encounter in the field.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* BLS Protocol */}
            <Card className="hover:shadow-xl transition-shadow duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-4">
                  <Heart className="w-6 h-6 text-green-600" />
                </div>
                <CardTitle className="text-2xl">Basic Life Support (BLS)</CardTitle>
                <Badge variant="secondary" className="w-fit">Free Access</Badge>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-6">
                  Essential CPR and defibrillation protocols for adult and paediatric patients. 
                  Perfect for first aiders and basic responders.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                    <span>CPR ratio and metronome guidance</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                    <span>2-minute compression swap reminder</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                    <span>Basic BLS airway and CPR event logging - Easily scaled up to ILS and ALS when additional resources arrive</span>
                  </div>

                </div>
              </CardContent>
            </Card>

            {/* ILS Protocol */}
            <Card className="hover:shadow-xl transition-shadow duration-300 border-blue-200">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-4">
                  <Stethoscope className="w-6 h-6 text-blue-600" />
                </div>
                <CardTitle className="text-2xl">Intermediate Life Support (ILS)</CardTitle>
                <Badge className="w-fit bg-blue-600">Premium - £1.99/month</Badge>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-6">
                  Advanced airway management and medication protocols for EMTs and 
                  intermediate-level practitioners.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-blue-500" />
                    <span>Advanced airway techniques</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-blue-500" />
                    <span>Reversible causes (4Hs & 4Ts)</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-blue-500" />
                    <span>ECG rhythm recognition</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* ALS Protocol */}
            <Card className="hover:shadow-xl transition-shadow duration-300 border-purple-200">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-4">
                  <Target className="w-6 h-6 text-purple-600" />
                </div>
                <CardTitle className="text-2xl">Advanced Life Support (ALS)</CardTitle>
                <Badge className="w-fit bg-purple-600">Premium - £1.99/month</Badge>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-6">
                  Complete advanced protocols for paramedics including complex drug calculations, 
                  advanced procedures, and comprehensive patient management.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-purple-500" />
                    <span>Advanced drug and intervention protocols</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-purple-500" />
                    <span>Automated drug calculations</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-purple-500" />
                    <span>Reversible causes tracking</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-purple-500" />
                    <span>Automatic Adrenaline reminders</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Key Features */}
      <div className="bg-white py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Revolutionary Features That Save Time & Lives
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Every feature is designed to reduce your cognitive load during high-stress emergency situations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* Real-time Intervention Logging */}
            <div className="flex gap-6">
              <div className="flex-shrink-0">
                <div className="w-16 h-16 bg-blue-100 rounded-xl flex items-center justify-center">
                  <FileText className="w-8 h-8 text-blue-600" />
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Real-time Intervention Logging</h3>
                <p className="text-gray-600 mb-4">
                  Automatically timestamps and records every intervention during resuscitation. 
                  No more manual note-taking - focus on the patient while ResusMGR handles documentation.
                </p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <ArrowRight className="w-4 h-4 text-blue-500" />
                    <span className="text-sm">One-tap intervention recording</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ArrowRight className="w-4 h-4 text-blue-500" />
                    <span className="text-sm">Automatic timestamp generation</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ArrowRight className="w-4 h-4 text-blue-500" />
                    <span className="text-sm">Team member assignment tracking</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Smart Drug Calculator */}
            <div className="flex gap-6">
              <div className="flex-shrink-0">
                <div className="w-16 h-16 bg-green-100 rounded-xl flex items-center justify-center">
                  <Calculator className="w-8 h-8 text-green-600" />
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Smart Drug Calculator</h3>
                <p className="text-gray-600 mb-4">
                  Weight-based drug calculations for paediatric and adult patients. Eliminates calculation 
                  errors with pre-programmed JRCALC-compliant drug protocols.
                </p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <ArrowRight className="w-4 h-4 text-green-500" />
                    <span className="text-sm">Instant dose calculations</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ArrowRight className="w-4 h-4 text-green-500" />
                    <span className="text-sm">Volume and concentration guidance</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ArrowRight className="w-4 h-4 text-green-500" />
                    <span className="text-sm">Age-appropriate pediatric dosing</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Audio Prompts */}
            <div className="flex gap-6">
              <div className="flex-shrink-0">
                <div className="w-16 h-16 bg-purple-100 rounded-xl flex items-center justify-center">
                  <Headphones className="w-8 h-8 text-purple-600" />
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Audio Guidance & Metronome</h3>
                <p className="text-gray-600 mb-4">
                  Hands-free audio prompts guide you through protocols while the built-in metronome 
                  ensures perfect CPR timing at 100-120 BPM.
                </p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <ArrowRight className="w-4 h-4 text-purple-500" />
                    <span className="text-sm">Hands-free operation</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ArrowRight className="w-4 h-4 text-purple-500" />
                    <span className="text-sm">CPR timing metronome</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ArrowRight className="w-4 h-4 text-purple-500" />
                    <span className="text-sm">Critical step reminders</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Team Management */}
            <div className="flex gap-6">
              <div className="flex-shrink-0">
                <div className="w-16 h-16 bg-orange-100 rounded-xl flex items-center justify-center">
                  <Users className="w-8 h-8 text-orange-600" />
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Team Role Management</h3>
                <p className="text-gray-600 mb-4">
                  Assign and track team member roles during multi-person resuscitations. 
                  Ensures clear communication and accountability in high-stress situations.
                </p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <ArrowRight className="w-4 h-4 text-orange-500" />
                    <span className="text-sm">Role-based task assignment</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ArrowRight className="w-4 h-4 text-orange-500" />
                    <span className="text-sm">Real-time team coordination</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ArrowRight className="w-4 h-4 text-orange-500" />
                    <span className="text-sm">Performance tracking</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* How It Saves Time */}
      <div className="bg-gray-50 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Save Hours of Documentation Time
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Traditional paper-based documentation takes 45-60 minutes per call. 
              ResusMGR reduces this to under 15 minutes with automated reporting.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-6">Traditional Method</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3 text-red-600">
                  <AlertTriangle className="w-5 h-5" />
                  <span>45-60 minutes of manual documentation</span>
                </div>
                <div className="flex items-center gap-3 text-red-600">
                  <AlertTriangle className="w-5 h-5" />
                  <span>Risk of missing critical timestamps</span>
                </div>
                <div className="flex items-center gap-3 text-red-600">
                  <AlertTriangle className="w-5 h-5" />
                  <span>Illegible handwriting issues</span>
                </div>
                <div className="flex items-center gap-3 text-red-600">
                  <AlertTriangle className="w-5 h-5" />
                  <span>Manual drug calculation errors</span>
                </div>
                <div className="flex items-center gap-3 text-red-600">
                  <AlertTriangle className="w-5 h-5" />
                  <span>Inconsistent reporting format</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-6">With ResusMGR</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3 text-green-600">
                  <CheckCircle2 className="w-5 h-5" />
                  <span>10-15 minutes automated report generation</span>
                </div>
                <div className="flex items-center gap-3 text-green-600">
                  <CheckCircle2 className="w-5 h-5" />
                  <span>Automatic timestamp recording</span>
                </div>
                <div className="flex items-center gap-3 text-green-600">
                  <CheckCircle2 className="w-5 h-5" />
                  <span>Digital, exportable reports</span>
                </div>
                <div className="flex items-center gap-3 text-green-600">
                  <CheckCircle2 className="w-5 h-5" />
                  <span>Zero calculation errors</span>
                </div>
                <div className="flex items-center gap-3 text-green-600">
                  <CheckCircle2 className="w-5 h-5" />
                  <span>Standardized NHS-compliant format</span>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center mt-12">
            <div className="bg-white rounded-2xl p-8 max-w-md mx-auto shadow-lg">
              <div className="text-6xl font-bold text-green-600 mb-2">70%</div>
              <p className="text-xl text-gray-600">Less documentation time</p>
              <p className="text-sm text-gray-500 mt-2">More time for patient care</p>
            </div>
          </div>
        </div>
      </div>

      {/* NHS Compliance */}
      <div className="bg-blue-600 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">
              NHS-Grade Security & Compliance
            </h2>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Built to meet the highest NHS security standards with full UK Resuscitation Council 
              and JRCALC Guidelines compliance.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="bg-white/10 border-white/20 text-white">
              <CardHeader>
                <Shield className="w-12 h-12 text-blue-200 mb-4" />
                <CardTitle className="text-xl text-white">Data Security</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-sm">End-to-end encryption</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-sm">GDPR compliant</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-sm">NHS Digital approved</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-sm">Secure cloud storage</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 border-white/20 text-white">
              <CardHeader>
                <BookOpen className="w-12 h-12 text-blue-200 mb-4" />
                <CardTitle className="text-xl text-white">Clinical Compliance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-sm">UK RC Guidelines 2021</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-sm">JRCALC Guidelines 2024</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-sm">Evidence-based protocols</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-sm">Regular clinical updates</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 border-white/20 text-white">
              <CardHeader>
                <Award className="w-12 h-12 text-blue-200 mb-4" />
                <CardTitle className="text-xl text-white">Professional Standards</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-sm">Developed by NHS professionals</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-sm">Peer-reviewed protocols</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-sm">Continuous quality improvement</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <span className="text-sm">Professional indemnity covered</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Getting Started */}
      <div className="bg-white py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Get Started in 3 Simple Steps
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Begin using ResusMGR immediately with our free BLS access. 
              Upgrade to premium features when you're ready for advanced protocols.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-blue-600">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Create Your Account</h3>
              <p className="text-gray-600">
                Register with your professional credentials. All NHS staff get verified access 
                with enhanced features.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-green-600">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Start with BLS</h3>
              <p className="text-gray-600">
                Access all Basic Life Support protocols immediately. Perfect for learning 
                the system and basic emergency response.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-purple-600">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Upgrade for Advanced</h3>
              <p className="text-gray-600">
                Subscribe to premium for ILS/ALS protocols, drug calculations, 
                and comprehensive reporting features.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 py-20">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-4xl font-bold text-white mb-4">
            Ready to Transform Your Emergency Response?
          </h3>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Join other NHS and private emergency healthcare professionals already using ResusMGR for better patient outcomes 
            and streamlined emergency documentation.
          </p>
          
          <div className="bg-white rounded-2xl p-8 max-w-md mx-auto shadow-lg mb-8">
            <div className="text-center mb-6">
              <div className="text-4xl font-bold text-gray-900 mb-2">
                £1.99<span className="text-lg font-normal text-gray-600">/month</span>
              </div>
              <p className="text-gray-600">Professional resuscitation tools</p>
              <p className="text-sm text-green-600 font-medium">BLS protocols always free</p>
            </div>
            
            <Button 
              onClick={() => window.location.href = '/auth'}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 px-6 rounded-xl font-semibold hover:from-blue-700 hover:to-purple-700 transition-all"
            >
              Sign Up Now
            </Button>
            
            <p className="text-xs text-gray-500 mt-4">
              No commitment • Cancel anytime • Full access to BLS protocols forever
            </p>
          </div>
        </div>
      </div>

      <FooterLinks />
    </div>
  );
}