import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import Navigation from "@/components/navigation";
import Timer from "@/components/timer";
import Metronome from "@/components/metronome";
import InterventionLogger from "@/components/intervention-logger";
import ReversibleCauses from "@/components/reversible-causes";
import DrugCalculator from "@/components/drug-calculator";
import PreSessionTeamManager from "@/components/pre-session-team-manager";
import InterventionConfirmationDialog from "@/components/intervention-confirmation-dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Heart, 
  Clock, 
  Volume2, 
  VolumeX, 
  Stethoscope, 
  Syringe, 
  Pill, 
  Zap,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Home,
  Users,
  Activity,
  FileText,
  Wind
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useTimer } from "@/hooks/useTimer";
import type { ResuscitationSession, Intervention } from "@shared/schema";
import FooterLinks from "@/components/footer-links";

export default function ALSPaediatric() {
  const [, params] = useRoute("/als-paediatric/:sessionId?");
  const sessionId = params?.sessionId ? parseInt(params.sessionId) : null;
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Debug logging
  console.log("ALS Paediatric - sessionId from params:", sessionId);
  console.log("ALS Paediatric - params:", params);
  
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [showEndSessionDialog, setShowEndSessionDialog] = useState(false);
  const [sessionOutcome, setSessionOutcome] = useState<"ROSC" | "ROLE" | "">("");
  const [sessionNotes, setSessionNotes] = useState("");
  const [blsStarted, setBlsStarted] = useState(false);
  const [ilsStarted, setIlsStarted] = useState(false);
  const [alsStarted, setAlsStarted] = useState(false);
  const [blsStartTime, setBlsStartTime] = useState<Date | null>(null);
  const [metronomeEnabled, setMetronomeEnabled] = useState(false);
  const [currentBpm, setCurrentBpm] = useState(120);
  const [twoMinuteTimer, setTwoMinuteTimer] = useState(120);
  const [showTwoMinutePrompt, setShowTwoMinutePrompt] = useState(false);
  const [confirmationMessage, setConfirmationMessage] = useState("");
  const [showInterventionConfirm, setShowInterventionConfirm] = useState(false);
  const [localTeamMembers, setLocalTeamMembers] = useState<any[]>([]);
  const [showSavingPage, setShowSavingPage] = useState(false);
  const [showReadyDialog, setShowReadyDialog] = useState(false);

  // Session ID input state
  const [customSessionId, setCustomSessionId] = useState("");
  const [sessionIdSet, setSessionIdSet] = useState(false);
  
  // Intervention confirmation dialog state
  const [showInterventionDialog, setShowInterventionDialog] = useState(false);
  const [selectedIntervention, setSelectedIntervention] = useState("");

  // Get user data
  const { data: user } = useQuery({
    queryKey: ["/api/user"]
  });

  // Get active session
  const { data: session, refetch: refetchSession } = useQuery({
    queryKey: ["/api/sessions/active"],
    enabled: !sessionId
  });

  // Get session by ID if provided
  const { data: sessionById } = useQuery({
    queryKey: ["/api/sessions", sessionId],
    enabled: !!sessionId
  });

  // Get interventions for the session
  const interventionsQuery = useQuery({
    queryKey: ["/api/sessions", sessionId, "interventions"],
    enabled: !!sessionId
  });

  // Get team members for the session
  const { data: sessionTeamMembers } = useQuery({
    queryKey: ["/api/sessions", sessionId, "team-members"],
    enabled: !!sessionId
  });

  const interventions = interventionsQuery.data || [];

  // Calculate elapsed time
  const { elapsedTime } = useTimer(blsStartTime);

  // Create new session mutation
  const createSessionMutation = useMutation({
    mutationFn: async (sessionData: any) => {
      const response = await apiRequest("POST", "/api/sessions", sessionData);
      return response.json();
    },
    onSuccess: (newSession: ResuscitationSession) => {
      toast({
        title: "Session Created",
        description: "ALS Paediatric session has been created successfully"
      });
      setLocation(`/als-paediatric/${newSession.id}`);
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Log intervention mutation
  const logInterventionMutation = useMutation({
    mutationFn: async (intervention: any) => {
      const response = await apiRequest("POST", "/api/interventions", intervention);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions", sessionId, "interventions"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error logging intervention",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Start protocol handlers
  const handleStartBLS = () => {
    if (localTeamMembers.length === 0) {
      toast({
        title: "Team Required",
        description: "Please add at least one team member before starting",
        variant: "destructive"
      });
      return;
    }

    setShowSavingPage(true);
    
    setTimeout(() => {
      const sessionData = {
        protocolType: "ALS",
        patientType: "Paediatric",
        customSessionId: customSessionId.trim() || undefined
      };

      createSessionMutation.mutate(sessionData);
      setBlsStarted(true);
      setBlsStartTime(new Date());
      setShowSavingPage(false);
      setShowReadyDialog(true);
    }, 2000);
  };

  const handleStartILS = () => {
    if (!blsStarted) {
      handleStartBLS();
    }
    setIlsStarted(true);
  };

  const handleStartALS = () => {
    if (!blsStarted) {
      handleStartBLS();
    }
    setAlsStarted(true);
  };

  // Intervention handler
  const handleIntervention = (type: string) => {
    setSelectedIntervention(type);
    setShowInterventionDialog(true);
  };

  // Confirm intervention
  const confirmIntervention = (details: any) => {
    if (sessionId) {
      logInterventionMutation.mutate({
        sessionId: sessionId,
        type: selectedIntervention,
        details: details
      });
    }
    setShowInterventionDialog(false);
    setSelectedIntervention("");
  };

  // End session handler
  const handleEndSession = () => {
    // Implementation for ending session
    setShowEndSessionDialog(false);
    toast({
      title: "Session Ended",
      description: "The resuscitation session has been completed"
    });
  };

  // Team members validation
  const validTeamMembers = localTeamMembers.filter(member => 
    member.name?.trim() && member.role?.trim()
  );

  // Show saving page
  if (showSavingPage) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto mb-4"></div>
            <h2 className="text-xl font-semibold mb-2">Saving Team Setup</h2>
            <p className="text-gray-600 dark:text-gray-400">
              Preparing your ALS Paediatric session...
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navigation />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Session Header */}
        <Card className="mb-8 border-orange-200 bg-orange-50 dark:bg-orange-900/20">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-orange-900 dark:text-orange-100 mb-2">
                  ALS Paediatric Resuscitation
                </h1>
                {(blsStarted || ilsStarted || alsStarted) && (
                  <p className="text-orange-700 dark:text-orange-300">
                    Resuscitation Started: {blsStartTime?.toLocaleString("en-GB")}
                  </p>
                )}
              </div>
              <div className="flex items-center gap-4">
                <Button
                  onClick={() => setIsAudioEnabled(!isAudioEnabled)}
                  variant="outline"
                  size="sm"
                >
                  {isAudioEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            
            {/* Custom Session ID Input */}
            <div className="mt-4">
              <Label htmlFor="sessionId" className="text-orange-800 dark:text-orange-200">
                CAD/Session ID (Optional)
              </Label>
              <Input
                id="sessionId"
                placeholder="Enter CAD number or session identifier"
                value={customSessionId}
                onChange={(e) => setCustomSessionId(e.target.value)}
                maxLength={50}
                className="mt-2"
              />
            </div>
            <Alert className="border-amber-300 bg-amber-50 dark:bg-amber-900/20 mt-4">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-amber-700 dark:text-amber-300 text-sm">
                <strong>Patient Data Warning:</strong> Do not enter any personal identifiable information (PII) 
                such as full names, NHS numbers, or addresses. Use CAD numbers or initials only for clinical tracking purposes.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {/* Enhanced Team Management */}
        <div className="mb-8">
          <PreSessionTeamManager 
            onTeamMembersChange={(members) => {
              setLocalTeamMembers(members);
            }}
            initialMembers={[]}
          />
        </div>

        {/* Protocol Start Buttons */}
        {!blsStarted && !ilsStarted && !alsStarted && (
          <Card className="mb-8 border-red-200 bg-red-50 dark:bg-red-900/20">
            <CardContent className="pt-8 pb-8 text-center">
              {validTeamMembers.length === 0 && (
                <Alert className="mb-6 border-amber-300 bg-amber-50 dark:bg-amber-900/20">
                  <AlertTriangle className="h-4 w-4 text-amber-600" />
                  <AlertDescription className="text-amber-700 dark:text-amber-300">
                    You must add at least one team member before starting resuscitation
                  </AlertDescription>
                </Alert>
              )}
              <div className="space-y-4">
                <Button
                  onClick={handleStartBLS}
                  disabled={validTeamMembers.length === 0}
                  className="bg-red-600 hover:bg-red-700 text-white text-lg px-8 py-3 h-auto"
                >
                  <Heart className="h-6 w-6 mr-3" />
                  Start ALS Paediatric Protocol
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Main Protocol Interface */}
        {(blsStarted || ilsStarted || alsStarted) && (
          <div className="space-y-6">
            {/* Timer Card */}
            <Card className="border-blue-200 bg-blue-50 dark:bg-blue-900/20">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center text-lg font-semibold text-blue-800 dark:text-blue-200">
                  <Clock className="w-5 h-5 mr-2" />
                  Resuscitation Timer
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Timer elapsedTime={elapsedTime} />
              </CardContent>
            </Card>

            {/* CPR Controls */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-red-600" />
                  CPR & Rhythm Management
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Button 
                    onClick={() => handleIntervention('CPR_START')}
                    className="bg-red-600 hover:bg-red-700 text-white"
                  >
                    <Heart className="h-4 w-4 mr-2" />
                    Start CPR
                  </Button>
                  <Button 
                    onClick={() => handleIntervention('PULSE_CHECK')}
                    variant="outline"
                  >
                    <Activity className="h-4 w-4 mr-2" />
                    Pulse Check
                  </Button>
                  <Button 
                    onClick={() => handleIntervention('RHYTHM_CHECK')}
                    variant="outline"
                  >
                    <Zap className="h-4 w-4 mr-2" />
                    Rhythm Check
                  </Button>
                  <Button 
                    onClick={() => handleIntervention('SHOCK')}
                    variant="outline"
                    className="border-orange-500 text-orange-700 hover:bg-orange-50"
                  >
                    <Zap className="h-4 w-4 mr-2" />
                    Defibrillation
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Drug Administration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Syringe className="h-5 w-5 text-blue-600" />
                  Drug Administration
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <Button 
                    onClick={() => handleIntervention('ADRENALINE')}
                    variant="outline"
                    className="border-blue-500 text-blue-700 hover:bg-blue-50"
                  >
                    <Syringe className="h-4 w-4 mr-2" />
                    Adrenaline
                  </Button>
                  <Button 
                    onClick={() => handleIntervention('AMIODARONE')}
                    variant="outline"
                    className="border-purple-500 text-purple-700 hover:bg-purple-50"
                  >
                    <Pill className="h-4 w-4 mr-2" />
                    Amiodarone
                  </Button>
                  <Button 
                    onClick={() => handleIntervention('IV_ACCESS')}
                    variant="outline"
                  >
                    <Syringe className="h-4 w-4 mr-2" />
                    IV/IO Access
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Airway & Breathing */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Stethoscope className="h-5 w-5 text-green-600" />
                  Airway & Breathing
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <Button 
                    onClick={() => handleIntervention('AIRWAY_MANAGEMENT')}
                    variant="outline"
                  >
                    <Stethoscope className="h-4 w-4 mr-2" />
                    Airway Management
                  </Button>
                  <Button 
                    onClick={() => handleIntervention('VENTILATION')}
                    variant="outline"
                  >
                    <Wind className="h-4 w-4 mr-2" />
                    Ventilation
                  </Button>
                  <Button 
                    onClick={() => handleIntervention('INTUBATION')}
                    variant="outline"
                  >
                    <Stethoscope className="h-4 w-4 mr-2" />
                    Intubation
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Intervention Timeline */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-blue-600" />
                  Intervention Timeline
                </CardTitle>
              </CardHeader>
              <CardContent>
                {interventionsQuery.isLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-600"></div>
                  </div>
                ) : interventions && interventions.length > 0 ? (
                  <div className="space-y-4 max-h-64 overflow-y-auto">
                    {interventions.slice().reverse().map((intervention: any) => (
                      <div key={intervention.id} className="flex items-center gap-4 p-3 border rounded-lg">
                        <div className="text-sm font-mono text-gray-500">
                          {intervention.timestamp ? new Date(intervention.timestamp).toLocaleTimeString() : 'Time not available'}
                        </div>
                        <div className="flex-1">
                          <span className="font-medium">{intervention.type.replace(/_/g, ' ')}</span>
                          {intervention.details && Object.keys(intervention.details).length > 0 && (
                            <div className="text-sm text-gray-600 mt-1">
                              {Object.entries(intervention.details).map(([key, value]) => (
                                <span key={key} className="mr-4">
                                  {key}: {typeof value === 'string' ? value : JSON.stringify(value)}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    No interventions recorded yet
                  </div>
                )}
              </CardContent>
            </Card>

            {/* End Session */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">End Session</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Complete the resuscitation session when finished
                    </p>
                  </div>
                  <Button
                    onClick={() => setShowEndSessionDialog(true)}
                    variant="outline"
                    className="border-red-500 text-red-700 hover:bg-red-50"
                  >
                    End Session
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Dialogs */}
        {showInterventionDialog && (
          <InterventionConfirmationDialog
            isOpen={showInterventionDialog}
            onClose={() => setShowInterventionDialog(false)}
            onConfirm={confirmIntervention}
            interventionName={selectedIntervention}
            teamMembers={sessionTeamMembers || []}
            interventionType="general"
            isAudioEnabled={isAudioEnabled}
          />
        )}

        {showEndSessionDialog && (
          <Dialog open={showEndSessionDialog} onOpenChange={setShowEndSessionDialog}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>End Resuscitation Session</DialogTitle>
                <DialogDescription>
                  Please select the outcome of this resuscitation session.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="outcome">Session Outcome</Label>
                  <Select value={sessionOutcome} onValueChange={setSessionOutcome}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select outcome" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ROSC">ROSC (Return of Spontaneous Circulation)</SelectItem>
                      <SelectItem value="ROLE">ROLE (Recognition of Life Extinct)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="notes">Additional Notes (Optional)</Label>
                  <Textarea
                    id="notes"
                    placeholder="Enter any additional notes about the session..."
                    value={sessionNotes}
                    onChange={(e) => setSessionNotes(e.target.value)}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowEndSessionDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleEndSession} disabled={!sessionOutcome}>
                  End Session
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}

        {showReadyDialog && (
          <Dialog open={showReadyDialog} onOpenChange={setShowReadyDialog}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle className="text-center text-xl font-bold text-green-700">
                  ALS Paediatric Protocol Ready
                </DialogTitle>
                <DialogDescription className="text-center">
                  Your resuscitation session has been initialized and is ready to begin.
                </DialogDescription>
              </DialogHeader>
              <div className="text-center py-4">
                <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
                <p className="text-lg font-medium mb-2">Session Active</p>
                <p className="text-sm text-gray-600">
                  All team members have been registered and the timer has started.
                </p>
              </div>
              <DialogFooter>
                <Button onClick={() => setShowReadyDialog(false)} className="w-full">
                  Begin Resuscitation
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </main>

      <FooterLinks />
    </div>
  );
}