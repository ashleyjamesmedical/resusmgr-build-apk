import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation, Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Shield, Activity, Clock, Heart } from "lucide-react";

const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

const registerSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  confirmEmail: z.string().email("Please enter a valid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  recoveryPasscode: z.string().length(10, "Recovery passcode must be exactly 10 digits").regex(/^\d+$/, "Recovery passcode must contain only numbers"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  role: z.string().min(1, "Please select your role"),
});

type LoginForm = z.infer<typeof loginSchema>;
type RegisterForm = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user, loginMutation, registerMutation } = useAuth();
  const [activeTab, setActiveTab] = useState("login");

  // Redirect if already logged in
  if (user) {
    setLocation("/");
    return null;
  }

  const loginForm = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const registerForm = useForm<RegisterForm>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      email: "",
      confirmEmail: "",
      password: "",
      recoveryPasscode: "",
      firstName: "",
      lastName: "",
      role: "Emergency Medicine",
    },
  });

  const handleLogin = (data: LoginForm) => {
    loginMutation.mutate(data, {
      onSuccess: () => {
        toast({
          title: "Welcome back!",
          description: "Successfully logged in to ResusMGR",
        });
        setLocation("/");
      },
    });
  };

  const handleRegister = (data: RegisterForm) => {
    console.log("Registration data:", data);
    // Remove confirmEmail before sending to backend
    const { confirmEmail, ...registrationData } = data;
    registerMutation.mutate(registrationData, {
      onSuccess: () => {
        toast({
          title: "Welcome to ResusMGR!",
          description: "Your account has been created successfully",
        });
        setLocation("/");
      },
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8 items-center min-h-[calc(100vh-4rem)]">
          
          {/* Hero Section */}
          <div className="space-y-6">
            <div className="flex items-center space-x-3 mb-8">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">ResusMGR</h1>
                <p className="text-gray-600">Professional Resuscitation Management</p>
              </div>
            </div>

            <div className="space-y-6">
              <h2 className="text-4xl font-bold text-gray-900 leading-tight">
                Advanced Emergency<br />
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Protocol Management
                </span>
              </h2>
              
              <p className="text-xl text-gray-600 leading-relaxed">
                Secure access to UK Resuscitation Council guidelines, intervention logging, 
                and comprehensive case management for emergency medical professionals.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-8">
                <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-gray-100">
                  <Shield className="w-8 h-8 text-blue-600 mb-3" />
                  <h3 className="font-semibold text-gray-900 mb-1">Secure Data</h3>
                  <p className="text-sm text-gray-600">Encrypted storage and secure authentication</p>
                </div>
                
                <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-gray-100">
                  <Activity className="w-8 h-8 text-purple-600 mb-3" />
                  <h3 className="font-semibold text-gray-900 mb-1">Real-time Logging</h3>
                  <p className="text-sm text-gray-600">Live intervention and timing tracking</p>
                </div>
                
                <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-gray-100">
                  <Clock className="w-8 h-8 text-green-600 mb-3" />
                  <h3 className="font-semibold text-gray-900 mb-1">Quick Access</h3>
                  <p className="text-sm text-gray-600">Instant protocol access from any device</p>
                </div>
              </div>
            </div>
          </div>

          {/* Auth Form */}
          <div className="lg:pl-8">
            <div className="w-full max-w-lg mx-auto bg-white rounded-lg shadow-xl p-6">
              <div className="pb-4">
                <h2 className="text-2xl font-bold text-center text-gray-900">
                  Access ResusMGR
                </h2>
                <p className="text-center text-gray-600">
                  Secure login for emergency medical professionals
                </p>
              </div>
              
              <div>
                {/* Reset Password Link - Outside tabs */}
                <div className="mb-6 bg-yellow-100 border-2 border-yellow-400 rounded-lg p-4 text-center">
                  <p className="text-lg font-bold text-yellow-800 mb-2">FORGOT PASSWORD?</p>
                  <button
                    type="button"
                    onClick={() => setLocation("/reset-password")}
                    className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-bold text-lg"
                  >
                    RESET PASSWORD HERE
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-8">
                  {/* Login Form */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Sign In</h3>
                    {/* Reset Password Link - Top of Login Tab */}
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-center mb-4">
                      <span className="text-sm text-blue-800">Need to reset your password? </span>
                      <button
                        type="button"
                        onClick={() => setLocation("/reset-password")}
                        className="text-blue-600 hover:text-blue-800 underline font-medium text-sm ml-1"
                      >
                        Click here to reset it
                      </button>
                    </div>
                    
                    <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="login-email">Email Address</Label>
                        <Input
                          id="login-email"
                          type="email"
                          placeholder="your.email@hospital.nhs.uk"
                          {...loginForm.register("email")}
                        />
                        {loginForm.formState.errors.email && (
                          <p className="text-sm text-red-600">{loginForm.formState.errors.email.message}</p>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="login-password">Password</Label>
                        <Input
                          id="login-password"
                          type="password"
                          placeholder="Enter your password"
                          {...loginForm.register("password")}
                        />
                        {loginForm.formState.errors.password && (
                          <p className="text-sm text-red-600">{loginForm.formState.errors.password.message}</p>
                        )}
                      </div>
                      
                      <Button 
                        type="submit" 
                        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                        disabled={loginMutation.isPending}
                      >
                        {loginMutation.isPending ? "Signing In..." : "Sign In"}
                      </Button>
                    </form>
                    
                    {/* Reset Password Section - Should be visible */}
                    <div className="mt-6 p-4 bg-red-100 border-2 border-red-300 rounded-lg text-center" style={{display: 'block', visibility: 'visible'}}>
                      <p className="text-lg font-bold text-red-800 mb-3">RESET PASSWORD SECTION</p>
                      <p className="text-sm text-gray-600 mb-2">Forgot your password?</p>
                      <button
                        type="button"
                        onClick={() => setLocation("/reset-password")}
                        className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded text-lg font-bold"
                      >
                        RESET PASSWORD
                      </button>
                    </div>
                  </div>
                  
                  {/* Register Form */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Create Account</h3>
                    <form onSubmit={registerForm.handleSubmit(handleRegister)} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="register-firstName">First Name</Label>
                          <Input
                            id="register-firstName"
                            placeholder="John"
                            {...registerForm.register("firstName")}
                          />
                          {registerForm.formState.errors.firstName && (
                            <p className="text-sm text-red-600">{registerForm.formState.errors.firstName.message}</p>
                          )}
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="register-lastName">Last Name</Label>
                          <Input
                            id="register-lastName"
                            placeholder="Smith"
                            {...registerForm.register("lastName")}
                          />
                          {registerForm.formState.errors.lastName && (
                            <p className="text-sm text-red-600">{registerForm.formState.errors.lastName.message}</p>
                          )}
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="register-email">Email Address</Label>
                          <Input
                            id="register-email"
                            type="email"
                            placeholder="your.email@hospital.nhs.uk"
                            {...registerForm.register("email")}
                          />
                          {registerForm.formState.errors.email && (
                            <p className="text-sm text-red-600">{registerForm.formState.errors.email.message}</p>
                          )}
                        </div>
                        
                        <div className="space-y-2 bg-yellow-100 p-4 border-2 border-yellow-500">
                          <div className="text-red-600 font-bold text-lg">CONFIRM EMAIL FIELD TEST</div>
                          <Label htmlFor="register-confirm-email">Confirm Email Address</Label>
                          <Input
                            id="register-confirm-email"
                            type="email"
                            placeholder="Re-enter your email address"
                            {...registerForm.register("confirmEmail")}
                          />
                          {registerForm.formState.errors.confirmEmail && (
                            <p className="text-sm text-red-600">{registerForm.formState.errors.confirmEmail.message}</p>
                          )}
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="register-recovery">10-Digit Recovery Passcode</Label>
                        <Input
                          id="register-recovery"
                          type="text"
                          placeholder="Enter 10 digits (e.g., 1234567890)"
                          maxLength={10}
                          {...registerForm.register("recoveryPasscode")}
                        />
                        <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mt-2">
                          <p className="text-xs text-amber-800 font-medium">
                            ⚠️ Important: Choose and remember your recovery passcode
                          </p>
                          <p className="text-xs text-amber-700 mt-1">
                            This 10-digit code will be needed to reset your password if you forget it. Make sure to write it down safely.
                          </p>
                        </div>
                        {registerForm.formState.errors.recoveryPasscode && (
                          <p className="text-sm text-red-600">{registerForm.formState.errors.recoveryPasscode.message}</p>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="register-role">Professional Role</Label>
                        <Select onValueChange={(value) => registerForm.setValue("role", value)} defaultValue="Emergency Medicine">
                          <SelectTrigger>
                            <SelectValue placeholder="Select your role" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Emergency Medicine">Emergency Medicine</SelectItem>
                            <SelectItem value="Paramedic">Paramedic</SelectItem>
                            <SelectItem value="Critical Care Paramedic">Critical Care Paramedic</SelectItem>
                            <SelectItem value="Emergency Care Assistant">Emergency Care Assistant</SelectItem>
                            <SelectItem value="Student Paramedic">Student Paramedic</SelectItem>
                            <SelectItem value="Emergency Medical Technician">Emergency Medical Technician</SelectItem>
                            <SelectItem value="Other Healthcare Professional">Other Healthcare Professional</SelectItem>
                          </SelectContent>
                        </Select>
                        {registerForm.formState.errors.role && (
                          <p className="text-sm text-red-600">{registerForm.formState.errors.role.message}</p>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="register-password">Password</Label>
                        <Input
                          id="register-password"
                          type="password"
                          placeholder="Create a secure password"
                          {...registerForm.register("password")}
                        />
                        {registerForm.formState.errors.password && (
                          <p className="text-sm text-red-600">{registerForm.formState.errors.password.message}</p>
                        )}
                      </div>
                      
                      <Button 
                        type="submit" 
                        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                        disabled={registerMutation.isPending}
                      >
                        {registerMutation.isPending ? "Creating Account..." : "Create Account"}
                      </Button>
                    </form>
                  </div>
                </div>
                
                <div className="mt-6 text-center">
                  <p className="text-xs text-gray-500">
                    By signing in, you agree to our terms of service and privacy policy.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}