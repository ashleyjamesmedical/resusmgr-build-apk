import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { CreditCard, ArrowLeft, AlertTriangle } from "lucide-react";

const cancelSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

type CancelForm = z.infer<typeof cancelSchema>;

export default function CancelSubscription() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const form = useForm<CancelForm>({
    resolver: zodResolver(cancelSchema),
    defaultValues: {
      email: "",
    },
  });

  const handleCancel = async (data: CancelForm) => {
    setIsLoading(true);
    try {
      const response = await apiRequest("POST", "/api/cancel-subscription-public", {
        email: data.email,
      });

      if (response.ok) {
        const result = await response.json();
        setIsSuccess(true);
        toast({
          title: "Subscription Cancelled",
          description: result.message || "Your subscription has been successfully cancelled.",
        });
      } else {
        const error = await response.text();
        toast({
          title: "Cancellation Failed",
          description: error || "Unable to find an active subscription for this email address.",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      toast({
        title: "Cancellation Failed",
        description: error.message || "An error occurred while cancelling your subscription.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <Card className="shadow-xl border-0 backdrop-blur-sm bg-white/95">
            <CardHeader className="text-center pb-6">
              <div className="mx-auto mb-4 w-16 h-16 bg-green-600 rounded-full flex items-center justify-center">
                <CreditCard className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl font-bold text-green-600">
                Subscription Cancelled
              </CardTitle>
              <CardDescription className="text-gray-600">
                Your subscription has been successfully cancelled. You will not be charged again.
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <div className="space-y-4">
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
                  <p className="text-sm text-green-800">
                    ✓ Subscription cancelled successfully
                  </p>
                  <p className="text-xs text-green-600 mt-1">
                    You'll retain access until your current billing period ends
                  </p>
                </div>
                
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => setLocation("/auth")}
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Sign In
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Card className="shadow-xl border-0 backdrop-blur-sm bg-white/95">
          <CardHeader className="text-center pb-6">
            <div className="mx-auto mb-4 w-16 h-16 bg-gradient-to-r from-orange-600 to-red-600 rounded-full flex items-center justify-center">
              <CreditCard className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
              Cancel Subscription
            </CardTitle>
            <CardDescription className="text-gray-600">
              Cancel your ResusMGR subscription without needing to log in
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-4">
              <div className="flex items-start space-x-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-xs text-amber-800 font-medium">
                    Important Notice
                  </p>
                  <p className="text-xs text-amber-700 mt-1">
                    This will cancel any active subscriptions associated with your email address. 
                    You'll retain access until your current billing period ends.
                  </p>
                </div>
              </div>
            </div>

            <form onSubmit={form.handleSubmit(handleCancel)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@hospital.nhs.uk"
                  {...form.register("email")}
                />
                <p className="text-xs text-gray-600">
                  Enter the email address associated with your ResusMGR subscription
                </p>
                {form.formState.errors.email && (
                  <p className="text-sm text-red-600">{form.formState.errors.email.message}</p>
                )}
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700"
                disabled={isLoading}
              >
                {isLoading ? "Cancelling Subscription..." : "Cancel Subscription"}
              </Button>
              
              <Button
                type="button"
                variant="ghost"
                className="w-full"
                onClick={() => setLocation("/reset-password")}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Password Reset
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}