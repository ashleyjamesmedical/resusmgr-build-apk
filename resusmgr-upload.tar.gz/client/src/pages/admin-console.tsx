import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Shield, Users, Server, UserX, Trash2, Crown, AlertTriangle, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Link } from "wouter";

interface AdminUser {
  id: string;
  email: string;
  firstName: string | null;
  lastName: string | null;
  profileImageUrl: string | null;
  role: string | null;
  subscriptionActive: boolean;
  disclaimerAccepted: boolean;
  lastLoginAt: Date | null;
  createdAt: Date | null;
}

interface ServerStatus {
  uptime: number;
  memoryUsage: number;
  activeConnections: number;
  dbConnectionStatus: string;
}

export default function AdminConsole() {
  const { user: currentUser } = useAuth();
  const { toast } = useToast();
  const [selectedAction, setSelectedAction] = useState<string | null>(null);

  // Check if user is admin - but allow access since backend verification works
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-4">
        <div className="max-w-md mx-auto mt-20">
          <Card>
            <CardContent className="p-8 text-center">
              <p>Loading user data...</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Since backend admin endpoints are working, proceed with admin console
  if (currentUser && currentUser.role !== "Administrator") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-4">
        <div className="max-w-md mx-auto mt-20">
          <Card className="border-red-200">
            <CardHeader className="text-center">
              <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <CardTitle className="text-red-600">Access Denied</CardTitle>
              <CardDescription>
                You do not have administrator privileges to access this page.
                <br />
                Debug: User exists: {currentUser ? 'Yes' : 'No'}
                <br />
                Current role: '{currentUser?.role || 'undefined'}'
                <br />
                Expected: 'Administrator'
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/" className="w-full">
                <Button variant="outline" className="w-full">
                  Return to Dashboard
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Fetch server status
  const { data: serverStatus, isLoading: statusLoading } = useQuery<ServerStatus>({
    queryKey: ["/api/admin/server-status"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Fetch active users
  const { data: activeUsers, isLoading: usersLoading } = useQuery<AdminUser[]>({
    queryKey: ["/api/admin/users"],
    refetchInterval: 60000, // Refresh every minute
  });

  // Fetch unauthorized participation reports
  const { data: unauthorizedReports, isLoading: reportsLoading, error: reportsError, refetch: refetchReports } = useQuery<any[]>({
    queryKey: ["/api/admin/unauthorized-participation-reports"],
    staleTime: 0, // Always fetch fresh data
  });

  // Fetch support conversations
  const { data: supportConversations, isLoading: conversationsLoading, refetch: refetchConversations } = useQuery<any[]>({
    queryKey: ["/api/admin/support-conversations"],
    staleTime: 0,
  });

  // Function to force refresh by invalidating cache
  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/admin/unauthorized-participation-reports"] });
    queryClient.removeQueries({ queryKey: ["/api/admin/unauthorized-participation-reports"] });
    refetchReports();
  };

  // State for review dialog
  const [reviewingReport, setReviewingReport] = useState<any>(null);
  const [reviewAction, setReviewAction] = useState<'keep' | 'remove' | ''>('');
  const [adminNotes, setAdminNotes] = useState('');

  // Mutation for resolving reports
  const resolveReportMutation = useMutation({
    mutationFn: async ({ reportId, action, notes }: { reportId: number, action: 'keep' | 'remove', notes: string }) => {
      const response = await apiRequest("POST", `/api/admin/unauthorized-participation-reports/${reportId}/resolve`, {
        action,
        adminNotes: notes,
        reviewedBy: currentUser?.username || 'Admin'
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Report Resolved",
        description: "The unauthorised participation report has been successfully resolved.",
      });
      setReviewingReport(null);
      setReviewAction('');
      setAdminNotes('');
      handleRefresh();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to resolve the report",
        variant: "destructive",
      });
    },
  });

  // Calculate report counts
  const reportsArray = Array.isArray(unauthorizedReports) ? unauthorizedReports : [];
  const pendingReports = reportsArray.filter(report => report && report.status === 'pending');
  const totalReportsCount = reportsArray.length;
  const pendingCount = pendingReports.length;



  // User action mutations
  const blockUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const response = await apiRequest("PATCH", `/api/admin/users/${userId}/block`);
      return await response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      const action = data.action; // 'blocked' or 'unblocked'
      toast({
        title: action === 'blocked' ? "User Blocked" : "User Unblocked",
        description: action === 'blocked' ? "User has been successfully blocked." : "User has been successfully unblocked.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update user status.",
        variant: "destructive",
      });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("DELETE", `/api/admin/users/${userId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "User Deleted",
        description: "User has been permanently deleted.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete user.",
        variant: "destructive",
      });
    },
  });

  const makeAdminMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("PATCH", `/api/admin/users/${userId}/make-admin`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "User Promoted",
        description: "User has been granted Administrator privileges.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to promote user to admin.",
        variant: "destructive",
      });
    },
  });

  const makeProUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const response = await apiRequest("PATCH", `/api/admin/users/${userId}/make-pro`);
      return await response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      const action = data.action; // 'upgraded' or 'downgraded'
      toast({
        title: action === 'upgraded' ? "User Upgraded" : "User Downgraded",
        description: action === 'upgraded' ? "User has been granted Pro access." : "User has been downgraded to Free access.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update user subscription.",
        variant: "destructive",
      });
    },
  });

  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };

  const getInitials = (firstName: string | null, lastName: string | null) => {
    const first = firstName?.[0] || "";
    const last = lastName?.[0] || "";
    return (first + last).toUpperCase() || "?";
  };

  const isUserOnline = (adminUser: AdminUser) => {
    // If this is the current user viewing the admin panel, they're definitely online
    if (adminUser.id === currentUser?.id) return true;
    
    // Check lastActivityAt first (more accurate), then fall back to lastLoginAt
    const lastActivity = adminUser.lastActivityAt || adminUser.lastLoginAt;
    if (!lastActivity) return false;
    
    try {
      // Consider a user online if they've been active within the last 5 minutes  
      const lastActiveTime = new Date(lastActivity);
      const now = new Date();
      const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000);
      
      return lastActiveTime > fiveMinutesAgo;
    } catch (error) {
      console.error('Error parsing date for user', adminUser.firstName, adminUser.lastName, ':', error);
      return false;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">Admin Console</h1>
          </div>
          <p className="text-gray-600">System administration and user management</p>
          <Link href="/" className="inline-block mt-4">
            <Button variant="outline" size="sm">
              ← Back to Dashboard
            </Button>
          </Link>
        </div>



        {/* Server Status Card */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Server className="h-5 w-5" />
              Live Server Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            {statusLoading ? (
              <div className="text-center py-4 text-gray-500">Loading server status...</div>
            ) : serverStatus ? (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {formatUptime(serverStatus.uptime)}
                  </div>
                  <div className="text-sm text-gray-600">Uptime</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {Math.round(serverStatus.memoryUsage)}%
                  </div>
                  <div className="text-sm text-gray-600">Memory Usage</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">
                    {serverStatus.activeConnections}
                  </div>
                  <div className="text-sm text-gray-600">Active Connections</div>
                </div>
                <div className="text-center">
                  <Badge 
                    variant={serverStatus.dbConnectionStatus === "Connected" ? "default" : "destructive"}
                    className="text-sm"
                  >
                    {serverStatus.dbConnectionStatus}
                  </Badge>
                  <div className="text-sm text-gray-600 mt-1">Database</div>
                </div>
              </div>
            ) : (
              <div className="text-center py-4 text-red-500">Failed to load server status</div>
            )}
          </CardContent>
        </Card>


        {/* Unauthorized Participation Reports */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Unauthorised Participation Reports 
              {pendingCount > 0 && (
                <Badge variant="destructive" className="ml-2">
                  {pendingCount}
                </Badge>
              )}
              <span className="text-xs text-gray-500 ml-2">
                (Total: {totalReportsCount})
              </span>
              <Button
                onClick={handleRefresh}
                variant="outline"
                size="sm"
                className="ml-auto"
                disabled={reportsLoading}
              >
                <RefreshCw className={`h-4 w-4 ${reportsLoading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </CardTitle>
            <CardDescription>
              Security reports from users about unauthorised session participation
            </CardDescription>
          </CardHeader>
          <CardContent>
            {reportsError && (
              <div className="text-center py-4 text-red-500">
                Error loading reports: {(reportsError as any)?.message || 'Unknown error'}
              </div>
            )}
            {reportsLoading ? (
              <div className="text-center py-4 text-gray-500">Loading reports...</div>
            ) : Array.isArray(unauthorizedReports) && unauthorizedReports.length > 0 ? (
              <div className="space-y-4">
                {unauthorizedReports.map((report: any) => (
                  <div 
                    key={report.id} 
                    className={`flex items-start justify-between p-4 border rounded-lg transition-all ${
                      report.status === 'resolved' 
                        ? 'bg-gray-100 dark:bg-gray-800 border-gray-300 dark:border-gray-600 opacity-50' 
                        : 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
                    }`}
                    style={{
                      pointerEvents: report.status === 'resolved' ? 'none' : 'auto'
                    }}
                  >
                    <div className="flex-1">
                      <div className={`font-medium ${
                        report.status === 'resolved' ? 'text-gray-600' : 'text-red-800'
                      }`}>
                        Report #{report.id}
                      </div>
                      <div className={`text-sm mt-1 ${
                        report.status === 'resolved' ? 'text-gray-500' : 'text-red-600'
                      }`}>
                        Session ID: {report.sessionId} | Team Member ID: {report.teamMemberId}
                      </div>
                      <div className={`text-sm mt-2 ${
                        report.status === 'resolved' ? 'text-gray-500' : 'text-gray-700'
                      }`}>
                        <strong>Reason:</strong> {report.reason}
                      </div>
                      <div className="text-xs text-gray-500 mt-2">
                        Reported: {new Date(report.createdAt).toLocaleString('en-GB')}
                      </div>
                      {report.reviewedAt && (
                        <div className="text-xs text-green-600 mt-1">
                          Reviewed: {new Date(report.reviewedAt).toLocaleString('en-GB')}
                        </div>
                      )}
                      {report.adminNotes && (
                        <div className="text-xs text-gray-600 mt-1">
                          <strong>Admin Notes:</strong> {report.adminNotes}
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-2 ml-4">
                      <Badge variant={report.status === 'pending' ? 'destructive' : 'default'}>
                        {report.status}
                      </Badge>
                      {report.status === 'pending' && (
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="text-green-600"
                          onClick={() => setReviewingReport(report)}
                        >
                          Review
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">No unauthorised participation reports</div>
            )}
          </CardContent>
        </Card>

        {/* User Management */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Active Users ({activeUsers?.length || 0})
            </CardTitle>
            <CardDescription>
              Manage user accounts and permissions
            </CardDescription>
          </CardHeader>
          <CardContent>
            {usersLoading ? (
              <div className="text-center py-8 text-gray-500">Loading users...</div>
            ) : activeUsers && activeUsers.length > 0 ? (
              <div className="space-y-4">
                {activeUsers.map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="relative">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={user.profileImageUrl || undefined} />
                          <AvatarFallback>
                            {getInitials(user.firstName, user.lastName)}
                          </AvatarFallback>
                        </Avatar>
                        {/* Online status indicator */}
                        <div className={`absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full border-2 border-white ${
                          isUserOnline(user) ? 'bg-green-500' : 'bg-red-500'
                        }`} 
                        title={isUserOnline(user) ? 'Online' : 'Offline'} />
                      </div>
                      <div>
                        <div className="font-medium">
                          {user.firstName} {user.lastName}
                        </div>
                        <div className="text-sm text-gray-600">{user.email}</div>
                        <div className="text-xs text-gray-500 mb-1">
                          Last login: {user.lastLoginAt ? new Date(user.lastLoginAt).toLocaleString('en-GB') : 'Never'}
                        </div>
                        <div className="flex gap-2 mt-1">
                          <Badge variant={user.subscriptionActive ? "default" : "secondary"}>
                            {user.subscriptionActive ? "Pro" : "Free"}
                          </Badge>
                          <Badge variant={user.role === "Administrator" ? "destructive" : "outline"}>
                            {user.role || "User"}
                          </Badge>
                          {user.disclaimerAccepted && (
                            <Badge variant="outline" className="text-green-600">
                              Verified
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {currentUser && currentUser.id !== user.id && (
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => blockUserMutation.mutate(user.id)}
                          disabled={selectedAction === user.id}
                          className="text-orange-600 hover:text-orange-700"
                        >
                          <UserX className="h-4 w-4 mr-1" />
                          {user.role === 'Blocked' ? 'Unblock' : 'Block'}
                        </Button>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => makeProUserMutation.mutate(user.id)}
                          disabled={selectedAction === user.id}
                          className="text-blue-600 hover:text-blue-700"
                        >
                          <Crown className="h-4 w-4 mr-1" />
                          {user.subscriptionActive ? 'Downgrade to Free' : 'Make Pro'}
                        </Button>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => makeAdminMutation.mutate(user.id)}
                          disabled={selectedAction === user.id || user.role === 'Administrator'}
                          className="text-purple-600 hover:text-purple-700"
                        >
                          <Shield className="h-4 w-4 mr-1" />
                          {user.role === 'Administrator' ? 'Admin' : 'Make Admin'}
                        </Button>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            if (confirm(`Are you sure you want to permanently delete ${user.firstName} ${user.lastName}?`)) {
                              deleteUserMutation.mutate(user.id);
                            }
                          }}
                          disabled={selectedAction === user.id}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">No active users found</div>
            )}
          </CardContent>
        </Card>

        {/* Support Messages */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Support Messages
            </CardTitle>
            <CardDescription>
              User support requests and conversations
            </CardDescription>
          </CardHeader>
          <CardContent>
            {conversationsLoading ? (
              <div className="text-center py-8">Loading support conversations...</div>
            ) : supportConversations && supportConversations.length > 0 ? (
              <div className="space-y-4">
                {supportConversations.map((conversation: any) => (
                  <div key={conversation.id} className="p-4 bg-gray-50 rounded-lg border">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-medium">{conversation.title}</h4>
                          <Badge variant="outline" className="text-xs">
                            {conversation.type}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">
                          From: {conversation.createdBy}
                        </p>
                        <p className="text-sm text-gray-500">
                          Created: {new Date(conversation.createdAt).toLocaleString('en-GB')}
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(`/chat/${conversation.id}`, '_blank')}
                      >
                        View & Reply
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">No support messages found</div>
            )}
          </CardContent>
        </Card>

        {/* Review Report Dialog */}
        <Dialog open={!!reviewingReport} onOpenChange={() => setReviewingReport(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Review Unauthorised Participation Report #{reviewingReport?.id}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="text-sm">
                  <strong>Session ID:</strong> {reviewingReport?.sessionId}
                </div>
                <div className="text-sm">
                  <strong>Team Member ID:</strong> {reviewingReport?.teamMemberId}
                </div>
                <div className="text-sm mt-2">
                  <strong>Reason:</strong> {reviewingReport?.reason}
                </div>
                <div className="text-sm mt-2">
                  <strong>Reported:</strong> {reviewingReport?.createdAt ? new Date(reviewingReport.createdAt).toLocaleString('en-GB') : 'Unknown'}
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-base font-medium">Resolution Action:</Label>
                <RadioGroup value={reviewAction} onValueChange={setReviewAction}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="keep" id="keep" />
                    <Label htmlFor="keep">Keep team member - Report was invalid</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="remove" id="remove" />
                    <Label htmlFor="remove">Remove team member - Report was valid</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label htmlFor="admin-notes">Admin Notes:</Label>
                <Textarea
                  id="admin-notes"
                  placeholder="Add notes about this resolution..."
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setReviewingReport(null)}>
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  if (reviewAction && reviewingReport) {
                    resolveReportMutation.mutate({
                      reportId: reviewingReport.id,
                      action: reviewAction as 'keep' | 'remove',
                      notes: adminNotes
                    });
                  }
                }}
                disabled={!reviewAction || resolveReportMutation.isPending}
              >
                {resolveReportMutation.isPending ? 'Resolving...' : 'Resolve Report'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}