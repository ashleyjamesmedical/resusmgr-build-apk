import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  ArrowLeft,
  Clock,
  User,
  FileText,
  Download,
  Share,
  Trash2,
  CheckCircle,
  XCircle,
  Activity,
  Pill,
  AlertTriangle,
} from "lucide-react";
import { Link } from "wouter";

export default function ResusSummary() {
  const [, params] = useRoute("/resus-summary/:id");
  const sessionId = params?.id ? parseInt(params.id) : null;
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  // Fetch session details
  const { data: session, isLoading: sessionLoading } = useQuery({
    queryKey: [`/api/sessions/${sessionId}`],
    enabled: !!sessionId,
  });

  // Fetch interventions
  const { data: interventions = [], isLoading: interventionsLoading } = useQuery({
    queryKey: [`/api/sessions/${sessionId}/interventions`],
    enabled: !!sessionId,
  });

  // Fetch drug doses
  const { data: drugDoses = [], isLoading: drugDosesLoading } = useQuery({
    queryKey: [`/api/sessions/${sessionId}/drug-doses`],
    enabled: !!sessionId,
  });

  // Fetch team members
  const { data: teamMembers = [], isLoading: teamMembersLoading } = useQuery({
    queryKey: [`/api/sessions/${sessionId}/team-members`],
    enabled: !!sessionId,
  });

  // Fetch reversible causes
  const { data: reversibleCauses, isLoading: causesLoading } = useQuery({
    queryKey: [`/api/sessions/${sessionId}/reversible-causes`],
    enabled: !!sessionId,
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (sessionId: number) => {
      const response = await apiRequest("DELETE", `/api/sessions/${sessionId}`);
      return response.json();
    },
    onSuccess: () => {
      // Invalidate and refetch sessions list
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      toast({
        title: "Resus Deleted",
        description: "The resuscitation report has been successfully deleted.",
      });
      // Navigate back to reports page
      setLocation("/reports");
    },
    onError: (error: Error) => {
      toast({
        title: "Delete Failed",
        description: error.message || "Unable to delete the report. Please try again.",
        variant: "destructive",
      });
    },
  });

  const isLoading = sessionLoading || interventionsLoading || drugDosesLoading || teamMembersLoading || causesLoading;

  if (!sessionId) {
    return <div>Invalid session ID</div>;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Loading resus details...</p>
        </div>
      </div>
    );
  }

  if (!session) {
    return <div>Session not found</div>;
  }

  const duration = session.endTime && session.startTime 
    ? Math.round((new Date(session.endTime).getTime() - new Date(session.startTime).getTime()) / 60000)
    : 0;

  const getOutcomeBadge = (outcome: string | null) => {
    if (!outcome) return <Badge variant="secondary">Ongoing</Badge>;
    
    switch (outcome) {
      case "ROSC":
        return <Badge className="bg-green-100 text-green-800 border-green-200"><CheckCircle className="w-3 h-3 mr-1" />ROSC</Badge>;
      case "ROLE":
        return <Badge className="bg-red-100 text-red-800 border-red-200"><XCircle className="w-3 h-3 mr-1" />ROLE</Badge>;
      default:
        return <Badge variant="secondary">{outcome}</Badge>;
    }
  };

  const downloadReport = async () => {
    try {
      // Generate PDF content (reuse the same function from reports page)
      generatePDF(session, interventions, drugDoses, reversibleCauses);
    } catch (error) {
      console.error("Error downloading report:", error);
      toast({
        title: "Download Failed",
        description: "Unable to download the report. Please try again.",
        variant: "destructive",
      });
    }
  };

  const generatePDF = (session: any, interventions: any[], drugDoses: any[], reversibleCauses: any) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    
    const duration = session.endTime && session.startTime 
      ? Math.round((new Date(session.endTime).getTime() - new Date(session.startTime).getTime()) / 60000)
      : 0;
    
    const html = `
<!DOCTYPE html>
<html>
<head>
    <title>Resuscitation Report - ${session.customSessionId ? session.customSessionId : `Resus #${session.id}`}</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 20px; 
            color: #333;
        }
        .header { 
            text-align: center; 
            border-bottom: 2px solid #2563eb; 
            padding-bottom: 20px; 
            margin-bottom: 30px;
        }
        .header h1 { 
            color: #2563eb; 
            margin: 0;
        }
        .section { 
            margin-bottom: 25px; 
            page-break-inside: avoid;
        }
        .section h2 { 
            color: #1e40af; 
            border-bottom: 1px solid #e5e7eb; 
            padding-bottom: 5px;
        }
        .info-grid { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 15px; 
            margin-bottom: 20px;
        }
        .info-item { 
            background: #f8fafc; 
            padding: 10px; 
            border-radius: 5px;
        }
        .info-label { 
            font-weight: bold; 
            color: #374151;
        }
        .intervention-item { 
            background: #f0f9ff; 
            border-left: 4px solid #2563eb; 
            padding: 10px; 
            margin-bottom: 10px;
        }
        .drug-item { 
            background: #f0fdf4; 
            border-left: 4px solid #059669; 
            padding: 10px; 
            margin-bottom: 10px;
        }
        .causes-grid { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 10px;
        }
        .cause-item { 
            padding: 8px; 
            border-radius: 5px;
        }
        .cause-checked { 
            background: #fee2e2; 
            color: #dc2626;
        }
        .cause-unchecked { 
            background: #f3f4f6; 
            color: #6b7280;
        }
        .team-member-item { 
            background: #fef3c7; 
            border-left: 4px solid #f59e0b; 
            padding: 10px; 
            margin-bottom: 10px;
        }
        .footer { 
            margin-top: 40px; 
            padding-top: 20px; 
            border-top: 1px solid #e5e7eb; 
            text-align: center; 
            color: #6b7280; 
            font-size: 12px;
        }
        @media print {
            body { margin: 0; }
            .header { page-break-after: avoid; }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>ResusMGR - Resuscitation Report</h1>
        <h2>${session.customSessionId ? session.customSessionId : `Resus #${session.id}`}</h2>
        <p>Generated: ${new Date().toLocaleString('en-GB')}</p>
    </div>
    
    <div class="section">
        <h2>Session Overview</h2>
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label">CAD Number / Patient ID:</div>
                <div><strong>${session.customSessionId || 'Not recorded'}</strong></div>
            </div>
            <div class="info-item">
                <div class="info-label">Protocol:</div>
                <div>${session.protocolType || 'Not specified'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Patient Type:</div>
                <div>${session.patientType || 'Not specified'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Outcome:</div>
                <div>${session.outcome || 'Ongoing'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Start Time:</div>
                <div>${session.startTime ? new Date(session.startTime).toLocaleString('en-GB') : 'Not recorded'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">End Time:</div>
                <div>${session.endTime ? new Date(session.endTime).toLocaleString('en-GB') : 'Ongoing'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Duration:</div>
                <div>${duration > 0 ? `${duration} minutes` : 'Ongoing'}</div>
            </div>
            <div class="info-item">
                <div class="info-label">Weight:</div>
                <div>${session.patientWeight ? `${session.patientWeight} kg` : 'Not recorded'}</div>
            </div>
        </div>
        ${session.notes ? `
        <div class="info-item">
            <div class="info-label">Notes:</div>
            <div>${session.notes}</div>
        </div>
        ` : ''}
    </div>
    
    ${interventions.length > 0 ? `
    <div class="section">
        <h2>Interventions (${interventions.length})</h2>
        ${interventions.map(intervention => `
        <div class="intervention-item">
            <strong>${intervention.type}</strong> - ${intervention.description}<br>
            <small>Time: ${new Date(intervention.timestamp).toLocaleString('en-GB')}</small>
        </div>
        `).join('')}
    </div>
    ` : ''}
    
    ${drugDoses.length > 0 ? `
    <div class="section">
        <h2>Drug Administration (${drugDoses.length})</h2>
        ${drugDoses.map(drug => `
        <div class="drug-item">
            <strong>${drug.drugName}</strong><br>
            Dose: ${drug.dose} | Volume: ${drug.volume} | Route: ${drug.route}<br>
            <small>Administered: ${new Date(drug.timestamp).toLocaleString('en-GB')}</small>
            ${drug.notes ? `<br><em>Notes: ${drug.notes}</em>` : ''}
        </div>
        `).join('')}
    </div>
    ` : ''}
    
    ${reversibleCauses ? `
    <div class="section">
        <h2>Reversible Causes (4Hs & 4Ts)</h2>
        <div class="causes-grid">
            <div class="cause-item ${reversibleCauses.hypoxia ? 'cause-checked' : 'cause-unchecked'}">
                ${reversibleCauses.hypoxia ? '✓' : '○'} Hypoxia
            </div>
            <div class="cause-item ${reversibleCauses.hypovolaemia ? 'cause-checked' : 'cause-unchecked'}">
                ${reversibleCauses.hypovolaemia ? '✓' : '○'} Hypovolaemia
            </div>
            <div class="cause-item ${reversibleCauses.hypoHyperkalaemia ? 'cause-checked' : 'cause-unchecked'}">
                ${reversibleCauses.hypoHyperkalaemia ? '✓' : '○'} Hypo/Hyperkalaemia
            </div>
            <div class="cause-item ${reversibleCauses.hypothermia ? 'cause-checked' : 'cause-unchecked'}">
                ${reversibleCauses.hypothermia ? '✓' : '○'} Hypothermia
            </div>
            <div class="cause-item ${reversibleCauses.thrombosis ? 'cause-checked' : 'cause-unchecked'}">
                ${reversibleCauses.thrombosis ? '✓' : '○'} Thrombosis
            </div>
            <div class="cause-item ${reversibleCauses.tensionPneumothorax ? 'cause-checked' : 'cause-unchecked'}">
                ${reversibleCauses.tensionPneumothorax ? '✓' : '○'} Tension Pneumothorax
            </div>
            <div class="cause-item ${reversibleCauses.tamponade ? 'cause-checked' : 'cause-unchecked'}">
                ${reversibleCauses.tamponade ? '✓' : '○'} Tamponade
            </div>
            <div class="cause-item ${reversibleCauses.toxins ? 'cause-checked' : 'cause-unchecked'}">
                ${reversibleCauses.toxins ? '✓' : '○'} Toxins
            </div>
        </div>
    </div>
    ` : ''}
    
    ${teamMembers.length > 0 ? `
    <div class="section">
        <h2>Resuscitation Team Members (${teamMembers.length})</h2>
        ${teamMembers.map(member => `
        <div class="team-member-item">
            <strong>${member.name || member.username || 'Unknown Member'}</strong>
            ${member.role ? ` - ${member.role}` : ''}
            <br><small>Added: ${new Date(member.createdAt).toLocaleString('en-GB')}</small>
        </div>
        `).join('')}
    </div>
    ` : ''}
    
    <div class="footer">
        <p>This report was generated by ResusMGR - Professional Resuscitation Management System</p>
        <p>For UK Emergency Services - Following Resuscitation Council UK Guidelines</p>
    </div>
</body>
</html>
    `;
    
    printWindow.document.write(html);
    printWindow.document.close();
    
    printWindow.onload = () => {
      printWindow.print();
      printWindow.close();
    };
  };

  const shareReport = () => {
    const shareUrl = `${window.location.origin}/resuscitation/${sessionId}`;
    navigator.clipboard.writeText(shareUrl).then(() => {
      toast({
        title: "Link Copied",
        description: "Report link copied to clipboard",
      });
    }).catch(() => {
      toast({
        title: "Share Failed",
        description: "Unable to copy link to clipboard",
        variant: "destructive",
      });
    });
  };

  const deleteReport = () => {
    if (sessionId && confirm("Are you sure you want to delete this resus report? This action cannot be undone.")) {
      deleteMutation.mutate(sessionId);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Link href="/reports">
              <Button variant="outline" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Reports
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">
                {session.customSessionId ? session.customSessionId : `Resus #${session.id}`} - Report Summary
              </h1>
              <p className="text-gray-600 dark:text-gray-400 mt-1">
                Detailed resuscitation session report
              </p>
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={downloadReport}
            >
              <Download className="w-4 h-4 mr-2" />
              Download
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="btn-medical-blue"
              onClick={shareReport}
            >
              <Share className="w-4 h-4 mr-2" />
              Share
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
              onClick={deleteReport}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete
            </Button>
          </div>
        </div>

        {/* Session Overview */}
        <Card className="medical-card mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-600" />
              Session Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
              <div className="flex items-center gap-3">
                <FileText className="w-4 h-4 text-gray-500" />
                <div>
                  <p className="text-sm text-gray-500">Protocol</p>
                  <p className="font-medium">{session.protocolType || 'Not specified'}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <User className="w-4 h-4 text-gray-500" />
                <div>
                  <p className="text-sm text-gray-500">Patient Type</p>
                  <p className="font-medium">{session.patientType || 'Not specified'}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Activity className="w-4 h-4 text-gray-500" />
                <div>
                  <p className="text-sm text-gray-500">Outcome</p>
                  <div>{getOutcomeBadge(session.outcome)}</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="w-4 h-4 text-gray-500" />
                <div>
                  <p className="text-sm text-gray-500">Duration</p>
                  <p className="font-medium">{duration > 0 ? `${duration} minutes` : 'Ongoing'}</p>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <p className="text-sm text-gray-500">Start Time</p>
                <p className="font-medium">{session.startTime ? new Date(session.startTime).toLocaleString('en-GB') : 'Not recorded'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">End Time</p>
                <p className="font-medium">{session.endTime ? new Date(session.endTime).toLocaleString('en-GB') : 'Ongoing'}</p>
              </div>
              {session.patientWeight && (
                <div>
                  <p className="text-sm text-gray-500">Patient Weight</p>
                  <p className="font-medium">{session.patientWeight} kg</p>
                </div>
              )}
            </div>

            {session.notes && (
              <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <p className="text-sm text-gray-500 mb-2">Notes</p>
                <p className="text-gray-900 dark:text-white">{session.notes}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Team Members */}
        <Card className="medical-card mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5 text-blue-600" />
              Resuscitation Team Members
            </CardTitle>
          </CardHeader>
          <CardContent>
            {teamMembers.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {teamMembers.map((member: any, index: number) => (
                  <div key={member.id} className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <User className="w-4 h-4 text-gray-500" />
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">
                        {member.name || member.username || `Team Member ${index + 1}`}
                      </p>
                      {member.role && (
                        <p className="text-xs text-blue-600 dark:text-blue-400 font-medium">
                          {member.role}
                        </p>
                      )}
                      <p className="text-sm text-gray-500">
                        Added: {new Date(member.createdAt).toLocaleString('en-GB')}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-gray-500">
                <User className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>No team members recorded for this session</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Interventions */}
        {interventions.length > 0 && (
          <Card className="medical-card mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-blue-600" />
                Interventions ({interventions.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {interventions.map((intervention: any, index: number) => (
                  <div key={index} className="p-3 bg-blue-50 dark:bg-blue-900/20 border-l-4 border-blue-500 rounded-r">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white">{intervention.type}</p>
                        <p className="text-gray-600 dark:text-gray-400 text-sm">{intervention.description}</p>
                      </div>
                      <p className="text-xs text-gray-500">{new Date(intervention.timestamp).toLocaleString('en-GB')}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Drug Administration */}
        {drugDoses.length > 0 && (
          <Card className="medical-card mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Pill className="w-5 h-5 text-green-600" />
                Drug Administration ({drugDoses.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {drugDoses.map((drug: any, index: number) => (
                  <div key={index} className="p-3 bg-green-50 dark:bg-green-900/20 border-l-4 border-green-500 rounded-r">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white">{drug.drugName}</p>
                        <p className="text-gray-600 dark:text-gray-400 text-sm">
                          Dose: {drug.dose} | Volume: {drug.volume} | Route: {drug.route}
                        </p>
                        {drug.notes && (
                          <p className="text-gray-500 text-xs italic mt-1">{drug.notes}</p>
                        )}
                      </div>
                      <p className="text-xs text-gray-500">{new Date(drug.timestamp).toLocaleString('en-GB')}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Reversible Causes */}
        {reversibleCauses && (
          <Card className="medical-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600" />
                Reversible Causes (4Hs & 4Ts)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { key: 'hypoxia', label: 'Hypoxia' },
                  { key: 'hypovolaemia', label: 'Hypovolaemia' },
                  { key: 'hypoHyperkalaemia', label: 'Hypo/Hyperkalaemia' },
                  { key: 'hypothermia', label: 'Hypothermia' },
                  { key: 'thrombosis', label: 'Thrombosis' },
                  { key: 'tensionPneumothorax', label: 'Tension Pneumothorax' },
                  { key: 'tamponade', label: 'Tamponade' },
                  { key: 'toxins', label: 'Toxins' },
                ].map((cause) => (
                  <div 
                    key={cause.key}
                    className={`p-3 rounded-lg text-center ${
                      reversibleCauses[cause.key]
                        ? 'bg-red-100 text-red-800 border border-red-200' 
                        : 'bg-gray-100 text-gray-600 border border-gray-200'
                    }`}
                  >
                    <div className="font-medium text-lg mb-1">
                      {reversibleCauses[cause.key] ? '✓' : '○'}
                    </div>
                    <div className="text-sm">{cause.label}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}