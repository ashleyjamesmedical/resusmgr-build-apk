import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import Navigation from "@/components/navigation";
import Timer from "@/components/timer";
import Metronome from "@/components/metronome";
import InterventionLogger from "@/components/intervention-logger";
import ReversibleCauses from "@/components/reversible-causes";
import DrugCalculator from "@/components/drug-calculator";
import PreSessionTeamManager from "@/components/pre-session-team-manager";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Heart, 
  Clock, 
  Volume2, 
  VolumeX, 
  Stethoscope, 
  Syringe, 
  Pill, 
  Zap,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Home,
  Users,
  Activity
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useTimer } from "@/hooks/useTimer";
import type { ResuscitationSession, Intervention } from "@shared/schema";
import FooterLinks from "@/components/footer-links";

export default function ILSAdult() {
  const [, params] = useRoute("/ils-adult/:sessionId?");
  const sessionId = params?.sessionId ? parseInt(params.sessionId) : null;
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [showEndSessionDialog, setShowEndSessionDialog] = useState(false);
  const [sessionOutcome, setSessionOutcome] = useState<"ROSC" | "ROLE" | "">("");
  const [sessionNotes, setSessionNotes] = useState("");
  const [blsStarted, setBlsStarted] = useState(false);
  const [ilsStarted, setIlsStarted] = useState(false);
  const [alsStarted, setAlsStarted] = useState(false);
  const [metronomeEnabled, setMetronomeEnabled] = useState(false);
  const [currentBpm, setCurrentBpm] = useState(120);
  const [twoMinuteTimer, setTwoMinuteTimer] = useState(120);
  const [showTwoMinutePrompt, setShowTwoMinutePrompt] = useState(false);
  const [localTeamMembers, setLocalTeamMembers] = useState<any[]>([]);
  
  // Intervention confirmation popup state
  const [showInterventionConfirm, setShowInterventionConfirm] = useState(false);
  const [confirmationMessage, setConfirmationMessage] = useState('');

  // Auto-hide confirmation popup after 1 second
  useEffect(() => {
    if (showInterventionConfirm) {
      const timer = setTimeout(() => {
        setShowInterventionConfirm(false);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [showInterventionConfirm]);

  // Fetch session data
  const { data: session, isLoading } = useQuery({
    queryKey: ["/api/sessions", sessionId],
    enabled: !!sessionId,
  });

  // Fetch session team members
  const { data: sessionTeamMembers } = useQuery({
    queryKey: ["/api/sessions", sessionId, "team-members"],
    enabled: !!sessionId,
  });

  // Fetch interventions for this session
  const { data: interventions, refetch: refetchInterventions } = useQuery({
    queryKey: ["/api/sessions", sessionId, "interventions"],
    enabled: !!sessionId,
  });

  // Timer hook
  const { elapsedTime, startTimer, stopTimer, isRunning } = useTimer();

  // Team member mutation for saving team members
  const saveTeamMemberMutation = useMutation({
    mutationFn: async (member: any) => {
      const response = await apiRequest("POST", `/api/sessions/${sessionId}/team-members`, member);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions", sessionId, "team-members"] });
    },
  });

  // Handle team member data loading and transformation
  useEffect(() => {
    if (sessionId && Array.isArray(sessionTeamMembers) && sessionTeamMembers.length > 0) {
      const transformedMembers = sessionTeamMembers.map((member: any) => ({
        name: member.name || '',
        role: member.role || '',
        userId: member.userId,
        isResusMgrUser: member.isResusMgrUser || false
      }));
      setLocalTeamMembers(transformedMembers);
    } else if (sessionId && Array.isArray(sessionTeamMembers)) {
      // Empty array case - no saved team members
    }
  }, [sessionTeamMembers, sessionId]);
  
  // Use local team members (which includes transformed session data)
  const teamMembers = localTeamMembers;
  
  // Count valid team members (those with both name and role filled)
  const validTeamMembers = Array.isArray(teamMembers) ? teamMembers.filter((member: any) => {
    if (!member) return false;
    
    // Check if member has valid name and role
    const hasName = member.name && typeof member.name === 'string' && member.name.trim().length > 0;
    const hasRole = member.role && typeof member.role === 'string' && member.role.trim().length > 0;
    
    return hasName && hasRole;
  }) : [];

  // Force refetch interventions when session changes
  useEffect(() => {
    if (sessionId && refetchInterventions) {
      refetchInterventions();
    }
  }, [sessionId, refetchInterventions]);

  // 2-minute timer countdown effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (ilsStarted && !showTwoMinutePrompt) {
      interval = setInterval(() => {
        setTwoMinuteTimer(prev => {
          if (prev <= 1) {
            setShowTwoMinutePrompt(true);
            return 120;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [ilsStarted, showTwoMinutePrompt]);

  // ILS Start function
  const handleStartILS = () => {
    setIlsStarted(true);
    setTwoMinuteTimer(120); // Reset 2-minute timer
    if (!isRunning) {
      startTimer(0);
      setMetronomeEnabled(true);
    }
    // Log ILS start intervention
    if (sessionId) {
      logInterventionMutation.mutate({
        type: "ILS_START",
        description: "Intermediate Life Support protocol initiated",
        details: { metronomeRate: 120 }
      });
    }
    toast({
      title: "ILS Started",
      description: "Timer and metronome active at 120 BPM",
      duration: 3000,
    });
  };

  // Intervention logging mutation
  const logInterventionMutation = useMutation({
    mutationFn: async (interventionData: {
      type: string;
      description: string;
      teamMemberId?: string;
      details?: any;
    }) => {
      const response = await apiRequest("POST", `/api/sessions/${sessionId}/interventions`, interventionData);
      return response.json();
    },
    onSuccess: () => {
      refetchInterventions();
      setConfirmationMessage('Intervention logged successfully');
      setShowInterventionConfirm(true);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to log intervention",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Session update mutation
  const updateSessionMutation = useMutation({
    mutationFn: async (updates: { outcome?: string; notes?: string; endTime?: Date }) => {
      const response = await apiRequest("PATCH", `/api/sessions/${sessionId}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions", sessionId] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update session",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleEndSession = () => {
    if (sessionOutcome && sessionId) {
      updateSessionMutation.mutate({
        outcome: sessionOutcome,
        notes: sessionNotes,
        endTime: new Date()
      });
      setShowEndSessionDialog(false);
      stopTimer();
      setLocation("/dashboard");
    }
  };

  const handleReturnToDashboard = () => {
    setLocation("/dashboard");
  };

  // Loading state
  if (isLoading) {
    return <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
        <p className="text-gray-600 dark:text-gray-400">Loading session...</p>
      </div>
    </div>;
  }

  // Only show "Session Not Found" if we have a sessionId but can't find the session
  if (sessionId && !session && !isLoading) {
    return <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">Session Not Found</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-4">The resuscitation session could not be found.</p>
        <Button onClick={handleReturnToDashboard}>
          <Home className="w-4 h-4 mr-2" />
          Return to Dashboard
        </Button>
      </div>
    </div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800 dark:text-white flex items-center">
              <Stethoscope className="w-8 h-8 mr-3 text-blue-600" />
              Intermediate Life Support - Adult
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Intermediate Life Support for Adult Patients {session && `• Session #${session.id}`}
            </p>
          </div>
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              onClick={() => setIsAudioEnabled(!isAudioEnabled)}
              className="flex items-center gap-2"
            >
              {isAudioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              {isAudioEnabled ? "Audio On" : "Audio Off"}
            </Button>
            <Button
              variant="outline"
              onClick={handleReturnToDashboard}
              className="flex items-center gap-2"
            >
              <Home className="w-4 h-4" />
              Dashboard
            </Button>
          </div>
        </div>

        {/* Clinical Warning */}
        <Alert className="mb-8 border-orange-200 bg-orange-50 dark:bg-orange-900/20">
          <AlertTriangle className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-800 dark:text-orange-200">
            <strong>Clinical Reminder:</strong> Users must work to their level of training and scope of practice. 
            This tool provides guidance but does not replace clinical judgment or replace proper medical training.
          </AlertDescription>
        </Alert>

        {/* Team Management */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4 flex items-center">
            <Users className="w-5 h-5 mr-2" />
            Resuscitation Team Management
          </h3>
          <PreSessionTeamManager 
            onTeamMembersChange={(members: any) => {
              setLocalTeamMembers(members);
              // Save team members to session if we have a sessionId
              if (sessionId && Array.isArray(members)) {
                const currentSessionMembers = Array.isArray(sessionTeamMembers) ? sessionTeamMembers : [];
                
                members.forEach((member: any) => {
                  if (member.name && member.role && member.name.trim() && member.role.trim()) {
                    // Check if this member is already saved in the database
                    const isAlreadySaved = currentSessionMembers.some((existing: any) => 
                      existing.name === member.name.trim() && existing.role === member.role.trim()
                    );
                    
                    if (!isAlreadySaved) {
                      saveTeamMemberMutation.mutate({
                        name: member.name.trim(),
                        role: member.role.trim(),
                        userId: member.userId,
                        isResusMgrUser: member.isResusMgrUser || false
                      });
                    }
                  }
                });
              }
            }}
            initialMembers={teamMembers}
          />
        </div>

        {/* Protocol Start Buttons */}
        {!blsStarted && !ilsStarted && !alsStarted && (
          <Card className="mb-8 border-blue-200 bg-blue-50 dark:bg-blue-900/20">
            <CardContent className="pt-8 pb-8 text-center">
              {validTeamMembers.length === 0 && (
                <Alert className="mb-6 border-amber-300 bg-amber-50 dark:bg-amber-900/20">
                  <AlertTriangle className="h-4 w-4 text-amber-600" />
                  <AlertDescription className="text-amber-700 dark:text-amber-300">
                    You must add at least one team member before starting resuscitation
                  </AlertDescription>
                </Alert>
              )}
              <div className="space-y-4">
                <Button
                  onClick={handleStartILS}
                  disabled={validTeamMembers.length === 0}
                  size="lg"
                  className={`px-12 py-6 text-xl font-bold shadow-xl transition-all duration-200 w-full ${
                    validTeamMembers.length === 0 
                      ? "bg-gray-400 text-gray-600 cursor-not-allowed"
                      : "bg-blue-600 hover:bg-blue-700 text-white hover:shadow-2xl transform hover:scale-105"
                  }`}
                >
                  <Stethoscope className="w-8 h-8 mr-4 animate-pulse" />
                  START ADULT ILS
                </Button>
              </div>
              <p className="text-blue-600 dark:text-blue-400 mt-2 text-base font-medium">
                Users must work to their level of training and scope of practice
              </p>
            </CardContent>
          </Card>
        )}

        {/* ILS Active Status */}
        {ilsStarted && (
          <Card className="mb-8 medical-card border-blue-200 bg-blue-50 dark:bg-blue-900/20">
            <CardHeader>
              <CardTitle className="flex items-center text-blue-800 dark:text-blue-200">
                <Stethoscope className="w-6 h-6 mr-3" />
                ILS Protocol Active
                <Badge variant="secondary" className="ml-4 bg-blue-100 text-blue-800">
                  Intermediate Life Support
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Timer */}
                <Card className="medical-card border-gray-200">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center">
                      <Clock className="w-4 h-4 mr-2" />
                      Session Timer
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Timer
                      elapsedTime={elapsedTime}
                      isRunning={isRunning}
                      showControls={false}
                    />
                  </CardContent>
                </Card>

                {/* Metronome */}
                {metronomeEnabled && (
                  <Card className="medical-card border-red-200">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium flex items-center">
                        <Heart className="w-4 h-4 mr-2 text-red-500" />
                        CPR Metronome
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Metronome
                        isEnabled={metronomeEnabled && isAudioEnabled}
                        onBpmChange={setCurrentBpm}
                      />
                    </CardContent>
                  </Card>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Main ILS Content */}
        {ilsStarted && (
          <>
            {/* Intervention Logging */}
            <Card className="mb-8 medical-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="w-5 h-5 mr-2" />
                  Log Intervention
                </CardTitle>
              </CardHeader>
              <CardContent>
                <InterventionLogger 
                  sessionId={sessionId!} 
                  onInterventionLogged={(intervention) => {
                    setConfirmationMessage('Intervention logged successfully');
                    setShowInterventionConfirm(true);
                  }}
                />
              </CardContent>
            </Card>

            {/* Reversible Causes */}
            <Card className="mb-8 medical-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CheckCircle className="w-5 h-5 mr-2" />
                  Reversible Causes (4 H's & 4 T's)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ReversibleCauses sessionId={sessionId!} />
              </CardContent>
            </Card>

            {/* Drug Calculator */}
            <Card className="mb-8 medical-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Syringe className="w-5 h-5 mr-2" />
                  Emergency Medications
                </CardTitle>
              </CardHeader>
              <CardContent>
                <DrugCalculator sessionId={sessionId} patientType="Adult" />
              </CardContent>
            </Card>

            {/* Session Controls */}
            <Card className="mb-8 medical-card border-red-200">
              <CardHeader>
                <CardTitle className="flex items-center text-red-700 dark:text-red-300">
                  <XCircle className="w-5 h-5 mr-2" />
                  End Session
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={() => setShowEndSessionDialog(true)}
                  variant="destructive"
                  size="lg"
                  className="w-full"
                >
                  End ILS Session
                </Button>
              </CardContent>
            </Card>
          </>
        )}

        {/* 2-minute timer prompt */}
        {showTwoMinutePrompt && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <Card className="w-96 border-red-200 bg-red-50 dark:bg-red-900/20">
              <CardContent className="pt-8 pb-8 text-center">
                <div className="text-6xl mb-4">⏰</div>
                <h3 className="text-xl font-bold text-red-700 dark:text-red-300 mb-2">
                  2 Minutes Elapsed
                </h3>
                <p className="text-red-600 dark:text-red-400 mb-6">
                  Check pulse and rhythm
                </p>
                <Button
                  onClick={() => {
                    setShowTwoMinutePrompt(false);
                    setTwoMinuteTimer(120);
                  }}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  Continue ILS
                </Button>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Intervention Confirmation Popup */}
        {showInterventionConfirm && (
          <div className="fixed top-4 right-4 z-50">
            <Card className="border-green-200 bg-green-50 dark:bg-green-900/20">
              <CardContent className="pt-4 pb-4">
                <div className="flex items-center">
                  <CheckCircle className="w-5 h-5 mr-2 text-green-600" />
                  <span className="text-green-700 dark:text-green-300 font-medium">
                    {confirmationMessage}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* End Session Dialog */}
        <Dialog open={showEndSessionDialog} onOpenChange={setShowEndSessionDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>End ILS Session</DialogTitle>
              <DialogDescription>
                Please select the outcome and add any notes before ending the session.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Session Outcome</label>
                <Select value={sessionOutcome} onValueChange={(value: "ROSC" | "ROLE") => setSessionOutcome(value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select outcome" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ROSC">ROSC (Return of Spontaneous Circulation)</SelectItem>
                    <SelectItem value="ROLE">ROLE (Recognition of Life Extinct)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Session Notes</label>
                <Textarea
                  value={sessionNotes}
                  onChange={(e) => setSessionNotes(e.target.value)}
                  placeholder="Add any relevant notes about the session..."
                  rows={4}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowEndSessionDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleEndSession} disabled={!sessionOutcome}>
                End Session
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <FooterLinks />
    </div>
  );
}