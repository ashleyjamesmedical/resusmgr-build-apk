import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Clock, Play, Pause, RotateCcw, Volume2, VolumeX, Zap, Stethoscope, Syringe, Activity } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useTimer } from "@/hooks/useTimer";
import { useMetronome } from "@/hooks/useMetronome";
import Navigation from "@/components/navigation";
import Timer from "@/components/timer";
import Metronome from "@/components/metronome";
import InterventionLogger from "@/components/intervention-logger";
import ReversibleCauses from "@/components/reversible-causes";
import DrugCalculator from "@/components/drug-calculator";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { ResuscitationSession } from "@shared/schema";
import FooterLinks from "@/components/footer-links";

export default function ALSPaediatric() {
  const { id } = useParams<{ id?: string }>();
  const sessionId = id ? parseInt(id) : null;
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Protocol state
  const [alsStarted, setAlsStarted] = useState(false);
  
  // Timer and metronome
  const { elapsedTime, isRunning, startTimer, pauseTimer, resetTimer } = useTimer();
  const { bmp, isPlaying, toggle } = useMetronome();
  
  // 2-minute countdown for rhythm checks
  const [countdown, setCountdown] = useState(120);
  const [countdownActive, setCountdownActive] = useState(false);

  // Fetch session data
  const { data: session, isLoading: sessionLoading } = useQuery<ResuscitationSession>({
    queryKey: ["/api/sessions", sessionId],
    enabled: !!sessionId,
  });

  // Create session mutation for when START is pressed
  const createSessionMutation = useMutation({
    mutationFn: async (protocolData: { protocolType: string; patientType: string }) => {
      const response = await apiRequest("POST", "/api/sessions", protocolData);
      return await response.json();
    },
    onSuccess: (newSession) => {
      setLocation(`/als-paediatric/${newSession.id}`);
    },
  });

  // Auto-start ALS when session loads for paediatric ALS sessions
  useEffect(() => {
    if (session && !session.endTime && !alsStarted) {
      if (session.protocolType === "ALS" && session.patientType === "Paediatric") {
        handleStartALS();
      }
    }
  }, [session, alsStarted]);

  // Start timer when ALS protocol starts
  useEffect(() => {
    if (session && !session.endTime && !isRunning && alsStarted) {
      const sessionStart = new Date(session.startTime).getTime();
      const now = Date.now();
      const elapsed = Math.floor((now - sessionStart) / 1000);
      startTimer(elapsed);
    }
  }, [session, isRunning, startTimer, alsStarted]);

  // 2-minute countdown timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (countdownActive && countdown > 0) {
      interval = setInterval(() => {
        setCountdown(prev => {
          if (prev <= 1) {
            // Time for rhythm check and compressions swap
            toast({
              title: "2 Minutes Complete!",
              description: "🔄 Time for rhythm check and swap compressions",
              duration: 5000,
            });
            return 120; // Reset for next cycle
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [countdownActive, countdown, toast]);

  const handleStartALS = () => {
    setAlsStarted(true);
    setCountdownActive(true);
    setCountdown(120);
    
    // Log the ALS start intervention
    logInterventionMutation.mutate({
      type: "PROTOCOL_START",
      description: "ALS Protocol started - Paediatric",
      details: { protocol: "ALS", patientType: "Paediatric" }
    });

    toast({
      title: "ALS Protocol Started",
      description: "Paediatric Advanced Life Support initiated",
      duration: 3000,
    });
  };

  // Log intervention mutation
  const logInterventionMutation = useMutation({
    mutationFn: async (intervention: { type: string; description: string; details?: any }) => {
      if (!id) throw new Error("No session ID");
      const response = await apiRequest("POST", `/api/sessions/${id}/interventions`, {
        sessionId: parseInt(id),
        ...intervention
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions", id, "interventions"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to log intervention",
        variant: "destructive",
      });
    },
  });

  // End session mutation
  const endSessionMutation = useMutation({
    mutationFn: async ({ outcome, notes }: { outcome: string; notes?: string }) => {
      if (!id) throw new Error("No session ID");
      const response = await apiRequest("POST", `/api/sessions/${id}/end`, {
        outcome,
        notes,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Session Ended",
        description: "Resuscitation session completed successfully",
      });
      setLocation("/dashboard");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to end session",
        variant: "destructive",
      });
    },
  });

  const handleEndSession = (outcome: string) => {
    const confirmed = confirm(`Are you sure you want to end this resuscitation session with outcome: ${outcome}?`);
    if (confirmed) {
      endSessionMutation.mutate({ outcome });
    }
  };

  const formatCountdown = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (sessionLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  // Only show session completed if we have a session that's ended
  if (session && session.endTime) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">Session Completed</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Outcome: {session.outcome}
          </p>
          <Button onClick={() => setLocation("/dashboard")}>Return to Dashboard</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navigation />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 md:py-8">
        {/* Session Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
                ALS Protocol - Paediatric
              </h1>
              <div className="flex items-center space-x-4">
                <Badge variant="secondary" className="bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400">
                  Advanced Life Support
                </Badge>
                {session ? (
                  <Badge variant="outline">
                    Session #{session.id}
                  </Badge>
                ) : (
                  <Badge variant="outline">
                    Ready to start ALS resuscitation protocol
                  </Badge>
                )}
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Timer 
                elapsedTime={elapsedTime}
                isRunning={isRunning}
                onStart={startTimer}
                onPause={pauseTimer}
                onReset={resetTimer}
                showControls={true}
              />
            </div>
          </div>
        </div>

        {/* Protocol Start Button */}
        {!alsStarted && (
          <Card className="mb-8 border-purple-200 bg-purple-50 dark:bg-purple-900/20">
            <CardContent className="pt-8 pb-8 text-center">
              <Button
                onClick={handleStartALS}
                size="lg"
                className="bg-purple-600 hover:bg-purple-700 text-white px-12 py-6 text-xl font-bold shadow-xl hover:shadow-2xl transition-all duration-200 transform hover:scale-105 w-full"
              >
                <Zap className="w-8 h-8 mr-4 animate-pulse" />
                START ALS RESUS
              </Button>
              <p className="text-purple-700 dark:text-purple-300 mt-4 text-lg">
                Begin Advanced Life Support for paediatric patient
              </p>
            </CardContent>
          </Card>
        )}

        {/* Active ALS Protocol Interface */}
        {alsStarted && (
          <>
            {/* Rhythm Check Timer and Metronome */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              <Card className="border-purple-200 bg-purple-50 dark:bg-purple-900/20">
                <CardHeader>
                  <CardTitle className="flex items-center text-lg text-purple-700 dark:text-purple-300">
                    <Clock className="w-5 h-5 mr-2" />
                    Rhythm Check Timer (2 Min Cycles)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-4xl font-mono font-bold text-purple-600 dark:text-purple-400 mb-4">
                      {formatCountdown(countdown)}
                    </div>
                    <p className="text-purple-700 dark:text-purple-300">
                      Time remaining until rhythm check and compression swap
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-purple-200 bg-purple-50 dark:bg-purple-900/20">
                <CardHeader>
                  <CardTitle className="flex items-center text-lg text-purple-700 dark:text-purple-300">
                    <Volume2 className="w-5 h-5 mr-2" />
                    CPR Metronome (100-120 BPM)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Metronome 
                    isEnabled={alsStarted}
                    onBeatChange={() => {}}
                    onBpmChange={() => {}}
                  />
                </CardContent>
              </Card>
            </div>

            {/* Paediatric ALS Specific Interventions */}
            <Card className="mb-8 border-purple-200 bg-purple-50 dark:bg-purple-900/20">
              <CardHeader>
                <CardTitle className="flex items-center text-lg text-purple-700 dark:text-purple-300">
                  <Zap className="w-5 h-5 mr-2" />
                  Paediatric ALS Advanced Interventions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <Button
                    onClick={() => {
                      logInterventionMutation.mutate({
                        type: "ENDOTRACHEAL_INTUBATION",
                        description: "Paediatric endotracheal intubation performed",
                        details: { tube_size: "Age/4 + 4mm", depth: "Age/2 + 12cm", confirmation: "EtCO2 + chest rise" }
                      });
                      toast({
                        title: "Paediatric ETT",
                        description: "Endotracheal tube placed and confirmed",
                        duration: 2000,
                      });
                    }}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                    size="lg"
                  >
                    <Syringe className="w-5 h-5 mr-2" />
                    Paediatric ETT
                  </Button>

                  <Button
                    onClick={() => {
                      logInterventionMutation.mutate({
                        type: "VASCULAR_ACCESS",
                        description: "Paediatric IV/IO vascular access established",
                        details: { access_type: "IV/IO", location: "Antecubital/Tibial", gauge: "22-24G", ageGroup: "Paediatric" }
                      });
                      toast({
                        title: "Paediatric Access",
                        description: "IV/IO access established",
                        duration: 2000,
                      });
                    }}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                    size="lg"
                  >
                    <Syringe className="w-5 h-5 mr-2" />
                    Paediatric IV/IO
                  </Button>

                  <Button
                    onClick={() => {
                      logInterventionMutation.mutate({
                        type: "SYNCHRONIZED_CARDIOVERSION",
                        description: "Paediatric synchronized cardioversion performed",
                        details: { energy: "1-2J/kg", rhythm: "SVT/VT with pulse", sedation: "Administered", ageGroup: "Paediatric" }
                      });
                      toast({
                        title: "Paediatric Cardioversion",
                        description: "Cardioversion delivered",
                        duration: 2000,
                      });
                    }}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                    size="lg"
                  >
                    <Zap className="w-5 h-5 mr-2" />
                    Paediatric Cardioversion
                  </Button>

                  <Button
                    onClick={() => {
                      logInterventionMutation.mutate({
                        type: "CHEST_COMPRESSIONS",
                        description: "Paediatric chest compressions at 100-120/min",
                        details: { rate: "100-120/min", depth: "1/3 chest depth", ratio: "15:2", technique: "Age-appropriate" }
                      });
                      toast({
                        title: "Paediatric Compressions",
                        description: "Age-appropriate compressions logged",
                        duration: 2000,
                      });
                    }}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                    size="lg"
                  >
                    <Heart className="w-5 h-5 mr-2" />
                    Paediatric CPR
                  </Button>

                  <Button
                    onClick={() => {
                      logInterventionMutation.mutate({
                        type: "RHYTHM_ANALYSIS",
                        description: "Paediatric advanced cardiac rhythm analysis",
                        details: { method: "12-lead ECG + monitor", interpretation: "Age-appropriate assessment", shockable: "Determined" }
                      });
                      toast({
                        title: "Paediatric ECG",
                        description: "Advanced rhythm assessment",
                        duration: 2000,
                      });
                    }}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                    size="lg"
                  >
                    <Stethoscope className="w-5 h-5 mr-2" />
                    Paediatric ECG
                  </Button>

                  <Button
                    onClick={() => {
                      logInterventionMutation.mutate({
                        type: "MANUAL_DEFIBRILLATION",
                        description: "Paediatric manual defibrillation with biphasic shock",
                        details: { energy: "4J/kg", waveform: "Biphasic", rhythm: "VF/pVT", safety: "All clear", ageGroup: "Paediatric" }
                      });
                      toast({
                        title: "Paediatric Defibrillation",
                        description: "Biphasic shock delivered",
                        duration: 2000,
                      });
                    }}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                    size="lg"
                  >
                    <Zap className="w-5 h-5 mr-2" />
                    Paediatric Defib
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Reversible Causes */}
            <ReversibleCauses sessionId={parseInt(id!)} />

            {/* Drug Calculator */}
            <DrugCalculator sessionId={parseInt(id!)} patientType="Paediatric" />

            {/* Intervention Logger */}
            <InterventionLogger sessionId={parseInt(id!)} />

            {/* End Session */}
            <Card className="mb-8 border-gray-200">
              <CardHeader>
                <CardTitle className="text-lg">End Resuscitation Session</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button
                    onClick={() => handleEndSession("ROSC")}
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    End - ROSC Achieved
                  </Button>
                  <Button
                    onClick={() => handleEndSession("Ceased")}
                    variant="destructive"
                  >
                    End - Resuscitation Ceased
                  </Button>
                  <Button
                    onClick={() => handleEndSession("Transferred")}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    End - Patient Transferred
                  </Button>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </main>
      <FooterLinks />
    </div>
  );
}