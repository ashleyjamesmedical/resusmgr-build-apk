import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Shield, Users, Server, UserX, Trash2, Crown, RefreshCw, AlertTriangle, Eye, CheckCircle, XCircle, Bell } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Link } from "wouter";

interface AdminUser {
  id: string;
  email: string;
  firstName: string | null;
  lastName: string | null;
  profileImageUrl: string | null;
  role: string | null;
  subscriptionActive: boolean;
  disclaimerAccepted: boolean;
  lastLoginAt: Date | null;
  lastActivityAt: Date | null;
  createdAt: Date | null;
}

interface ServerStatus {
  uptime: number;
  memoryUsage: number;
  activeConnections: number;
  dbConnectionStatus: string;
}

export default function AdminConsole() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedAction, setSelectedAction] = useState<string | null>(null);
  const [selectedReport, setSelectedReport] = useState<any | null>(null);
  const [reviewDialogOpen, setReviewDialogOpen] = useState(false);
  const [reviewStatus, setReviewStatus] = useState("");
  const [adminNotes, setAdminNotes] = useState("");

  // Check if user is admin
  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-4">
        <div className="max-w-md mx-auto mt-20">
          <Card>
            <CardContent className="p-8 text-center">
              <p>Loading user data...</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (user.role !== "Administrator") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-4">
        <div className="max-w-md mx-auto mt-20">
          <Card className="border-red-200">
            <CardHeader className="text-center">
              <Shield className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <CardTitle className="text-red-700">Access Denied</CardTitle>
              <CardDescription className="text-red-600">
                Administrator privileges required to access this console.
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <Link href="/">
                <Button variant="outline">← Return to Dashboard</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Fetch server status
  const { data: serverStatus, isLoading: statusLoading } = useQuery<ServerStatus>({
    queryKey: ["/api/admin/server-status"],
    refetchInterval: 30000,
  });

  // Fetch active users
  const { data: activeUsers, isLoading: usersLoading, refetch: refetchUsers } = useQuery<AdminUser[]>({
    queryKey: ["/api/admin/users"],
    refetchInterval: 10000, // Refresh every 10 seconds for real-time status
    staleTime: 0, // Always consider data stale
    cacheTime: 0, // Don't cache results
  });

  // Fetch unauthorized participation reports
  const { data: unauthorizedReports, isLoading: reportsLoading } = useQuery<any[]>({
    queryKey: ["/api/admin/unauthorized-participation-reports"],
    refetchInterval: 30000, // Refresh every 30 seconds
    staleTime: 0, // Always fetch fresh data
  });

  // Block user mutation
  const blockUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await apiRequest("PATCH", `/api/admin/users/${userId}/block`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "User blocked successfully",
        description: "The user has been blocked from accessing the system.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to block user",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete user mutation
  const deleteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await apiRequest("DELETE", `/api/admin/users/${userId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "User deleted successfully",
        description: "The user account has been permanently removed.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to delete user",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Upgrade/Downgrade user mutation
  const toggleUserStatusMutation = useMutation({
    mutationFn: async ({ userId, action }: { userId: string; action: 'upgrade' | 'downgrade' }) => {
      const endpoint = action === 'upgrade' 
        ? `/api/admin/users/${userId}/make-pro`
        : `/api/admin/users/${userId}/remove-pro`;
      const res = await apiRequest("PATCH", endpoint);
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      const message = variables.action === 'upgrade' 
        ? "User upgraded to Pro successfully"
        : "User subscription downgraded successfully";
      toast({
        title: message,
        description: variables.action === 'upgrade' 
          ? "The user has been granted Pro access."
          : "The user's Pro subscription has been removed.",
      });
    },
    onError: (error: any, variables) => {
      const action = variables.action === 'upgrade' ? 'upgrade' : 'downgrade';
      toast({
        title: `Failed to ${action} user`,
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const makeAdminMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await apiRequest("PATCH", `/api/admin/users/${userId}/make-admin`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Admin access granted",
        description: "User has been granted administrator privileges",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to grant admin access",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const removeAdminMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await apiRequest("PATCH", `/api/admin/users/${userId}/remove-admin`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Admin access removed",
        description: "Administrator privileges have been removed from user",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to remove admin access",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Review unauthorized participation report mutation
  const reviewReportMutation = useMutation({
    mutationFn: async ({ reportId, status, adminNotes, action }: { reportId: number; status: string; adminNotes: string; action?: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/unauthorized-participation-reports/${reportId}`, {
        status,
        adminNotes,
        action
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/unauthorized-participation-reports"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin"] });
      toast({
        title: "Report reviewed successfully",
        description: "The unauthorised participation report has been updated.",
      });
      setReviewDialogOpen(false);
      setSelectedReport(null);
      setReviewStatus("");
      setAdminNotes("");
    },
    onError: (error: any) => {
      toast({
        title: "Failed to review report",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle opening review dialog
  const handleOpenReviewDialog = (report: any) => {
    setSelectedReport(report);
    setReviewStatus("");
    setAdminNotes("");
    setReviewDialogOpen(true);
  };

  // Handle investigation action (keep/remove)
  const handleInvestigationAction = (action: 'keep' | 'remove') => {
    console.log('handleInvestigationAction called with action:', action);
    console.log('selectedReport:', selectedReport);
    
    if (!selectedReport) {
      console.log('No selected report, returning');
      return;
    }

    const actionNotes = action === 'keep' 
      ? 'Investigation complete: Team member participation was legitimate and has been retained in the session.'
      : 'Investigation complete: Unauthorized participation confirmed. Team member has been removed from the session.';

    console.log('About to call reviewReportMutation.mutate with:', {
      reportId: selectedReport.id,
      status: 'resolved',
      adminNotes: `${adminNotes ? adminNotes + '\n\n' : ''}${actionNotes}`,
      action: action
    });

    // Use the existing mutation but with the action-specific notes
    reviewReportMutation.mutate({
      reportId: selectedReport.id,
      status: 'resolved',
      adminNotes: `${adminNotes ? adminNotes + '\n\n' : ''}${actionNotes}`,
      action: action
    });

    setReviewDialogOpen(false);
    setSelectedReport(null);
    setReviewStatus("");
    setAdminNotes("");
  };

  // Handle submitting review
  const handleSubmitReview = () => {
    if (!selectedReport || !reviewStatus) {
      toast({
        title: "Missing Information",
        description: "Please select a status for the review.",
        variant: "destructive",
      });
      return;
    }

    reviewReportMutation.mutate({
      reportId: selectedReport.id,
      status: reviewStatus,
      adminNotes: adminNotes || `Report ${reviewStatus} by administrator`
    });

    setReviewDialogOpen(false);
    setSelectedReport(null);
    setReviewStatus("");
    setAdminNotes("");
  };

  const refreshActivityMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await apiRequest("PATCH", `/api/admin/users/${userId}/refresh-activity`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Status refreshed",
        description: "User activity status has been updated",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to refresh status",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const restoreProfileImagesMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/admin/restore-profile-images");
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Profile images restored",
        description: data.message,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to restore profile images",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Test notification mutation
  const testNotificationMutation = useMutation({
    mutationFn: async (userId: string) => {
      const response = await apiRequest("POST", "/api/admin/test-welcome-notification", { userId });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Test Notification Sent",
        description: data.message,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to send test notification",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };

  const getInitials = (firstName: string | null, lastName: string | null) => {
    const first = firstName?.[0] || "";
    const last = lastName?.[0] || "";
    return (first + last).toUpperCase() || "?";
  };

  const isUserOnline = (adminUser: AdminUser) => {
    // If this is the current user viewing the admin panel, they're definitely online
    if (adminUser.id === user?.id) return true;
    
    // Check lastActivityAt first (more accurate), then fall back to lastLoginAt
    const lastActivity = adminUser.lastActivityAt || adminUser.lastLoginAt;
    if (!lastActivity) return false;
    
    try {
      // Consider a user online if they've been active within the last 5 minutes  
      const lastActiveTime = new Date(lastActivity);
      const now = new Date();
      const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000);
      
      // Debug log to see what's happening
      console.log(`User ${adminUser.firstName} ${adminUser.lastName}:`, {
        lastActivity,
        lastActiveTime: lastActiveTime.toISOString(),
        now: now.toISOString(),
        fiveMinutesAgo: fiveMinutesAgo.toISOString(),
        isOnline: lastActiveTime > fiveMinutesAgo
      });
      
      return lastActiveTime > fiveMinutesAgo;
    } catch (error) {
      console.error('Error parsing date for user', adminUser.firstName, adminUser.lastName, ':', error);
      return false;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">Admin Console</h1>
          </div>
          <p className="text-gray-600">System administration and user management</p>
          <Link href="/" className="inline-block mt-4">
            <Button variant="outline" size="sm">
              ← Back to Dashboard
            </Button>
          </Link>
        </div>

        {/* Server Status Card */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Server className="h-5 w-5" />
              Live Server Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            {statusLoading ? (
              <div className="text-center py-4 text-gray-500">Loading server status...</div>
            ) : serverStatus ? (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-green-600">
                    {formatUptime(serverStatus.uptime)}
                  </div>
                  <div className="text-sm text-gray-600">Uptime</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-blue-600">
                    {Math.round(serverStatus.memoryUsage)}%
                  </div>
                  <div className="text-sm text-gray-600">Memory Usage</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-purple-600">
                    {serverStatus.activeConnections}
                  </div>
                  <div className="text-sm text-gray-600">Active Sessions</div>
                </div>
                <div className="text-center">
                  <Badge 
                    variant={serverStatus.dbConnectionStatus === "Connected" ? "default" : "destructive"}
                    className="text-sm"
                  >
                    {serverStatus.dbConnectionStatus}
                  </Badge>
                  <div className="text-sm text-gray-600 mt-1">Database</div>
                </div>
              </div>
            ) : (
              <div className="text-center py-4 text-red-500">Failed to load server status</div>
            )}
          </CardContent>
        </Card>

        {/* System Maintenance */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <RefreshCw className="h-5 w-5" />
              System Maintenance
            </CardTitle>
            <CardDescription>
              Database cleanup and system maintenance tools
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={() => restoreProfileImagesMutation.mutate()}
                disabled={restoreProfileImagesMutation.isPending}
                variant="outline"
                className="flex items-center gap-2"
              >
                {restoreProfileImagesMutation.isPending ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  <RefreshCw className="h-4 w-4" />
                )}
                Restore Profile Images
              </Button>
              <div className="text-sm text-gray-600 flex items-center">
                Cleans up missing profile image references from the database
              </div>
            </div>
          </CardContent>
        </Card>

        {/* User Management */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Active Users ({activeUsers?.length || 0})
            </CardTitle>
            <CardDescription>
              Manage user accounts and permissions
            </CardDescription>
          </CardHeader>
          <CardContent>
            {usersLoading ? (
              <div className="text-center py-8 text-gray-500">Loading users...</div>
            ) : activeUsers && activeUsers.length > 0 ? (
              <div className="space-y-4">
                {activeUsers.map((adminUser) => (
                  <div key={adminUser.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="relative">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={adminUser.profileImageUrl || undefined} />
                          <AvatarFallback>
                            {getInitials(adminUser.firstName, adminUser.lastName)}
                          </AvatarFallback>
                        </Avatar>
                        {/* Online status indicator */}
                        <div className={`absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full border-2 border-white ${
                          isUserOnline(adminUser) ? 'bg-green-500' : 'bg-red-500'
                        }`} 
                        title={isUserOnline(adminUser) ? 'Online' : 'Offline'} />
                      </div>
                      <div>
                        <div className="font-medium">
                          {adminUser.firstName} {adminUser.lastName}
                        </div>
                        <div className="text-sm text-gray-600">{adminUser.email}</div>
                        <div className="text-xs text-gray-500 mb-1">
                          Last login: {adminUser.lastLoginAt ? new Date(adminUser.lastLoginAt).toLocaleString('en-GB') : 'Never'}
                        </div>
                        <div className="flex gap-2 mt-1">
                          <Badge variant={adminUser.subscriptionActive ? "default" : "secondary"}>
                            {adminUser.subscriptionActive ? "Pro" : "Free"}
                          </Badge>
                          <Badge variant={adminUser.role === "Administrator" ? "destructive" : "outline"}>
                            {adminUser.role || "User"}
                          </Badge>
                          {adminUser.disclaimerAccepted && (
                            <Badge variant="outline" className="text-green-600">
                              Verified
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {adminUser.id !== user.id && (
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => blockUserMutation.mutate(adminUser.id)}
                          disabled={selectedAction === adminUser.id}
                          className="text-orange-600 hover:text-orange-700"
                        >
                          <UserX className="h-4 w-4 mr-1" />
                          Block
                        </Button>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const action = adminUser.subscriptionActive ? 'downgrade' : 'upgrade';
                            toggleUserStatusMutation.mutate({ userId: adminUser.id, action });
                          }}
                          disabled={selectedAction === adminUser.id || adminUser.role === "Administrator"}
                          className={adminUser.subscriptionActive ? "text-orange-600 hover:text-orange-700" : "text-blue-600 hover:text-blue-700"}
                        >
                          <Crown className="h-4 w-4 mr-1" />
                          {adminUser.subscriptionActive ? 'Downgrade' : 'Upgrade'}
                        </Button>
                        
                        {adminUser.role !== "Administrator" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => makeAdminMutation.mutate(adminUser.id)}
                            disabled={selectedAction === adminUser.id}
                            className="text-purple-600 hover:text-purple-700"
                          >
                            <Shield className="h-4 w-4 mr-1" />
                            Make Admin
                          </Button>
                        )}
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => testNotificationMutation.mutate(adminUser.id)}
                          disabled={testNotificationMutation.isPending}
                          className="text-green-600 hover:text-green-700"
                        >
                          <Bell className="h-4 w-4 mr-1" />
                          Test Notification
                        </Button>
                        
                        {adminUser.role === "Administrator" && adminUser.id !== user?.id && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => removeAdminMutation.mutate(adminUser.id)}
                            disabled={selectedAction === adminUser.id}
                            className="text-purple-600 hover:text-purple-700"
                          >
                            <Shield className="h-4 w-4 mr-1" />
                            Remove Admin
                          </Button>
                        )}
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => refreshActivityMutation.mutate(adminUser.id)}
                          disabled={selectedAction === adminUser.id}
                          className="text-blue-600 hover:text-blue-700"
                        >
                          <RefreshCw className="h-4 w-4 mr-1" />
                          Refresh Status
                        </Button>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteUserMutation.mutate(adminUser.id)}
                          disabled={selectedAction === adminUser.id}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">No active users found</div>
            )}
          </CardContent>
        </Card>

        {/* Unauthorized Participation Reports */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              Unauthorised Participation Reports
              {unauthorizedReports && (
                <Badge variant="destructive" className="ml-2">
                  {unauthorizedReports.length}
                </Badge>
              )}
            </CardTitle>
            <CardDescription>
              Security reports from users about unauthorised session participation
            </CardDescription>
          </CardHeader>
          <CardContent>
            {reportsLoading ? (
              <div className="text-center py-8 text-gray-500">Loading reports...</div>
            ) : unauthorizedReports && unauthorizedReports.length > 0 ? (
              <div className="space-y-4">
                {unauthorizedReports.map((report: any) => (
                  <div key={report.id} className="flex items-start justify-between p-4 border rounded-lg bg-red-50 border-red-200">
                    <div className="flex-1">
                      <div className="font-medium text-red-800">
                        Security Report #{report.id}
                      </div>
                      <div className="text-sm text-red-600 mt-1">
                        Session ID: {report.sessionId} | Team Member ID: {report.teamMemberId || 'null'}
                      </div>
                      <div className="text-sm text-gray-700 mt-2">
                        <strong>Reason:</strong> {report.reason}
                      </div>
                      <div className="text-xs text-gray-500 mt-2">
                        Reported: {new Date(report.createdAt).toLocaleString('en-GB')}
                      </div>
                      {report.reviewedAt && (
                        <div className="text-xs text-green-600 mt-1">
                          Reviewed: {new Date(report.reviewedAt).toLocaleString('en-GB')}
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-2 ml-4">
                      <Badge 
                        variant={
                          report.status === 'pending' ? 'destructive' : 
                          report.status === 'resolved' ? 'default' : 
                          'secondary'
                        }
                      >
                        {report.status === 'pending' ? 'Pending Review' : 
                         report.status === 'resolved' ? 'Resolved' : 
                         report.status}
                      </Badge>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-blue-600"
                        onClick={() => handleOpenReviewDialog(report)}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        View Details
                      </Button>
                      {report.status === 'pending' && (
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="text-green-600"
                          onClick={() => handleOpenReviewDialog(report)}
                        >
                          Review
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Shield className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <p>No unauthorized participation reports found.</p>
                <p className="text-sm mt-1">Security reports will appear here when submitted.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Review Dialog */}
        <Dialog open={reviewDialogOpen} onOpenChange={setReviewDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-red-500" />
                Review Unauthorized Participation Report #{selectedReport?.id}
              </DialogTitle>
              <DialogDescription>
                Review this security report and take appropriate action
              </DialogDescription>
            </DialogHeader>
            
            {selectedReport && (
              <div className="space-y-4">
                {/* Report Details */}
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <h4 className="font-semibold text-red-800 mb-2">Report Details</h4>
                  <div className="space-y-2 text-sm">
                    <div><strong>Session ID:</strong> {selectedReport.sessionId}</div>
                    <div><strong>Team Member ID:</strong> {selectedReport.teamMemberId || 'Not specified'}</div>
                    <div><strong>Reported By:</strong> {selectedReport.reporterDisplayName || selectedReport.reporterName || selectedReport.reportedByUserId}</div>
                    <div><strong>Date:</strong> {new Date(selectedReport.createdAt).toLocaleString('en-GB')}</div>
                    <div><strong>Current Status:</strong> 
                      <Badge variant={selectedReport.status === 'pending' ? 'destructive' : 'default'} className="ml-2">
                        {selectedReport.status}
                      </Badge>
                    </div>
                  </div>
                </div>

                {/* Reason */}
                <div>
                  <h4 className="font-semibold mb-2">Reason for Report</h4>
                  <div className="bg-gray-50 border rounded p-3 text-sm">
                    {selectedReport.reason}
                  </div>
                </div>

                {/* Previous Admin Notes */}
                {selectedReport.adminNotes && (
                  <div>
                    <h4 className="font-semibold mb-2">Previous Admin Notes</h4>
                    <div className="bg-blue-50 border border-blue-200 rounded p-3 text-sm">
                      {selectedReport.adminNotes}
                    </div>
                  </div>
                )}

                {/* Review Actions */}
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Review Status</label>
                    <Select value={reviewStatus} onValueChange={setReviewStatus}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select review status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="under_review">Under Review</SelectItem>
                        <SelectItem value="investigating">Investigating</SelectItem>
                        <SelectItem value="resolved">Resolved</SelectItem>
                        <SelectItem value="dismissed">Dismissed</SelectItem>
                        <SelectItem value="escalated">Escalated</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Investigation Resolution Actions */}
                  {(reviewStatus === 'resolved' || reviewStatus === 'investigating') && (
                    <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                      <h4 className="font-semibold text-amber-800 mb-3">Investigation Resolution</h4>
                      <p className="text-sm text-amber-700 mb-3">
                        Choose the appropriate action for the reported team member:
                      </p>
                      <div className="space-y-3">
                        <button
                          type="button"
                          className="w-full p-3 text-left border border-green-300 bg-green-50 hover:bg-green-100 rounded-lg transition-colors"
                          onClick={() => handleInvestigationAction('keep')}
                        >
                          <div className="flex items-center">
                            <CheckCircle className="h-5 w-5 text-green-600 mr-3" />
                            <div>
                              <div className="font-medium text-green-800">Keep Team Member</div>
                              <div className="text-sm text-green-700">Participation was legitimate - no action required</div>
                            </div>
                          </div>
                        </button>
                        
                        <button
                          type="button"
                          className="w-full p-3 text-left border border-red-300 bg-red-50 hover:bg-red-100 rounded-lg transition-colors"
                          onClick={() => handleInvestigationAction('remove')}
                        >
                          <div className="flex items-center">
                            <XCircle className="h-5 w-5 text-red-600 mr-3" />
                            <div>
                              <div className="font-medium text-red-800">Remove Team Member</div>
                              <div className="text-sm text-red-700">Unauthorized participation confirmed - remove from session</div>
                            </div>
                          </div>
                        </button>
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="text-sm font-medium mb-2 block">Admin Notes</label>
                    <Textarea
                      value={adminNotes}
                      onChange={(e) => setAdminNotes(e.target.value)}
                      placeholder="Add your review notes here..."
                      rows={4}
                    />
                  </div>
                </div>
              </div>
            )}

            <DialogFooter>
              <Button variant="outline" onClick={() => setReviewDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleSubmitReview}
                disabled={reviewReportMutation.isPending || !reviewStatus}
                className="bg-green-600 hover:bg-green-700"
              >
                {reviewReportMutation.isPending ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Submit Review
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}