import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import Navigation from "@/components/navigation";
import Timer from "@/components/timer";
import Metronome from "@/components/metronome";
import InterventionLogger from "@/components/intervention-logger";
import ReversibleCauses from "@/components/reversible-causes";
import DrugCalculator from "@/components/drug-calculator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Heart, 
  Clock, 
  Volume2, 
  VolumeX, 
  Stethoscope, 
  Syringe, 
  Pill, 
  Zap,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Home
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useTimer } from "@/hooks/useTimer";
import type { ResuscitationSession, Intervention } from "@shared/schema";
import FooterLinks from "@/components/footer-links";

export default function ILSPaediatric() {
  const [, params] = useRoute("/ils-paediatric/:sessionId?");
  const sessionId = params?.sessionId ? parseInt(params.sessionId) : null;
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [showEndSessionDialog, setShowEndSessionDialog] = useState(false);
  const [sessionOutcome, setSessionOutcome] = useState<"ROSC" | "ROLE" | "">("");
  const [sessionNotes, setSessionNotes] = useState("");
  const [blsStarted, setBlsStarted] = useState(false);
  const [ilsStarted, setIlsStarted] = useState(false);
  const [alsStarted, setAlsStarted] = useState(false);
  const [blsStartTime, setBlsStartTime] = useState<Date | null>(null);
  const [metronomeEnabled, setMetronomeEnabled] = useState(false);
  const [currentBpm, setCurrentBpm] = useState(120);
  const [twoMinuteTimer, setTwoMinuteTimer] = useState(120);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [showIgelSelection, setShowIgelSelection] = useState(false);
  
  // Timer and metronome
  const { elapsedTime, isRunning, startTimer, pauseTimer, resetTimer, stopTimer } = useTimer();

  // Fetch session data
  const { data: session, isLoading: sessionLoading } = useQuery<ResuscitationSession>({
    queryKey: ["/api/sessions", sessionId],
    enabled: !!sessionId,
    retry: false,
  });

  // Fetch interventions for this session
  const { data: interventions = [] } = useQuery<Intervention[]>({
    queryKey: ["/api/sessions", sessionId, "interventions"],
    enabled: !!sessionId,
    retry: false,
  });

  // 2-minute protocol timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning && twoMinuteTimer > 0) {
      interval = setInterval(() => {
        setTwoMinuteTimer(prev => {
          if (prev <= 1) {
            // Time for rhythm check or compressions swap
            toast({
              title: "2 Minutes Complete!",
              description: blsStarted && !ilsStarted && !alsStarted ? "🔄 Time to swap compressions" : "🔍 Check rhythm & swap compressions",
              duration: 5000,
            });
            
            // Play audio alert if enabled
            if (isAudioEnabled) {
              try {
                const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
                const oscillator = audioContext.createOscillator();
                const gainNode = audioContext.createGain();
                
                oscillator.connect(gainNode);
                gainNode.connect(audioContext.destination);
                
                oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
                gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
                
                oscillator.start(audioContext.currentTime);
                oscillator.stop(audioContext.currentTime + 0.5);
              } catch (error) {
                console.log("Audio not available");
              }
            }
            
            return 120; // Reset for next cycle
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, twoMinuteTimer, blsStarted, ilsStarted, alsStarted, isAudioEnabled, toast]);

  const handleStartBLS = () => {
    setBlsStarted(true);
    setBlsStartTime(new Date());
    setMetronomeEnabled(true);
    setIsTimerRunning(true);
    
    // Log the BLS start intervention
    logInterventionMutation.mutate({
      type: "BLS_START",
      description: "BLS Paediatric protocol initiated",
      details: { timestamp: new Date().toISOString(), protocol: "BLS", patientType: "Paediatric" }
    });
    
    // Start the main timer
    startTimer();
    
    toast({
      title: "BLS Started",
      description: "Paediatric Basic Life Support protocol initiated",
      duration: 3000,
    });
  };

  const handleStartILS = () => {
    if (!blsStarted) {
      toast({
        title: "Start BLS First",
        description: "Please start BLS protocol before progressing to ILS",
        variant: "destructive",
      });
      return;
    }
    
    setIlsStarted(true);
    logInterventionMutation.mutate({
      type: "ILS_START",
      description: "ILS Paediatric protocol initiated",
      details: { timestamp: new Date().toISOString(), protocol: "ILS", patientType: "Paediatric" }
    });
    
    toast({
      title: "ILS Started",
      description: "Paediatric Intermediate Life Support protocol initiated",
      duration: 3000,
    });
  };

  const handleStartALS = () => {
    if (!blsStarted) {
      toast({
        title: "Start BLS First",
        description: "Please start BLS protocol before progressing to ALS",
        variant: "destructive",
      });
      return;
    }
    
    setAlsStarted(true);
    logInterventionMutation.mutate({
      type: "ALS_START",
      description: "ALS Paediatric protocol initiated",
      details: { timestamp: new Date().toISOString(), protocol: "ALS", patientType: "Paediatric" }
    });
    
    toast({
      title: "ALS Started",
      description: "Paediatric Advanced Life Support protocol initiated",
      duration: 3000,
    });
  };

  const handleProtocolAction = (action: string) => {
    if (action === 'shock') {
      logInterventionMutation.mutate({
        type: "DEFIBRILLATION",
        description: "Defibrillation shock delivered",
        details: { energy: "4J/kg", protocol: alsStarted ? "ALS" : ilsStarted ? "ILS" : "BLS", timestamp: new Date().toISOString() }
      });
      toast({
        title: "Shock Delivered",
        description: "Defibrillation completed - Continue CPR",
        duration: 3000,
      });
    } else if (action === 'rhythm_check') {
      logInterventionMutation.mutate({
        type: "RHYTHM_CHECK",
        description: "2-minute rhythm analysis performed",
        details: { protocol: alsStarted ? "ALS" : ilsStarted ? "ILS" : "BLS", timestamp: new Date().toISOString() }
      });
      toast({
        title: "Rhythm Check",
        description: "2-minute analysis completed",
        duration: 2000,
      });
    }
  };

  // Check if protocol was already started in this session
  useEffect(() => {
    if (session && !session.endTime) {
      // Check if any protocol was already started based on session interventions
      const hasBlsStart = interventions?.some((intervention: Intervention) => 
        intervention.type === "BLS_START"
      );
      const hasIlsStart = interventions?.some((intervention: Intervention) => 
        intervention.type === "ILS_START"
      );
      const hasAlsStart = interventions?.some((intervention: Intervention) => 
        intervention.type === "ALS_START"
      );
      
      if (hasBlsStart) setBlsStarted(true);
      if (hasIlsStart) setIlsStarted(true);
      if (hasAlsStart) setAlsStarted(true);
      
      // If any protocol was started, enable metronome and start timer
      if (hasBlsStart || hasIlsStart || hasAlsStart) {
        setMetronomeEnabled(true);
        setIsTimerRunning(true);
        if (!isRunning) {
          const sessionStart = new Date(session.startTime).getTime();
          const now = Date.now();
          const elapsed = Math.floor((now - sessionStart) / 1000);
          startTimer(elapsed);
        }
      }
    }
  }, [session, interventions, isRunning, startTimer]);

  // Log intervention mutation
  const logInterventionMutation = useMutation({
    mutationFn: async (intervention: { type: string; description: string; details?: any }) => {
      const response = await apiRequest("POST", `/api/sessions/${sessionId}/interventions`, intervention);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions", sessionId, "interventions"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to log intervention",
        variant: "destructive",
      });
    },
  });

  // End session mutation
  const endSessionMutation = useMutation({
    mutationFn: async ({ outcome, notes }: { outcome: string; notes?: string }) => {
      const response = await apiRequest("PUT", `/api/sessions/${sessionId}/end`, {
        outcome,
        notes,
      });
      return response.json();
    },
    onSuccess: () => {
      stopTimer();
      toast({
        title: "Session Ended",
        description: `Resuscitation session completed with outcome: ${sessionOutcome}`,
      });
      // Redirect to dashboard
      window.location.href = "/";
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to end session",
        variant: "destructive",
      });
    },
  });

  const handleIntervention = (type: string, description: string, details?: any) => {
    logInterventionMutation.mutate({ type, description, details });
    
    // Play audio confirmation if enabled
    if (isAudioEnabled) {
      try {
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
        oscillator.frequency.setValueAtTime(400, audioContext.currentTime + 0.1);
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.2);
      } catch (error) {
        console.log("Audio not available");
      }
    }
  };

  const handleEndSession = () => {
    if (!sessionOutcome) {
      toast({
        title: "Select Outcome",
        description: "Please select ROSC or ROLE outcome before ending session",
        variant: "destructive",
      });
      return;
    }
    
    endSessionMutation.mutate({ outcome: sessionOutcome, notes: sessionNotes });
    setShowEndSessionDialog(false);
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`;
  };

  if (sessionLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-blue-900/20 dark:to-indigo-900/30">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="text-center">
              <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
              <p className="text-blue-700 dark:text-blue-300">Loading session...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-blue-900/20 dark:to-indigo-900/30">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <Card className="mb-8 border-blue-200 bg-blue-50 dark:bg-blue-900/20">
          <CardContent className="pt-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
              <div>
                <h1 className="text-4xl font-bold text-blue-700 dark:text-blue-300 mb-2">
                  ILS Paediatric Protocol
                </h1>
                <p className="text-lg text-blue-600 dark:text-blue-400 mb-4">
                  {session ? `Session ${session.id} - ${new Date(session.startTime).toLocaleString()}` : "No active session"}
                </p>
                {!blsStarted && !ilsStarted && !alsStarted && (
                  <p className="text-blue-700 dark:text-blue-300">
                    Ready to start ILS Paediatric resuscitation protocol
                  </p>
                )}
              </div>
              <div className="flex space-x-4">
                <Button
                  variant="outline"
                  onClick={() => setLocation("/")}
                  className="border-blue-300 text-blue-700 hover:bg-blue-100"
                >
                  <Home className="w-4 h-4 mr-2" />
                  Return to Dashboard
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setIsAudioEnabled(!isAudioEnabled)}
                  className="border-blue-300 text-blue-700 hover:bg-blue-100"
                >
                  {isAudioEnabled ? <Volume2 className="w-4 h-4 mr-2" /> : <VolumeX className="w-4 h-4 mr-2" />}
                  {isAudioEnabled ? "Mute" : "Unmute"}
                </Button>
                <Button 
                  onClick={() => setShowEndSessionDialog(true)}
                  disabled={!blsStarted}
                  className={`${
                    blsStarted 
                      ? "bg-red-600 text-white hover:bg-red-700" 
                      : "bg-gray-400 text-gray-200 cursor-not-allowed"
                  }`}
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  End Resuscitation
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Protocol Start Buttons */}
        {!blsStarted && !ilsStarted && !alsStarted && (
          <Card className="mb-8 border-red-200 bg-red-50 dark:bg-red-900/20">
            <CardContent className="pt-8 pb-8 text-center">
              <div className="space-y-4">
                <Button
                  onClick={handleStartBLS}
                  size="lg"
                  className="bg-red-600 hover:bg-red-700 text-white px-12 py-6 text-xl font-bold shadow-xl hover:shadow-2xl transition-all duration-200 transform hover:scale-105 w-full"
                >
                  <Heart className="w-8 h-8 mr-4 animate-pulse" />
                  START ILS PAEDIATRIC RESUS
                </Button>
                <p className="text-sm text-red-600 dark:text-red-400">
                  This will start the timer, metronome, and begin logging interventions
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Protocol Progression Buttons */}
        {blsStarted && !ilsStarted && !alsStarted && (
          <Card className="mb-8 border-blue-200 bg-blue-50 dark:bg-blue-900/20">
            <CardContent className="pt-6 pb-6">
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  onClick={handleStartILS}
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg font-semibold"
                >
                  <Stethoscope className="w-6 h-6 mr-3" />
                  Escalate to ILS
                </Button>
                <Button
                  onClick={handleStartALS}
                  size="lg"
                  className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-4 text-lg font-semibold"
                >
                  <Syringe className="w-6 h-6 mr-3" />
                  Escalate to ALS
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Protocol Progression Buttons - ILS */}
        {blsStarted && ilsStarted && !alsStarted && (
          <Card className="mb-8 border-purple-200 bg-purple-50 dark:bg-purple-900/20">
            <CardContent className="pt-6 pb-6 text-center">
              <Button
                onClick={handleStartALS}
                size="lg"
                className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-4 text-lg font-semibold"
              >
                <Syringe className="w-6 h-6 mr-3" />
                Escalate to ALS
              </Button>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Timer and Metronome */}
          <div className="space-y-6">
            
            {/* Timer */}
            <Card className="medical-card">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Clock className="w-5 h-5 mr-2" />
                  Session Timer
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Timer 
                  elapsedTime={elapsedTime}
                  isRunning={isRunning}
                  showControls={false}
                />
              </CardContent>
            </Card>

            {/* 2-Minute Protocol Timer */}
            {blsStarted && (
              <Card className="medical-card border-blue-200 bg-blue-50 dark:bg-blue-900/20">
                <CardHeader>
                  <CardTitle className="flex items-center text-lg text-blue-700 dark:text-blue-300">
                    <AlertTriangle className="w-5 h-5 mr-2" />
                    2-Minute Timer
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-4xl font-bold text-blue-700 dark:text-blue-300 mb-2">
                    {Math.floor(twoMinuteTimer / 60)}:{(twoMinuteTimer % 60).toString().padStart(2, '0')}
                  </div>
                  <p className="text-sm text-blue-600 dark:text-blue-400">
                    {blsStarted && !ilsStarted && !alsStarted ? "Next: Swap compressions" : "Next: Check rhythm & swap"}
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Metronome */}
            <Card className="medical-card">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Heart className="w-5 h-5 mr-2" />
                  CPR Metronome {blsStarted && (
                    <Badge className={`ml-2 ${
                      currentBpm === 120 ? 'bg-green-600' : 
                      currentBpm === 110 ? 'bg-orange-600' : 
                      'bg-red-600'
                    }`}>
                      {currentBpm} BPM
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {blsStarted ? (
                  <div className="space-y-4">
                    <Metronome 
                      isEnabled={metronomeEnabled && isAudioEnabled}
                      onBeatChange={(beat) => {
                        // Visual feedback for beats
                        if (beat && metronomeEnabled && isAudioEnabled) {
                          document.body.style.backgroundColor = "rgba(59, 130, 246, 0.1)";
                          setTimeout(() => {
                            document.body.style.backgroundColor = "";
                          }, 100);
                        }
                      }}
                      onBpmChange={(bpm) => {
                        setCurrentBpm(bpm);
                      }}
                    />
                    <div className="flex justify-center">
                      <Button
                        variant="outline"
                        onClick={() => setMetronomeEnabled(!metronomeEnabled)}
                        className="border-blue-300 text-blue-700 hover:bg-blue-100"
                      >
                        {metronomeEnabled ? <VolumeX className="w-4 h-4 mr-2" /> : <Volume2 className="w-4 h-4 mr-2" />}
                        {metronomeEnabled ? "Mute Metronome" : "Unmute Metronome"}
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Heart className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Metronome will start when BLS is initiated</p>
                  </div>
                )}
              </CardContent>
            </Card>

          </div>

          {/* Interventions and Protocols */}
          <div className="lg:col-span-2 space-y-6">

            {/* ILS Specific Interventions */}
            {(ilsStarted || alsStarted) && (
              <Card className="medical-card border-blue-200 bg-blue-50 dark:bg-blue-900/20">
                <CardHeader>
                  <CardTitle className="flex items-center text-lg text-blue-700 dark:text-blue-300">
                    <Stethoscope className="w-5 h-5 mr-2" />
                    ILS/ALS Interventions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Button
                      onClick={() => setShowIgelSelection(true)}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                      size="lg"
                    >
                      <Syringe className="w-5 h-5 mr-2" />
                      Supraglottic Airway (iGel)
                    </Button>
                    
                    <Button
                      onClick={() => {
                        logInterventionMutation.mutate({
                          type: "OXYGEN_THERAPY",
                          description: "High-flow oxygen therapy initiated",
                          details: { flowRate: "15L/min", method: "Non-rebreather mask" }
                        });
                        toast({
                          title: "Oxygen Therapy",
                          description: "High-flow oxygen initiated",
                          duration: 2000,
                        });
                      }}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                      size="lg"
                    >
                      <Heart className="w-5 h-5 mr-2" />
                      High-Flow Oxygen
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* ALS Specific Interventions */}
            {alsStarted && (
              <Card className="medical-card border-purple-200 bg-purple-50 dark:bg-purple-900/20">
                <CardHeader>
                  <CardTitle className="flex items-center text-lg text-purple-700 dark:text-purple-300">
                    <Pill className="w-5 h-5 mr-2" />
                    ALS Advanced Interventions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Button
                      onClick={() => handleProtocolAction('shock')}
                      className="bg-red-600 hover:bg-red-700 text-white"
                      size="lg"
                    >
                      <Zap className="w-5 h-5 mr-2" />
                      Defibrillation (4J/kg)
                    </Button>
                    
                    <Button
                      onClick={() => handleProtocolAction('rhythm_check')}
                      className="bg-purple-600 hover:bg-purple-700 text-white"
                      size="lg"
                    >
                      <Heart className="w-5 h-5 mr-2" />
                      Rhythm Check
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Reversible Causes */}
            {(ilsStarted || alsStarted) && sessionId && (
              <Card className="medical-card">
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <CheckCircle className="w-5 h-5 mr-2" />
                    Reversible Causes (4Hs & 4Ts)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ReversibleCauses sessionId={sessionId} />
                </CardContent>
              </Card>
            )}

            {/* Drug Calculator */}
            {alsStarted && sessionId && (
              <Card className="medical-card">
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <Pill className="w-5 h-5 mr-2" />
                    Drug Calculator
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <DrugCalculator sessionId={sessionId} patientType="Paediatric" />
                </CardContent>
              </Card>
            )}

            {/* Intervention Logger */}
            {blsStarted && sessionId && (
              <Card className="medical-card">
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <Heart className="w-5 h-5 mr-2" />
                    Intervention Logger
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <InterventionLogger 
                    sessionId={sessionId}
                    onInterventionLogged={handleIntervention}
                  />
                </CardContent>
              </Card>
            )}

          </div>
        </div>
      </div>

      {/* End Session Dialog */}
      <Dialog open={showEndSessionDialog} onOpenChange={setShowEndSessionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>End Resuscitation Session</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Outcome</label>
              <Select value={sessionOutcome} onValueChange={(value: "ROSC" | "ROLE") => setSessionOutcome(value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select outcome" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ROSC">ROSC (Return of Spontaneous Circulation)</SelectItem>
                  <SelectItem value="ROLE">ROLE (Recognition of Life Extinct)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Notes (Optional)</label>
              <Textarea
                value={sessionNotes}
                onChange={(e) => setSessionNotes(e.target.value)}
                placeholder="Additional notes about the session..."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEndSessionDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleEndSession} className="bg-red-600 hover:bg-red-700 text-white">
              End Session
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* iGel Selection Dialog */}
      <Dialog open={showIgelSelection} onOpenChange={setShowIgelSelection}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Select Supraglottic Airway Size</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            {[
              { size: "Size 1", weight: "2-5kg", color: "bg-pink-600" },
              { size: "Size 1.5", weight: "5-12kg", color: "bg-blue-600" },
              { size: "Size 2", weight: "10-25kg", color: "bg-green-600" },
              { size: "Size 2.5", weight: "25-35kg", color: "bg-yellow-600" },
              { size: "Size 3", weight: "30-60kg", color: "bg-orange-600" },
              { size: "Size 4", weight: "50-90kg", color: "bg-purple-600" },
              { size: "Size 5", weight: ">90kg", color: "bg-red-600" }
            ].map((igel) => (
              <Button
                key={igel.size}
                onClick={() => {
                  logInterventionMutation.mutate({
                    type: "AIRWAY_MANAGEMENT",
                    description: `Supraglottic airway inserted - ${igel.size}`,
                    details: { device: "iGel", size: igel.size, weightRange: igel.weight }
                  });
                  toast({
                    title: "Airway Secured",
                    description: `iGel ${igel.size} inserted successfully`,
                    duration: 3000,
                  });
                  setShowIgelSelection(false);
                }}
                className={`${igel.color} hover:opacity-90 text-white p-4 h-auto flex flex-col`}
                size="lg"
              >
                <div className="font-bold">{igel.size}</div>
                <div className="text-sm">{igel.weight}</div>
              </Button>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowIgelSelection(false)}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <FooterLinks />
    </div>
  );
}