import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Shield, Activity, Clock, Heart, X } from "lucide-react";
import FooterLinks from "@/components/footer-links";

const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

const registerSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  confirmEmail: z.string().email("Please enter a valid email address"),
  password: z.string()
    .min(8, "Password must be at least 8 characters")
    .regex(/[A-Z]/, "Password must contain at least one capital letter")
    .regex(/[0-9]/, "Password must contain at least one number")
    .regex(/[^A-Za-z0-9]/, "Password must contain at least one special character"),
  confirmPassword: z.string(),
  recoveryPasscode: z.string().length(10, "Recovery passcode must be exactly 10 digits").regex(/^\d+$/, "Recovery passcode must contain only numbers"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  role: z.string().min(1, "Please select your role"),
  professionalRegistration: z.string().optional(),
}).refine((data) => data.email === data.confirmEmail, {
  message: "Email addresses must match",
  path: ["confirmEmail"],
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
}).refine((data) => {
  const protectedRoles = ["Doctor", "Nurse", "Paramedic"];
  if (protectedRoles.includes(data.role) && !data.professionalRegistration) {
    return false;
  }
  return true;
}, {
  message: "Professional registration number is required for this role",
  path: ["professionalRegistration"],
});

type LoginForm = z.infer<typeof loginSchema>;
type RegisterForm = z.infer<typeof registerSchema>;

export default function AuthPageWorking() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user, loginMutation, registerMutation } = useAuth();
  const [isLogin, setIsLogin] = useState(true);

  if (user) {
    setLocation("/");
    return null;
  }

  const loginForm = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const registerForm = useForm<RegisterForm>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      email: "",
      password: "",
      confirmPassword: "",
      recoveryPasscode: "",
      firstName: "",
      lastName: "",
      role: "",
      professionalRegistration: "",
    },
  });

  const handleLogin = (data: LoginForm) => {
    loginMutation.mutate(data, {
      onSuccess: () => {
        toast({
          title: "Welcome back!",
          description: "Successfully logged in to ResusMGR",
        });
        setLocation("/");
      },
    });
  };

  const handleRegister = (data: RegisterForm) => {
    // Remove confirmEmail and confirmPassword before sending to server
    const { confirmEmail, confirmPassword, ...registrationData } = data;
    registerMutation.mutate(registrationData, {
      onSuccess: () => {
        toast({
          title: "Welcome to ResusMGR!",
          description: "Your account has been created successfully",
        });
        setLocation("/");
      },
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 relative">
      {/* Close Button */}
      <button
        onClick={() => setLocation("/")}
        className="absolute top-4 right-4 z-10 bg-white/90 hover:bg-white shadow-lg rounded-full p-2 text-gray-600 hover:text-gray-800 transition-colors"
      >
        <X className="w-6 h-6" />
      </button>
      
      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8 items-center min-h-[calc(100vh-4rem)]">
          
          <div className="space-y-6">
            <div className="flex items-center space-x-3 mb-8">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">ResusMGR</h1>
                <p className="text-gray-600">Professional Resuscitation Management</p>
              </div>
            </div>

            <div className="space-y-6">
              <h2 className="text-4xl font-bold text-gray-900 leading-tight">
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Welcome to ResusMGR
                </span>
              </h2>
              

            </div>
          </div>

          <div className="lg:pl-8">
            <div className="w-full max-w-lg mx-auto bg-white rounded-lg shadow-xl p-6">
              <div className="pb-4">
                <h2 className="text-2xl font-bold text-center text-gray-900">
                  Access ResusMGR
                </h2>
                <p className="text-center text-gray-600">
                  Secure login for emergency medical professionals
                </p>
              </div>
              
              <div className="flex mb-6 bg-gray-100 rounded-lg p-1">
                <button
                  type="button"
                  onClick={() => setIsLogin(true)}
                  className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
                    isLogin 
                      ? 'bg-white text-gray-900 shadow-sm' 
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => setIsLogin(false)}
                  className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
                    !isLogin 
                      ? 'bg-white text-gray-900 shadow-sm' 
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Sign Up
                </button>
              </div>

              {isLogin ? (
                <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
                  <div>
                    <Label htmlFor="login-email">Email Address</Label>
                    <Input
                      id="login-email"
                      type="email"
                      placeholder="your.email@hospital.nhs.uk"
                      {...loginForm.register("email")}
                    />
                    {loginForm.formState.errors.email && (
                      <p className="text-sm text-red-600">{loginForm.formState.errors.email.message}</p>
                    )}
                  </div>
                  
                  <div>
                    <Label htmlFor="login-password">Password</Label>
                    <Input
                      id="login-password"
                      type="password"
                      placeholder="Enter your password"
                      {...loginForm.register("password")}
                    />
                    {loginForm.formState.errors.password && (
                      <p className="text-sm text-red-600">{loginForm.formState.errors.password.message}</p>
                    )}
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? "Signing In..." : "Sign In"}
                  </Button>
                  
                  <div className="mt-4 text-center">
                    <button
                      type="button"
                      onClick={() => setLocation("/reset-password")}
                      className="text-blue-600 hover:text-blue-800 underline text-sm"
                    >
                      Forgot your password?
                    </button>
                  </div>
                </form>
              ) : (
                <form onSubmit={registerForm.handleSubmit(handleRegister)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        placeholder="John"
                        {...registerForm.register("firstName")}
                      />
                      {registerForm.formState.errors.firstName && (
                        <p className="text-sm text-red-600">{registerForm.formState.errors.firstName.message}</p>
                      )}
                    </div>
                    
                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        placeholder="Smith"
                        {...registerForm.register("lastName")}
                      />
                      {registerForm.formState.errors.lastName && (
                        <p className="text-sm text-red-600">{registerForm.formState.errors.lastName.message}</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your.email@hospital.nhs.uk"
                      {...registerForm.register("email")}
                    />
                    {registerForm.formState.errors.email && (
                      <p className="text-sm text-red-600">{registerForm.formState.errors.email.message}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="confirmEmail">Confirm Email Address</Label>
                    <Input
                      id="confirmEmail"
                      type="email"
                      placeholder="Re-enter your email address"
                      {...registerForm.register("confirmEmail")}
                    />
                    {registerForm.formState.errors.confirmEmail && (
                      <p className="text-sm text-red-600">{registerForm.formState.errors.confirmEmail.message}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="recoveryPasscode">10-Digit Recovery Passcode</Label>
                    <Input
                      id="recoveryPasscode"
                      type="text"
                      placeholder="Enter 10 digits (e.g., 1234567890)"
                      maxLength={10}
                      {...registerForm.register("recoveryPasscode")}
                    />
                    <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mt-2">
                      <p className="text-xs text-amber-800 font-medium">
                        ⚠️ Important: Choose and remember your recovery passcode
                      </p>
                      <p className="text-xs text-amber-700 mt-1">
                        This 10-digit code will be needed to reset your password if you forget it. Make sure to write it down safely.
                      </p>
                    </div>
                    {registerForm.formState.errors.recoveryPasscode && (
                      <p className="text-sm text-red-600">{registerForm.formState.errors.recoveryPasscode.message}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="role">Professional Role *</Label>
                    <select 
                      {...registerForm.register("role")}
                      className="w-full p-2 border border-gray-300 rounded"
                      required
                    >
                      <option value="">Select your professional role</option>
                      <option value="Doctor">Doctor</option>
                      <option value="Nurse">Nurse</option>
                      <option value="Paramedic">Paramedic</option>
                      <option value="Critical Care Paramedic">Critical Care Paramedic</option>
                      <option value="Emergency Medical Technician">Emergency Medical Technician</option>
                      <option value="Emergency Care Assistant">Emergency Care Assistant</option>
                      <option value="Student Paramedic">Student Paramedic</option>
                      <option value="First Aider">First Aider</option>
                      <option value="Community First Responder">Community First Responder</option>
                      <option value="Other Healthcare Professional">Other Healthcare Professional</option>
                    </select>
                    {registerForm.formState.errors.role && (
                      <p className="text-sm text-red-600">{registerForm.formState.errors.role.message}</p>
                    )}
                  </div>

                  {/* Professional Registration Number for protected roles */}
                  {registerForm.watch("role") && ["Doctor", "Nurse", "Paramedic"].includes(registerForm.watch("role")) && (
                    <div>
                      <Label htmlFor="professionalRegistration">
                        Professional Registration Number *
                        {registerForm.watch("role") === "Doctor" && " (GMC Number)"}
                        {registerForm.watch("role") === "Nurse" && " (NMC PIN)"}
                        {registerForm.watch("role") === "Paramedic" && " (HCPC Number)"}
                      </Label>
                      <Input
                        id="professionalRegistration"
                        placeholder={
                          registerForm.watch("role") === "Doctor" ? "e.g., 1234567" :
                          registerForm.watch("role") === "Nurse" ? "e.g., 12A3456E" :
                          "e.g., PH123456"
                        }
                        {...registerForm.register("professionalRegistration")}
                        required
                      />
                      <div className="mt-1 text-xs text-gray-600">
                        {registerForm.watch("role") === "Doctor" && "Enter your General Medical Council (GMC) registration number"}
                        {registerForm.watch("role") === "Nurse" && "Enter your Nursing and Midwifery Council (NMC) PIN"}
                        {registerForm.watch("role") === "Paramedic" && "Enter your Health and Care Professions Council (HCPC) registration number"}
                      </div>
                      {registerForm.formState.errors.professionalRegistration && (
                        <p className="text-sm text-red-600">{registerForm.formState.errors.professionalRegistration.message}</p>
                      )}
                    </div>
                  )}

                  <div>
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="Create a secure password"
                      {...registerForm.register("password")}
                    />
                    <div className="mt-1 text-xs text-gray-600">
                      Must contain: 1 capital letter, 1 number, 1 special character
                    </div>
                    {registerForm.formState.errors.password && (
                      <p className="text-sm text-red-600">{registerForm.formState.errors.password.message}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="confirmPassword">Confirm Password</Label>
                    <Input
                      id="confirmPassword"
                      type="password"
                      placeholder="Re-enter your password"
                      {...registerForm.register("confirmPassword")}
                    />
                    {registerForm.formState.errors.confirmPassword && (
                      <p className="text-sm text-red-600">{registerForm.formState.errors.confirmPassword.message}</p>
                    )}
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                    disabled={registerMutation.isPending}
                  >
                    {registerMutation.isPending ? "Creating Account..." : "Create Account"}
                  </Button>
                </form>
              )}

              <div className="mt-6 text-center">
                <p className="text-xs text-gray-500">
                  By signing in, you agree to our terms of service and privacy policy.
                </p>
              </div>
            </div>
          </div>
        </div>
        <FooterLinks />
      </div>
    </div>
  );
}