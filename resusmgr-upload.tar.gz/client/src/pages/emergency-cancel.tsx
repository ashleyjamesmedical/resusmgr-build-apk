import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle, CheckCircle, Mail, CreditCard } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function EmergencyCancel() {
  const [formData, setFormData] = useState({
    email: "",
    last4Digits: "",
    expiryMonth: "",
    expiryYear: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState<{ type: "success" | "error"; message: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setResult(null);

    try {
      const response = await apiRequest("POST", "/api/emergency-cancel-subscription", formData);
      const data = await response.json();

      if (response.ok) {
        setResult({
          type: "success",
          message: "Your subscription has been successfully cancelled. You will receive a confirmation notification in your account."
        });
        setFormData({ email: "", last4Digits: "", expiryMonth: "", expiryYear: "" });
      } else {
        setResult({
          type: "error",
          message: data.message || "Failed to cancel subscription. Please check your details and try again."
        });
      }
    } catch (error) {
      setResult({
        type: "error",
        message: "Unable to process your request. Please try again later or contact support."
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Card className="shadow-lg border-0">
          <CardHeader className="text-center space-y-4">
            <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-orange-600 rounded-full flex items-center justify-center mx-auto">
              <AlertTriangle className="w-8 h-8 text-white" />
            </div>
            <div>
              <CardTitle className="text-2xl font-bold text-gray-900 dark:text-white">
                Emergency Cancellation
              </CardTitle>
              <CardDescription className="text-gray-600 dark:text-gray-400 mt-2">
                Cancel your subscription if you've lost access to your account
              </CardDescription>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            <Alert className="border-amber-200 bg-amber-50 dark:border-amber-800 dark:bg-amber-900/20">
              <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
              <AlertDescription className="text-amber-800 dark:text-amber-300">
                This will immediately cancel your subscription. Only use this if you cannot access your account.
              </AlertDescription>
            </Alert>

            {result && (
              <Alert className={result.type === "success" ? "border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-900/20" : "border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-900/20"}>
                {result.type === "success" ? (
                  <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                ) : (
                  <AlertTriangle className="h-4 w-4 text-red-600 dark:text-red-400" />
                )}
                <AlertDescription className={result.type === "success" ? "text-green-800 dark:text-green-300" : "text-red-800 dark:text-red-300"}>
                  {result.message}
                </AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Email Address
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your account email"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  required
                  className="bg-white dark:bg-gray-800"
                />
              </div>

              <div className="space-y-4">
                <Label className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4" />
                  Card Details Used for Subscription
                </Label>
                
                <div className="space-y-2">
                  <Label htmlFor="last4" className="text-sm text-gray-600 dark:text-gray-400">
                    Last 4 digits of card
                  </Label>
                  <Input
                    id="last4"
                    type="text"
                    placeholder="1234"
                    maxLength={4}
                    value={formData.last4Digits}
                    onChange={(e) => handleInputChange("last4Digits", e.target.value.replace(/\D/g, ""))}
                    required
                    className="bg-white dark:bg-gray-800"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="month" className="text-sm text-gray-600 dark:text-gray-400">
                      Expiry Month
                    </Label>
                    <Input
                      id="month"
                      type="text"
                      placeholder="MM"
                      maxLength={2}
                      value={formData.expiryMonth}
                      onChange={(e) => handleInputChange("expiryMonth", e.target.value.replace(/\D/g, ""))}
                      required
                      className="bg-white dark:bg-gray-800"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="year" className="text-sm text-gray-600 dark:text-gray-400">
                      Expiry Year
                    </Label>
                    <Input
                      id="year"
                      type="text"
                      placeholder="YYYY"
                      maxLength={4}
                      value={formData.expiryYear}
                      onChange={(e) => handleInputChange("expiryYear", e.target.value.replace(/\D/g, ""))}
                      required
                      className="bg-white dark:bg-gray-800"
                    />
                  </div>
                </div>
              </div>

              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-red-600 hover:bg-red-700 text-white"
              >
                {isSubmitting ? "Cancelling Subscription..." : "Cancel Subscription"}
              </Button>
            </form>

            <div className="text-center space-y-2">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Remember your login details?
              </p>
              <Button variant="link" asChild className="text-blue-600 hover:text-blue-700">
                <a href="/auth">Sign in to your account</a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}