import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  ArrowLeft, 
  Book, 
  MessageSquare, 
  Mail, 
  Play, 
  Timer, 
  Users, 
  FileText, 
  Calculator,
  Heart,
  AlertTriangle,
  CheckCircle,
  Info,
  Camera,
  Clock,
  Stethoscope
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import targetedElementImage1 from "@assets/targeted_element_1748365129456.png";
import targetedElementImage2 from "@assets/targeted_element_1748640738460.png";
import Navigation from "@/components/navigation";

export default function HelpPage() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [messageSubject, setMessageSubject] = useState("");
  const [messageContent, setMessageContent] = useState("");
  const [activeSection, setActiveSection] = useState("overview");

  const sendMessageMutation = useMutation({
    mutationFn: async (messageData: { subject: string; content: string }) => {
      return apiRequest("POST", "/api/support-messages", messageData);
    },
    onSuccess: () => {
      toast({
        title: "Message Sent",
        description: "Your support message has been sent to our team. We'll respond within 24 hours.",
      });
      setMessageSubject("");
      setMessageContent("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again or email us directly.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!messageSubject.trim() || !messageContent.trim()) {
      toast({
        title: "Incomplete Message",
        description: "Please provide both a subject and message content.",
        variant: "destructive",
      });
      return;
    }

    sendMessageMutation.mutate({
      subject: messageSubject,
      content: messageContent,
    });
  };

  const sections = [
    { id: "overview", title: "App Overview", icon: Book },
    { id: "dashboard", title: "Dashboard Guide", icon: Heart },
    { id: "protocols", title: "Protocol Pages", icon: Stethoscope },
    { id: "sessions", title: "Managing Sessions", icon: Timer },
    { id: "reporting", title: "Reports & Data", icon: FileText },
    { id: "troubleshooting", title: "Troubleshooting", icon: AlertTriangle },
    { id: "contact", title: "Contact Support", icon: MessageSquare },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
              ResusMGR Help Center
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
              Comprehensive guide to using ResusMGR for emergency resuscitation management and reporting
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Navigation Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle className="text-lg">Help Topics</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <nav className="space-y-1">
                  {sections.map((section) => {
                    const IconComponent = section.icon;
                    return (
                      <button
                        key={section.id}
                        onClick={() => setActiveSection(section.id)}
                        className={`w-full flex items-center px-4 py-3 text-left text-sm font-medium rounded-none transition-colors ${
                          activeSection === section.id
                            ? "bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 border-r-2 border-blue-500"
                            : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
                        }`}
                      >
                        <IconComponent className="w-4 h-4 mr-3" />
                        {section.title}
                      </button>
                    );
                  })}
                </nav>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <Card>
              <CardContent className="p-8">
                {activeSection === "overview" && (
                  <div className="space-y-6">
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                        Welcome to ResusMGR
                      </h2>
                      <p className="text-gray-600 dark:text-gray-400 mb-6">
                        ResusMGR is a comprehensive digital resuscitation management platform designed for UK emergency ambulance crews and healthcare professionals. It provides real-time guidance, intervention logging, and comprehensive reporting capabilities aligned with UK Resuscitation Council guidelines.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Key Features</h3>
                        <div className="space-y-3">
                          <div className="flex items-start space-x-3">
                            <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                            <div>
                              <p className="font-medium text-gray-900 dark:text-white">Real-time Protocol Guidance</p>
                              <p className="text-sm text-gray-600 dark:text-gray-400">Step-by-step logging for BLS, ILS and ALS resuscitation protocols</p>
                            </div>
                          </div>
                          <div className="flex items-start space-x-3">
                            <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                            <div>
                              <p className="font-medium text-gray-900 dark:text-white">Intervention Logging</p>
                              <p className="text-sm text-gray-600 dark:text-gray-400">Automatic timestamping of all interventions and drug administrations</p>
                            </div>
                          </div>
                          <div className="flex items-start space-x-3">
                            <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                            <div>
                              <p className="font-medium text-gray-900 dark:text-white">Comprehensive Reporting</p>
                              <p className="text-sm text-gray-600 dark:text-gray-400">Detailed session reports with timeline and intervention summary</p>
                            </div>
                          </div>
                          <div className="flex items-start space-x-3">
                            <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                            <div>
                              <p className="font-medium text-gray-900 dark:text-white">Drug Calculator</p>
                              <p className="text-sm text-gray-600 dark:text-gray-400">Paediatric drug dose calculations with safety limits</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Getting Started</h3>
                        <div className="space-y-3">
                          <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                            <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">1. Choose Your Protocol</h4>
                            <p className="text-sm text-blue-800 dark:text-blue-200">Select from BLS, ILS, or ALS protocols for Adult or Paediatric patients</p>
                          </div>
                          <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                            <h4 className="font-medium text-green-900 dark:text-green-100 mb-2">2. Enter Patient Details</h4>
                            <p className="text-sm text-green-800 dark:text-green-200">Add CAD number, patient initials, and weight for accurate tracking</p>
                          </div>
                          <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                            <h4 className="font-medium text-purple-900 dark:text-purple-100 mb-2">3. Follow Protocol</h4>
                            <p className="text-sm text-purple-800 dark:text-purple-200">Use the guided interface to log interventions and monitor progress</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeSection === "dashboard" && (
                  <div className="space-y-6">
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                        Dashboard Guide
                      </h2>
                      <p className="text-gray-600 dark:text-gray-400 mb-6">
                        The dashboard is your main control center, providing quick access to all protocols and session management tools.
                      </p>
                    </div>

                    <div className="space-y-6">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Protocol Selection Cards</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                          <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                            <h4 className="font-medium text-green-700 dark:text-green-300 mb-2">Basic Life Support (BLS)</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              High-quality chest compressions, rescue breathing, and defibrillation for both adult and paediatric patients.
                            </p>
                          </div>
                          <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                            <h4 className="font-medium text-blue-700 dark:text-blue-300 mb-2">Intermediate Life Support (ILS)</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              Advanced airway management, reversible causes (4Hs & 4Ts), and cardiac rhythm analysis in addition to BLS procedures.
                            </p>
                          </div>
                          <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                            <h4 className="font-medium text-purple-700 dark:text-purple-300 mb-2">Advanced Life Support (ALS)</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              Comprehensive resuscitation including advanced monitoring, complex drug protocols, and post-ROSC care.
                            </p>
                          </div>
                          <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                            <h4 className="font-medium text-orange-700 dark:text-orange-300 mb-2">Drug Calculator</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              Weight-based drug dose calculations with age estimation tools and safety limits for paediatric patients.
                            </p>
                          </div>
                        </div>

                        <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
                          <div className="flex items-start space-x-3">
                            <Info className="w-5 h-5 text-yellow-600 dark:text-yellow-400 mt-0.5" />
                            <div>
                              <h4 className="font-medium text-yellow-900 dark:text-yellow-100 mb-1">Pro Tip</h4>
                              <p className="text-sm text-yellow-800 dark:text-yellow-200">
                                Click on any protocol card to start a new session. You can switch between protocols during an active session if needed.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Recent Sessions</h3>
                        <p className="text-gray-600 dark:text-gray-400 mb-4">
                          The recent sessions section shows your last 10 resuscitation sessions with key information:
                        </p>
                        <div className="space-y-3">
                          <div className="flex items-center space-x-3">
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">ROSC</Badge>
                            <span className="text-sm text-gray-600 dark:text-gray-400">Return of Spontaneous Circulation achieved</span>
                          </div>
                          <div className="flex items-center space-x-3">
                            <Badge variant="destructive">ROLE</Badge>
                            <span className="text-sm text-gray-600 dark:text-gray-400">Recognition of Life Extinct</span>
                          </div>
                          <div className="flex items-center space-x-3">
                            <Badge variant="secondary" className="bg-blue-50 text-blue-700 border-blue-200">Active</Badge>
                            <span className="text-sm text-gray-600 dark:text-gray-400">Session currently in progress</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeSection === "protocols" && (
                  <div className="space-y-6">
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                        Protocol Pages Guide
                      </h2>
                      <p className="text-gray-600 dark:text-gray-400 mb-6">
                        Each protocol page provides step-by-step guidance with real-time intervention logging and timeline tracking.
                      </p>
                    </div>

                    <div className="space-y-6">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Starting a Session</h3>
                        <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-6">
                          <div className="space-y-4">
                            <div>
                              <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">1. Enter Patient Information</h4>
                              <div className="space-y-2 text-sm text-blue-800 dark:text-blue-200">
                                <p>• <strong>CAD Number:</strong> Your ambulance service's Computer Aided Dispatch number</p>
                                <p>• <strong>Patient Initials:</strong> First and last name initials for identification</p>
                                <p>• <strong>Patient Weight:</strong> Required for accurate drug dose calculations</p>
                              </div>
                            </div>
                            <div>
                              <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">2. Start Protocol</h4>
                              <p className="text-sm text-blue-800 dark:text-blue-200">
                                Click "Start [Protocol]" to begin the session timer and activate intervention logging.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Key Interface Elements</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-4">
                            <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                              <div className="flex items-center space-x-2 mb-2">
                                <Timer className="w-5 h-5 text-blue-500" />
                                <h4 className="font-medium text-gray-900 dark:text-white">Session Timer</h4>
                              </div>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                Shows elapsed time since session start. Automatically timestamps all interventions.
                              </p>
                            </div>
                            <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                              <div className="flex items-center space-x-2 mb-2">
                                <Users className="w-5 h-5 text-green-500" />
                                <h4 className="font-medium text-gray-900 dark:text-white">Team Management</h4>
                              </div>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                Add team members and assign roles. Each member's actions are logged individually.
                              </p>
                            </div>
                          </div>
                          <div className="space-y-4">
                            <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                              <div className="flex items-center space-x-2 mb-2">
                                <Heart className="w-5 h-5 text-red-500" />
                                <h4 className="font-medium text-gray-900 dark:text-white">Rhythm Analysis</h4>
                              </div>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                Quick rhythm assessment buttons for shockable and non-shockable rhythms.
                              </p>
                            </div>
                            <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                              <div className="flex items-center space-x-2 mb-2">
                                <Calculator className="w-5 h-5 text-purple-500" />
                                <h4 className="font-medium text-gray-900 dark:text-white">Drug Administration</h4>
                              </div>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                Weight-based drug calculations with one-click administration logging.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Protocol-Specific Features</h3>
                        <div className="space-y-4">
                          <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                            <h4 className="font-medium text-green-900 dark:text-green-100 mb-2">BLS Protocols</h4>
                            <p className="text-sm text-green-800 dark:text-green-200 mb-2">
                              Focus on high-quality CPR and defibrillation with minimal interruptions.
                            </p>
                            <ul className="text-sm text-green-800 dark:text-green-200 space-y-1">
                              <li>• 2-minute compression cycles with automatic timing alerts</li>
                              <li>• Shock delivery tracking with energy levels</li>
                              <li>• Airway management progression from basic to advanced</li>
                            </ul>
                          </div>
                          <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                            <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">ILS Protocols</h4>
                            <p className="text-sm text-blue-800 dark:text-blue-200 mb-2">
                              Enhanced with advanced airway management and basic drug administration.
                            </p>
                            <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
                              <li>• Supraglottic airway device placement tracking</li>
                              <li>• Reversible causes assessment and management</li>
                            </ul>
                          </div>
                          <div className="p-4 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-lg">
                            <h4 className="font-medium text-purple-900 dark:text-purple-100 mb-2">ALS Protocols</h4>
                            <p className="text-sm text-purple-800 dark:text-purple-200 mb-2">
                              Comprehensive advanced life support with full drug protocols and post-ROSC care.
                            </p>
                            <ul className="text-sm text-purple-800 dark:text-purple-200 space-y-1">
                              <li>• Complete drug administration tracking with dose calculations</li>
                              <li>• Advanced airway management including intubation</li>
                              <li>• Post-ROSC care protocols and monitoring guidance</li>
                              <li>• Comprehensive reversible causes management</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeSection === "sessions" && (
                  <div className="space-y-6">
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                        Managing Sessions
                      </h2>
                      <p className="text-gray-600 dark:text-gray-400 mb-6">
                        Learn how to effectively manage resuscitation sessions from start to completion.
                      </p>
                    </div>

                    <div className="space-y-6">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Session Lifecycle</h3>
                        <div className="space-y-4">
                          <div className="flex items-start space-x-4">
                            <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 rounded-full flex items-center justify-center text-sm font-bold">1</div>
                            <div>
                              <h4 className="font-medium text-gray-900 dark:text-white mb-1">Session Creation</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                Enter patient details and click start to begin timing and intervention logging.
                              </p>
                            </div>
                          </div>
                          <div className="flex items-start space-x-4">
                            <div className="w-8 h-8 bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 rounded-full flex items-center justify-center text-sm font-bold">2</div>
                            <div>
                              <h4 className="font-medium text-gray-900 dark:text-white mb-1">Active Management</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                Follow protocol guidance, log interventions, and manage team members in real-time.
                              </p>
                            </div>
                          </div>
                          <div className="flex items-start space-x-4">
                            <div className="w-8 h-8 bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300 rounded-full flex items-center justify-center text-sm font-bold">3</div>
                            <div>
                              <h4 className="font-medium text-gray-900 dark:text-white mb-1">Session Completion</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                End the session with an outcome (ROSC, ROLE, or ongoing) and add final notes.
                              </p>
                            </div>
                          </div>
                          <div className="flex items-start space-x-4">
                            <div className="w-8 h-8 bg-orange-100 dark:bg-orange-900 text-orange-700 dark:text-orange-300 rounded-full flex items-center justify-center text-sm font-bold">4</div>
                            <div>
                              <h4 className="font-medium text-gray-900 dark:text-white mb-1">Report Generation</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                Comprehensive session report generated automatically with all intervention details.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Team Management</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                            <h4 className="font-medium text-gray-900 dark:text-white mb-2">Adding Team Members</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                              Click "Add Team Member" and search by name or manually enter details.
                            </p>
                            <div className="text-xs text-gray-500 dark:text-gray-400">
                              <p>• Search existing users by name</p>
                              <p>• Add external personnel manually</p>
                              <p>• Assign specific roles to each member</p>
                            </div>
                          </div>
                          <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                            <h4 className="font-medium text-gray-900 dark:text-white mb-2">Role Assignment</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                              Assign specific roles to track responsibilities and actions.
                            </p>
                            <div className="text-xs text-gray-500 dark:text-gray-400">
                              <p>• Team Leader: Overall coordination</p>
                              <p>• Compressor: Chest compressions</p>
                              <p>• Airway Manager: Ventilation and airway</p>
                              <p>• Drug Administrator: Medication preparation</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Data Auto-Save</h3>
                        <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
                          <div className="flex items-start space-x-3">
                            <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                            <div>
                              <h4 className="font-medium text-green-900 dark:text-green-100 mb-1">Automatic Data Protection</h4>
                              <p className="text-sm text-green-800 dark:text-green-200">
                                All session data is automatically saved as you work. CAD numbers, patient initials, and interventions are preserved even if you navigate away and return to the session.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeSection === "reporting" && (
                  <div className="space-y-6">
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                        Reports & Data
                      </h2>
                      <p className="text-gray-600 dark:text-gray-400 mb-6">
                        Understanding the comprehensive reporting system and data management features.
                      </p>
                    </div>

                    <div className="space-y-6">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Session Reports</h3>
                        <p className="text-gray-600 dark:text-gray-400 mb-4">
                          Each completed session generates a comprehensive report containing:
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-3">
                            <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                              <h4 className="font-medium text-blue-900 dark:text-blue-100 text-sm mb-1">Session Overview</h4>
                              <p className="text-xs text-blue-800 dark:text-blue-200">CAD number, patient details, protocol type, duration, and outcome</p>
                            </div>
                            <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                              <h4 className="font-medium text-green-900 dark:text-green-100 text-sm mb-1">Team Members</h4>
                              <p className="text-xs text-green-800 dark:text-green-200">Complete list of participating team members with assigned roles</p>
                            </div>
                            <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                              <h4 className="font-medium text-purple-900 dark:text-purple-100 text-sm mb-1">Intervention Timeline</h4>
                              <p className="text-xs text-purple-800 dark:text-purple-200">Chronological list of all interventions with precise timestamps</p>
                            </div>
                          </div>
                          <div className="space-y-3">
                            <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                              <h4 className="font-medium text-orange-900 dark:text-orange-100 text-sm mb-1">Drug Administration</h4>
                              <p className="text-xs text-orange-800 dark:text-orange-200">All medications given with doses, times, and administration routes</p>
                            </div>
                            <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                              <h4 className="font-medium text-red-900 dark:text-red-100 text-sm mb-1">Reversible Causes</h4>
                              <p className="text-xs text-red-800 dark:text-red-200">Assessment and management of potentially reversible causes</p>
                            </div>
                            <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                              <h4 className="font-medium text-gray-900 dark:text-gray-100 text-sm mb-1">Clinical Notes</h4>
                              <p className="text-xs text-gray-700 dark:text-gray-300">Additional observations and clinical decision rationale</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Data Export & Sharing</h3>
                        <div className="space-y-4">
                          <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                            <h4 className="font-medium text-gray-900 dark:text-white mb-2">Print-Friendly Reports</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                              All session reports are optimized for printing with clear formatting and clinical relevance.
                            </p>
                            <div className="text-xs text-gray-500 dark:text-gray-400">
                              <p>• Professional medical report format</p>
                              <p>• Includes hospital continuation guidance</p>
                              <p>• QR code for digital access to full session data</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Data Security & Compliance</h3>
                        <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                          <div className="space-y-3">
                            <div className="flex items-start space-x-3">
                              <CheckCircle className="w-5 h-5 text-blue-500 mt-0.5" />
                              <div>
                                <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-1">GDPR Compliant</h4>
                                <p className="text-sm text-blue-800 dark:text-blue-200">All patient data is handled in accordance with UK GDPR regulations</p>
                              </div>
                            </div>
                            <div className="flex items-start space-x-3">
                              <CheckCircle className="w-5 h-5 text-blue-500 mt-0.5" />
                              <div>
                                <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-1">Encrypted Storage</h4>
                                <p className="text-sm text-blue-800 dark:text-blue-200">All data is encrypted both in transit and at rest using industry-standard encryption</p>
                              </div>
                            </div>
                            <div className="flex items-start space-x-3">
                              <CheckCircle className="w-5 h-5 text-blue-500 mt-0.5" />
                              <div>
                                <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-1">Clinical Compliance</h4>
                                <p className="text-sm text-blue-800 dark:text-blue-200">Aligned with UK Resuscitation Council Guidelines (2021/2023) and JRCALC Clinical Practice Guidelines (2024)</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeSection === "troubleshooting" && (
                  <div className="space-y-6">
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                        Troubleshooting
                      </h2>
                      <p className="text-gray-600 dark:text-gray-400 mb-6">
                        Common issues and solutions to help you get the most out of ResusMGR.
                      </p>
                    </div>

                    <div className="space-y-6">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Common Issues</h3>
                        <div className="space-y-4">
                          <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                            <h4 className="font-medium text-gray-900 dark:text-white mb-2">Session Not Saving</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                              If your session data appears to be lost:
                            </p>
                            <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                              <li>• Check your internet connection - data syncs automatically when reconnected</li>
                              <li>• Refresh the page - auto-saved data will be restored</li>
                              <li>• Ensure you've clicked "Start" before logging interventions</li>
                            </ul>
                          </div>

                          <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                            <h4 className="font-medium text-gray-900 dark:text-white mb-2">Drug Calculator Not Working</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                              If drug doses aren't calculating correctly:
                            </p>
                            <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                              <li>• Verify patient weight is entered in kilograms</li>
                              <li>• Check that age estimation matches clinical assessment</li>
                              <li>• Ensure you have an active Pro subscription for full calculator access</li>
                            </ul>
                          </div>

                          <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                            <h4 className="font-medium text-gray-900 dark:text-white mb-2">Login Issues</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                              If you can't access your account:
                            </p>
                            <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                              <li>• Verify your email address and password are correct</li>
                              <li>• Check for any error messages and note the specific details</li>
                              <li>• Try clearing your browser cache and cookies</li>
                              <li>• Contact support if the issue persists</li>
                            </ul>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Browser Compatibility</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                            <h4 className="font-medium text-green-900 dark:text-green-100 mb-2">Recommended Browsers</h4>
                            <ul className="text-sm text-green-800 dark:text-green-200 space-y-1">
                              <li>• Chrome (latest version)</li>
                              <li>• Firefox (latest version)</li>
                              <li>• Safari (latest version)</li>
                              <li>• Edge (latest version)</li>
                            </ul>
                          </div>
                          <div className="p-4 bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-lg">
                            <h4 className="font-medium text-orange-900 dark:text-orange-100 mb-2">Performance Tips</h4>
                            <ul className="text-sm text-orange-800 dark:text-orange-200 space-y-1">
                              <li>• Keep browser updated</li>
                              <li>• Close unnecessary tabs</li>
                              <li>• Enable JavaScript</li>
                              <li>• Clear cache regularly</li>
                            </ul>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Emergency Procedures</h3>
                        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
                          <div className="flex items-start space-x-3">
                            <AlertTriangle className="w-5 h-5 text-red-500 mt-0.5" />
                            <div>
                              <h4 className="font-medium text-red-900 dark:text-red-100 mb-2">If Technology Fails During Emergency</h4>
                              <div className="text-sm text-red-800 dark:text-red-200 space-y-1">
                                <p>• Continue with manual protocols - never let technology delay life-saving interventions</p>
                                <p>• Document interventions on paper if necessary</p>
                                <p>• Return to digital logging when system is restored</p>
                                <p>• Contact support after the emergency for data recovery assistance</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeSection === "contact" && (
                  <div className="space-y-6" id="contact">
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                        Contact Support
                      </h2>
                      <p className="text-gray-600 dark:text-gray-400 mb-6">
                        Get help with any questions or issues you're experiencing with ResusMGR.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Email Support */}
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center text-lg">
                            <Mail className="w-5 h-5 mr-2 text-blue-500" />
                            Email Support
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                              <p className="font-medium text-blue-900 dark:text-blue-100 mb-1">
                                info@ashleyjamesmedical.org.uk
                              </p>
                              <p className="text-sm text-blue-700 dark:text-blue-300">
                                Response time: Within 24 hours
                              </p>
                            </div>
                            <div className="text-sm text-gray-600 dark:text-gray-400">
                              <p className="mb-2">When contacting us, please include:</p>
                              <ul className="space-y-1">
                                <li>• Your username/email address</li>
                                <li>• Description of the issue</li>
                                <li>• Browser and device information</li>
                                <li>• Any error messages you've seen</li>
                              </ul>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      {/* In-App Messaging */}
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center text-lg">
                            <MessageSquare className="w-5 h-5 mr-2 text-green-500" />
                            In-App Messaging
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div className="space-y-3">
                              <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                  Subject
                                </label>
                                <Input
                                  value={messageSubject}
                                  onChange={(e) => setMessageSubject(e.target.value)}
                                  placeholder="Brief description of your issue"
                                  className="w-full"
                                />
                              </div>
                              <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                  Message
                                </label>
                                <Textarea
                                  value={messageContent}
                                  onChange={(e) => setMessageContent(e.target.value)}
                                  placeholder="Please describe your issue in detail..."
                                  rows={4}
                                  className="w-full"
                                />
                              </div>
                            </div>
                            <Button
                              onClick={handleSendMessage}
                              disabled={sendMessageMutation.isPending}
                              className="w-full bg-green-600 hover:bg-green-700 text-white"
                            >
                              {sendMessageMutation.isPending ? "Sending..." : "Send Message"}
                            </Button>
                            <p className="text-xs text-gray-500 dark:text-gray-400">
                              Messages are sent directly to our support team and you'll receive a response within 24 hours.
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                        Emergency Clinical Support
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                          <h4 className="font-medium text-red-900 dark:text-red-100 mb-2">
                            During Active Resuscitation
                          </h4>
                          <p className="text-sm text-red-800 dark:text-red-200">
                            If you experience technical issues during an active resuscitation, continue with standard protocols and contact technical support after patient care is complete.
                          </p>
                        </div>
                        <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
                          <h4 className="font-medium text-yellow-900 dark:text-yellow-100 mb-2">
                            Clinical Questions
                          </h4>
                          <p className="text-sm text-yellow-800 dark:text-yellow-200">
                            For clinical protocol questions, consult your local guidelines or contact your clinical supervisor. This app supports but does not replace clinical judgment.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}