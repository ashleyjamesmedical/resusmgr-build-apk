import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useState, useEffect } from "react";
import { Download, Heart, Clock, Shield, Users, CheckCircle, Smartphone, Monitor } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import QRCode from "qrcode";

export default function Landing() {
  const [currentUrl, setCurrentUrl] = useState("");
  const [qrCodeUrl, setQrCodeUrl] = useState("");
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstallPrompt, setShowInstallPrompt] = useState(false);
  const [showFallbackInstall, setShowFallbackInstall] = useState(false);
  const [showInstallBanner, setShowInstallBanner] = useState(false);

  // Fetch user count
  const { data: userCountData } = useQuery({
    queryKey: ["/api/public/user-count"],
  });

  useEffect(() => {
    const url = window.location.origin;
    setCurrentUrl(url);

    // Generate QR code for app download URL
    const downloadUrl = `${url}/api/download-apk`;
    QRCode.toDataURL(downloadUrl, {
      width: 192,
      margin: 2,
      color: {
        dark: '#1f2937',
        light: '#ffffff'
      }
    }).then(setQrCodeUrl);

    // Check if app is already installed
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
    const isInWebAppiOS = (window.navigator as any).standalone === true;
    const isInstalled = isStandalone || isInWebAppiOS;

    // Check if user came via QR code with install parameter
    const urlParams = new URLSearchParams(window.location.search);
    const installType = urlParams.get('install');
    
    if (installType === 'true') {
      setShowInstallBanner(true);
    } else if (installType === 'apk') {
      // Show APK installation instructions
      const isAndroid = /Android/i.test(navigator.userAgent);
      if (isAndroid) {
        alert(
          'For Android users:\n\n' +
          '1. Open Chrome browser\n' +
          '2. Visit this website\n' +
          '3. Tap the menu (3 dots) → "Add to Home screen"\n' +
          '4. Confirm installation\n\n' +
          'This will install ResusMGR as a native app on your device.'
        );
      } else {
        alert(
          'This link is designed for Android devices.\n\n' +
          'On iOS: Use Safari and tap "Share" → "Add to Home Screen"\n' +
          'On Desktop: Look for the install icon in your browser address bar'
        );
      }
    }

    if (!isInstalled) {
      // Show fallback install button for all devices
      setShowFallbackInstall(true);

      // Listen for the beforeinstallprompt event (Chrome/Edge)
      const handleBeforeInstallPrompt = (e: Event) => {
        e.preventDefault();
        setDeferredPrompt(e);
        setShowInstallPrompt(true);
        
        // If user came via QR code, automatically trigger install prompt
        if (installType === 'true') {
          setTimeout(() => {
            if (confirm('Install ResusMGR as an app on your device?\n\nThis will add ResusMGR to your home screen for quick access during emergencies.')) {
              (e as any).prompt().then((result: any) => {
                if (result.outcome === 'accepted') {
                  alert('ResusMGR has been installed! Look for it on your home screen.');
                } else {
                  alert('Installation cancelled. You can still use ResusMGR in your browser.');
                }
              });
            }
          }, 1000);
        }
      };

      window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

      return () => {
        window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      };
    }
  }, []);

  const handleInstallClick = () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then((choiceResult: any) => {
        if (choiceResult.outcome === 'accepted') {
          console.log('User accepted the install prompt');
        } else {
          console.log('User dismissed the install prompt');
        }
        setDeferredPrompt(null);
        setShowInstallPrompt(false);
      });
    } else {
      // Fallback instructions for browsers that don't support beforeinstallprompt
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
      const isAndroid = /Android/.test(navigator.userAgent);
      
      if (isIOS) {
        alert('To install ResusMGR on iOS:\n\n1. Tap the Share button (square with arrow)\n2. Select "Add to Home Screen"\n3. Tap "Add" to confirm\n\nResusMGR will then appear on your home screen like a native app.');
      } else if (isAndroid) {
        alert('To install ResusMGR on Android:\n\n1. Tap the menu button (3 dots) in your browser\n2. Select "Add to Home screen" or "Install app"\n3. Confirm the installation\n\nResusMGR will then appear on your home screen like a native app.');
      } else {
        alert('To install ResusMGR:\n\nLook for an install icon in your browser address bar, or check your browser menu for "Install" or "Add to Home Screen" options.\n\nOnce installed, ResusMGR will work offline and load faster.');
      }
    }
  };

  const userCount = userCountData?.count || "2";

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-indigo-100 dark:from-gray-900 dark:via-blue-900 dark:to-indigo-900">
      <div className="relative">
        {/* Install Banner */}
        {showInstallBanner && (
          <div className="fixed top-0 left-0 right-0 bg-blue-600 text-white p-3 text-center z-50">
            <p className="text-sm">Install ResusMGR for quick access during emergencies</p>
            <Button 
              size="sm" 
              variant="secondary" 
              onClick={handleInstallClick}
              className="ml-2 bg-white text-blue-600 hover:bg-gray-100"
            >
              Install Now
            </Button>
          </div>
        )}

        {/* Navigation */}
        <nav className="flex justify-between items-center p-6">
          <div className="flex items-center space-x-2">
            <Heart className="h-8 w-8 text-red-500" />
            <span className="text-2xl font-bold text-gray-900 dark:text-white">ResusMGR</span>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant="secondary" className="text-sm">
              {userCount} Healthcare Professionals
            </Badge>
            <Button asChild>
              <a href="/auth">Sign In</a>
            </Button>
          </div>
        </nav>

        {/* Hero Section */}
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="text-center mb-16">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
              Professional
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600"> Resuscitation </span>
              Management
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
              Advanced digital platform for UK emergency ambulance crews and healthcare professionals. 
              Comprehensive resuscitation protocol guidance with real-time intervention logging and timing.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                <a href="/auth">Start Free Trial</a>
              </Button>
              {(showInstallPrompt || showFallbackInstall) && (
                <Button size="lg" variant="outline" onClick={handleInstallClick}>
                  <Download className="mr-2 h-5 w-5" />
                  Install App
                </Button>
              )}
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <Card>
              <CardHeader>
                <Clock className="h-12 w-12 text-blue-600 mb-4" />
                <CardTitle>Precise Timing</CardTitle>
                <CardDescription>
                  2-minute cycle tracking with audio prompts for compressions and rhythm checks
                </CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <Shield className="h-12 w-12 text-green-600 mb-4" />
                <CardTitle>Protocol Compliance</CardTitle>
                <CardDescription>
                  UK Resuscitation Council guidelines for BLS, ILS, and ALS protocols
                </CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <Users className="h-12 w-12 text-purple-600 mb-4" />
                <CardTitle>Team Management</CardTitle>
                <CardDescription>
                  Track team members, interventions, and drug administrations in real-time
                </CardDescription>
              </CardHeader>
            </Card>
          </div>

          {/* Download Section */}
          <div id="download-section" className="grid md:grid-cols-2 gap-8 mb-16">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Smartphone className="mr-2 h-6 w-6" />
                  Mobile App
                </CardTitle>
                <CardDescription>
                  Install on your phone for instant access during emergencies
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {qrCodeUrl && (
                    <div className="flex justify-center">
                      <img 
                        src={qrCodeUrl} 
                        alt="QR Code for ResusMGR Android installation" 
                        className="border border-gray-200 dark:border-gray-700 rounded"
                      />
                    </div>
                  )}
                  <div className="text-center">
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                      Scan with your Android device
                    </p>
                    <Badge variant="outline">Works offline once installed</Badge>
                  </div>
                  {(showInstallPrompt || showFallbackInstall) && (
                    <Button onClick={handleInstallClick} className="w-full">
                      <Download className="mr-2 h-4 w-4" />
                      Install Now
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Monitor className="mr-2 h-6 w-6" />
                  Web Access
                </CardTitle>
                <CardDescription>
                  Access via any modern web browser on desktop or mobile
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center py-8">
                    <div className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                      {currentUrl}
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Bookmark this URL for quick access
                    </p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                      <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                      Works on all devices
                    </div>
                    <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                      <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                      No app store required
                    </div>
                    <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                      <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                      Always up to date
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Professional Focus */}
          <div className="text-center bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Built for Healthcare Professionals
            </h2>
            <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-2xl mx-auto">
              Specifically designed for First Aiders, Emergency Responders, and Ambulance Staff. 
              Trusted by healthcare professionals across the UK for critical resuscitation scenarios.
            </p>
            <div className="grid md:grid-cols-3 gap-6 text-left">
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">BLS Protocols</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">Basic Life Support with compression timing and airway management</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">ILS Protocols</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">Intermediate Life Support with defibrillation and drug calculations</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">ALS Protocols</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">Advanced Life Support with paramedic drugs and advanced airways</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}