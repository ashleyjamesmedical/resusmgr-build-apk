import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Shield, 
  Server, 
  Users, 
  Activity, 
  Database,
  UserX,
  UserCheck,
  Trash2,
  Crown,
  Star,
  Clock,
  Heart,
  StopCircle,
  AlertTriangle,
  CheckCircle,
  XCircle,
  MessageSquare,
  Eye,
  Mail
} from "lucide-react";

interface AdminUser {
  id: string;
  email: string;
  firstName: string | null;
  lastName: string | null;
  profileImageUrl: string | null;
  role: string | null;
  subscriptionActive: boolean;
  disclaimerAccepted: boolean;
  lastLoginAt: Date | null;
  createdAt: Date | null;
  activeSessionCount?: number;
  activeSession?: {
    id: number;
    protocolType: string;
    patientType: string;
    startTime: Date;
    duration: number;
  };
}

interface ServerStatus {
  uptime: number;
  memoryUsage: number;
  activeConnections: number;
  dbConnectionStatus: string;
}

interface UnauthorizedReport {
  id: number;
  reportedByUserId: string;
  sessionId: number;
  teamMemberId: number | null;
  reason: string;
  status: string;
  adminNotes: string | null;
  reviewedBy: string | null;
  createdAt: Date;
  reviewedAt: Date | null;
}

export default function AdminConsole() {
  const { toast } = useToast();
  const [selectedReport, setSelectedReport] = useState<UnauthorizedReport | null>(null);
  const [reportStatus, setReportStatus] = useState("");
  const [adminNotes, setAdminNotes] = useState("");

  // Fetch server status
  const { data: serverStatus, isLoading: statusLoading } = useQuery<ServerStatus>({
    queryKey: ["/api/admin/server-status"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Fetch users
  const { data: users, isLoading: usersLoading } = useQuery<AdminUser[]>({
    queryKey: ["/api/admin/users"],
    refetchInterval: 60000, // Refresh every minute
  });

  // Fetch unauthorized participation reports
  const { data: unauthorizedReports, isLoading: reportsLoading } = useQuery<UnauthorizedReport[]>({
    queryKey: ["/api/admin/unauthorized-participation-reports"],
    refetchInterval: 60000, // Refresh every minute
  });

  // User management mutations
  const blockUser = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("PATCH", `/api/admin/users/${userId}/block`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "User Blocked",
        description: "User has been blocked from accessing the system.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to block user.",
        variant: "destructive",
      });
    },
  });

  const deleteUser = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("DELETE", `/api/admin/users/${userId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "User Deleted",
        description: "User has been permanently deleted.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete user.",
        variant: "destructive",
      });
    },
  });

  const makeAdmin = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("PATCH", `/api/admin/users/${userId}/make-admin`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "User Promoted",
        description: "User has been granted Administrator privileges.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to promote user to admin.",
        variant: "destructive",
      });
    },
  });

  const makeProUser = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("PATCH", `/api/admin/users/${userId}/make-pro`);
    },
    onSuccess: () => {
      // Force a complete cache refresh
      queryClient.removeQueries({ queryKey: ["/api/admin/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "User Upgraded",
        description: "User has been granted free Pro access.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to upgrade user.",
        variant: "destructive",
      });
    },
  });

  const removeProUser = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("PATCH", `/api/admin/users/${userId}/remove-pro`);
    },
    onSuccess: () => {
      // Force a complete cache refresh
      queryClient.removeQueries({ queryKey: ["/api/admin/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Pro Access Revoked",
        description: "User's Pro access has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to remove Pro access.",
        variant: "destructive",
      });
    },
  });

  const endUserSession = useMutation({
    mutationFn: async ({ userId, sessionId }: { userId: string; sessionId: number }) => {
      return await apiRequest("POST", `/api/admin/users/${userId}/end-session`, { sessionId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Session Ended",
        description: "User's resuscitation session has been terminated.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to end user's session.",
        variant: "destructive",
      });
    },
  });

  // Update report status mutation
  const updateReportMutation = useMutation({
    mutationFn: async ({ id, status, adminNotes }: { id: number; status: string; adminNotes: string }) => {
      return await apiRequest("PATCH", `/api/admin/unauthorized-participation-reports/${id}`, {
        status,
        adminNotes
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/unauthorized-participation-reports"] });
      toast({
        title: "Report Updated",
        description: "The unauthorized participation report has been updated successfully."
      });
      setSelectedReport(null);
    },
    onError: (error: any) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update report",
        variant: "destructive"
      });
    }
  });

  // Create conversation mutation
  const createConversationMutation = useMutation({
    mutationFn: async ({ name, relatedReportId, participantIds }: { 
      name: string; 
      relatedReportId: number; 
      participantIds: string[] 
    }) => {
      return await apiRequest("POST", "/api/chat/conversations", {
        name,
        type: "report_discussion",
        relatedReportId,
        participantIds
      });
    },
    onSuccess: () => {
      toast({
        title: "Conversation Created",
        description: "A secure discussion has been started for this report."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Create Conversation",
        description: error.message || "Could not start conversation",
        variant: "destructive"
      });
    }
  });

  const handleViewReport = (report: UnauthorizedReport) => {
    setSelectedReport(report);
    setReportStatus(report.status);
    setAdminNotes(report.adminNotes || "");
  };

  const handleUpdateReport = () => {
    if (!selectedReport) return;
    
    updateReportMutation.mutate({
      id: selectedReport.id,
      status: reportStatus,
      adminNotes
    });
  };

  const handleStartConversation = (report: UnauthorizedReport) => {
    // Create conversation with the team member who made the report
    if (report.reportedByUserId) {
      createConversationMutation.mutate({
        name: `Security Report #${report.id} Discussion`,
        relatedReportId: report.id,
        participantIds: [report.reportedByUserId]
      });
    } else {
      toast({
        title: "Cannot Start Conversation",
        description: "No user ID found for this report",
        variant: "destructive"
      });
    }
  };

  // Investigation outcome mutations
  const resolveReportMutation = useMutation({
    mutationFn: async ({ reportId, action, adminNotes }: { 
      reportId: number; 
      action: 'keep' | 'remove'; 
      adminNotes: string 
    }) => {
      const response = await apiRequest("POST", `/api/admin/unauthorized-participation-reports/${reportId}/resolve`, {
        action,
        adminNotes
      });
      return await response.json();
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/unauthorized-participation-reports"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      toast({
        title: "Investigation Complete",
        description: data.message || "Report has been resolved successfully."
      });
      setSelectedReport(null);
    },
    onError: (error: any) => {
      toast({
        title: "Resolution Failed",
        description: error.message || "Failed to resolve report",
        variant: "destructive"
      });
    }
  });

  const handleKeepInResus = (report: UnauthorizedReport) => {
    resolveReportMutation.mutate({
      reportId: report.id,
      action: 'keep',
      adminNotes: `After investigation, the team member's participation has been deemed appropriate and they will remain in the resuscitation records. Session ${report.sessionId} team composition is confirmed as accurate.`
    });
  };

  const handleRemoveFromResus = (report: UnauthorizedReport) => {
    resolveReportMutation.mutate({
      reportId: report.id,
      action: 'remove',
      adminNotes: `Following investigation, the team member's participation was found to be unauthorized. They have been removed from the resuscitation records for session ${report.sessionId} to maintain accurate clinical documentation.`
    });
  };

  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };

  const getInitials = (firstName: string | null, lastName: string | null) => {
    const first = firstName?.[0] || "";
    const last = lastName?.[0] || "";
    return (first + last).toUpperCase() || "?";
  };

  const formatLastLogin = (lastLoginAt: Date | null) => {
    if (!lastLoginAt) return "Never";
    const date = new Date(lastLoginAt);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return "Today";
    if (diffDays === 1) return "Yesterday";
    if (diffDays < 7) return `${diffDays} days ago`;
    return date.toLocaleDateString();
  };

  const getRoleBadgeVariant = (role: string | null) => {
    switch (role) {
      case "Administrator": return "destructive";
      case "Pro": return "default";
      case "Blocked": return "secondary";
      default: return "outline";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">Admin Console</h1>
          </div>
          <p className="text-gray-600">System administration and user management</p>
          <Link href="/" className="inline-block mt-4">
            <Button variant="outline" size="sm">
              ← Back to Dashboard
            </Button>
          </Link>
        </div>

        {/* Server Status Card */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Server className="h-5 w-5" />
              Live Server Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            {statusLoading ? (
              <div className="text-center py-4 text-gray-500">Loading server status...</div>
            ) : serverStatus ? (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {formatUptime(serverStatus.uptime)}
                  </div>
                  <div className="text-sm text-gray-600">Server Uptime</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {Math.round(serverStatus.memoryUsage)}%
                  </div>
                  <div className="text-sm text-gray-600">Memory Usage</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">
                    {serverStatus.activeConnections}
                  </div>
                  <div className="text-sm text-gray-600">Active Connections</div>
                </div>
                <div className="text-center">
                  <div className={`text-2xl font-bold ${
                    serverStatus.dbConnectionStatus === "Connected" ? "text-green-600" : "text-red-600"
                  }`}>
                    {serverStatus.dbConnectionStatus}
                  </div>
                  <div className="text-sm text-gray-600">Database Status</div>
                </div>
              </div>
            ) : (
              <div className="text-center py-4 text-red-500">Failed to load server status</div>
            )}
          </CardContent>
        </Card>

        {/* Unauthorized Participation Reports */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              Unauthorised Participation Reports
              {unauthorizedReports && (
                <Badge variant="destructive" className="ml-2">
                  {unauthorizedReports.length}
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {reportsLoading ? (
              <div className="text-center py-8 text-gray-500">Loading reports...</div>
            ) : unauthorizedReports && unauthorizedReports.length > 0 ? (
              <div className="space-y-4">
                {unauthorizedReports.map((report) => (
                  <div 
                    key={report.id} 
                    className="flex items-start justify-between p-4 border rounded-lg bg-red-50 border-red-200 cursor-pointer hover:bg-red-100 transition-colors"
                    onClick={() => handleViewReport(report)}
                  >
                    <div className="flex-1">
                      <div className="font-medium text-red-800">
                        Security Report #{report.id}
                      </div>
                      <div className="text-sm text-red-600 mt-1">
                        Session ID: {report.sessionId} | Team Member ID: {report.teamMemberId || 'null'}
                      </div>
                      <div className="text-sm text-gray-700 mt-2">
                        <strong>Reason:</strong> {report.reason}
                      </div>
                      {report.adminNotes && (
                        <div className="text-sm text-blue-700 mt-2">
                          <strong>Admin Notes:</strong> {report.adminNotes}
                        </div>
                      )}
                      <div className="text-xs text-gray-500 mt-2">
                        Reported: {new Date(report.createdAt).toLocaleString('en-GB')}
                        {report.reviewedBy && (
                          <span className="ml-4">
                            Reviewed by: {report.reviewedBy}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 ml-4">
                      {report.status === 'pending' && (
                        <>
                          <Button
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleKeepInResus(report);
                            }}
                            disabled={resolveReportMutation.isPending}
                            className="bg-green-600 hover:bg-green-700 text-white"
                          >
                            <UserCheck className="h-4 w-4 mr-1" />
                            Keep in Resus
                          </Button>
                          <Button
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleRemoveFromResus(report);
                            }}
                            disabled={resolveReportMutation.isPending}
                            className="bg-red-600 hover:bg-red-700 text-white"
                          >
                            <UserX className="h-4 w-4 mr-1" />
                            Remove from Resus
                          </Button>
                        </>
                      )}
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleStartConversation(report);
                        }}
                        className="mr-2"
                      >
                        <MessageSquare className="h-4 w-4 mr-1" />
                        Message
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleViewReport(report);
                        }}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        Review
                      </Button>
                      <Badge 
                        variant={
                          report.status === 'pending' ? 'destructive' : 
                          report.status === 'resolved' ? 'default' : 
                          'secondary'
                        }
                      >
                        {report.status === 'pending' ? 'Pending Review' : 
                         report.status === 'resolved' ? 'Resolved' : 
                         report.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Shield className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <p>No unauthorised participation reports found.</p>
                <p className="text-sm mt-1">Security reports will appear here when submitted.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* User Management Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              User Management
              {users && (
                <Badge variant="secondary" className="ml-2">
                  {users.length} users
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {usersLoading ? (
              <div className="text-center py-8 text-gray-500">Loading users...</div>
            ) : users && users.length > 0 ? (
              <div className="space-y-4">
                {users.map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg bg-white">
                    <div className="flex items-center gap-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={user.profileImageUrl || undefined} />
                        <AvatarFallback className="bg-blue-100 text-blue-600">
                          {getInitials(user.firstName, user.lastName)}
                        </AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-gray-900">
                            {user.firstName && user.lastName 
                              ? `${user.firstName} ${user.lastName}`
                              : user.email
                            }
                          </h3>
                          <Badge variant={getRoleBadgeVariant(user.role)}>
                            {user.role || "User"}
                          </Badge>
                          {user.subscriptionActive && (
                            <Badge variant="default" className="bg-green-100 text-green-800">
                              Pro
                            </Badge>
                          )}
                        </div>
                        <div className="text-sm text-gray-600 space-y-1">
                          <div>{user.email}</div>
                          <div className="flex items-center gap-4">
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              Last login: {formatLastLogin(user.lastLoginAt)}
                            </span>
                            <span>
                              Disclaimer: {user.disclaimerAccepted ? "Accepted" : "Pending"}
                            </span>
                          </div>
                          {user.activeSession && (
                            <div className="flex items-center gap-1 text-red-600 font-medium">
                              <Heart className="h-3 w-3" />
                              Active Session: {user.activeSession.protocolType} {user.activeSession.patientType} 
                              ({Math.floor(user.activeSession.duration / 60)}:{(user.activeSession.duration % 60).toString().padStart(2, '0')})
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {user.role !== "Administrator" && (
                        <>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => makeAdmin.mutate(user.id)}
                            disabled={makeAdmin.isPending}
                            className="text-purple-600 hover:text-purple-700"
                          >
                            <Crown className="h-4 w-4 mr-1" />
                            Make Admin
                          </Button>
                          
                          {!user.subscriptionActive ? (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => makeProUser.mutate(user.id)}
                              disabled={makeProUser.isPending}
                              className="text-green-600 hover:text-green-700"
                            >
                              <Star className="h-4 w-4 mr-1" />
                              Give Pro
                            </Button>
                          ) : (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => removeProUser.mutate(user.id)}
                              disabled={removeProUser.isPending}
                              className="text-orange-600 hover:text-orange-700"
                            >
                              <Star className="h-4 w-4 mr-1" />
                              Remove Pro
                            </Button>
                          )}
                          
                          {user.activeSession && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => endUserSession.mutate({ userId: user.id, sessionId: user.activeSession!.id })}
                              disabled={endUserSession.isPending}
                              className="text-red-600 hover:text-red-700"
                            >
                              <StopCircle className="h-4 w-4 mr-1" />
                              End Session
                            </Button>
                          )}
                          
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => blockUser.mutate(user.id)}
                            disabled={blockUser.isPending}
                            className="text-orange-600 hover:text-orange-700"
                          >
                            <UserX className="h-4 w-4 mr-1" />
                            Block
                          </Button>
                          
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              if (confirm(`Are you sure you want to permanently delete ${user.email}? This action cannot be undone.`)) {
                                deleteUser.mutate(user.id);
                              }
                            }}
                            disabled={deleteUser.isPending}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            Delete
                          </Button>
                        </>
                      )}
                      
                      {user.role === "Administrator" && (
                        <Badge variant="destructive">Protected Admin</Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">No users found</div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Detailed Report View Dialog */}
      <Dialog open={!!selectedReport} onOpenChange={() => setSelectedReport(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              Security Report #{selectedReport?.id} - Detailed Review
            </DialogTitle>
          </DialogHeader>
          
          {selectedReport && (
            <div className="space-y-6">
              {/* Report Details */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-gray-700">Session ID</Label>
                  <p className="text-sm text-gray-900">{selectedReport.sessionId}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-700">Team Member ID</Label>
                  <p className="text-sm text-gray-900">{selectedReport.teamMemberId || 'null'}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-700">Current Status</Label>
                  <Badge 
                    variant={
                      selectedReport.status === 'pending' ? 'destructive' : 
                      selectedReport.status === 'resolved' ? 'default' : 
                      'secondary'
                    }
                    className="mt-1"
                  >
                    {selectedReport.status === 'pending' ? 'Pending Review' : 
                     selectedReport.status === 'resolved' ? 'Resolved' : 
                     selectedReport.status}
                  </Badge>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-700">Reported</Label>
                  <p className="text-sm text-gray-900">
                    {new Date(selectedReport.createdAt).toLocaleString('en-GB')}
                  </p>
                </div>
              </div>

              {/* Security Concern Details */}
              <div>
                <Label className="text-sm font-medium text-gray-700">Security Concern</Label>
                <div className="mt-1 p-3 bg-red-50 border border-red-200 rounded-md">
                  <p className="text-sm text-red-800">{selectedReport.reason}</p>
                </div>
              </div>

              {/* Status Update */}
              <div className="space-y-3">
                <Label className="text-sm font-medium text-gray-700">Update Status</Label>
                <Select value={reportStatus} onValueChange={setReportStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending Review</SelectItem>
                    <SelectItem value="reviewed">Under Investigation</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                    <SelectItem value="dismissed">Dismissed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Admin Notes */}
              <div className="space-y-3">
                <Label className="text-sm font-medium text-gray-700">Administrative Notes</Label>
                <Textarea
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  placeholder="Add your review notes, actions taken, or resolution details..."
                  className="min-h-[100px]"
                />
              </div>

              {/* Previous Review Info */}
              {selectedReport.reviewedBy && (
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-md">
                  <p className="text-sm text-blue-800">
                    <strong>Previously reviewed by:</strong> {selectedReport.reviewedBy}
                  </p>
                  {selectedReport.adminNotes && (
                    <p className="text-sm text-blue-700 mt-1">
                      <strong>Previous notes:</strong> {selectedReport.adminNotes}
                    </p>
                  )}
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex justify-between pt-4 border-t">
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => handleStartConversation(selectedReport)}
                    disabled={createConversationMutation.isPending}
                  >
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Start Secure Discussion
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      // Could add email functionality here if needed
                      toast({
                        title: "Email Feature",
                        description: "Direct email notification would be sent to involved parties."
                      });
                    }}
                  >
                    <Mail className="h-4 w-4 mr-2" />
                    Send Notification
                  </Button>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setSelectedReport(null)}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleUpdateReport}
                    disabled={updateReportMutation.isPending}
                  >
                    {updateReportMutation.isPending ? "Updating..." : "Update Report"}
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}