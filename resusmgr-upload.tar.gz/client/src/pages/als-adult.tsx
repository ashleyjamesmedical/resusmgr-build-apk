import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import Navigation from "@/components/navigation";
import Timer from "@/components/timer";
import Metronome from "@/components/metronome";
import InterventionLogger from "@/components/intervention-logger";
import ReversibleCauses from "@/components/reversible-causes";
import DrugCalculator from "@/components/drug-calculator";
import PreSessionTeamManager from "@/components/pre-session-team-manager";
import InterventionConfirmationDialog from "@/components/intervention-confirmation-dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Heart, 
  Clock, 
  Volume2, 
  VolumeX, 
  Stethoscope, 
  Syringe, 
  Pill, 
  Zap,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Home,
  Users,
  Activity,
  FileText
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useTimer } from "@/hooks/useTimer";
import type { ResuscitationSession, Intervention } from "@shared/schema";
import FooterLinks from "@/components/footer-links";

export default function ALSAdult() {
  const [, params] = useRoute("/als-adult/:sessionId?");
  const sessionId = params?.sessionId ? parseInt(params.sessionId) : null;
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [showEndSessionDialog, setShowEndSessionDialog] = useState(false);
  const [sessionOutcome, setSessionOutcome] = useState<"ROSC" | "ROLE" | "">("");
  const [sessionNotes, setSessionNotes] = useState("");
  const [blsStarted, setBlsStarted] = useState(false);
  const [ilsStarted, setIlsStarted] = useState(false);
  const [alsStarted, setAlsStarted] = useState(false);
  const [blsStartTime, setBlsStartTime] = useState<Date | null>(null);
  const [metronomeEnabled, setMetronomeEnabled] = useState(false);
  const [currentBpm, setCurrentBpm] = useState(120);
  const [twoMinuteTimer, setTwoMinuteTimer] = useState(120);
  const [showTwoMinutePrompt, setShowTwoMinutePrompt] = useState(false);
  const [confirmationMessage, setConfirmationMessage] = useState("");
  const [showInterventionConfirm, setShowInterventionConfirm] = useState(false);
  const [localTeamMembers, setLocalTeamMembers] = useState<any[]>([]);
  const [showSavingPage, setShowSavingPage] = useState(false);
  const [showReadyDialog, setShowReadyDialog] = useState(false);

  // ALS Specific Timer State (30-minute protocol timer)
  const [alsStartTime, setAlsStartTime] = useState<Date | null>(null);
  const [alsElapsedTime, setAlsElapsedTime] = useState(0);
  const [alsTimerRunning, setAlsTimerRunning] = useState(false);
  const [thirtyMinuteWarningShown, setThirtyMinuteWarningShown] = useState(false);
  
  // Session ID input state
  const [customSessionId, setCustomSessionId] = useState("");
  const [sessionIdSet, setSessionIdSet] = useState(false);
  
  // IV/IO access state
  const [hasIvAccess, setHasIvAccess] = useState(false);
  const [hasIoAccess, setHasIoAccess] = useState(false);
  const [hasIvIoAccess, setHasIvIoAccess] = useState(false);
  const [showIvIoSiteDialog, setShowIvIoSiteDialog] = useState(false);
  const [selectedIvIoSite, setSelectedIvIoSite] = useState<string>("");
  const [accessType, setAccessType] = useState<'IV' | 'IO' | null>(null);
  const [showCustomLocationDialog, setShowCustomLocationDialog] = useState(false);
  const [customLocation, setCustomLocation] = useState("");
  const [showIvIoRequiredDialog, setShowIvIoRequiredDialog] = useState(false);
  const [accessTeamMember, setAccessTeamMember] = useState("");
  const [accessSize, setAccessSize] = useState("");
  
  // Intervention confirmation dialog state
  const [showInterventionDialog, setShowInterventionDialog] = useState(false);
  const [pendingIntervention, setPendingIntervention] = useState<{type: string, name: string} | null>(null);
  
  // Drug administration state
  const [selectedDrug, setSelectedDrug] = useState<{
    name: string;
    dose: string;
    route: string;
  } | null>(null);
  const [showDrugConfirmDialog, setShowDrugConfirmDialog] = useState(false);
  const [drugTeamMember, setDrugTeamMember] = useState("");
  
  // Enhanced adrenaline timer state (3-5 minute intervals as per UK RC Guidelines)
  const [lastAdrenalineTime, setLastAdrenalineTime] = useState<Date | null>(null);
  const [adrenalineTimer, setAdrenalineTimer] = useState(0);
  const [adrenalineTimerRunning, setAdrenalineTimerRunning] = useState(false);
  const [adrenalineCount, setAdrenalineCount] = useState(0);
  const [showAdrenalinePrompt, setShowAdrenalinePrompt] = useState(false);
  const [showImmediateAdrenalinePrompt, setShowImmediateAdrenalinePrompt] = useState(false);

  // Shock tracking for adrenaline prompts
  const [shockCount, setShockCount] = useState(0);
  const [showThreeShockPrompt, setShowThreeShockPrompt] = useState(false);
  const [showShockAdrenalinePrompt, setShowShockAdrenalinePrompt] = useState(false);

  // EtCO2 monitoring state
  const [showEtco2Dialog, setShowEtco2Dialog] = useState(false);
  const [etco2Value, setEtco2Value] = useState("");
  
  // Additional notes state
  const [additionalNotes, setAdditionalNotes] = useState("");
  const [etco2Unit, setEtco2Unit] = useState<"mmHg" | "kPa">("mmHg");
  
  // Track logged reversible causes
  const [loggedReversibleCauses, setLoggedReversibleCauses] = useState<Set<string>>(new Set());
  
  // Interactive reversible causes state
  const [showReversibleCauseDialog, setShowReversibleCauseDialog] = useState(false);
  const [selectedReversibleCause, setSelectedReversibleCause] = useState("");
  const [reversibleCauseReadings, setReversibleCauseReadings] = useState<{
    [key: string]: { reading: string; isAbnormal: boolean }
  }>({});
  
  // Rhythm tracking state
  const [hasInitialRhythm, setHasInitialRhythm] = useState(false);
  const [showRhythmRequiredDialog, setShowRhythmRequiredDialog] = useState(false);
  const [showPostShockRhythmDialog, setShowPostShockRhythmDialog] = useState(false);
  const [pendingShockType, setPendingShockType] = useState<string>("");
  
  // Rhythm check dialog state
  const [showRhythmCheckDialog, setShowRhythmCheckDialog] = useState(false);
  const [selectedRhythm, setSelectedRhythm] = useState("");

  // LUCAS device state
  const [lucasActive, setLucasActive] = useState(false);
  const [lucasOperator, setLucasOperator] = useState("");
  const [showLucasConfirmDialog, setShowLucasConfirmDialog] = useState(false);

  const { elapsedTime, isRunning, startTimer, pauseTimer, resetTimer } = useTimer();

  // Fetch session data - always get fresh data for protocol escalations
  // Fetch current user data for scope checking
  const { data: user } = useQuery({
    queryKey: ["/api/user"],
    staleTime: 1000 * 60 * 5, // Cache for 5 minutes
  });

  const { data: session, isLoading: sessionLoading } = useQuery<ResuscitationSession>({
    queryKey: ["/api/sessions", sessionId],
    enabled: !!sessionId,
    staleTime: 0, // Always fetch fresh data
    gcTime: 0, // Don't cache data
  });

  // Fetch interventions for current session only
  const { data: interventions = [] } = useQuery<Intervention[]>({
    queryKey: [`/api/sessions/${sessionId}/interventions`],
    enabled: !!sessionId,
  });

  // Fetch team members for existing session
  const { data: sessionTeamMembers = [] } = useQuery({
    queryKey: [`/api/sessions/${sessionId}/team-members`],
    enabled: !!sessionId && !!session,
    retry: false,
  });

  // Save team member mutation
  const saveTeamMemberMutation = useMutation({
    mutationFn: async (member: any) => {
      if (!sessionId) throw new Error("No session ID");
      return apiRequest("POST", `/api/sessions/${sessionId}/team-members`, member);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/sessions/${sessionId}/team-members`] });
    },
  });

  // Create session mutation
  const createSessionMutation = useMutation({
    mutationFn: async (sessionData: any) => {
      const response = await apiRequest("POST", "/api/sessions", sessionData);
      return response.json();
    },
    onSuccess: async (newSession) => {
      const newSessionId = newSession.id;
      console.log("New session created:", newSessionId);
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/sessions/active"] });
      
      // Navigate to the new session - team members will be handled by PreSessionTeamManager
      setLocation(`/als-adult/${newSessionId}`);
    },
  });

  // End session mutation
  const endSessionMutation = useMutation({
    mutationFn: async ({ outcome, notes }: { outcome: string; notes?: string }) => {
      if (!sessionId) throw new Error("No session ID");
      return apiRequest("PUT", `/api/sessions/${sessionId}/end`, { outcome, notes });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/sessions/active"] });
      setLocation("/");
    },
  });

  // Log intervention mutation
  const logInterventionMutation = useMutation({
    mutationFn: async (intervention: { type: string; description: string; details?: any }) => {
      if (!sessionId) throw new Error("No session ID");
      return apiRequest("POST", "/api/interventions", {
        ...intervention,
        sessionId: sessionId
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/sessions/${sessionId}/interventions`] });
    },
  });

  // Update custom session ID mutation
  const updateCustomSessionIdMutation = useMutation({
    mutationFn: async (customSessionId: string) => {
      if (!sessionId) throw new Error("No session ID");
      return apiRequest("PATCH", `/api/sessions/${sessionId}/custom-id`, { customSessionId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions", sessionId] });
      toast({
        title: "Session Updated",
        description: "CAD number/patient initials saved successfully",
      });
    },
  });

  // Notification creation mutation for scope violations
  const createNotificationMutation = useMutation({
    mutationFn: async (notification: { type: string; title: string; message: string; priority: string }) => {
      const response = await fetch("/api/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(notification),
      });
      if (!response.ok) throw new Error("Failed to create notification");
      return response.json();
    },
    onError: (error: any) => {
      console.error("Failed to create notification:", error);
    },
  });

  // Load custom session ID from existing session
  useEffect(() => {
    if (session && session.customSessionId && !customSessionId) {
      setCustomSessionId(session.customSessionId);
    }
  }, [session, customSessionId]);

  // Session restoration: Check for existing interventions and restore session state
  useEffect(() => {
    if (session && Array.isArray(interventions) && interventions.length > 0) {
      const sessionObj = session;
      
      // Check for protocol start interventions
      const hasBlsStart = interventions.some((intervention: Intervention) => 
        intervention.type === "BLS_START"
      );
      const hasIlsStart = interventions.some((intervention: Intervention) => 
        intervention.type === "ILS_START"
      );
      const hasAlsStart = interventions.some((intervention: Intervention) => 
        intervention.type === "ALS_START"
      );
      
      // Restore protocol states
      if (hasBlsStart) setBlsStarted(true);
      if (hasIlsStart) setIlsStarted(true);
      if (hasAlsStart) {
        setAlsStarted(true);
        // Initialize ALS timer only if escalating (has previous BLS or ILS)
        if (!alsTimerRunning && (hasBlsStart || hasIlsStart)) {
          setAlsTimerRunning(true);
          setAlsStartTime(new Date());
          setAlsElapsedTime(0);
          setThirtyMinuteWarningShown(false);
        }
      }
      
      // If any protocol was started, enable metronome and start timer
      if (hasBlsStart || hasIlsStart || hasAlsStart) {
        setMetronomeEnabled(true);
        setIsAudioEnabled(true); // Ensure audio is enabled for metronome to work
        
        // Debug logging
        console.log("ALS page - Protocol started, session data:", {
          hasBlsStart,
          hasIlsStart,
          hasAlsStart,
          isRunning,
          startTime: sessionObj?.startTime,
          sessionObj
        });
        
        if (!isRunning && sessionObj?.startTime) {
          const sessionStart = new Date(sessionObj.startTime).getTime();
          const now = Date.now();
          console.log("ALS page - Timer calculation:", {
            sessionStart,
            now,
            elapsed: Math.floor((now - sessionStart) / 1000),
            isValidTime: !isNaN(sessionStart) && sessionStart > 0
          });
          
          if (!isNaN(sessionStart) && sessionStart > 0) {
            const elapsed = Math.floor((now - sessionStart) / 1000);
            console.log("ALS page - Starting timer with elapsed time:", elapsed);
            startTimer(elapsed);
          } else {
            console.log("ALS page - Starting timer from 0");
            startTimer(0);
          }
        } else {
          console.log("ALS page - Timer not started:", { isRunning, hasStartTime: !!sessionObj?.startTime });
        }
      }
    }
  }, [session, interventions, isRunning, startTimer]);

  // ALS Timer Effect - Separate timer for ALS protocol with 30-minute warning
  useEffect(() => {
    let alsInterval: NodeJS.Timeout;
    
    if (alsTimerRunning && alsStartTime) {
      alsInterval = setInterval(() => {
        const now = Date.now();
        const alsElapsed = Math.floor((now - alsStartTime.getTime()) / 1000);
        setAlsElapsedTime(alsElapsed);
        
        // 30-minute warning (1800 seconds)
        if (alsElapsed >= 1800 && !thirtyMinuteWarningShown) {
          setThirtyMinuteWarningShown(true);
          if (isAudioEnabled) {
            const utterance = new SpeechSynthesisUtterance("Warning: Advanced Life Support has been running for 30 minutes. Consider termination of resuscitation if no ROSC achieved.");
            utterance.rate = 0.9;
            utterance.volume = 1.0;
            utterance.pitch = 1.0;
            speechSynthesis.speak(utterance);
          }
          toast({
            title: "ALS 30-Minute Warning",
            description: "Consider termination of resuscitation if no ROSC achieved",
            variant: "destructive",
            duration: 10000,
          });
        }
      }, 1000);
    }
    
    return () => {
      if (alsInterval) clearInterval(alsInterval);
    };
  }, [alsTimerRunning, alsStartTime, thirtyMinuteWarningShown, isAudioEnabled]);

  // Timer effects
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isRunning) {
      interval = setInterval(() => {
        if (twoMinuteTimer > 0) {
          setTwoMinuteTimer(prev => prev - 1);
        } else if (twoMinuteTimer === 0 && (blsStarted || ilsStarted || alsStarted)) {
          setShowTwoMinutePrompt(true);
          
          // Play audio prompt for rhythm check and compression swap
          if (isAudioEnabled) {
            const message = (ilsStarted || alsStarted) 
              ? "Two minutes complete - Check rhythm and swap compressions now"
              : "Two minutes complete - Swap compressions now";
            
            const utterance = new SpeechSynthesisUtterance(message);
            utterance.rate = 1.0;
            utterance.volume = 1.0;
            utterance.pitch = 1.1;
            speechSynthesis.speak(utterance);
          }
          
          // Automatically show rhythm check dialog after 2 minutes
          setTimeout(() => {
            setShowRhythmCheckDialog(true);
          }, 1000);
          
          setTwoMinuteTimer(120); // Reset for next cycle
        }

        // Update adrenaline timer if running
        if (adrenalineTimerRunning && adrenalineTimer > 0) {
          setAdrenalineTimer(prev => prev - 1);
        } else if (adrenalineTimerRunning && adrenalineTimer === 0) {
          // Adrenaline due
          setShowAdrenalinePrompt(true);
          if (isAudioEnabled) {
            const utterance = new SpeechSynthesisUtterance("Adrenaline due now - Five minutes elapsed");
            utterance.rate = 1.0;
            utterance.volume = 1.0;
            utterance.pitch = 1.2;
            speechSynthesis.speak(utterance);
          }
          setAdrenalineTimer(300); // Reset to 5 minutes
        }
      }, 1000);
    }
    
    return () => clearInterval(interval);
  }, [isRunning, twoMinuteTimer, adrenalineTimer, adrenalineTimerRunning, blsStarted, ilsStarted, alsStarted, isAudioEnabled]);

  // Sync session team members with local state when they're loaded
  useEffect(() => {
    if (sessionId && Array.isArray(sessionTeamMembers) && sessionTeamMembers.length > 0) {
      console.log("Loading saved team members from database:", sessionTeamMembers);
      // Transform database team members to match the expected format
      const transformedMembers = sessionTeamMembers.map((member: any) => ({
        name: member.name,
        role: member.role,
        userId: member.userId,
        isResusMgrUser: member.isResusMgrUser || false
      }));
      console.log("Transformed team members for UI:", transformedMembers);
      setLocalTeamMembers(transformedMembers);
    } else if (sessionId && Array.isArray(sessionTeamMembers)) {
      console.log("No saved team members found for session:", sessionId);
    }
  }, [sessionTeamMembers, sessionId]);
  
  // Update logged reversible causes when interventions change
  useEffect(() => {
    if (interventions && interventions.length > 0) {
      const loggedCauses = new Set<string>();
      interventions.forEach((intervention: any) => {
        if (intervention.type === 'REVERSIBLE_CAUSE') {
          loggedCauses.add(intervention.description);
        }
      });
      setLoggedReversibleCauses(loggedCauses);
    }
  }, [interventions]);

  // Use local team members (which includes transformed session data)
  const teamMembers = localTeamMembers;
  
  // Count valid team members (those with both name and role filled)
  const validTeamMembers = Array.isArray(teamMembers) ? teamMembers.filter((member: any) => {
    if (!member) return false;
    
    // Check if member has valid name and role
    const hasName = member.name && typeof member.name === 'string' && member.name.trim().length > 0;
    const hasRole = member.role && typeof member.role === 'string' && member.role.trim().length > 0;
    
    return hasName && hasRole;
  }) : [];

  const validInterventions = Array.isArray(interventions) ? interventions : [];

  // Start ALS function with dual timer system
  const handleStartBLS = async () => {
    // If already showing ready dialog, this is the second click - actually start resus
    if (showReadyDialog) {
      setShowReadyDialog(false);
      
      const now = new Date();
      setBlsStarted(true);
      setAlsStarted(true);
      setBlsStartTime(now);
      setMetronomeEnabled(true);
      setTwoMinuteTimer(120);
      
      // Initialize ALS-specific timer
      setAlsStartTime(new Date());
      setAlsElapsedTime(0);
      setAlsTimerRunning(true);
      setThirtyMinuteWarningShown(false);
      
      if (!isRunning) {
        startTimer(0);
      }

      // Audio announcement
      if (isAudioEnabled) {
        const utterance = new SpeechSynthesisUtterance("Advanced Life Support Adult resus started. Dual timer system active.");
        utterance.rate = 1.0;
        utterance.volume = 1.0;
        speechSynthesis.speak(utterance);
      }

      // Log start intervention
      logInterventionMutation.mutate({
        type: "ALS_START",
        description: "Advanced Life Support Adult resus started - Dual timer system initiated",
        details: { 
          metronomeRate: 120,
          protocolType: "ALS",
          patientType: "Adult",
          alsTimerStarted: true,
          thirtyMinuteWarning: "Enabled"
        }
      });

      toast({
        title: "ALS Started",
        description: "Advanced Life Support protocol active with 30-minute timer",
        duration: 3000,
      });
      return;
    }

    // First click - validate and show saving process
    
    // Check scope of practice - ALS requires Nurse, Doctor, or Paramedic
    const qualifiedRoles = ['nurse', 'doctor', 'paramedic', 'registered nurse', 'rn', 'consultant', 'physician', 'gp'];
    const hasQualifiedTeamMember = validTeamMembers.some(member => 
      qualifiedRoles.includes(member.role.toLowerCase())
    );
    const userIsQualified = user && qualifiedRoles.includes(((user as any).role || '').toLowerCase());

    if (!hasQualifiedTeamMember && !userIsQualified) {
      // Create notification for scope violation
      createNotificationMutation.mutate({
        type: "scope_violation",
        title: "ALS Protocol Access Denied",
        message: "ALS protocols require at least one Nurse, Doctor, or Paramedic on the team. Add a qualified team member or ensure your role qualifications are correct.",
        priority: "high"
      });
      
      toast({
        title: "Access Denied",
        description: "ALS requires Nurse, Doctor, or Paramedic qualification",
        variant: "destructive",
        duration: 5000,
      });
      return;
    }

    // Validate both CAD number and team member requirements
    if (!customSessionId || !customSessionId.trim()) {
      toast({
        title: "CAD Number Required",
        description: "Please enter a CAD number or patient identifier before starting resuscitation",
        variant: "destructive",
      });
      return;
    }

    // Validate team member requirement
    if (validTeamMembers.length === 0) {
      toast({
        title: "Team Member Required", 
        description: "Please add at least one team member with both name and role before starting resuscitation",
        variant: "destructive",
      });
      return;
    }

    try {
      // Show saving page
      setShowSavingPage(true);

      // Create session if needed
      if (!sessionId) {
        await createSessionMutation.mutateAsync({
          protocolType: "ALS",
          patientType: "Adult",
          startTime: new Date().toISOString(),
          customSessionId: customSessionId.trim() || undefined,
        });
      }

      // Save all team members
      for (const member of validTeamMembers) {
        try {
          await saveTeamMemberMutation.mutateAsync({
            name: member.name,
            role: member.role,
            userId: member.userId,
            isResusMgrUser: member.isResusMgrUser || false
          });
        } catch (error) {
          console.error("Failed to save team member:", error);
        }
      }

      // Hide saving page and show ready dialog
      setTimeout(() => {
        setShowSavingPage(false);
        setShowReadyDialog(true);
      }, 2000);

    } catch (error) {
      setShowSavingPage(false);
      toast({
        title: "Error",
        description: "Failed to save team setup",
        variant: "destructive",
      });
    }
  };

  // Handle IV/IO access establishment with site selection
  const handleSpecificAccess = (type: 'IV' | 'IO') => {
    setAccessType(type);
    setShowIvIoSiteDialog(true);
  };

  // Enhanced airway intervention handler
  const handleAirwayIntervention = (interventionName: string) => {
    if (!(blsStarted || ilsStarted || alsStarted)) return;
    
    setPendingIntervention({ type: 'airway', name: interventionName });
    setShowInterventionDialog(true);
  };

  // Handle intervention confirmation with team member and size details
  const handleInterventionConfirmation = (details: any) => {
    if (!pendingIntervention || !sessionId) return;

    const { teamMember, size, notes } = details;

    // Log intervention with enhanced details
    logInterventionMutation.mutate({
      type: pendingIntervention.type.toUpperCase(),
      description: `${pendingIntervention.name} - ${size || 'Size not specified'} by ${teamMember}`,
      details: {
        intervention: pendingIntervention.name,
        teamMember,
        size,
        notes,
        timestamp: new Date().toISOString()
      }
    });

    // Start adrenaline timer ONLY when adrenaline is actually confirmed/administered
    if (pendingIntervention.name.includes('Adrenaline')) {
      const newCount = adrenalineCount + 1;
      setAdrenalineCount(newCount);
      setLastAdrenalineTime(new Date());
      
      // Start adrenaline timer only after first dose is confirmed
      if (newCount === 1) {
        setAdrenalineTimer(300); // 5 minutes = 300 seconds
        setAdrenalineTimerRunning(true);
        
        // Audio confirmation that adrenaline timer has started
        if (isAudioEnabled) {
          const utterance = new SpeechSynthesisUtterance("Adrenaline timer started - next dose due in 5 minutes");
          utterance.rate = 1.0;
          utterance.volume = 1.0;
          utterance.pitch = 1.0;
          speechSynthesis.speak(utterance);
        }
      }
      
      // Clear all adrenaline prompts
      setShowAdrenalinePrompt(false);
      setShowThreeShockPrompt(false);
      setShowImmediateAdrenalinePrompt(false);
      setShowShockAdrenalinePrompt(false);
    }

    // Update reversible causes state if this is a reversible cause
    if (pendingIntervention.type === 'reversible_cause') {
      setLoggedReversibleCauses(prev => new Set([...prev, pendingIntervention.name]));
    }

    // Check if this is a shock - trigger post-shock rhythm prompt
    if (pendingIntervention.type === 'shock') {
      // Close intervention dialog first
      setShowInterventionDialog(false);
      setPendingIntervention(null);
      
      // Show post-shock rhythm prompt
      setTimeout(() => {
        setShowPostShockRhythmDialog(true);
      }, 500);
      return;
    }

    // Reset dialog state
    setShowInterventionDialog(false);
    setPendingIntervention(null);
  };

  // Confirm IV/IO access establishment
  const handleAccessConfirm = () => {
    if (!accessType || !selectedIvIoSite || !accessTeamMember || !accessSize) return;

    const finalLocation = selectedIvIoSite === "Other Location" ? customLocation : selectedIvIoSite;

    // Set access flags
    if (accessType === 'IV') {
      setHasIvAccess(true);
    } else {
      setHasIoAccess(true);
    }
    setHasIvIoAccess(true); // Combined flag for drug administration

    // Log access intervention with enhanced details
    logInterventionMutation.mutate({
      type: "VASCULAR_ACCESS",
      description: `${accessType} access established by ${accessTeamMember} - ${accessSize} at ${finalLocation}`,
      details: { 
        accessType,
        teamMember: accessTeamMember,
        size: accessSize,
        location: finalLocation,
        timestamp: new Date().toISOString()
      }
    });

    // Audio confirmation for IV/IO access with team member and size details
    if (isAudioEnabled) {
      const accessMessage = `${accessType} access confirmed - ${accessSize} by ${accessTeamMember} at ${finalLocation}`;
      const utterance = new SpeechSynthesisUtterance(accessMessage);
      utterance.rate = 1.0;
      utterance.volume = 1.0;
      utterance.pitch = 1.1;
      speechSynthesis.speak(utterance);
    }

    toast({
      title: `${accessType} Access Established`,
      description: `${accessSize} ${accessType} access by ${accessTeamMember} at ${finalLocation}`,
      duration: 3000,
    });

    // Reset dialog state
    setShowIvIoSiteDialog(false);
    setSelectedIvIoSite("");
    setAccessType(null);
    setCustomLocation("");
    setAccessTeamMember("");
    setAccessSize("");
  };

  // Drug handler for adults
  const handleDrugSelect = (drugName: string, dose: string, route: string) => {
    // Check if IV/IO access has been established for IV/IO drugs
    if (route.includes("IV/IO") && !hasIvIoAccess) {
      setShowIvIoRequiredDialog(true);
      if (isAudioEnabled) {
        const utterance = new SpeechSynthesisUtterance("IV IO access must be established before administering drugs");
        utterance.rate = 1.0;
        utterance.volume = 1.0;
        speechSynthesis.speak(utterance);
      }
      return;
    }

    setSelectedDrug({ name: drugName, dose, route });
    setShowDrugConfirmDialog(true);
  };

  // Confirm drug administration
  const handleDrugConfirm = () => {
    if (!selectedDrug || !drugTeamMember) return;

    const now = new Date();
    
    // Log drug intervention with team member information
    logInterventionMutation.mutate({
      type: "DRUG",
      description: `${selectedDrug.name} ${selectedDrug.dose} ${selectedDrug.route} administered by ${drugTeamMember}`,
      details: { 
        drug: selectedDrug.name,
        dose: selectedDrug.dose,
        route: selectedDrug.route,
        administeredBy: drugTeamMember,
        timestamp: now.toISOString()
      }
    });
    
    setShowDrugConfirmDialog(false);
    setSelectedDrug(null);
    setDrugTeamMember("");
    
    // Track adrenaline administration for timer
    if (selectedDrug.name === "Adrenaline") {
      setLastAdrenalineTime(now);
      setAdrenalineCount(prev => prev + 1);
    }
    
    // Generic audio confirmation with team member name
    if (isAudioEnabled) {
      const audioMessage = `Drug Administration Logged by ${drugTeamMember}`;
      const utterance = new SpeechSynthesisUtterance(audioMessage);
      utterance.rate = 1.0;
      utterance.volume = 1.0;
      utterance.pitch = 1.1;
      speechSynthesis.speak(utterance);
    }
    
    toast({
      title: "Drug Administered",
      description: `${selectedDrug.name} ${selectedDrug.dose} administered by ${drugTeamMember}`,
      duration: 3000,
    });
  };

  // Intervention handler - now properly opens confirmation dialog
  // Check if IV/IO access has been logged
  const hasIVIOAccess = () => {
    if (!interventions || !Array.isArray(interventions)) return false;
    return interventions.some((intervention: any) => 
      (intervention.type === 'VASCULAR_ACCESS' || intervention.type === 'ACCESS') && 
      (intervention.description?.includes('IV access') || 
       intervention.description?.includes('IO access'))
    );
  };

  const handleInterventionSelect = (type: string, description: string) => {
    if (!(blsStarted || ilsStarted || alsStarted)) return;
    
    // Check for IV/IO access requirement for adult cardiac arrest drugs (excluding oxygen)
    if (type === 'drug' && description !== 'Oxygen' && !description.includes('Oxygen')) {
      // List of adult cardiac arrest drugs that require IV/IO access
      const requiresIVIO = [
        'Adrenaline', 'Amiodarone', 'Atropine', 'Naloxone', 
        'Glucose 10%', 'Sodium Chloride'
      ];
      
      const drugRequiresAccess = requiresIVIO.some(drug => description.includes(drug));
      
      if (drugRequiresAccess && !hasIVIOAccess()) {
        toast({
          title: "IV/IO Access Required",
          description: "You must log IV Access or IO Access before administering this drug.",
          variant: "destructive",
          duration: 4000,
        });
        return;
      }
    }
    
    // Check for initial rhythm requirement before allowing shocks
    if (type === 'shock') {
      if (!hasInitialRhythm) {
        setShowRhythmRequiredDialog(true);
        return;
      }
      
      // Store pending shock for post-shock rhythm prompt
      setPendingShockType(description);
      
      // Track shock count and prompt for adrenaline after odd-numbered shocks (3rd, 5th, 7th, etc.)
      const newShockCount = shockCount + 1;
      setShockCount(newShockCount);
      
      // Check if adrenaline should be prompted after this shock (3rd, 5th, 7th, 9th etc)
      if (newShockCount >= 3 && newShockCount % 2 === 1) {
        setShowThreeShockPrompt(true);
        
        // Audio prompt for adrenaline after odd shocks
        if (isAudioEnabled) {
          const shockOrdinal = newShockCount === 3 ? '3rd' : 
                               newShockCount === 5 ? '5th' : 
                               newShockCount === 7 ? '7th' : 
                               newShockCount === 9 ? '9th' : `${newShockCount}th`;
          const utterance = new SpeechSynthesisUtterance(`${shockOrdinal} shock delivered - adrenaline due now`);
          utterance.rate = 1.0;
          utterance.volume = 1.0;
          utterance.pitch = 1.1;
          speechSynthesis.speak(utterance);
        }
      }
    }
    
    // Track rhythm logging
    if (description.includes('Rhythm:') || description.includes('VF/VT') || description.includes('Asystole') || description.includes('PEA')) {
      setHasInitialRhythm(true);
    }
    
    // Track adrenaline doses but do NOT start timer here - wait for confirmation
    if (description.includes('Adrenaline')) {
      const newCount = adrenalineCount + 1;
      setAdrenalineCount(newCount);
      // Timer will be started in handleInterventionConfirmation when intervention is confirmed
    }
    
    // Check for IV/IO access and prompt immediate adrenaline for non-shockable rhythms
    if ((description.includes('IV access') || description.includes('IO access')) && 
        alsStarted && adrenalineCount === 0) {
      // Check if we have a non-shockable rhythm logged
      const hasNonShockableRhythm = interventions?.some((intervention: any) => 
        intervention.description?.includes('Asystole') || 
        intervention.description?.includes('PEA')
      );
      
      if (hasNonShockableRhythm) {
        setShowImmediateAdrenalinePrompt(true);
      }
    }

    setPendingIntervention({ type, name: description });
    setShowInterventionDialog(true);
  };

  // EtCO2 monitoring handler
  const handleEtco2Log = () => {
    if (!etco2Value || !sessionId) return;
    
    const co2Value = parseFloat(etco2Value);
    if (isNaN(co2Value) || co2Value < 0) {
      toast({
        title: "Invalid Value",
        description: "Please enter a valid CO2 measurement",
        variant: "destructive",
      });
      return;
    }

    // Convert kPa to mmHg for status determination (1 kPa = 7.5 mmHg)
    const valueInMmHg = etco2Unit === "kPa" ? co2Value * 7.5 : co2Value;
    let status = "Normal";
    
    if (valueInMmHg < 35) {
      status = "Low";
    } else if (valueInMmHg > 40) {
      status = "High";
    }

    logInterventionMutation.mutate({
      type: "ETCO2_READING",
      description: `End Tidal CO2: ${etco2Value} ${etco2Unit} (${status})`,
      details: { 
        value: co2Value,
        unit: etco2Unit,
        status,
        timestamp: new Date().toISOString(),
        protocol: alsStarted ? "ALS" : "ILS"
      }
    });
    
    setShowEtco2Dialog(false);
    setEtco2Value("");
    
    // Audio feedback
    if (isAudioEnabled) {
      const unitSpoken = etco2Unit === "mmHg" ? "millimeters of mercury" : "kilopascals";
      const utterance = new SpeechSynthesisUtterance(`End Tidal CO2 logged: ${etco2Value} ${unitSpoken}, status ${status}`);
      utterance.rate = 1.0;
      utterance.volume = 1.0;
      speechSynthesis.speak(utterance);
    }
    
    toast({
      title: "EtCO2 Logged",
      description: `CO2 reading: ${etco2Value} ${etco2Unit} (${status}) recorded`,
      duration: 3000,
    });
  };

  // Reversible cause handler with clinical readings
  const handleReversibleCauseSelect = (cause: string) => {
    setSelectedReversibleCause(cause);
    setShowReversibleCauseDialog(true);
  };

  // Process reversible cause with clinical reading
  const handleReversibleCauseSubmit = (reading: string) => {
    if (!reading || !selectedReversibleCause) return;

    let isAbnormal = false;
    let normalRange = "";
    let clinicalInterpretation = "";

    // Determine normal ranges and assess readings
    switch (selectedReversibleCause) {
      case 'Hypoxia':
        const spo2 = parseInt(reading);
        isAbnormal = spo2 < 95;
        normalRange = "95-100%";
        clinicalInterpretation = spo2 < 95 ? "CRITICALLY LOW - Immediate oxygen therapy required" : "Normal range";
        break;
      case 'Hypo/Hyperkalaemia':
        const glucose = parseFloat(reading);
        isAbnormal = glucose < 4.0 || glucose > 11.0;
        normalRange = "4.0-11.0 mmol/L";
        clinicalInterpretation = glucose < 4.0 ? "HYPOGLYCEMIC - Consider glucose administration" : 
                               glucose > 11.0 ? "HYPERGLYCEMIC - Monitor ketones" : "Normal range";
        break;
      case 'Hypothermia':
        const temp = parseFloat(reading);
        isAbnormal = temp < 35.0;
        normalRange = "36.0-37.5°C";
        clinicalInterpretation = temp < 35.0 ? "HYPOTHERMIC - Active rewarming required" : 
                               temp < 36.0 ? "Mild hypothermia - Monitor closely" : "Normal range";
        break;
      default:
        isAbnormal = false;
        clinicalInterpretation = "Reading logged";
    }

    // Store the reading and assessment
    setReversibleCauseReadings(prev => ({
      ...prev,
      [selectedReversibleCause]: { reading, isAbnormal }
    }));

    // Log the intervention with clinical details
    logInterventionMutation.mutate({
      type: "REVERSIBLE_CAUSE",
      description: `${selectedReversibleCause} assessed - ${clinicalInterpretation}`,
      details: { 
        cause: selectedReversibleCause,
        reading,
        normalRange,
        isAbnormal,
        interpretation: clinicalInterpretation,
        timestamp: new Date().toISOString(),
        protocol: alsStarted ? "ALS" : (ilsStarted ? "ILS" : "BLS")
      }
    });

    // Add to logged causes
    setLoggedReversibleCauses(prev => new Set(prev.add(selectedReversibleCause)));

    setShowReversibleCauseDialog(false);
    setSelectedReversibleCause("");

    toast({
      title: "Reversible Cause Assessed",
      description: `${selectedReversibleCause}: ${reading} - ${clinicalInterpretation}`,
      duration: 4000,
      variant: isAbnormal ? "destructive" : "default",
    });
  };

  // End session handler
  const handleEndSession = () => {
    if (!sessionOutcome) return;
    
    // Combine session notes with additional notes from the card
    const combinedNotes = [
      sessionNotes,
      additionalNotes && `Additional Notes: ${additionalNotes}`
    ].filter(Boolean).join('\n\n');
    
    endSessionMutation.mutate({
      outcome: sessionOutcome,
      notes: combinedNotes
    });
  };

  // Critical adrenaline timer effect (UK RC Guidelines: every 3-5 minutes)
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (lastAdrenalineTime && alsStarted) {
      interval = setInterval(() => {
        const now = new Date();
        const timeSinceAdrenaline = Math.floor((now.getTime() - lastAdrenalineTime.getTime()) / 1000);
        
        // Calculate countdown to next dose (300 seconds = 5 minutes)
        const timeUntilNext = 300 - (timeSinceAdrenaline % 300);
        setAdrenalineTimer(timeUntilNext);
        
        // 5-minute interval prompts (300, 600, 900 seconds etc)
        if (timeSinceAdrenaline > 0 && timeSinceAdrenaline % 300 === 0 && !showAdrenalinePrompt) {
          setShowAdrenalinePrompt(true);
          if (isAudioEnabled) {
            const utterance = new SpeechSynthesisUtterance("Adrenaline due now - 5 minutes since last dose");
            utterance.rate = 1.0;
            utterance.volume = 1.0;
            utterance.pitch = 1.1;
            speechSynthesis.speak(utterance);
          }
          // Reset prompt after 5 seconds
          setTimeout(() => setShowAdrenalinePrompt(false), 5000);
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [lastAdrenalineTime, alsStarted, showAdrenalinePrompt, isAudioEnabled]);

  if (sessionId && sessionLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <Navigation />
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-purple-600"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navigation />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Session Header */}
        <Card className="mb-8 border-purple-200 bg-purple-50 dark:bg-purple-900/20">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-purple-900 dark:text-purple-100 mb-2">
                  ALS Adult Resus
                </h1>
                {(blsStarted || ilsStarted || alsStarted) && (
                  <p className="text-purple-700 dark:text-purple-300">
                    Resus Started: {(blsStartTime || (session && new Date(session.startTime))).toLocaleString("en-GB", { 
                      year: "numeric",
                      month: "2-digit",
                      day: "2-digit",
                      hour: "2-digit", 
                      minute: "2-digit",
                      second: "2-digit",
                      timeZone: "GMT"
                    })} GMT
                  </p>
                )}
              </div>
              <div className="flex space-x-4">
                <Button
                  variant="outline"
                  onClick={() => setLocation("/")}
                  className="border-blue-300 text-blue-700 hover:bg-blue-100"
                >
                  <Home className="w-4 h-4 mr-2" />
                  Return to Dashboard
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setIsAudioEnabled(!isAudioEnabled)}
                  className="border-purple-300 text-purple-700 hover:bg-purple-100"
                >
                  {isAudioEnabled ? <Volume2 className="w-4 h-4 mr-2" /> : <VolumeX className="w-4 h-4 mr-2" />}
                  {isAudioEnabled ? "Mute" : "Unmute"}
                </Button>
                <Button 
                  onClick={() => setShowEndSessionDialog(true)}
                  disabled={!blsStarted}
                  className={`${
                    blsStarted 
                      ? "bg-red-600 text-white hover:bg-red-700" 
                      : "bg-gray-400 text-gray-200 cursor-not-allowed"
                  }`}
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  End Resuscitation
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Session ID Input - Always visible */}
        <Card className="mb-8 border-orange-200 bg-orange-50 dark:bg-orange-900/20">
            <CardHeader>
              <CardTitle className="flex items-center text-orange-800 dark:text-orange-200">
                <FileText className="w-5 h-5 mr-2" />
                Session Information (Required)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="session-id" className="text-sm font-medium">
                    Enter CAD Number or Patient Initials
                  </Label>
                  <Input
                    id="session-id"
                    type="text"
                    placeholder="e.g., CAD12345 or AB"
                    value={customSessionId}
                    onChange={(e) => {
                      const newValue = e.target.value;
                      setCustomSessionId(newValue);
                      
                      // If we have an active session, save the custom ID
                      if (sessionId && newValue.trim()) {
                        // Debounce the save to avoid too many API calls
                        clearTimeout((window as any).customSessionIdTimeout);
                        (window as any).customSessionIdTimeout = setTimeout(() => {
                          updateCustomSessionIdMutation.mutate(newValue.trim());
                        }, 1000);
                      }
                    }}
                    className="mt-2"
                    maxLength={20}
                  />
                </div>
                <Alert className="border-red-300 bg-red-50 dark:bg-red-900/20">
                  <AlertTriangle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-700 dark:text-red-300 text-sm">
                    <strong>WARNING:</strong> Do not enter patient identifiable details such as full names, NHS numbers, or addresses. Use only CAD numbers or patient initials.
                  </AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>

        {/* Enhanced Team Management - always visible */}
        <div className="mb-8">
          <PreSessionTeamManager 
            onTeamMembersChange={(members) => {
              setLocalTeamMembers(members);
            }}
            initialMembers={teamMembers}
          />
        </div>

        {/* Protocol Start Buttons */}
        {!blsStarted && !ilsStarted && !alsStarted && (
          <Card className="mb-8 border-red-200 bg-red-50 dark:bg-red-900/20">
            <CardContent className="pt-8 pb-8 text-center">
              {validTeamMembers.length === 0 && (
                <Alert className="mb-6 border-amber-300 bg-amber-50 dark:bg-amber-900/20">
                  <AlertTriangle className="h-4 w-4 text-amber-600" />
                  <AlertDescription className="text-amber-700 dark:text-amber-300">
                    You must add at least one team member before starting resuscitation
                  </AlertDescription>
                </Alert>
              )}
              <div className="space-y-4">
                <Button
                  onClick={handleStartBLS}
                  disabled={validTeamMembers.length === 0}
                  size="lg"
                  className={`px-12 py-6 text-xl font-bold shadow-xl transition-all duration-200 w-full ${
                    validTeamMembers.length === 0 
                      ? "bg-gray-400 text-gray-600 cursor-not-allowed"
                      : "bg-purple-600 hover:bg-purple-700 text-white hover:shadow-2xl transform hover:scale-105"
                  }`}
                >
                  <Zap className="w-8 h-8 mr-4 animate-pulse" />
                  START ADULT ALS
                </Button>
              </div>
              <p className="text-purple-600 dark:text-purple-400 mt-2 text-base font-medium">
                Users must work to their level of training and scope of practice
              </p>
            </CardContent>
          </Card>
        )}

        {/* Main Protocol Layout - Standardized Design */}
        <div className="grid grid-cols-1 xl:grid-cols-9 gap-6">
          {/* Left Sidebar - Timer & Metronome */}
          <div className="xl:col-span-3 space-y-6">
            {/* Primary Timer Card */}
            <Card className="medical-card border-blue-200 bg-blue-50 dark:bg-blue-900/20">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center text-lg font-semibold text-blue-800 dark:text-blue-200">
                  <Clock className="w-5 h-5 mr-2" />
                  Resuscitation Timer
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Timer elapsedTime={elapsedTime} />
                
                {/* 2-Minute Countdown Timer */}
                {(blsStarted || ilsStarted || alsStarted) && (
                  <div className="border-t border-blue-300 pt-4">
                    <div className="flex items-center justify-center mb-2">
                      <AlertTriangle className="w-4 h-4 mr-2 text-orange-600" />
                      <span className="font-medium text-orange-700 dark:text-orange-300">2-Minute Timer</span>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-orange-700 dark:text-orange-300 mb-1">
                        {Math.floor(twoMinuteTimer / 60)}:{(twoMinuteTimer % 60).toString().padStart(2, '0')}
                      </div>
                      <p className="text-sm text-orange-600 dark:text-orange-400">
                        Next: Check rhythm & swap
                      </p>
                    </div>
                  </div>
                )}

                {/* ALS Specific Timer - 30-minute warning system */}
                {alsTimerRunning && alsStarted && (
                  <div className="border-t border-purple-300 pt-4">
                    <div className="flex items-center justify-center mb-2">
                      <Zap className="w-4 h-4 mr-2 text-purple-600" />
                      <span className="font-medium text-purple-700 dark:text-purple-300">ALS Protocol Timer</span>
                    </div>
                    <div className="text-center">
                      <div className={`text-3xl font-bold mb-1 ${
                        alsElapsedTime >= 1800 ? 'text-red-600 animate-pulse' : 
                        alsElapsedTime >= 1500 ? 'text-orange-600' : 'text-purple-700 dark:text-purple-300'
                      }`}>
                        {Math.floor(alsElapsedTime / 60)}:{(alsElapsedTime % 60).toString().padStart(2, '0')}
                      </div>
                      <p className="text-sm text-purple-600 dark:text-purple-400">
                        {alsElapsedTime >= 1800 ? 'Consider termination if no ROSC' : 
                         alsElapsedTime >= 1500 ? 'Approaching 30-minute mark' : 'ALS protocol time'}
                      </p>
                    </div>
                  </div>
                )}

                {/* Adrenaline Timer - Only shown when timer is running */}
                {adrenalineTimerRunning && (
                  <div className="border-t border-green-300 pt-4">
                    <div className="flex items-center justify-center mb-2">
                      <Syringe className="w-4 h-4 mr-2 text-green-600" />
                      <span className="font-medium text-green-700 dark:text-green-300">Adrenaline Timer</span>
                    </div>
                    <div className="text-center">
                      <div className={`text-3xl font-bold mb-1 ${
                        adrenalineTimer <= 60 ? 'text-red-600 animate-pulse' : 'text-green-700 dark:text-green-300'
                      }`}>
                        {Math.floor(adrenalineTimer / 60)}:{(adrenalineTimer % 60).toString().padStart(2, '0')}
                      </div>
                      <p className="text-sm text-green-600 dark:text-green-400">
                        {adrenalineTimer <= 60 ? 'ADRENALINE DUE NOW!' : 'Until next adrenaline dose'}
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Metronome Card */}
            <Card className="medical-card border-red-200 bg-red-50 dark:bg-red-900/20">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center text-lg font-semibold text-red-800 dark:text-red-200">
                  <Heart className="w-5 h-5 mr-2" />
                  CPR Metronome 
                  {(blsStarted || ilsStarted || alsStarted) && !lucasActive && (
                    <Badge className={`ml-2 ${
                      currentBpm === 120 ? 'bg-green-600' : 
                      currentBpm === 110 ? 'bg-orange-600' : 
                      'bg-red-600'
                    }`}>
                      {currentBpm} BPM
                    </Badge>
                  )}
                  {lucasActive && (
                    <Badge className="ml-2 bg-purple-600">
                      LUCAS Device Active
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {(blsStarted || ilsStarted || alsStarted) ? (
                  <div className="space-y-4">
                    {lucasActive ? (
                      <div className="text-center py-8">
                        <Activity className="w-12 h-12 mx-auto mb-4 text-purple-600" />
                        <p className="text-purple-700 dark:text-purple-300 font-semibold">
                          LUCAS device in use by {lucasOperator}
                        </p>
                        <p className="text-sm text-purple-600 dark:text-purple-400 mt-2">
                          Mechanical compressions active
                        </p>
                        <Button
                          onClick={() => {
                            setLucasActive(false);
                            setMetronomeEnabled(true);
                            
                            // Log intervention for stopping LUCAS
                            logInterventionMutation.mutate({
                              type: "LUCAS_DEVICE",
                              description: `LUCAS device stopped - Resumed manual CPR`,
                              details: { 
                                operator: lucasOperator,
                                action: "stopped",
                                resumedManualCPR: true,
                                timestamp: new Date().toISOString()
                              }
                            });

                            toast({
                              title: "LUCAS Device Stopped",
                              description: "Manual CPR resumed - Metronome reactivated",
                              duration: 3000,
                            });

                            setLucasOperator("");
                          }}
                          className="mt-4 bg-red-600 hover:bg-red-700 text-white"
                          size="sm"
                        >
                          Stop LUCAS & Resume Manual CPR
                        </Button>
                      </div>
                    ) : (
                      <Metronome 
                        isEnabled={metronomeEnabled && isAudioEnabled && !lucasActive}
                        onBeatChange={(beat) => {
                          if (beat && metronomeEnabled && isAudioEnabled && !lucasActive) {
                            document.body.style.backgroundColor = "rgba(239, 68, 68, 0.1)";
                            setTimeout(() => {
                              document.body.style.backgroundColor = "";
                            }, 100);
                          }
                        }}
                        onBpmChange={(bpm) => {
                          setCurrentBpm(bpm);
                        }}
                      />
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    <Heart className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Metronome starts when ALS begins</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* EtCO2 Monitoring Card */}
            <Card className="medical-card border-blue-200 bg-blue-50 dark:bg-blue-900/20">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center text-lg font-semibold text-blue-800 dark:text-blue-200">
                  <Activity className="w-5 h-5 mr-2" />
                  EtCO2 Monitoring
                  <Badge variant="secondary" className="ml-2 bg-blue-200 text-blue-800 text-xs">
                    35-40 mmHg Normal
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {(ilsStarted || alsStarted) ? (
                  <div className="space-y-4">
                    <Button
                      onClick={() => setShowEtco2Dialog(true)}
                      variant="outline"
                      className="w-full border-blue-300 text-blue-700 hover:bg-blue-100 dark:hover:bg-blue-900/30"
                    >
                      <Activity className="w-4 h-4 mr-2" />
                      Log CO2 Reading
                    </Button>
                    <div className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
                      <p><strong>Normal Range:</strong> 35-40 mmHg or 4.0-5.7 kPa</p>
                      <p><strong>Low CO2 (&lt;35):</strong> Check tube position</p>
                      <p><strong>High CO2 (&gt;40):</strong> Consider circulation</p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    <Activity className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>EtCO2 monitoring available in ILS/ALS</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Center Content - Main Protocol Actions */}
          <div className="xl:col-span-6 space-y-6">
            {/* Emergency Interventions Card */}
            <Card className={`medical-card ${
              (blsStarted || ilsStarted || alsStarted)
                ? "border-green-200 bg-green-50 dark:bg-green-900/20"
                : "border-gray-200 bg-gray-50 dark:bg-gray-900/20"
            }`}>
              <CardHeader className="pb-3">
                <CardTitle className={`flex items-center text-lg font-semibold ${
                  (blsStarted || ilsStarted || alsStarted)
                    ? "text-green-800 dark:text-green-200"
                    : "text-gray-500 dark:text-gray-400"
                }`}>
                  <Activity className="w-5 h-5 mr-2" />
                  Emergency Interventions
                  {!(blsStarted || ilsStarted || alsStarted) && (
                    <Badge variant="secondary" className="ml-2 bg-gray-200 text-gray-600 text-xs">
                      Available after protocol start
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Record Airway Intervention */}
                <div className="space-y-2">
                  <label className={`text-sm font-medium ${
                    (blsStarted || ilsStarted || alsStarted)
                      ? "text-green-700 dark:text-green-300"
                      : "text-gray-500 dark:text-gray-400"
                  }`}>
                    Record Airway Intervention
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      onClick={() => handleAirwayIntervention('OP Airway')}
                      variant="outline"
                      disabled={!(blsStarted || ilsStarted || alsStarted)}
                      className={
                        (blsStarted || ilsStarted || alsStarted)
                          ? "border-green-300 text-green-700 hover:bg-green-100 dark:hover:bg-green-900/30"
                          : "border-gray-300 text-gray-500 cursor-not-allowed"
                      }
                    >
                      OP Airway
                    </Button>
                    <Button
                      onClick={() => handleAirwayIntervention('NP Airway')}
                      variant="outline"
                      disabled={!(blsStarted || ilsStarted || alsStarted)}
                      className={
                        (blsStarted || ilsStarted || alsStarted)
                          ? "border-green-300 text-green-700 hover:bg-green-100 dark:hover:bg-green-900/30"
                          : "border-gray-300 text-gray-500 cursor-not-allowed"
                      }
                    >
                      NP Airway
                    </Button>
                    <Button
                      onClick={() => handleAirwayIntervention('iGel Airway')}
                      variant="outline"
                      disabled={!(blsStarted || ilsStarted || alsStarted)}
                      className={
                        (blsStarted || ilsStarted || alsStarted)
                          ? "border-green-300 text-green-700 hover:bg-green-100 dark:hover:bg-green-900/30"
                          : "border-gray-300 text-gray-500 cursor-not-allowed"
                      }
                    >
                      iGel Airway
                    </Button>
                  </div>
                </div>

                {/* Advanced Airway Interventions - ALS Level */}
                <div className="space-y-2">
                  <label className={`text-sm font-medium ${
                    (blsStarted || ilsStarted || alsStarted)
                      ? "text-purple-700 dark:text-purple-300"
                      : "text-gray-500 dark:text-gray-400"
                  }`}>
                    Advanced Airway
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      onClick={() => handleAirwayIntervention('Endotracheal Intubation')}
                      variant="outline"
                      disabled={!(blsStarted || ilsStarted || alsStarted)}
                      className={
                        (blsStarted || ilsStarted || alsStarted)
                          ? "border-purple-300 text-purple-700 hover:bg-purple-100 dark:hover:bg-purple-900/30"
                          : "border-gray-300 text-gray-500 cursor-not-allowed"
                      }
                    >
                      <Stethoscope className="w-4 h-4 mr-2" />
                      Endotracheal Intubation
                    </Button>
                    <Button
                      onClick={() => handleAirwayIntervention('Needle Cricothyroidotomy')}
                      variant="outline"
                      disabled={!(blsStarted || ilsStarted || alsStarted)}
                      className={
                        (blsStarted || ilsStarted || alsStarted)
                          ? "border-red-300 text-red-700 hover:bg-red-100 dark:hover:bg-red-900/30"
                          : "border-gray-300 text-gray-500 cursor-not-allowed"
                      }
                    >
                      <Syringe className="w-4 h-4 mr-2" />
                      Needle Cricothyroidotomy
                    </Button>
                  </div>
                </div>

                {/* Vascular Access - ALS specific */}
                <div className="space-y-2">
                  <label className={`text-sm font-medium ${
                    (blsStarted || ilsStarted || alsStarted)
                      ? "text-green-700 dark:text-green-300"
                      : "text-gray-500 dark:text-gray-400"
                  }`}>
                    Vascular Access
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      onClick={() => (blsStarted || ilsStarted || alsStarted) && handleSpecificAccess('IV')}
                      variant="outline"
                      disabled={!(blsStarted || ilsStarted || alsStarted)}
                      className={
                        (blsStarted || ilsStarted || alsStarted)
                          ? "border-blue-300 text-blue-700 hover:bg-blue-100 dark:hover:bg-blue-900/30"
                          : "border-gray-300 text-gray-500 cursor-not-allowed"
                      }
                    >
                      <Activity className="w-4 h-4 mr-2" />
                      IV Access
                    </Button>
                    <Button
                      onClick={() => (blsStarted || ilsStarted || alsStarted) && handleSpecificAccess('IO')}
                      variant="outline"
                      disabled={!(blsStarted || ilsStarted || alsStarted)}
                      className={
                        (blsStarted || ilsStarted || alsStarted)
                          ? "border-purple-300 text-purple-700 hover:bg-purple-100 dark:hover:bg-purple-900/30"
                          : "border-gray-300 text-gray-500 cursor-not-allowed"
                      }
                    >
                      <Activity className="w-4 h-4 mr-2" />
                      IO Access
                    </Button>
                  </div>
                </div>

                {/* Record Drug Intervention - Adult Cardiac Arrest Drugs */}
                <div className="space-y-2">
                  <label className={`text-sm font-medium ${
                    (blsStarted || ilsStarted || alsStarted)
                      ? "text-green-700 dark:text-green-300"
                      : "text-gray-500 dark:text-gray-400"
                  }`}>
                    Record Drug Intervention
                  </label>
                  <div className="space-y-2">
                    {/* Basic Intervention */}
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('drug', 'Oxygen 15ltr/min')}
                        variant="outline"
                        disabled={!(blsStarted || ilsStarted || alsStarted)}
                        className={
                          (blsStarted || ilsStarted || alsStarted)
                            ? "border-green-300 text-green-700 hover:bg-green-100 dark:hover:bg-green-900/30"
                            : "border-gray-300 text-gray-500 cursor-not-allowed"
                        }
                      >
                        <Pill className="w-4 h-4 mr-2" />
                        Oxygen 15ltr/min
                      </Button>
                    </div>

                    {/* Adult Cardiac Arrest Drugs */}
                    <div className="text-xs text-green-600 dark:text-green-400 font-medium mt-3 mb-2">
                      Adult Cardiac Arrest Drugs:
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('drug', 'Adrenaline 1mg (IV/IO)')}
                        variant="outline"
                        disabled={!(blsStarted || ilsStarted || alsStarted)}
                        className={
                          (blsStarted || ilsStarted || alsStarted)
                            ? "border-red-300 text-red-700 hover:bg-red-100 dark:hover:bg-red-900/30 text-xs"
                            : "border-gray-300 text-gray-500 cursor-not-allowed text-xs"
                        }
                      >
                        <div className="text-left">
                          <div>Adrenaline 1mg</div>
                          {!(blsStarted || ilsStarted || alsStarted) && (
                            <div className="text-xs">(IV/IO required)</div>
                          )}
                          {adrenalineTimer > 0 && (
                            <div className="text-xs">
                              ({Math.floor(adrenalineTimer / 60)}:{(adrenalineTimer % 60).toString().padStart(2, '0')})
                            </div>
                          )}
                        </div>
                      </Button>
                      <Button
                        onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('drug', 'Amiodarone 300mg (IV/IO)')}
                        variant="outline"
                        disabled={!(blsStarted || ilsStarted || alsStarted)}
                        className={
                          (blsStarted || ilsStarted || alsStarted)
                            ? "border-purple-300 text-purple-700 hover:bg-purple-100 dark:hover:bg-purple-900/30 text-xs"
                            : "border-gray-300 text-gray-500 cursor-not-allowed text-xs"
                        }
                      >
                        Amiodarone 300mg {!(blsStarted || ilsStarted || alsStarted) ? "(IV/IO required)" : ""}
                      </Button>
                      <Button
                        onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('drug', 'Atropine 3mg (IV/IO)')}
                        variant="outline"
                        disabled={!(blsStarted || ilsStarted || alsStarted)}
                        className={
                          (blsStarted || ilsStarted || alsStarted)
                            ? "border-blue-300 text-blue-700 hover:bg-blue-100 dark:hover:bg-blue-900/30 text-xs"
                            : "border-gray-300 text-gray-500 cursor-not-allowed text-xs"
                        }
                      >
                        Atropine 3mg {!(blsStarted || ilsStarted || alsStarted) ? "(IV/IO required)" : ""}
                      </Button>
                      <Button
                        onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('drug', 'Naloxone 400mcg (IV/IO/IM)')}
                        variant="outline"
                        disabled={!(blsStarted || ilsStarted || alsStarted)}
                        className={
                          (blsStarted || ilsStarted || alsStarted)
                            ? "border-orange-300 text-orange-700 hover:bg-orange-100 dark:hover:bg-orange-900/30 text-xs"
                            : "border-gray-300 text-gray-500 cursor-not-allowed text-xs"
                        }
                      >
                        Naloxone 400mcg
                      </Button>
                      <Button
                        onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('drug', 'Glucose 10% 250ml (IV)')}
                        variant="outline"
                        disabled={!(blsStarted || ilsStarted || alsStarted)}
                        className={
                          (blsStarted || ilsStarted || alsStarted)
                            ? "border-yellow-300 text-yellow-700 hover:bg-yellow-100 dark:hover:bg-yellow-900/30 text-xs"
                            : "border-gray-300 text-gray-500 cursor-not-allowed text-xs"
                        }
                      >
                        Glucose 10% 250ml {!(blsStarted || ilsStarted || alsStarted) ? "(IV required)" : ""}
                      </Button>
                      <Button
                        onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('drug', 'Sodium Chloride 0.9% 500ml (IV)')}
                        variant="outline"
                        disabled={!(blsStarted || ilsStarted || alsStarted)}
                        className={
                          (blsStarted || ilsStarted || alsStarted)
                            ? "border-cyan-300 text-cyan-700 hover:bg-cyan-100 dark:hover:bg-cyan-900/30 text-xs"
                            : "border-gray-300 text-gray-500 cursor-not-allowed text-xs"
                        }
                      >
                        NaCl 0.9% 500ml {!(blsStarted || ilsStarted || alsStarted) ? "(IV required)" : ""}
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Record Shock Delivery */}
                <div className="space-y-2">
                  <label className={`text-sm font-medium ${
                    (blsStarted || ilsStarted || alsStarted)
                      ? "text-green-700 dark:text-green-300"
                      : "text-gray-500 dark:text-gray-400"
                  }`}>
                    Record Shock Delivery
                  </label>
                  <div className="grid grid-cols-1 gap-2">
                    <Button
                      onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('shock', 'Shock Delivered')}
                      variant="outline"
                      disabled={!(blsStarted || ilsStarted || alsStarted)}
                      className={
                        (blsStarted || ilsStarted || alsStarted)
                          ? "border-yellow-300 text-yellow-700 hover:bg-yellow-100 dark:hover:bg-yellow-900/30"
                          : "border-gray-300 text-gray-500 cursor-not-allowed"
                      }
                    >
                      <Zap className="w-4 h-4 mr-2" />
                      Shock Delivered
                    </Button>
                  </div>
                </div>

                {/* LUCAS Device - ALS Only */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-purple-700 dark:text-purple-300">
                    LUCAS Device (ALS)
                  </label>
                  <div className="grid grid-cols-1 gap-2">
                    <Button
                      onClick={() => setShowLucasConfirmDialog(true)}
                      variant="outline"
                      disabled={lucasActive || !(blsStarted || ilsStarted || alsStarted)}
                      className={
                        lucasActive || !(blsStarted || ilsStarted || alsStarted)
                          ? "border-gray-300 text-gray-500 cursor-not-allowed"
                          : "border-purple-300 text-purple-700 hover:bg-purple-100 dark:hover:bg-purple-900/30"
                      }
                    >
                      <Activity className="w-4 h-4 mr-2" />
                      {lucasActive ? "LUCAS Device Active" : "Deploy LUCAS Device"}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Sidebar - Removed duplicate intervention log */}
          <div className="xl:col-span-3 space-y-6">

            {/* Rhythm Analysis Card - Always visible but greyed out until session starts */}
            <Card className={`medical-card ${
              (blsStarted || ilsStarted || alsStarted)
                ? "border-blue-200 bg-blue-50 dark:bg-blue-900/20"
                : "border-gray-200 bg-gray-50 dark:bg-gray-900/20 opacity-60"
            }`}>
              <CardHeader className="pb-3">
                <CardTitle className={`flex items-center text-lg font-semibold ${
                  (blsStarted || ilsStarted || alsStarted)
                    ? "text-blue-800 dark:text-blue-200"
                    : "text-gray-500 dark:text-gray-400"
                }`}>
                  <Activity className="w-5 h-5 mr-2" />
                  Rhythm Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {/* Shockable Rhythms */}
                  <div>
                    <h4 className={`text-sm font-semibold mb-2 ${
                      (blsStarted || ilsStarted || alsStarted)
                        ? "text-red-700 dark:text-red-300"
                        : "text-gray-500 dark:text-gray-400"
                    }`}>
                      Shockable Rhythms
                    </h4>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('rhythm', 'VF (Ventricular Fibrillation)')}
                        variant="outline"
                        disabled={!(blsStarted || ilsStarted || alsStarted)}
                        className={
                          (blsStarted || ilsStarted || alsStarted)
                            ? "border-red-300 text-red-700 hover:bg-red-100 dark:hover:bg-red-900/30 text-xs"
                            : "border-gray-300 text-gray-500 cursor-not-allowed text-xs"
                        }
                      >
                        <Zap className="w-4 h-4 mr-1" />
                        VF
                      </Button>
                      <Button
                        onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('rhythm', 'VT (Ventricular Tachycardia)')}
                        variant="outline"
                        disabled={!(blsStarted || ilsStarted || alsStarted)}
                        className={
                          (blsStarted || ilsStarted || alsStarted)
                            ? "border-red-300 text-red-700 hover:bg-red-100 dark:hover:bg-red-900/30 text-xs"
                            : "border-gray-300 text-gray-500 cursor-not-allowed text-xs"
                        }
                      >
                        <Zap className="w-4 h-4 mr-1" />
                        VT
                      </Button>
                    </div>
                  </div>

                  {/* Non-Shockable Rhythms */}
                  <div>
                    <h4 className={`text-sm font-semibold mb-2 ${
                      (blsStarted || ilsStarted || alsStarted)
                        ? "text-blue-700 dark:text-blue-300"
                        : "text-gray-500 dark:text-gray-400"
                    }`}>
                      Non-Shockable Rhythms
                    </h4>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('rhythm', 'PEA (Pulseless Electrical Activity)')}
                        variant="outline"
                        disabled={!(blsStarted || ilsStarted || alsStarted)}
                        className={
                          (blsStarted || ilsStarted || alsStarted)
                            ? "border-blue-300 text-blue-700 hover:bg-blue-100 dark:hover:bg-blue-900/30 text-xs"
                            : "border-gray-300 text-gray-500 cursor-not-allowed text-xs"
                        }
                      >
                        <Heart className="w-4 h-4 mr-1" />
                        PEA
                      </Button>
                      <Button
                        onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('rhythm', 'Asystole')}
                        variant="outline"
                        disabled={!(blsStarted || ilsStarted || alsStarted)}
                        className={
                          (blsStarted || ilsStarted || alsStarted)
                            ? "border-blue-300 text-blue-700 hover:bg-blue-100 dark:hover:bg-blue-900/30 text-xs"
                            : "border-gray-300 text-gray-500 cursor-not-allowed text-xs"
                        }
                      >
                        <Heart className="w-4 h-4 mr-1" />
                        Asystole
                      </Button>
                    </div>
                  </div>


                </div>
              </CardContent>
            </Card>

            {/* Reversible Causes Checklist - Always visible but greyed out until session starts */}
            <Card className={`medical-card ${
              (blsStarted || ilsStarted || alsStarted)
                ? "border-red-200 bg-red-50 dark:bg-red-900/20"
                : "border-gray-200 bg-gray-50 dark:bg-gray-900/20 opacity-60"
            }`}>
              <CardHeader className="pb-3">
                <CardTitle className={`flex items-center text-lg font-semibold ${
                  (blsStarted || ilsStarted || alsStarted)
                    ? "text-red-800 dark:text-red-200"
                    : "text-gray-500 dark:text-gray-400"
                }`}>
                  <AlertTriangle className="w-5 h-5 mr-2" />
                  Reversible Causes (4 Hs & 4 Ts)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className={`font-semibold mb-2 ${
                      (blsStarted || ilsStarted || alsStarted)
                        ? "text-red-700 dark:text-red-300"
                        : "text-gray-500 dark:text-gray-400"
                    }`}>4 Hs</h4>
                    <div className="space-y-2">
                      {['Hypoxia', 'Hypovolaemia', 'Hypo/Hyperkalaemia', 'Hypothermia'].map((cause) => (
                        <Button
                          key={cause}
                          variant="outline"
                          size="sm"
                          onClick={() => (blsStarted || ilsStarted || alsStarted) && handleReversibleCauseSelect(cause)}
                          disabled={!(blsStarted || ilsStarted || alsStarted)}
                          className={`w-full text-left justify-start ${
                            loggedReversibleCauses.has(cause)
                              ? reversibleCauseReadings[cause]?.isAbnormal
                                ? "border-red-400 bg-red-100 text-red-800 hover:bg-red-200 dark:bg-red-900/30 dark:text-red-300 dark:border-red-600 shadow-md ring-2 ring-red-300"
                                : "border-green-400 bg-green-100 text-green-800 hover:bg-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-600"
                              : (blsStarted || ilsStarted || alsStarted)
                              ? "border-red-300 text-red-700 hover:bg-red-100 dark:hover:bg-red-900/30"
                              : "border-gray-300 text-gray-500 cursor-not-allowed"
                          }`}
                        >
                          {cause}
                          {loggedReversibleCauses.has(cause) && reversibleCauseReadings[cause] && (
                            <span className="ml-1 text-xs">
                              ({reversibleCauseReadings[cause].reading})
                            </span>
                          )}
                        </Button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className={`font-semibold mb-2 ${
                      (blsStarted || ilsStarted || alsStarted)
                        ? "text-red-700 dark:text-red-300"
                        : "text-gray-500 dark:text-gray-400"
                    }`}>4 Ts</h4>
                    <div className="space-y-2">
                      {['Thrombosis', 'Tension Pneumothorax', 'Tamponade', 'Toxins'].map((cause) => (
                        <Button
                          key={cause}
                          variant="outline"
                          size="sm"
                          onClick={() => (blsStarted || ilsStarted || alsStarted) && handleInterventionSelect('reversible_cause', cause)}
                          disabled={!(blsStarted || ilsStarted || alsStarted)}
                          className={`w-full text-left justify-start ${
                            loggedReversibleCauses.has(cause)
                              ? "border-green-400 bg-green-100 text-green-800 hover:bg-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-600"
                              : (blsStarted || ilsStarted || alsStarted)
                              ? "border-red-300 text-red-700 hover:bg-red-100 dark:hover:bg-red-900/30"
                              : "border-gray-300 text-gray-500 cursor-not-allowed"
                          }`}
                        >
                          {cause}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Intervention Log at Bottom */}
        <div className="mt-8">
          <Card className="medical-card border-purple-200 bg-purple-50 dark:bg-purple-900/20">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center text-lg font-semibold text-purple-800 dark:text-purple-200">
                <FileText className="w-5 h-5 mr-2" />
                Intervention Log
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {validInterventions.length > 0 ? (
                  validInterventions.slice(0, 15).map((intervention: any) => (
                    <div key={intervention.id} className="p-3 bg-white dark:bg-gray-800 rounded-lg border border-purple-200 dark:border-purple-700 shadow-sm">
                      <div className="font-medium text-gray-900 dark:text-gray-100 text-sm mb-1">
                        {intervention.description || 'No description available'}
                      </div>
                      <div className="text-xs text-gray-500 dark:text-gray-400 space-y-1">
                        <div className="flex justify-between items-start">
                          <span className="font-medium text-purple-700 dark:text-purple-300">
                            {intervention.type || 'Unknown'}
                          </span>
                          <span className="text-right">
                            {(() => {
                              try {
                                // First try to show actual timestamp
                                if (intervention.timestamp) {
                                  const interventionTime = new Date(intervention.timestamp);
                                  const timeString = interventionTime.toLocaleTimeString('en-GB', {
                                    hour: '2-digit',
                                    minute: '2-digit',
                                    second: '2-digit'
                                  });
                                  
                                  // Also calculate elapsed time if session start time is available
                                  if (session?.startTime) {
                                    const start = new Date(session.startTime);
                                    const diffMs = interventionTime.getTime() - start.getTime();
                                    const diffMinutes = Math.floor(diffMs / 60000);
                                    const diffSeconds = Math.floor((diffMs % 60000) / 1000);
                                    return `${timeString} (T+${diffMinutes}:${diffSeconds.toString().padStart(2, '0')})`;
                                  }
                                  
                                  return timeString;
                                }
                                return 'No time';
                              } catch (e) {
                                return 'Invalid time';
                              }
                            })()}
                          </span>
                        </div>
                        {intervention.details && (
                          <div className="text-gray-600 dark:text-gray-300 mt-1">
                            {(() => {
                              try {
                                const details = typeof intervention.details === 'string' 
                                  ? JSON.parse(intervention.details) 
                                  : intervention.details;
                                return Object.entries(details)
                                  .filter(([key, value]) => value && key !== 'sessionId')
                                  .map(([key, value]) => (
                                    <div key={key} className="text-xs">
                                      <span className="font-medium capitalize">{key}:</span> {String(value)}
                                    </div>
                                  ));
                              } catch (e) {
                                return null;
                              }
                            })()}
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <FileText className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                    <p className="text-sm text-gray-500 dark:text-gray-400">No interventions logged yet</p>
                    <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">Start the protocol to begin logging interventions</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Additional Notes Card */}
          <Card className="border-2 border-blue-200 bg-blue-50 dark:bg-blue-900/20 dark:border-blue-800">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center text-blue-700 dark:text-blue-300">
                <FileText className="w-5 h-5 mr-2" />
                Additional Notes
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-blue-700 dark:text-blue-300">
                  Notes for Summary Report
                </label>
                <textarea
                  value={additionalNotes}
                  onChange={(e) => setAdditionalNotes(e.target.value)}
                  placeholder="Add any additional notes about the resuscitation (clinical observations, team performance, equipment issues, etc.)"
                  className="w-full p-3 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 dark:border-blue-600"
                  rows={4}
                />
                <p className="text-xs text-blue-600 dark:text-blue-400">
                  These notes will be included in the final summary report
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* End Resus Button */}
        <div className="mt-6 text-center">
          <Button
            onClick={() => setShowEndSessionDialog(true)}
            disabled={!sessionId}
            size="lg"
            className={`px-12 py-4 text-lg font-bold shadow-xl transition-all duration-200 ${
              sessionId
                ? "bg-red-600 hover:bg-red-700 text-white hover:shadow-2xl transform hover:scale-105"
                : "bg-gray-400 text-gray-600 cursor-not-allowed"
            }`}
          >
            <XCircle className="w-6 h-6 mr-3" />
            END RESUSCITATION
          </Button>
        </div>

        {/* 2-minute timer prompt */}
        {showTwoMinutePrompt && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <Card className="w-96 border-red-200 bg-red-50 dark:bg-red-900/20">
              <CardContent className="pt-8 pb-8 text-center">
                <div className="text-6xl mb-4">⏰</div>
                <h3 className="text-xl font-bold text-red-700 dark:text-red-300 mb-2">
                  2 Minutes Elapsed
                </h3>
                <p className="text-red-600 dark:text-red-400 mb-6">
                  Check pulse and rhythm
                </p>
                <Button
                  onClick={() => {
                    setShowTwoMinutePrompt(false);
                    setTwoMinuteTimer(120);
                  }}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  Continue ALS
                </Button>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Intervention Confirmation Popup */}
        {showInterventionConfirm && (
          <div className="fixed top-4 right-4 z-50">
            <Card className="border-green-200 bg-green-50 dark:bg-green-900/20">
              <CardContent className="pt-4 pb-4">
                <div className="flex items-center">
                  <CheckCircle className="w-5 h-5 mr-2 text-green-600" />
                  <span className="text-green-700 dark:text-green-300 font-medium">
                    {confirmationMessage}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* IV/IO Site Selection Dialog */}
        <Dialog open={showIvIoSiteDialog} onOpenChange={setShowIvIoSiteDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Establish {accessType} Access</DialogTitle>
              <DialogDescription>
                Record details for {accessType} access establishment.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              {/* Team Member Selection */}
              <div>
                <label className="text-sm font-medium mb-2 block">Team Member</label>
                <Select value={accessTeamMember} onValueChange={setAccessTeamMember}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select team member" />
                  </SelectTrigger>
                  <SelectContent>
                    {validTeamMembers.map((member, index) => (
                      <SelectItem key={index} value={member.name}>
                        {member.name} ({member.role})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Gauge/Size Selection */}
              <div>
                <label className="text-sm font-medium mb-2 block">
                  {accessType === 'IV' ? 'Cannula Size' : 'Needle Size'}
                </label>
                <Select value={accessSize} onValueChange={setAccessSize}>
                  <SelectTrigger>
                    <SelectValue placeholder={`Select ${accessType === 'IV' ? 'cannula' : 'needle'} size`} />
                  </SelectTrigger>
                  <SelectContent>
                    {accessType === 'IV' ? (
                      <>
                        <SelectItem value="14G">14G (Orange)</SelectItem>
                        <SelectItem value="16G">16G (Grey)</SelectItem>
                        <SelectItem value="18G">18G (Green)</SelectItem>
                        <SelectItem value="20G">20G (Pink)</SelectItem>
                        <SelectItem value="22G">22G (Blue)</SelectItem>
                        <SelectItem value="24G">24G (Yellow)</SelectItem>
                      </>
                    ) : (
                      <>
                        <SelectItem value="15G">15G (Adult/Large)</SelectItem>
                        <SelectItem value="18G">18G (Adult/Standard)</SelectItem>
                        <SelectItem value="20G">20G (Pediatric)</SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
              </div>

              {/* Site Selection */}
              <div>
                <label className="text-sm font-medium mb-2 block">Access Site</label>
                <Select value={selectedIvIoSite} onValueChange={setSelectedIvIoSite}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select access site" />
                  </SelectTrigger>
                  <SelectContent>
                  {accessType === 'IV' ? (
                    <>
                      <SelectItem value="Left Antecubital Fossa">Left Antecubital Fossa</SelectItem>
                      <SelectItem value="Right Antecubital Fossa">Right Antecubital Fossa</SelectItem>
                      <SelectItem value="Left Hand">Left Hand</SelectItem>
                      <SelectItem value="Right Hand">Right Hand</SelectItem>
                      <SelectItem value="Left Forearm">Left Forearm</SelectItem>
                      <SelectItem value="Right Forearm">Right Forearm</SelectItem>
                      <SelectItem value="External Jugular">External Jugular</SelectItem>
                      <SelectItem value="Other Location">Other Location</SelectItem>
                    </>
                  ) : (
                    <>
                      <SelectItem value="Proximal Tibia">Proximal Tibia</SelectItem>
                      <SelectItem value="Distal Tibia">Distal Tibia</SelectItem>
                      <SelectItem value="Proximal Humerus">Proximal Humerus</SelectItem>
                      <SelectItem value="Distal Radius">Distal Radius</SelectItem>
                      <SelectItem value="Sternum">Sternum</SelectItem>
                      <SelectItem value="Other Location">Other Location</SelectItem>
                    </>
                  )}
                  </SelectContent>
                </Select>
              </div>
              
              {selectedIvIoSite === "Other Location" && (
                <div>
                  <label className="text-sm font-medium mb-2 block">Specify Location</label>
                  <input
                    type="text"
                    value={customLocation}
                    onChange={(e) => setCustomLocation(e.target.value)}
                    placeholder="Enter custom location..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowIvIoSiteDialog(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleAccessConfirm} 
                disabled={!accessTeamMember || !accessSize || !selectedIvIoSite || (selectedIvIoSite === "Other Location" && !customLocation)}
              >
                Confirm {accessType} Access
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Drug Confirmation Dialog */}
        <Dialog open={showDrugConfirmDialog} onOpenChange={setShowDrugConfirmDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Drug Administration</DialogTitle>
              <DialogDescription>
                Please confirm the administration of this medication.
              </DialogDescription>
            </DialogHeader>
            {selectedDrug && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-600">Drug</label>
                    <p className="text-lg font-semibold">{selectedDrug.name}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Dose</label>
                    <p className="text-lg font-semibold">{selectedDrug.dose}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Route</label>
                    <p className="text-lg font-semibold">{selectedDrug.route}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Time</label>
                    <p className="text-lg font-semibold">{new Date().toLocaleTimeString('en-GB')}</p>
                  </div>
                </div>
                
                {/* Team Member Selection */}
                <div>
                  <label className="text-sm font-medium text-gray-600 mb-2 block">Administered By</label>
                  <Select value={drugTeamMember} onValueChange={setDrugTeamMember}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select team member" />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.isArray(sessionTeamMembers) && sessionTeamMembers.map((member: any) => (
                        <SelectItem key={member.id} value={member.name}>
                          {member.name} ({member.role})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowDrugConfirmDialog(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleDrugConfirm} 
                disabled={!drugTeamMember}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                Confirm Administration
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* IV/IO Required Warning Dialog */}
        <Dialog open={showIvIoRequiredDialog} onOpenChange={setShowIvIoRequiredDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>IV/IO Access Required</DialogTitle>
              <DialogDescription>
                IV or IO access must be established before administering this medication.
              </DialogDescription>
            </DialogHeader>
            <div className="text-center py-4">
              <AlertTriangle className="w-16 h-16 mx-auto mb-4 text-amber-500" />
              <p className="text-gray-600">
                Please establish vascular access first using the IV Access or IO Access buttons.
              </p>
            </div>
            <DialogFooter>
              <Button onClick={() => setShowIvIoRequiredDialog(false)}>
                Understood
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Critical Adrenaline Timer Dialog - UK RC Guidelines */}
        <Dialog open={showAdrenalinePrompt} onOpenChange={setShowAdrenalinePrompt}>
          <DialogContent className="border-red-300 bg-red-50">
            <DialogHeader>
              <DialogTitle className="text-red-800 flex items-center">
                <AlertTriangle className="w-6 h-6 mr-2" />
                ADRENALINE DUE
              </DialogTitle>
              <DialogDescription className="text-red-700">
                UK RC Guidelines: Adrenaline should be administered every 3-5 minutes during CPR
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-white p-4 rounded border border-red-200">
                <p className="font-semibold text-red-800">
                  {adrenalineCount === 0 ? "First adrenaline dose due" : `Adrenaline dose ${adrenalineCount + 1} due`}
                </p>
                <p className="text-sm text-red-600 mt-1">
                  Adult dose: 1mg IV/IO (10ml of 1:10,000)
                </p>
                {lastAdrenalineTime && (
                  <p className="text-xs text-gray-600 mt-2">
                    Last dose: {lastAdrenalineTime.toLocaleTimeString('en-GB')}
                  </p>
                )}
              </div>
            </div>
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => setShowAdrenalinePrompt(false)}
                className="border-gray-300"
              >
                Remind Later
              </Button>
              <Button 
                onClick={() => {
                  setShowAdrenalinePrompt(false);
                  // Auto-fill adrenaline in drug calculator
                  handleDrugSelect("Adrenaline");
                }}
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                Give Adrenaline Now
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* EtCO2 Monitoring Dialog */}
        <Dialog open={showEtco2Dialog} onOpenChange={setShowEtco2Dialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Log EtCO2 Reading</DialogTitle>
              <DialogDescription>
                Enter the End Tidal CO2 measurement. Normal range is 35-40 mmHg or 4.0-5.7 kPa.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">CO2 Value</label>
                  <input
                    type="number"
                    value={etco2Value}
                    onChange={(e) => setEtco2Value(e.target.value)}
                    placeholder={`Enter CO2 value in ${etco2Unit}`}
                    min="0"
                    max={etco2Unit === "mmHg" ? "100" : "15"}
                    step={etco2Unit === "mmHg" ? "0.1" : "0.01"}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Unit</label>
                  <select
                    value={etco2Unit}
                    onChange={(e) => setEtco2Unit(e.target.value as "mmHg" | "kPa")}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="mmHg">mmHg</option>
                    <option value="kPa">kPa</option>
                  </select>
                </div>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg">
                <h4 className="font-medium text-blue-800 dark:text-blue-200 mb-2">EtCO2 Reference:</h4>
                <div className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
                  <p><strong>Normal:</strong> 35-40 mmHg or 4.0-5.7 kPa</p>
                  <p><strong>Low:</strong> Check tube position, ventilation</p>
                  <p><strong>High:</strong> Consider circulation status</p>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowEtco2Dialog(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleEtco2Log} 
                disabled={!etco2Value}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                Log EtCO2 Reading
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* End Session Dialog */}
        <Dialog open={showEndSessionDialog} onOpenChange={setShowEndSessionDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>End ALS Session</DialogTitle>
              <DialogDescription>
                Please select the outcome and add any notes before ending the session.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Session Outcome</label>
                <Select value={sessionOutcome} onValueChange={(value: "ROSC" | "ROLE") => setSessionOutcome(value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select outcome" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ROSC">ROSC (Return of Spontaneous Circulation)</SelectItem>
                    <SelectItem value="ROLE">ROLE (Recognition of Life Extinct)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Session Notes</label>
                <Textarea
                  value={sessionNotes}
                  onChange={(e) => setSessionNotes(e.target.value)}
                  placeholder="Add any relevant notes about the session..."
                  rows={4}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowEndSessionDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleEndSession} disabled={!sessionOutcome}>
                End Session
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Rhythm Required Dialog */}
        {showRhythmRequiredDialog && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <Card className="max-w-md w-full">
              <CardHeader>
                <CardTitle className="text-xl text-center text-red-600">
                  Initial Rhythm Required
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-center text-gray-600 dark:text-gray-400">
                  You must log the initial cardiac rhythm before delivering a shock.
                </p>
                
                <div className="grid grid-cols-1 gap-3">
                  <Button
                    onClick={() => {
                      setShowRhythmRequiredDialog(false);
                      // Automatically open rhythm selection
                      handleInterventionSelect('rhythm', 'Rhythm: VF/VT');
                    }}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    Log VF/VT Rhythm
                  </Button>
                  <Button
                    onClick={() => {
                      setShowRhythmRequiredDialog(false);
                      handleInterventionSelect('rhythm', 'Rhythm: Asystole');
                    }}
                    className="bg-gray-600 hover:bg-gray-700 text-white"
                  >
                    Log Asystole
                  </Button>
                  <Button
                    onClick={() => {
                      setShowRhythmRequiredDialog(false);
                      handleInterventionSelect('rhythm', 'Rhythm: PEA');
                    }}
                    className="bg-yellow-600 hover:bg-yellow-700 text-white"
                  >
                    Log PEA
                  </Button>
                  <Button
                    onClick={() => setShowRhythmRequiredDialog(false)}
                    variant="outline"
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Post-Shock Rhythm Dialog */}
        {showPostShockRhythmDialog && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <Card className="max-w-md w-full">
              <CardHeader>
                <CardTitle className="text-xl text-center text-blue-600">
                  Post-Shock Rhythm Check
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-center text-gray-600 dark:text-gray-400">
                  Please check and log the rhythm after the shock.
                </p>
                
                <div className="grid grid-cols-1 gap-3">
                  <Button
                    onClick={() => {
                      setShowPostShockRhythmDialog(false);
                      handleInterventionSelect('rhythm', 'Post-shock Rhythm: VF/VT');
                    }}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    VF/VT (Continue CPR)
                  </Button>
                  <Button
                    onClick={() => {
                      setShowPostShockRhythmDialog(false);
                      handleInterventionSelect('rhythm', 'Post-shock Rhythm: Asystole');
                    }}
                    className="bg-gray-600 hover:bg-gray-700 text-white"
                  >
                    Asystole
                  </Button>
                  <Button
                    onClick={() => {
                      setShowPostShockRhythmDialog(false);
                      handleInterventionSelect('rhythm', 'Post-shock Rhythm: PEA');
                    }}
                    className="bg-yellow-600 hover:bg-yellow-700 text-white"
                  >
                    PEA
                  </Button>
                  <Button
                    onClick={() => {
                      setShowPostShockRhythmDialog(false);
                      handleInterventionSelect('rhythm', 'Post-shock Rhythm: ROSC');
                    }}
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    ROSC Achieved
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Three Shock Prompt Dialog */}
        {showThreeShockPrompt && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <Card className="max-w-md w-full">
              <CardHeader>
                <CardTitle className="text-xl text-center text-red-600">
                  Consider Adrenaline
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-center text-gray-600 dark:text-gray-400">
                  {shockCount} shocks have been given. Please consider adrenaline administration.
                </p>
                
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    onClick={() => handleInterventionSelect('drug', 'Adrenaline 1mg (IV/IO)')}
                    className="bg-red-600 hover:bg-red-700 text-white"
                  >
                    Give Adrenaline
                  </Button>
                  <Button
                    onClick={() => setShowThreeShockPrompt(false)}
                    variant="outline"
                  >
                    Dismiss
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Enhanced Intervention Confirmation Dialog */}
        {pendingIntervention && (
          <InterventionConfirmationDialog
            isOpen={showInterventionDialog}
            onClose={() => {
              setShowInterventionDialog(false);
              setPendingIntervention(null);
            }}
            onConfirm={handleInterventionConfirmation}
            interventionType={pendingIntervention.type}
            interventionName={pendingIntervention.name}
            isAudioEnabled={isAudioEnabled}
            sessionId={sessionId || undefined}
            teamMembers={validTeamMembers}
          />
        )}

        {/* Enhanced Adrenaline Prompting Dialogs */}
        
        {/* Immediate Adrenaline Prompt for Non-Shockable Rhythms */}
        <Dialog open={showImmediateAdrenalinePrompt} onOpenChange={setShowImmediateAdrenalinePrompt}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="text-xl text-center text-green-600">
                Adrenaline Required Now
              </DialogTitle>
              <DialogDescription className="text-center">
                IV/IO access established for non-shockable rhythm
              </DialogDescription>
            </DialogHeader>
            <div className="text-center py-4">
              <Syringe className="w-16 h-16 mx-auto mb-4 text-green-500" />
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Give adrenaline 1mg IV/IO immediately for Asystole/PEA
              </p>
              <div className="bg-yellow-50 dark:bg-yellow-900/20 p-3 rounded-lg border border-yellow-200">
                <p className="text-sm text-yellow-800 dark:text-yellow-200">
                  <strong>Clinical Protocol:</strong> Adrenaline should be given as soon as IV/IO access is established in non-shockable rhythms
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowImmediateAdrenalinePrompt(false)}>
                Remind Me Later
              </Button>
              <Button 
                onClick={() => {
                  setShowImmediateAdrenalinePrompt(false);
                  handleInterventionSelect('drug', 'Adrenaline 1mg IV/IO');
                }}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                Give Adrenaline Now
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* 3rd Shock Adrenaline Prompt */}
        <Dialog open={showThreeShockPrompt} onOpenChange={setShowThreeShockPrompt}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="text-xl text-center text-orange-600">
                Adrenaline After 3rd Shock
              </DialogTitle>
              <DialogDescription className="text-center">
                Consider adrenaline after the 3rd shock
              </DialogDescription>
            </DialogHeader>
            <div className="text-center py-4">
              <div className="flex items-center justify-center mb-4">
                <Zap className="w-8 h-8 text-blue-500 mr-2" />
                <span className="text-2xl font-bold">3</span>
                <Syringe className="w-8 h-8 text-green-500 ml-2" />
              </div>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                After the 3rd shock in VF/VT, consider giving adrenaline 1mg IV/IO
              </p>
              <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg border border-blue-200">
                <p className="text-sm text-blue-800 dark:text-blue-200">
                  <strong>ALS Protocol:</strong> Adrenaline after 3rd shock, then every alternate shock (5th, 7th, etc.)
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowThreeShockPrompt(false)}>
                Not Now
              </Button>
              <Button 
                onClick={() => {
                  setShowThreeShockPrompt(false);
                  handleInterventionSelect('drug', 'Adrenaline 1mg IV/IO');
                }}
                className="bg-orange-600 hover:bg-orange-700 text-white"
              >
                Give Adrenaline
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* General Adrenaline Due Prompt */}
        <Dialog open={showAdrenalinePrompt} onOpenChange={setShowAdrenalinePrompt}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="text-xl text-center text-red-600">
                Adrenaline Due - 5 Minutes Elapsed
              </DialogTitle>
              <DialogDescription className="text-center">
                Timer indicates next adrenaline dose is due
              </DialogDescription>
            </DialogHeader>
            <div className="text-center py-4">
              <div className="flex items-center justify-center mb-4">
                <Clock className="w-8 h-8 text-red-500 mr-2" />
                <span className="text-3xl font-bold text-red-600">5:00</span>
                <Syringe className="w-8 h-8 text-green-500 ml-2" />
              </div>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Five minutes have elapsed since the last adrenaline dose
              </p>
              <div className="bg-red-50 dark:bg-red-900/20 p-3 rounded-lg border border-red-200">
                <p className="text-sm text-red-800 dark:text-red-200">
                  <strong>Timing Protocol:</strong> Adrenaline should be given every 3-5 minutes during cardiac arrest
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAdrenalinePrompt(false)}>
                Acknowledge
              </Button>
              <Button 
                onClick={() => {
                  setShowAdrenalinePrompt(false);
                  handleInterventionSelect('drug', 'Adrenaline 1mg IV/IO');
                }}
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                Give Adrenaline Now
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* LUCAS Device Confirmation Dialog */}
        <Dialog open={showLucasConfirmDialog} onOpenChange={setShowLucasConfirmDialog}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center text-purple-600">
                <Activity className="w-5 h-5 mr-2" />
                Deploy LUCAS Device
              </DialogTitle>
              <DialogDescription>
                Confirm LUCAS device deployment and operator details
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Team Member Operating LUCAS:</label>
                <Select value={lucasOperator} onValueChange={setLucasOperator}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select team member" />
                  </SelectTrigger>
                  <SelectContent>
                    {sessionTeamMembers?.map((member: any, index: number) => (
                      <SelectItem key={index} value={member.name}>
                        {member.name} - {member.role}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Alert className="border-purple-200 bg-purple-50 dark:bg-purple-900/20">
                <Activity className="h-4 w-4" />
                <AlertDescription className="text-purple-800 dark:text-purple-200">
                  <strong>LUCAS Device Deployment:</strong>
                  <ul className="mt-2 space-y-1 text-sm">
                    <li>• Stops manual CPR metronome</li>
                    <li>• Provides consistent mechanical compressions</li>
                    <li>• 2-minute rhythm check timer continues</li>
                    <li>• Can be stopped to resume manual CPR</li>
                  </ul>
                </AlertDescription>
              </Alert>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => {
                setShowLucasConfirmDialog(false);
                setLucasOperator("");
              }}>
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  if (!lucasOperator.trim()) {
                    toast({
                      title: "Team Member Required",
                      description: "Please enter the name of the team member operating the LUCAS device",
                      variant: "destructive",
                    });
                    return;
                  }

                  setLucasActive(true);
                  setMetronomeEnabled(false);
                  
                  // Log LUCAS deployment intervention
                  logInterventionMutation.mutate({
                    type: "LUCAS_DEVICE",
                    description: `LUCAS device deployed by ${lucasOperator}`,
                    details: { 
                      operator: lucasOperator,
                      action: "deployed",
                      stoppedManualCPR: true,
                      timestamp: new Date().toISOString()
                    }
                  });

                  // Audio confirmation if enabled
                  if (isAudioEnabled) {
                    const msg = new SpeechSynthesisUtterance(
                      `LUCAS device deployed by ${lucasOperator}. Mechanical compressions active.`
                    );
                    window.speechSynthesis.speak(msg);
                  }

                  toast({
                    title: "LUCAS Device Deployed",
                    description: `Operator: ${lucasOperator} - Mechanical compressions active`,
                    duration: 5000,
                  });

                  setShowLucasConfirmDialog(false);
                }}
                disabled={!lucasOperator.trim()}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                Deploy LUCAS Device
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>

      {/* Rhythm Check Dialog */}
      <Dialog open={showRhythmCheckDialog} onOpenChange={setShowRhythmCheckDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center text-blue-600">
              <Activity className="w-5 h-5 mr-2" />
              Rhythm Check
            </DialogTitle>
            <DialogDescription>
              Please select the observed cardiac rhythm and log it for clinical documentation.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Select Rhythm:</label>
              <Select value={selectedRhythm} onValueChange={setSelectedRhythm}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose observed rhythm" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="VF">VF (Ventricular Fibrillation)</SelectItem>
                  <SelectItem value="VT">VT (Ventricular Tachycardia)</SelectItem>
                  <SelectItem value="PEA">PEA (Pulseless Electrical Activity)</SelectItem>
                  <SelectItem value="Asystole">Asystole</SelectItem>
                  <SelectItem value="Sinus Rhythm">Sinus Rhythm</SelectItem>
                  <SelectItem value="Atrial Fibrillation">Atrial Fibrillation</SelectItem>
                  <SelectItem value="SVT">SVT (Supraventricular Tachycardia)</SelectItem>
                  <SelectItem value="Bradycardia">Bradycardia</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowRhythmCheckDialog(false);
                setSelectedRhythm("");
              }}
            >
              Skip
            </Button>
            <Button
              onClick={() => {
                if (selectedRhythm && sessionId) {
                  logInterventionMutation.mutate({
                    type: "rhythm_check",
                    description: `Rhythm observed: ${selectedRhythm}`,
                    details: { rhythm: selectedRhythm }
                  });
                  setShowRhythmCheckDialog(false);
                  setSelectedRhythm("");
                  setConfirmationMessage(`Rhythm logged: ${selectedRhythm}`);
                  setShowInterventionConfirm(true);
                }
              }}
              disabled={!selectedRhythm || logInterventionMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {logInterventionMutation.isPending ? "Logging..." : "Log Rhythm"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Saving Page */}
      {showSavingPage && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-8 max-w-md w-full mx-4">
            <div className="text-center">
              <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-purple-600 mx-auto mb-4"></div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                Saving Team Setup
              </h3>
              <p className="text-gray-600 dark:text-gray-300">
                Saving team members and CAD number...
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Ready to Start Dialog */}
      <Dialog open={showReadyDialog} onOpenChange={() => {}}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-green-700 dark:text-green-400">
              Team Setup Complete
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p className="text-center text-gray-700 dark:text-gray-300">
              Team members and CAD number saved successfully. You are now ready to begin your resuscitation.
            </p>
            <p className="text-center text-sm text-gray-600 dark:text-gray-400 mt-2">
              Click the Start button when ready.
            </p>
          </div>
          <DialogFooter className="flex justify-center">
            <Button 
              onClick={handleStartBLS}
              className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 text-lg font-semibold"
            >
              <Zap className="w-5 h-5 mr-2" />
              START ALS RESUS
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reversible Cause Clinical Reading Dialog */}
      <Dialog open={showReversibleCauseDialog} onOpenChange={setShowReversibleCauseDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-red-700 dark:text-red-400">
              Assess {selectedReversibleCause}
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <ReversibleCauseForm 
              cause={selectedReversibleCause}
              onSubmit={handleReversibleCauseSubmit}
              onCancel={() => setShowReversibleCauseDialog(false)}
            />
          </div>
        </DialogContent>
      </Dialog>

      <FooterLinks />
    </div>
  );
}

// Reversible Cause Form Component
function ReversibleCauseForm({ 
  cause, 
  onSubmit, 
  onCancel 
}: { 
  cause: string; 
  onSubmit: (reading: string) => void; 
  onCancel: () => void; 
}) {
  const [reading, setReading] = useState("");

  const getPromptInfo = () => {
    switch (cause) {
      case 'Hypoxia':
        return {
          prompt: "Enter patient's current SpO2 level:",
          placeholder: "e.g. 92",
          unit: "%",
          normalRange: "95-100%",
          description: "Oxygen saturation measurement"
        };
      case 'Hypo/Hyperkalaemia':
        return {
          prompt: "Enter patient's blood glucose (BM) level:",
          placeholder: "e.g. 6.5",
          unit: "mmol/L",
          normalRange: "4.0-11.0 mmol/L",
          description: "Blood glucose measurement"
        };
      case 'Hypothermia':
        return {
          prompt: "Enter patient's core temperature:",
          placeholder: "e.g. 34.2",
          unit: "°C",
          normalRange: "36.0-37.5°C",
          description: "Core body temperature"
        };
      default:
        return {
          prompt: `Enter clinical reading for ${cause}:`,
          placeholder: "Enter value",
          unit: "",
          normalRange: "See clinical guidelines",
          description: "Clinical assessment"
        };
    }
  };

  const info = getPromptInfo();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (reading.trim()) {
      onSubmit(reading.trim());
      setReading("");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          {info.prompt}
        </label>
        <div className="relative">
          <input
            type="text"
            value={reading}
            onChange={(e) => setReading(e.target.value)}
            placeholder={info.placeholder}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            autoFocus
          />
          {info.unit && (
            <span className="absolute right-3 top-2 text-sm text-gray-500 dark:text-gray-400">
              {info.unit}
            </span>
          )}
        </div>
        <div className="mt-2 text-xs text-gray-600 dark:text-gray-400">
          <p>Normal range: {info.normalRange}</p>
          <p className="text-gray-500">{info.description}</p>
        </div>
      </div>
      
      <div className="flex gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} className="flex-1">
          Cancel
        </Button>
        <Button 
          type="submit" 
          disabled={!reading.trim()}
          className="flex-1 bg-red-600 hover:bg-red-700 text-white"
        >
          Record Assessment
        </Button>
      </div>
    </form>
  );
}