import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Navigation from "@/components/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { ArrowLeft, Camera, Trash2, Key, User, Building, Shield, Upload, Eye, EyeOff, Edit, CreditCard, Calendar, X } from "lucide-react";
import FooterLinks from "@/components/footer-links";

const profileSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Valid email is required"),
  organisation: z.string().optional(),
  role: z.string().min(1, "Role is required"),
  professionalRegistration: z.string().optional(),
});

type ProfileForm = z.infer<typeof profileSchema>;

const professionalRoles = [
  "First Responder",
  "Emergency Medical Technician (EMT)",
  "Paramedic",
  "Nurse",
  "Doctor",
  "Emergency Physician",
  "Anesthesiologist",
  "Critical Care Nurse",
  "Flight Paramedic",
  "Emergency Services Manager",
  "Training Instructor",
  "Other"
];

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isUploading, setIsUploading] = useState(false);
  const [showRecoveryCode, setShowRecoveryCode] = useState(false);
  const [isEditingRecoveryCode, setIsEditingRecoveryCode] = useState(false);
  const [newRecoveryCode, setNewRecoveryCode] = useState("");

  // Fetch subscription data
  const { data: subscription, isLoading: subscriptionLoading } = useQuery({
    queryKey: ["/api/subscription"],
    retry: false,
  });

  const form = useForm<ProfileForm>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      email: user?.email || "",
      organisation: user?.organisation || "",
      role: user?.role || "",
      professionalRegistration: user?.professionalRegistration || "",
    },
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileForm) => {
      const res = await apiRequest("PUT", "/api/profile", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const uploadImageMutation = useMutation({
    mutationFn: async (file: File) => {
      try {
        // Create FormData for multipart upload
        const formData = new FormData();
        formData.append('image', file);
        
        const res = await fetch('/api/profile/upload-image', {
          method: 'POST',
          body: formData,
          credentials: 'include',
          // Don't set Content-Type header - let browser set it with boundary
        });
        
        if (!res.ok) {
          let errorMessage = 'Upload failed';
          try {
            const errorData = await res.json();
            errorMessage = errorData.error || errorMessage;
          } catch {
            errorMessage = `Upload failed with status ${res.status}`;
          }
          throw new Error(errorMessage);
        }
        
        const result = await res.json();
        return result;
      } catch (error: any) {
        // Handle network errors
        if (error.name === 'TypeError' && error.message.includes('fetch')) {
          throw new Error('Network error - please check your connection');
        }
        throw error;
      }
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Image Uploaded",
        description: "Your profile image has been updated successfully.",
      });
      setIsUploading(false);
      // Force a page refresh to show the new image
      window.location.reload();
    },
    onError: (error: Error) => {
      toast({
        title: "Upload Failed",
        description: error.message,
        variant: "destructive",
      });
      setIsUploading(false);
    },
  });

  const deleteAccountMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("DELETE", "/api/profile");
      return await res.json();
    },
    onSuccess: () => {
      // Clear authentication state immediately
      queryClient.setQueryData(["/api/user"], null);
      queryClient.clear();
      
      toast({
        title: "Account Deleted",
        description: "Your account has been permanently deleted.",
      });
      
      // Redirect to landing page after deletion with force reload
      setTimeout(() => {
        window.location.replace("/");
      }, 2000);
    },
    onError: (error: Error) => {
      toast({
        title: "Deletion Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateRecoveryCodeMutation = useMutation({
    mutationFn: async (recoveryPasscode: string) => {
      const res = await apiRequest("PATCH", "/api/update-recovery-code", {
        recoveryPasscode,
      });
      
      if (!res.ok) {
        const errorText = await res.text();
        let errorMessage = "Failed to update recovery code";
        try {
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.message || errorMessage;
        } catch {
          errorMessage = errorText || errorMessage;
        }
        throw new Error(errorMessage);
      }
      
      const responseText = await res.text();
      try {
        return JSON.parse(responseText);
      } catch {
        // If JSON parsing fails, return a success object
        return { success: true };
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Recovery Code Updated",
        description: "Your recovery passcode has been updated successfully.",
      });
      setIsEditingRecoveryCode(false);
      setNewRecoveryCode("");
    },
    onError: (error: Error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const cancelSubscriptionMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/subscription/cancel", {});
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscription"] });
      toast({
        title: "Subscription Cancelled",
        description: "Your subscription has been cancelled successfully. You'll continue to have access until your current billing period ends.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Cancellation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const compressImage = (file: File): Promise<File> => {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      
      img.onload = () => {
        // Calculate new dimensions (max 400x400 while maintaining aspect ratio)
        const maxSize = 400;
        let { width, height } = img;
        
        if (width > height) {
          if (width > maxSize) {
            height = (height * maxSize) / width;
            width = maxSize;
          }
        } else {
          if (height > maxSize) {
            width = (width * maxSize) / height;
            height = maxSize;
          }
        }
        
        canvas.width = width;
        canvas.height = height;
        
        // Draw and compress
        ctx?.drawImage(img, 0, 0, width, height);
        canvas.toBlob(
          (blob) => {
            if (blob) {
              const compressedFile = new File([blob], file.name, {
                type: 'image/jpeg',
                lastModified: Date.now(),
              });
              resolve(compressedFile);
            }
          },
          'image/jpeg',
          0.8 // 80% quality
        );
      };
      
      img.src = URL.createObjectURL(file);
    });
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check file type
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid File Type",
          description: "Please select a valid image file (JPG, PNG, etc.).",
          variant: "destructive",
        });
        return;
      }
      
      // Check file size (5MB limit)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File Too Large",
          description: "Please select an image smaller than 5MB.",
          variant: "destructive",
        });
        return;
      }
      
      setIsUploading(true);
      uploadImageMutation.mutate(file);
    }
  };

  const onSubmit = (data: ProfileForm) => {
    updateProfileMutation.mutate(data);
  };

  const getInitials = (firstName?: string | null, lastName?: string | null) => {
    const first = firstName?.charAt(0) || '';
    const last = lastName?.charAt(0) || '';
    return (first + last).toUpperCase() || 'U';
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navigation />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => window.location.href = "/"}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Dashboard
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Profile Settings</h1>
              <p className="text-gray-600 dark:text-gray-400 mt-1">Manage your personal information and account settings</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Image Section */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Camera className="w-5 h-5 mr-2" />
                  Profile Image
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="relative inline-block">
                  <Avatar className="w-32 h-32 mx-auto mb-4">
                    <AvatarImage 
                      src={user?.profileImageUrl || undefined} 
                      alt={`${user?.firstName} ${user?.lastName}`}
                    />
                    <AvatarFallback className="text-2xl">
                      {getInitials(user?.firstName, user?.lastName)}
                    </AvatarFallback>
                  </Avatar>
                  <button 
                    onClick={() => document.getElementById('image-upload')?.click()}
                    disabled={isUploading || uploadImageMutation.isPending}
                    className="absolute bottom-0 right-0 bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-full cursor-pointer shadow-lg transition-colors disabled:opacity-50"
                  >
                    <Upload className="w-4 h-4" />
                  </button>
                </div>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  disabled={isUploading || uploadImageMutation.isPending}
                  className="hidden"
                  id="image-upload"
                />
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {isUploading || uploadImageMutation.isPending ? "Uploading image..." : "Click the icon to upload a new image"}
                </p>
                <p className="text-xs text-gray-400 mt-1">Supports JPG, PNG. Max 5MB</p>
              </CardContent>
            </Card>
          </div>

          {/* Profile Information */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <User className="w-5 h-5 mr-2" />
                  Personal Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="firstName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>First Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="lastName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Last Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <Input type="email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="organisation"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Organisation</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., NHS Trust, Ambulance Service" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="role"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Professional Role</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select your role" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {professionalRoles.map((role) => (
                                <SelectItem key={role} value={role}>
                                  {role}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="professionalRegistration"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Professional Registration</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., NMC PIN, GMC Number, HCPC Registration" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      disabled={updateProfileMutation.isPending}
                      className="w-full"
                    >
                      {updateProfileMutation.isPending ? "Updating..." : "Update Profile"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Security Actions */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Password Reset */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-blue-600">
                <Key className="w-5 h-5 mr-2" />
                Password & Security
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Update your password to keep your account secure.
              </p>
              <Button 
                variant="outline" 
                onClick={() => window.location.href = "/reset-password"}
                className="w-full"
              >
                Reset Password
              </Button>
            </CardContent>
          </Card>

          {/* Subscription Management */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-blue-600">
                <CreditCard className="w-5 h-5 mr-2" />
                Subscription
              </CardTitle>
            </CardHeader>
            <CardContent>
              {subscriptionLoading ? (
                <p className="text-gray-600 dark:text-gray-400">Loading subscription details...</p>
              ) : subscription ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg bg-blue-50 dark:bg-blue-950/20">
                    <div>
                      <h4 className="font-medium text-blue-900 dark:text-blue-100">ResusMGR Pro Subscription</h4>
                      <p className="text-sm text-blue-700 dark:text-blue-300 capitalize">
                        Status: {subscription.status}
                      </p>
                      <div className="flex items-center mt-2 text-sm text-blue-600 dark:text-blue-400">
                        <Calendar className="w-4 h-4 mr-1" />
                        {subscription.cancelAtPeriodEnd ? (
                          <span>Ends on {new Date(subscription.currentPeriodEnd).toLocaleDateString()}</span>
                        ) : (
                          <span>Renews on {new Date(subscription.currentPeriodEnd).toLocaleDateString()}</span>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">£1.99</p>
                      <p className="text-sm text-blue-600 dark:text-blue-400">per month</p>
                    </div>
                  </div>

                  {subscription.status === 'active' && !subscription.cancelAtPeriodEnd && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="outline" className="w-full border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700">
                          <X className="w-4 h-4 mr-2" />
                          Cancel Subscription
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Cancel Subscription?</AlertDialogTitle>
                          <AlertDialogDescription>
                            You'll continue to have access to ResusMGR Pro features until your current billing period ends on{' '}
                            {new Date(subscription.currentPeriodEnd).toLocaleDateString()}. After that, you'll lose access to advanced protocols and features.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Keep Subscription</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => cancelSubscriptionMutation.mutate()}
                            className="bg-red-600 hover:bg-red-700"
                            disabled={cancelSubscriptionMutation.isPending}
                          >
                            {cancelSubscriptionMutation.isPending ? "Cancelling..." : "Cancel Subscription"}
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}

                  {subscription.cancelAtPeriodEnd && (
                    <div className="p-4 border rounded-lg bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800">
                      <p className="text-amber-800 dark:text-amber-200 text-sm">
                        Your subscription has been cancelled and will end on{' '}
                        {new Date(subscription.currentPeriodEnd).toLocaleDateString()}.
                      </p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-6">
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    You don't have an active subscription.
                  </p>
                  <Button 
                    onClick={() => window.location.href = '/subscribe'}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  >
                    Subscribe to ResusMGR Pro
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Account Deletion */}
          <Card className="border-red-200 dark:border-red-800">
            <CardHeader>
              <CardTitle className="flex items-center text-red-600">
                <Trash2 className="w-5 h-5 mr-2" />
                Danger Zone
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Permanently delete your account and all associated data. This action cannot be undone.
              </p>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" className="w-full">
                    Delete Account
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This action cannot be undone. This will permanently delete your account,
                      remove all your data, cancel any active subscriptions, and delete all
                      resuscitation session records.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={() => deleteAccountMutation.mutate()}
                      className="bg-red-600 hover:bg-red-700"
                      disabled={deleteAccountMutation.isPending}
                    >
                      {deleteAccountMutation.isPending ? "Deleting..." : "Delete Account"}
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </CardContent>
          </Card>

          {/* Recovery Passcode Management */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-amber-600">
                <Shield className="w-5 h-5 mr-2" />
                Account Recovery Passcode
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Your 10-digit recovery passcode is required to reset your password if forgotten.
              </p>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="text-sm">
                      <p className="font-medium">Recovery Passcode</p>
                      <p className="text-gray-500 font-mono">
                        {showRecoveryCode 
                          ? (user?.recoveryPasscode || "Not set") 
                          : "••••••••••"
                        }
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowRecoveryCode(!showRecoveryCode)}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      {showRecoveryCode ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setIsEditingRecoveryCode(true);
                        setNewRecoveryCode(user?.recoveryPasscode || "");
                      }}
                      className="text-amber-600 hover:text-amber-800"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {isEditingRecoveryCode && (
                  <div className="space-y-3 p-3 border rounded-lg bg-amber-50 dark:bg-amber-950/20">
                    <div>
                      <Label htmlFor="newRecoveryCode">New 10-Digit Recovery Passcode</Label>
                      <Input
                        id="newRecoveryCode"
                        type="text"
                        placeholder="1234567890"
                        maxLength={10}
                        value={newRecoveryCode}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, '');
                          setNewRecoveryCode(value);
                        }}
                        className="mt-1"
                      />
                      <p className="text-xs text-gray-600 mt-1">
                        Must be exactly 10 digits
                      </p>
                    </div>
                    
                    <div className="bg-amber-100 border border-amber-200 rounded-lg p-3">
                      <p className="text-xs text-amber-800 font-medium">
                        ⚠️ Important Security Notice
                      </p>
                      <p className="text-xs text-amber-700 mt-1">
                        Make sure to write down your new recovery passcode safely. Without it, you won't be able to reset your password if forgotten.
                      </p>
                    </div>

                    <div className="flex space-x-2">
                      <Button
                        type="button"
                        onClick={() => {
                          if (newRecoveryCode.length === 10) {
                            updateRecoveryCodeMutation.mutate(newRecoveryCode);
                          }
                        }}
                        disabled={newRecoveryCode.length !== 10 || updateRecoveryCodeMutation.isPending}
                        className="bg-amber-600 hover:bg-amber-700"
                      >
                        {updateRecoveryCodeMutation.isPending ? "Updating..." : "Update Passcode"}
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          setIsEditingRecoveryCode(false);
                          setNewRecoveryCode("");
                        }}
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <FooterLinks />
    </div>
  );
}