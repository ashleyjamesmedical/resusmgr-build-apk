import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import Navigation from "@/components/navigation";
import ProtocolCard from "@/components/protocol-card";
import DrugCalculator from "@/components/drug-calculator";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Heart, Clock, FileText, Plus, ChevronRight, User, Baby, Calculator, Pill, Shield, CreditCard, StopCircle, HelpCircle, Book, MessageSquare, Trophy } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ResuscitationSession } from "@shared/schema";
import FooterLinks from "@/components/footer-links";
import ChatSystem from "@/components/chat-system";


// Component to display real-time timer for ongoing sessions
function OngoingSessionTimer({ startTime }: { startTime: string }) {
  const [elapsedTime, setElapsedTime] = useState(0);

  useEffect(() => {
    const updateTimer = () => {
      const start = new Date(startTime).getTime();
      const now = Date.now();
      const elapsed = Math.floor((now - start) / 1000);
      setElapsedTime(elapsed);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [startTime]);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex items-center text-orange-800 dark:text-orange-200 font-mono text-lg font-bold">
      <Clock className="w-4 h-4 mr-2" />
      {formatTime(elapsedTime)}
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [showEndSessionDialog, setShowEndSessionDialog] = useState(false);
  const { toast } = useToast();

  // Fetch active session
  const { data: activeSession } = useQuery<ResuscitationSession | null>({
    queryKey: ["/api/sessions/active"],
    refetchInterval: 5000, // Check for active session every 5 seconds
  });

  // Fetch recent sessions
  const { data: recentSessions = [] } = useQuery<ResuscitationSession[]>({
    queryKey: ["/api/sessions"],
  });

  // Fetch subscription data
  const { data: subscription } = useQuery({
    queryKey: ["/api/subscription"],
    retry: false,
  });

  // End session mutation
  const endSessionMutation = useMutation({
    mutationFn: async (outcome: string) => {
      if (!activeSession) throw new Error("No active session");
      const response = await apiRequest("PUT", `/api/sessions/${activeSession.id}/end`, { 
        outcome,
        notes: `Session ended by user from dashboard` 
      });
      return response.json();
    },
    onSuccess: () => {
      // Immediately clear the active session from cache
      queryClient.setQueryData(["/api/sessions/active"], null);
      queryClient.setQueryData(["/api/sessions/active"], undefined);
      
      // Force refetch to ensure consistency
      queryClient.invalidateQueries({ queryKey: ["/api/sessions/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      
      // Invalidate user data to update ROSC/ROLE counters
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      
      setShowEndSessionDialog(false);
      toast({
        title: "Session Ended",
        description: "Your resuscitation session has been successfully completed.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: "Failed to end session. Please try again.",
        variant: "destructive",
      });
    },
  });

  // ROSC counter mutations
  const incrementRoscMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/counters/rosc/increment");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "ROSC Count Updated",
        description: "Successfully recorded Return of Spontaneous Circulation.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update ROSC count",
        variant: "destructive",
      });
    },
  });

  const resetRoscMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/counters/rosc/reset");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "ROSC Count Reset",
        description: "ROSC counter has been reset to zero.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to reset ROSC count",
        variant: "destructive",
      });
    },
  });

  // ROLE counter mutations
  const incrementRoleMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/counters/role/increment");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "ROLE Count Updated",
        description: "Successfully recorded Recognition of Life Extinct.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update ROLE count",
        variant: "destructive",
      });
    },
  });

  const resetRoleMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/counters/role/reset");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "ROLE Count Reset",
        description: "ROLE counter has been reset to zero.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to reset ROLE count",
        variant: "destructive",
      });
    },
  });

  const handleProtocolSelect = (protocolType: string, patientType: string) => {
    // Check if there's already an active session (restrict to 1 active session)
    if (activeSession) {
      alert("You already have an active resuscitation session in progress. Please complete the current session before starting a new one.");
      return;
    }

    // Check subscription status for premium features
    if (!subscription && protocolType !== "BLS") {
      setShowSubscriptionModal(true);
      return;
    }

    // Route to algorithm pages without creating sessions yet
    // Sessions will be created when the START button is pressed
    let routePath = "/resuscitation"; // Default fallback
    
    if (protocolType === "BLS" && patientType === "Adult") {
      routePath = "/bls-adult";
    } else if (protocolType === "BLS" && patientType === "Paediatric") {
      routePath = "/bls-paediatric";
    } else if (protocolType === "ILS" && patientType === "Adult") {
      routePath = "/ils-adult";
    } else if (protocolType === "ILS" && patientType === "Paediatric") {
      routePath = "/ils-paediatric";
    } else if (protocolType === "ALS" && patientType === "Adult") {
      routePath = "/als-adult";
    } else if (protocolType === "ALS" && patientType === "Paediatric") {
      routePath = "/als-paediatric";
    }
    
    setLocation(routePath);
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`;
  };

  const formatDateTime = (dateTime: string | Date | null) => {
    if (!dateTime) return 'Unknown';
    const date = typeof dateTime === 'string' ? new Date(dateTime) : dateTime;
    return date.toLocaleDateString("en-GB") + " - " + date.toLocaleTimeString("en-GB", { 
      hour: "2-digit", 
      minute: "2-digit",
      timeZone: "GMT"
    }) + " GMT";
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navigation />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 md:py-8">
        {/* Active Session Alert */}
        {activeSession && (
          <div className="mb-8">
            <Card className="border-red-200 bg-red-50 dark:bg-red-900/20 border-2">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-xl flex items-center justify-center">
                      <Heart className="w-8 h-8 text-red-600 animate-pulse" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-red-900 dark:text-red-100 flex items-center">
                        <span className="w-3 h-3 bg-red-600 rounded-full mr-3 animate-pulse"></span>
                        Ongoing {activeSession.protocolType} Resuscitation
                      </h3>
                      <p className="text-red-700 dark:text-red-300 mb-2">
                        {activeSession.protocolType} - {activeSession.patientType} Protocol
                      </p>
                      <OngoingSessionTimer startTime={activeSession.startTime?.toString() || activeSession.createdAt?.toString() || new Date().toISOString()} />
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Link href={`/${activeSession.protocolType.toLowerCase()}-${activeSession.patientType.toLowerCase()}/${activeSession.id}`}>
                      <Button className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 text-lg font-semibold">
                        <Heart className="w-5 h-5 mr-2" />
                        Return to Session
                      </Button>
                    </Link>
                    <Button 
                      onClick={() => setShowEndSessionDialog(true)}
                      className="bg-gray-600 hover:bg-gray-700 text-white px-6 py-3 text-lg font-semibold"
                      disabled={endSessionMutation.isPending}
                    >
                      <StopCircle className="w-5 h-5 mr-2" />
                      End Resus
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Header Section */}
        <div className="mb-6 md:mb-8">
          <Card className="medical-gradient text-white relative overflow-hidden medical-card-elevated">
            <CardContent className="pt-6 pb-6 md:pt-8 md:pb-8">
              <div className="relative z-10">
                <h2 className="text-2xl md:text-3xl font-bold mb-2">Hello, {user?.firstName || user?.username || 'User'}</h2>
                <p className="text-blue-100 text-base md:text-lg">Resuscitation Manager Dashboard</p>
                <div className="mt-4 md:mt-6 flex flex-wrap gap-2 md:gap-4">
                  {activeSession ? (
                    <Link href={`/${activeSession.protocolType.toLowerCase()}-${activeSession.patientType.toLowerCase()}/${activeSession.id}`}>
                      <div className="bg-white/20 rounded-lg px-4 py-2 cursor-pointer hover:bg-white/30 transition-colors">
                        <div className="text-sm opacity-90">Active Resuscitations</div>
                        <div className="text-2xl font-bold">1</div>
                      </div>
                    </Link>
                  ) : (
                    <div className="bg-white/20 rounded-lg px-4 py-2">
                      <div className="text-sm opacity-90">Active Resuscitations</div>
                      <div className="text-2xl font-bold">0</div>
                    </div>
                  )}
                  {subscription?.status === 'active' ? (
                    <Link href="/reports">
                      <div className="bg-white/20 rounded-lg px-4 py-2 cursor-pointer hover:bg-white/30 transition-colors">
                        <div className="text-sm opacity-90">Completed Resuscitations</div>
                        <div className="text-2xl font-bold">{(user?.roscCount || 0) + (user?.roleCount || 0)}</div>
                      </div>
                    </Link>
                  ) : (
                    <div className="bg-white/20 rounded-lg px-4 py-2">
                      <div className="text-sm opacity-90">Completed Resuscitations</div>
                      <div className="text-2xl font-bold">{(user?.roscCount || 0) + (user?.roleCount || 0)}</div>
                    </div>
                  )}
                </div>
              </div>
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
              <div className="absolute bottom-0 right-0 w-24 h-24 bg-white/5 rounded-full -mr-12 -mb-12"></div>
            </CardContent>
          </Card>
        </div>

        {/* ROSC/ROLE Counters Section */}
        <div className="mb-6 md:mb-8">
          <Card className="border-2 border-blue-200 dark:border-blue-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-yellow-500" />
                ROSC & ROLE Counters
              </CardTitle>
              <CardDescription>
                Track your Return of Spontaneous Circulation (ROSC) achievements
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* ROSC Counter */}
                <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-green-800 dark:text-green-200">ROSC Count</h3>
                      <p className="text-sm text-green-600 dark:text-green-300">Return of Spontaneous Circulation</p>
                    </div>
                    <div className="text-3xl font-bold text-green-800 dark:text-green-200">
                      {user?.roscCount || 0}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      className="bg-green-600 hover:bg-green-700 text-white"
                      onClick={() => incrementRoscMutation.mutate()}
                      disabled={incrementRoscMutation.isPending}
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add ROSC
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-green-300 text-green-700 hover:bg-green-50 dark:border-green-700 dark:text-green-300 dark:hover:bg-green-900/20"
                      onClick={() => resetRoscMutation.mutate()}
                      disabled={resetRoscMutation.isPending}
                    >
                      Reset
                    </Button>
                  </div>
                </div>

                {/* ROLE Counter */}
                <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-blue-800 dark:text-blue-200">ROLE Count</h3>
                      <p className="text-sm text-blue-600 dark:text-blue-300">Recognition of Life Extinct</p>
                    </div>
                    <div className="text-3xl font-bold text-blue-800 dark:text-blue-200">
                      {user?.roleCount || 0}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                      onClick={() => incrementRoleMutation.mutate()}
                      disabled={incrementRoleMutation.isPending}
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add ROLE
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-blue-300 text-blue-700 hover:bg-blue-50 dark:border-blue-700 dark:text-blue-300 dark:hover:bg-blue-900/20"
                      onClick={() => resetRoleMutation.mutate()}
                      disabled={resetRoleMutation.isPending}
                    >
                      Reset
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Algorithm Selection Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 mb-6 md:mb-8">
          <ProtocolCard
            title="BLS Algorithm"
            description="Basic Life Support procedures for cardiac arrest management"
            level="BASIC"
            color="green"
            icon={<Heart className="w-6 h-6" />}
            onAdultSelect={() => handleProtocolSelect("BLS", "Adult")}
            onPaediatricSelect={() => handleProtocolSelect("BLS", "Paediatric")}
            isLocked={false}
          />

          <ProtocolCard
            title="ILS Algorithm"
            description="Intermediate Life Support with some additional interventions"
            level="INTERMEDIATE"
            color="blue"
            icon={<Heart className="w-6 h-6" />}
            onAdultSelect={() => handleProtocolSelect("ILS", "Adult")}
            onPaediatricSelect={() => handleProtocolSelect("ILS", "Paediatric")}
            isLocked={!subscription}
          />

          <ProtocolCard
            title="ALS Algorithm"
            description="Advanced Life Support with full resuscitation capabilities"
            level="ADVANCED"
            color="purple"
            icon={<Heart className="w-6 h-6" />}
            onAdultSelect={() => handleProtocolSelect("ALS", "Adult")}
            onPaediatricSelect={() => handleProtocolSelect("ALS", "Paediatric")}
            isLocked={!subscription}
          />

          {/* Admin Console Card - Only visible to Administrator users */}
          {user?.role === "Administrator" && (
            <Card className="relative overflow-hidden bg-gradient-to-br from-red-500 to-red-600 text-white cursor-pointer hover:scale-105 transition-transform duration-200"
                  onClick={() => setLocation("/admin-console")}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Shield className="w-6 h-6" />
                    <div>
                      <CardTitle className="text-white">Admin Console</CardTitle>
                      <CardDescription className="text-red-100">
                        System administration and user management
                      </CardDescription>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3">
                  <Button 
                    className="w-full bg-white/10 hover:bg-white/20 text-white border-white/20"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLocation("/admin-console");
                    }}
                  >
                    Open Admin Console
                  </Button>
                </div>
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                <div className="absolute bottom-0 right-0 w-24 h-24 bg-white/5 rounded-full -mr-12 -mb-12"></div>
              </CardContent>
            </Card>
          )}

          {/* Subscribe Card - Only visible to non-admin users who aren't subscribed */}
          {user?.role !== "Administrator" && !subscription && (
            <Card className="relative overflow-hidden bg-gradient-to-br from-green-500 to-green-600 text-white cursor-pointer hover:scale-105 transition-transform duration-200"
                  onClick={() => setLocation("/subscribe")}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CreditCard className="w-6 h-6" />
                    <div>
                      <CardTitle className="text-white">Upgrade to Pro</CardTitle>
                      <CardDescription className="text-green-100">
                        Access advanced protocols and comprehensive reporting
                      </CardDescription>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3">
                  <div className="text-green-100 text-sm mb-2">
                    £1.99/month - Cancel anytime
                  </div>
                  <Button 
                    className="w-full bg-white/10 hover:bg-white/20 text-white border-white/20"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLocation("/subscribe");
                    }}
                  >
                    Subscribe Now
                  </Button>
                </div>
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                <div className="absolute bottom-0 right-0 w-24 h-24 bg-white/5 rounded-full -mr-12 -mb-12"></div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Drug Calculator */}
        {subscription ? (
          <DrugCalculator />
        ) : (
          <Card className="medical-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center text-lg">
                  <Calculator className="w-5 h-5 mr-2" />
                  Paediatric Drug Calculator
                </CardTitle>
                <Badge variant="outline" className="text-orange-600 border-orange-300">
                  Pro Feature
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Pill className="w-12 h-12 text-orange-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Premium Feature</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  Access weight-based paediatric drug calculations with age estimation tools and safety dose limits.
                </p>
                <Button onClick={() => setShowSubscriptionModal(true)} className="btn-medical-blue">
                  Upgrade to Pro Plan
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Recent Resuscitations */}
        <Card className="medical-card-elevated">
          <CardHeader className="pb-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <CardTitle className="flex items-center text-lg text-gray-900 dark:text-white">
                <FileText className="w-6 h-6 mr-3" />
                Resuscitation Reporting Tool
              </CardTitle>
              {subscription ? (
                <Link href="/reports">
                  <Button className="btn-medical-blue mobile-touch-target">
                    <Plus className="w-4 h-4 mr-2" />
                    <span className="hidden sm:inline">View All Reports</span>
                    <span className="sm:hidden">View All</span>
                  </Button>
                </Link>
              ) : (
                <Button 
                  onClick={() => setShowSubscriptionModal(true)}
                  className="btn-medical-blue mobile-touch-target"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  <span className="hidden sm:inline">Upgrade to Access</span>
                  <span className="sm:hidden">Upgrade</span>
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {!subscription ? (
              <div className="text-center py-12">
                <FileText className="w-12 h-12 text-orange-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Premium Feature</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">Upgrade to Pro Plan to access comprehensive resuscitation reporting and case management.</p>
                <Button onClick={() => setShowSubscriptionModal(true)} className="btn-medical-blue">
                  Upgrade to Pro Plan
                </Button>
              </div>
            ) : recentSessions.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">No Resuscitations Yet</h3>
                <p className="text-gray-600 dark:text-gray-400">Your completed resuscitation sessions will appear here.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {recentSessions.map((session: ResuscitationSession) => (
                  <Link key={session.id} href={`/resus-summary/${session.id}`}>
                    <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors cursor-pointer">
                    <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                        session.protocolType === "BLS" ? "bg-green-100 dark:bg-green-900/30" :
                        session.protocolType === "ILS" ? "bg-blue-100 dark:bg-blue-900/30" :
                        "bg-purple-100 dark:bg-purple-900/30"
                      }`}>
                        {session.patientType === "Paediatric" ? (
                          <Baby className={`w-6 h-6 ${
                            session.protocolType === "BLS" ? "text-green-600" :
                            session.protocolType === "ILS" ? "text-blue-600" :
                            "text-purple-600"
                          }`} />
                        ) : (
                          <User className={`w-6 h-6 ${
                            session.protocolType === "BLS" ? "text-green-600" :
                            session.protocolType === "ILS" ? "text-blue-600" :
                            "text-purple-600"
                          }`} />
                        )}
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 dark:text-white">
                          {session.patientType} {session.protocolType} Protocol
                        </h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {formatDateTime(session.startTime)}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <div className="text-sm font-semibold text-gray-900 dark:text-white">
                          {session.duration ? formatDuration(session.duration) : "In Progress"}
                        </div>
                        <Badge 
                          variant={session.outcome === "ROSC" ? "default" : session.outcome === "ROLE" ? "destructive" : "secondary"}
                          className={`text-xs ${
                            session.outcome === "ROSC" ? "status-rosc" :
                            session.outcome === "ROLE" ? "status-role" :
                            session.outcome ? "bg-gray-100 text-gray-700" : "status-active"
                          }`}
                        >
                          {session.outcome || "Active"}
                        </Badge>
                      </div>
                      <Button variant="ghost" size="sm">
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Help Card */}
        <Card className="medical-card border-blue-200 bg-blue-50 dark:bg-blue-900/20">
          <CardHeader>
            <CardTitle className="flex items-center text-lg text-blue-900 dark:text-blue-100">
              <HelpCircle className="w-5 h-5 mr-2" />
              Need Help?
            </CardTitle>
            <CardDescription className="text-blue-700 dark:text-blue-300">
              Get comprehensive guidance on using ResusMGR effectively
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <p className="text-sm text-blue-800 dark:text-blue-200">
                Access our detailed user guide with step-by-step instructions, screenshots, and troubleshooting tips for all features.
              </p>
              <div className="flex flex-col sm:flex-row gap-2">
                <Button 
                  onClick={() => setLocation("/help")}
                  className="bg-blue-600 hover:bg-blue-700 text-white flex-1"
                >
                  <Book className="w-4 h-4 mr-2" />
                  View Help Guide
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => setLocation("/help#contact")}
                  className="border-blue-300 text-blue-700 hover:bg-blue-100 dark:text-blue-300 dark:border-blue-600 dark:hover:bg-blue-900/30 flex-1"
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Contact Support
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Subscription Modal */}
      {showSubscriptionModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <Card className="max-w-md w-full medical-card-elevated">
            <CardContent className="pt-6">
              <div className="text-center mb-6">
                <div className="w-16 h-16 medical-gradient rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Premium Access Required</h2>
                <p className="text-gray-600 dark:text-gray-400">Unlock full ResusMGR functionality</p>
              </div>
              
              <div className="medical-gradient rounded-xl p-6 mb-6 text-white text-center">
                <div className="text-4xl font-bold mb-2">£1.99<span className="text-lg font-normal opacity-90">/month</span></div>
                <p className="opacity-90">Professional medical tools</p>
              </div>

              <div className="space-y-3">
                <Link href="/subscribe">
                  <Button className="w-full btn-medical-blue py-4 mobile-touch-target">
                    Subscribe Now
                  </Button>
                </Link>
                <Button 
                  className="w-full btn-medical-ghost mobile-touch-target" 
                  onClick={() => setShowSubscriptionModal(false)}
                >
                  Continue with limited access
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* End Session Dialog */}
      <Dialog open={showEndSessionDialog} onOpenChange={setShowEndSessionDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <StopCircle className="w-5 h-5 text-red-600" />
              End Resuscitation Session
            </DialogTitle>
            <DialogDescription>
              Please select the outcome of this resuscitation session. This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 pt-4">
            <Button
              onClick={() => endSessionMutation.mutate("ROSC")}
              disabled={endSessionMutation.isPending}
              className="w-full bg-green-600 hover:bg-green-700 text-white py-4 text-lg font-semibold"
            >
              <Heart className="w-5 h-5 mr-2" />
              ROSC (Return of Spontaneous Circulation)
            </Button>
            
            <Button
              onClick={() => endSessionMutation.mutate("ROLE")}
              disabled={endSessionMutation.isPending}
              className="w-full bg-red-600 hover:bg-red-700 text-white py-4 text-lg font-semibold"
            >
              <StopCircle className="w-5 h-5 mr-2" />
              ROLE (Recognition of Life Extinct)
            </Button>
            
            <Button
              onClick={() => setShowEndSessionDialog(false)}
              disabled={endSessionMutation.isPending}
              variant="outline"
              className="w-full py-3"
            >
              Cancel
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <FooterLinks />
      
      {/* Real-time chat system */}
      <ChatSystem />
    </div>
  );
}
