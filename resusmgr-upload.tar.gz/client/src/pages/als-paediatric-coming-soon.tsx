import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, ArrowLeft, Clock, Wrench, CheckCircle, Target } from "lucide-react";
import { Link } from "wouter";
import Navigation from "@/components/navigation";

export default function ALSPaediatricComingSoon() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 dark:from-gray-900 dark:to-gray-800">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <div className="w-20 h-20 bg-purple-100 dark:bg-purple-900/30 rounded-full flex items-center justify-center">
                <Target className="w-10 h-10 text-purple-600 dark:text-purple-400" />
              </div>
            </div>
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
              ALS Paediatric Algorithm
            </h1>
            <Badge className="bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300 px-4 py-2 text-lg">
              Coming Soon
            </Badge>
          </div>

          {/* Main Content Card */}
          <Card className="mb-8 shadow-lg">
            <CardHeader className="text-center pb-4">
              <div className="flex justify-center mb-4">
                <Clock className="w-12 h-12 text-blue-500" />
              </div>
              <CardTitle className="text-2xl text-gray-900 dark:text-white">
                Currently Under Development
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-6">
              <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
                We are currently working on the Advanced Life Support (ALS) Paediatric algorithm 
                to ensure it meets the highest standards for our professional users.
              </p>
              
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6">
                <div className="flex items-center justify-center mb-4">
                  <Wrench className="w-8 h-8 text-blue-600 dark:text-blue-400" />
                </div>
                <p className="text-blue-800 dark:text-blue-300 font-medium">
                  We want the app to work perfectly and for our professional users 
                  to get the most from our service.
                </p>
              </div>

              <p className="text-gray-600 dark:text-gray-400">
                Please check back later. Sorry for any inconvenience.
              </p>
            </CardContent>
          </Card>

          {/* Available Features */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center text-xl">
                <CheckCircle className="w-6 h-6 mr-3 text-green-500" />
                Available Paediatric Protocols
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Link href="/bls-paediatric">
                  <Card className="cursor-pointer hover:shadow-md transition-shadow bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
                    <CardContent className="p-6 text-center">
                      <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Heart className="w-6 h-6 text-green-600 dark:text-green-400" />
                      </div>
                      <h3 className="text-lg font-semibold text-green-800 dark:text-green-300 mb-2">
                        BLS Paediatric
                      </h3>
                      <p className="text-green-600 dark:text-green-400 text-sm">
                        Basic Life Support protocols for children
                      </p>
                    </CardContent>
                  </Card>
                </Link>

                <Link href="/ils-paediatric">
                  <Card className="cursor-pointer hover:shadow-md transition-shadow bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
                    <CardContent className="p-6 text-center">
                      <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Heart className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                      </div>
                      <h3 className="text-lg font-semibold text-blue-800 dark:text-blue-300 mb-2">
                        ILS Paediatric
                      </h3>
                      <p className="text-blue-600 dark:text-blue-400 text-sm">
                        Intermediate Life Support protocols for children
                      </p>
                    </CardContent>
                  </Card>
                </Link>
              </div>
            </CardContent>
          </Card>

          {/* Navigation */}
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/dashboard">
              <Button variant="outline" className="flex items-center">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <Link href="/ils-paediatric">
              <Button className="bg-blue-600 hover:bg-blue-700">
                Try ILS Paediatric
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}