import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function TestUpload() {
  const [isUploading, setIsUploading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const { toast } = useToast();

  const handleTestUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setResult(null);

    try {
      // Test the FormData upload
      const formData = new FormData();
      formData.append('image', file);
      
      console.log("Testing upload with:", {
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type
      });

      const res = await fetch('/api/test-upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });

      const data = await res.json();
      
      console.log("Upload response:", data);
      setResult(data);

      if (data.success) {
        toast({
          title: "Test Upload Successful",
          description: "The FormData upload is working correctly.",
        });
      } else {
        toast({
          title: "Test Upload Failed",
          description: data.error || "Unknown error occurred",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      console.error("Upload error:", error);
      setResult({ error: error.message });
      toast({
        title: "Upload Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="container mx-auto p-6">
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Upload className="w-5 h-5 mr-2" />
            Upload Test
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <input
              type="file"
              accept="image/*"
              onChange={handleTestUpload}
              disabled={isUploading}
              className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
            />
            
            <Button 
              onClick={() => document.querySelector('input[type="file"]')?.click()}
              disabled={isUploading}
              className="w-full"
            >
              {isUploading ? "Testing Upload..." : "Select Test Image"}
            </Button>

            {result && (
              <div className="mt-4 p-3 bg-gray-100 dark:bg-gray-800 rounded">
                <h4 className="font-semibold mb-2">Test Result:</h4>
                <pre className="text-xs overflow-auto">
                  {JSON.stringify(result, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}