/**
 * App Update Manager for ResusMGR
 * Handles automatic updates when deployed on Replit
 */

export class AppUpdateManager {
  private checkInterval: number = 60000; // Check every minute
  private currentVersion: string = '1.0.0';
  private updateCheckTimer: NodeJS.Timeout | null = null;

  constructor() {
    this.initializeUpdateCheck();
  }

  private initializeUpdateCheck() {
    // Check for updates when app loads
    this.checkForUpdates();
    
    // Set up periodic update checks
    this.updateCheckTimer = setInterval(() => {
      this.checkForUpdates();
    }, this.checkInterval);
  }

  private async checkForUpdates() {
    try {
      const response = await fetch('/api/app-version');
      const data = await response.json();
      
      if (data.version !== this.currentVersion) {
        this.promptForUpdate(data.version);
      }
    } catch (error) {
      console.log('Update check failed, continuing with current version');
    }
  }

  private promptForUpdate(newVersion: string) {
    const shouldUpdate = confirm(
      `ResusMGR has been updated to version ${newVersion}.\n\n` +
      'Would you like to refresh the app to get the latest features and improvements?\n\n' +
      'This will ensure you have the most up-to-date medical protocols and functionality.'
    );

    if (shouldUpdate) {
      this.performUpdate();
    }
  }

  private performUpdate() {
    // Clear any cached data
    if ('caches' in window) {
      caches.keys().then(names => {
        names.forEach(name => caches.delete(name));
      });
    }

    // Reload the application
    window.location.reload();
  }

  public destroy() {
    if (this.updateCheckTimer) {
      clearInterval(this.updateCheckTimer);
    }
  }
}

// Initialize update manager
export const updateManager = new AppUpdateManager();