/**
 * Audio utilities for medical emergency sounds and notifications
 */

export function createAudioBeep(
  audioContext: AudioContext,
  frequency: number = 800,
  duration: number = 0.1,
  volume: number = 0.3
): void {
  if (!audioContext) return;

  try {
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
    oscillator.type = 'sine';

    gainNode.gain.setValueAtTime(0, audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(volume, audioContext.currentTime + 0.01);
    gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + duration);

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + duration);
  } catch (error) {
    console.warn('Audio playback failed:', error);
  }
}

export function createDoubleBeep(audioContext: AudioContext): void {
  createAudioBeep(audioContext, 800, 0.1, 0.3);
  setTimeout(() => createAudioBeep(audioContext, 800, 0.1, 0.3), 150);
}

export function createAlertTone(audioContext: AudioContext): void {
  createAudioBeep(audioContext, 1000, 0.2, 0.4);
  setTimeout(() => createAudioBeep(audioContext, 800, 0.2, 0.4), 250);
}

export function createConfirmationBeep(audioContext: AudioContext): void {
  createAudioBeep(audioContext, 600, 0.15, 0.25);
}

export function createRhythmCheckAlert(audioContext: AudioContext): void {
  // Three ascending beeps for rhythm check
  createAudioBeep(audioContext, 600, 0.2, 0.4);
  setTimeout(() => createAudioBeep(audioContext, 800, 0.2, 0.4), 300);
  setTimeout(() => createAudioBeep(audioContext, 1000, 0.3, 0.4), 600);
}

export function createTeamSwapAlert(audioContext: AudioContext): void {
  // Two-tone alert for team swaps
  createDoubleBeep(audioContext);
  setTimeout(() => createDoubleBeep(audioContext), 500);
}

/**
 * Speech synthesis for critical alerts (if supported)
 */
export function speakAlert(message: string, lang: string = 'en-GB'): void {
  if ('speechSynthesis' in window) {
    try {
      const utterance = new SpeechSynthesisUtterance(message);
      utterance.lang = lang;
      utterance.rate = 1.2;
      utterance.volume = 0.8;
      window.speechSynthesis.speak(utterance);
    } catch (error) {
      console.warn('Speech synthesis failed:', error);
    }
  }
}

/**
 * Play pre-recorded audio alerts
 */
export function playAudioAlert(type: 'intervention' | 'rhythmCheck' | 'teamSwap' | 'confirmation'): void {
  if (typeof window === 'undefined') return;

  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  
  if (audioContext.state === 'suspended') {
    audioContext.resume();
  }

  switch (type) {
    case 'intervention':
      createConfirmationBeep(audioContext);
      break;
    case 'rhythmCheck':
      createRhythmCheckAlert(audioContext);
      speakAlert('Check rhythm');
      break;
    case 'teamSwap':
      createTeamSwapAlert(audioContext);
      speakAlert('Swap CPR team members');
      break;
    case 'confirmation':
      createConfirmationBeep(audioContext);
      break;
    default:
      createAudioBeep(audioContext);
  }
}

/**
 * Create a "bing bong" notification sound for new notifications
 */
export function createNotificationSound(audioContext: AudioContext): void {
  const gainNode = audioContext.createGain();
  gainNode.connect(audioContext.destination);
  
  // First tone (higher pitch "bing")
  const oscillator1 = audioContext.createOscillator();
  oscillator1.type = 'sine';
  oscillator1.frequency.setValueAtTime(800, audioContext.currentTime);
  oscillator1.connect(gainNode);
  
  gainNode.gain.setValueAtTime(0, audioContext.currentTime);
  gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.05);
  gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.4);
  
  oscillator1.start(audioContext.currentTime);
  oscillator1.stop(audioContext.currentTime + 0.4);
  
  // Second tone (lower pitch "bong") - delayed
  setTimeout(() => {
    const gainNode2 = audioContext.createGain();
    gainNode2.connect(audioContext.destination);
    
    const oscillator2 = audioContext.createOscillator();
    oscillator2.type = 'sine';
    oscillator2.frequency.setValueAtTime(400, audioContext.currentTime);
    oscillator2.connect(gainNode2);
    
    gainNode2.gain.setValueAtTime(0, audioContext.currentTime);
    gainNode2.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.05);
    gainNode2.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
    
    oscillator2.start(audioContext.currentTime);
    oscillator2.stop(audioContext.currentTime + 0.5);
  }, 200);
}

/**
 * Create a sharp metronome click sound for CPR timing at 120 BPM
 */
export function createMetronomeClick(audioContext: AudioContext, isAccent: boolean = false): void {
  if (!audioContext) return;

  try {
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    // Sharp click frequency - higher for accent beats
    oscillator.frequency.setValueAtTime(isAccent ? 2000 : 1500, audioContext.currentTime);
    oscillator.type = 'square';

    // Very short click envelope - this creates the "click" sound
    const volume = isAccent ? 0.8 : 0.6;
    gainNode.gain.setValueAtTime(0, audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(volume, audioContext.currentTime + 0.001);
    gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.02);

    // Very short duration for sharp click
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.02);
  } catch (error) {
    console.warn('Metronome click failed:', error);
  }
}
