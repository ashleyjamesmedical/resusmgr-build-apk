/**
 * Drug dose calculations for resuscitation scenarios
 * Based on UK Resuscitation Council Guidelines 2021
 */

export interface DrugDose {
  name: string;
  dose: string;
  volume: string;
  concentration: string;
  route: string;
  notes?: string;
}

export interface Drug {
  name: string;
  concentration: string; // mg/ml
  maxDose?: number; // mg
  dosePerKg: number; // mg/kg
  route: string[];
  notes?: string;
}

// UK RC cardiac arrest drugs only (as per compliance requirements)
export const RESUSCITATION_DRUGS: Drug[] = [
  {
    name: "Oxygen",
    concentration: "100%",
    dosePerKg: 0, // High flow oxygen
    route: ["Inhalation"],
    notes: "High-concentration during arrest; titrate post-ROSC",
  },
  {
    name: "Adrenaline",
    concentration: "1:10,000 (0.1 mg/ml)",
    dosePerKg: 0.01, // 0.01 mg/kg = 10 mcg/kg
    route: ["IV", "IO"],
    notes: "Every 3-5 minutes during CPR",
  },
  {
    name: "Amiodarone",
    concentration: "50 mg/ml",
    dosePerKg: 5, // 5 mg/kg
    maxDose: 300, // mg
    route: ["IV", "IO"],
    notes: "After 3rd shock for VF/pVT, then 150mg after 5th shock",
  },
  {
    name: "Atropine",
    concentration: "0.6 mg/ml",
    dosePerKg: 0.02, // 20 mcg/kg
    maxDose: 3, // mg (adult max dose)
    route: ["IV", "IO"],
    notes: "For bradycardia with poor perfusion",
  },
  {
    name: "Naloxone",
    concentration: "0.4 mg/ml",
    dosePerKg: 0.01, // 10 mcg/kg
    maxDose: 2, // mg initial adult dose
    route: ["IV", "IO", "IM", "Intranasal"],
    notes: "For suspected opioid overdose",
  },
  {
    name: "Glucose 10%",
    concentration: "100 mg/ml",
    dosePerKg: 2000, // 2 g/kg = 2000 mg/kg (but using 10% solution)
    route: ["IV", "IO"],
    notes: "For hypoglycaemia (safer than 50% glucose)",
  },
  {
    name: "Sodium Chloride",
    concentration: "9 mg/ml (0.9%)",
    dosePerKg: 20000, // 20 ml/kg fluid bolus
    route: ["IV", "IO"],
    notes: "Fluid resuscitation, drug dilution",
  },
];

/**
 * Calculate drug dose based on patient weight
 */
export function calculateDrugDose(
  drugName: string,
  patientWeight: number,
  isAdult: boolean = false
): DrugDose | null {
  const drug = RESUSCITATION_DRUGS.find(d => d.name === drugName);
  if (!drug) return null;

  // For adults, use standard doses
  if (isAdult) {
    return getAdultDose(drug);
  }

  // Calculate paediatric dose
  const totalDoseInMg = drug.dosePerKg * patientWeight;
  
  // Apply maximum dose limit if specified
  const finalDose = drug.maxDose ? Math.min(totalDoseInMg, drug.maxDose) : totalDoseInMg;
  
  // Calculate volume based on concentration
  const concentrationValue = parseConcentrationToMgMl(drug.concentration);
  const volumeInMl = finalDose / concentrationValue;

  return {
    name: drug.name,
    dose: formatDose(finalDose),
    volume: formatVolume(volumeInMl),
    concentration: drug.concentration,
    route: drug.route.join("/"),
    notes: drug.notes,
  };
}

/**
 * Get standard adult doses (UK RC Guidelines)
 */
function getAdultDose(drug: Drug): DrugDose {
  const adultDoses: Record<string, { dose: string; volume: string }> = {
    "Oxygen": { dose: "High-flow", volume: "15 L/min" },
    "Adrenaline": { dose: "1 mg", volume: "10 ml" },
    "Amiodarone": { dose: "300 mg", volume: "6 ml" },
    "Atropine": { dose: "0.5-3 mg", volume: "1-5 ml" },
    "Naloxone": { dose: "0.4-2 mg", volume: "1-5 ml" },
    "Glucose 10%": { dose: "250 ml", volume: "250 ml" },
    "Sodium Chloride": { dose: "500-1000 ml", volume: "500-1000 ml" },
  };

  const adultDose = adultDoses[drug.name] || { dose: "See guidelines", volume: "See guidelines" };

  return {
    name: drug.name,
    dose: adultDose.dose,
    volume: adultDose.volume,
    concentration: drug.concentration,
    route: drug.route.join("/"),
    notes: drug.notes,
  };
}

/**
 * Parse concentration string to mg/ml value
 */
function parseConcentrationToMgMl(concentration: string): number {
  // Handle different concentration formats
  if (concentration.includes("1:10,000")) {
    return 0.1; // 1:10,000 = 0.1 mg/ml
  }
  
  const match = concentration.match(/(\d+(?:\.\d+)?)\s*mg\/ml/);
  if (match) {
    return parseFloat(match[1]);
  }
  
  // Handle percentage concentrations
  const percentMatch = concentration.match(/(\d+(?:\.\d+)?)%/);
  if (percentMatch) {
    return parseFloat(percentMatch[1]) * 10; // % to mg/ml
  }
  
  return 1; // Default fallback
}

/**
 * Format dose for display
 */
function formatDose(doseInMg: number): string {
  if (doseInMg < 1) {
    return `${(doseInMg * 1000).toFixed(0)} mcg`;
  } else if (doseInMg >= 1000) {
    return `${(doseInMg / 1000).toFixed(1)} g`;
  } else {
    return `${doseInMg.toFixed(1)} mg`;
  }
}

/**
 * Format volume for display
 */
function formatVolume(volumeInMl: number): string {
  if (volumeInMl < 0.1) {
    return "< 0.1 ml";
  } else if (volumeInMl < 1) {
    return `${volumeInMl.toFixed(2)} ml`;
  } else {
    return `${volumeInMl.toFixed(1)} ml`;
  }
}

/**
 * Get weight-based fluid bolus calculation
 */
export function calculateFluidBolus(patientWeight: number, isAdult: boolean = false): string {
  if (isAdult) {
    return "500-1000 ml";
  }
  
  // Paediatric: 20 ml/kg
  const volume = patientWeight * 20;
  return `${volume} ml`;
}

/**
 * Calculate appropriate defibrillation energy (UK RC Guidelines)
 */
export function calculateDefibrillationEnergy(patientWeight: number, isAdult: boolean = false): string {
  if (isAdult) {
    return "150-200 J (biphasic)";
  }
  
  // Paediatric: 4 J/kg initial shock (as per compliance requirements)
  const energy = patientWeight * 4;
  return `${energy} J (4 J/kg)`;
}

/**
 * Validate patient weight
 */
export function validatePatientWeight(weight: number, isAdult: boolean = false): {
  isValid: boolean;
  message?: string;
} {
  if (weight <= 0) {
    return { isValid: false, message: "Weight must be greater than 0" };
  }
  
  if (isAdult) {
    if (weight < 30 || weight > 300) {
      return { isValid: false, message: "Adult weight should be between 30-300 kg" };
    }
  } else {
    if (weight < 1 || weight > 100) {
      return { isValid: false, message: "Paediatric weight should be between 1-100 kg" };
    }
  }
  
  return { isValid: true };
}

/**
 * Get age-based weight estimates for paediatrics
 */
export function getEstimatedWeight(ageInYears: number): number {
  if (ageInYears < 1) {
    // Infants: age in months × 0.5 + 4
    return Math.max(3, ageInYears * 12 * 0.5 + 4);
  } else if (ageInYears <= 10) {
    // 1-10 years: (age × 2) + 8
    return (ageInYears * 2) + 8;
  } else {
    // >10 years: (age × 3) + 7
    return (ageInYears * 3) + 7;
  }
}
