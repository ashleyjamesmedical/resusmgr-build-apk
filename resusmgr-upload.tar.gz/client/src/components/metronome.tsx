import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Play, Pause, Volume2, VolumeX } from "lucide-react";
import { useMetronome } from "@/hooks/useMetronome";

interface MetronomeProps {
  isEnabled?: boolean;
  onBeatChange?: (beat: number) => void;
  onBpmChange?: (bpm: number) => void;
}

export default function Metronome({ isEnabled = true, onBeatChange, onBpmChange }: MetronomeProps) {
  const {
    bpm,
    isPlaying,
    isMuted,
    currentBeat,
    start,
    stop,
    toggle,
    toggleMute,
    setBpm,
    setBeatCallback,
  } = useMetronome();

  const [beatIndicator, setBeatIndicator] = useState(false);

  // Set to 120 BPM automatically and start when enabled
  useEffect(() => {
    setBpm(120);
  }, []);

  useEffect(() => {
    if (isEnabled && !isPlaying) {
      start();
    } else if (!isEnabled && isPlaying) {
      stop();
    }
  }, [isEnabled, isPlaying, start, stop]);

  // Set beat callback for parent component
  useEffect(() => {
    if (onBeatChange) {
      setBeatCallback(onBeatChange);
    }
  }, [onBeatChange, setBeatCallback]);

  // Notify parent of BPM changes
  useEffect(() => {
    if (onBpmChange) {
      onBpmChange(bpm);
    }
  }, [bpm, onBpmChange]);

  // Visual beat indicator
  useEffect(() => {
    if (isPlaying) {
      setBeatIndicator(true);
      const timeout = setTimeout(() => setBeatIndicator(false), 100);
      return () => clearTimeout(timeout);
    }
  }, [currentBeat, isPlaying]);

  const getBpmRecommendation = (currentBpm: number) => {
    if (currentBpm >= 100 && currentBpm <= 120) {
      return { text: "Optimal rate", color: "text-green-600" };
    } else if (currentBpm < 100) {
      return { text: "Too slow", color: "text-red-600" };
    } else {
      return { text: "Too fast", color: "text-orange-600" };
    }
  };

  const recommendation = getBpmRecommendation(bpm);

  return (
    <div className="space-y-6">
      {/* BPM Display and Beat Indicator */}
      <div className="text-center">
        <div className="relative mb-4">
          <div className="relative w-32 h-24 mx-auto">
            {/* Floor/Ground */}
            <div className="absolute bottom-0 left-0 right-0 h-2 bg-gray-300 dark:bg-gray-700 rounded-sm"></div>
            
            {/* Patient laying on floor */}
            <div className="absolute bottom-2 left-4 w-20 h-12">
              {/* Patient body */}
              <div className="w-16 h-6 bg-orange-200 dark:bg-orange-800/50 rounded-lg border border-orange-300 dark:border-orange-700">
                {/* Chest area with sternum */}
                <div className="absolute top-1 left-6 w-4 h-4 bg-orange-300 dark:bg-orange-700/50 rounded border border-orange-400 dark:border-orange-600">
                  <div className="absolute left-1/2 top-0 w-0.5 h-full bg-orange-500 dark:bg-orange-600 transform -translate-x-1/2"></div>
                </div>
              </div>
              
              {/* Patient head */}
              <div className="absolute -top-2 left-14 w-6 h-6 bg-orange-100 dark:bg-orange-900/30 rounded-full border border-orange-300 dark:border-orange-600"></div>
              
              {/* Patient arms */}
              <div className="absolute top-2 -left-2 w-4 h-2 bg-orange-200 dark:bg-orange-800/50 rounded border border-orange-300 dark:border-orange-700"></div>
              <div className="absolute top-2 right-2 w-4 h-2 bg-orange-200 dark:bg-orange-800/50 rounded border border-orange-300 dark:border-orange-700"></div>
            </div>
            
            {/* Rescuer performing CPR */}
            <div className="absolute bottom-2 left-12">
              {/* Rescuer body (kneeling) */}
              <div className="w-8 h-16 bg-blue-200 dark:bg-blue-800/50 rounded-t-lg border border-blue-300 dark:border-blue-700"></div>
              
              {/* Rescuer head */}
              <div className="absolute -top-4 left-1 w-6 h-6 bg-blue-100 dark:bg-blue-900/30 rounded-full border border-blue-300 dark:border-blue-600"></div>
              
              {/* Rescuer arms extending to patient */}
              <div 
                className={`absolute top-4 -left-4 transition-all duration-150 ${
                  beatIndicator && isPlaying 
                    ? 'translate-y-1' 
                    : 'translate-y-0'
                }`}
              >
                {/* Left arm */}
                <div className="w-6 h-2 bg-blue-300 dark:bg-blue-700/50 rounded transform -rotate-45 border border-blue-400 dark:border-blue-600"></div>
                
                {/* Right arm */}
                <div className="absolute top-1 left-1 w-6 h-2 bg-blue-300 dark:bg-blue-700/50 rounded transform -rotate-45 border border-blue-400 dark:border-blue-600"></div>
                
                {/* Hands on patient chest */}
                <div className={`absolute top-2 left-4 w-4 h-3 rounded transition-all duration-150 ${
                  beatIndicator && isPlaying 
                    ? 'bg-blue-600 border-blue-700 shadow-lg' 
                    : 'bg-blue-500 border-blue-600'
                } border-2`}>
                  {/* Compression indicator */}
                  {beatIndicator && isPlaying && (
                    <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-2 h-1 bg-red-500 rounded-full"></div>
                  )}
                </div>
              </div>
              
              {/* Rescuer legs (kneeling position) */}
              <div className="absolute top-12 -left-1 w-3 h-6 bg-blue-200 dark:bg-blue-800/50 rounded border border-blue-300 dark:border-blue-700"></div>
              <div className="absolute top-12 left-6 w-3 h-6 bg-blue-200 dark:bg-blue-800/50 rounded border border-blue-300 dark:border-blue-700"></div>
            </div>
            
            {/* Compression depth indicator */}
            {beatIndicator && isPlaying && (
              <div className="absolute bottom-8 left-16 text-xs text-red-600 dark:text-red-400 font-semibold">
                5-6cm
              </div>
            )}
            
            {/* CPR rhythm indicator */}
            {beatIndicator && isPlaying && (
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2">
                <div className="flex space-x-1">
                  <div className="w-1 h-1 bg-green-500 rounded-full animate-pulse"></div>
                  <div className="w-1 h-1 bg-green-500 rounded-full animate-pulse"></div>
                  <div className="w-1 h-1 bg-green-500 rounded-full animate-pulse"></div>
                </div>
              </div>
            )}
          </div>
          
          {/* Beat counter */}
          <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
            <div className="flex space-x-1">
              {[0, 1, 2, 3].map((beat) => (
                <div
                  key={beat}
                  className={`w-2 h-2 rounded-full transition-colors duration-100 ${
                    beat === currentBeat && isPlaying
                      ? 'bg-red-500'
                      : 'bg-gray-300 dark:bg-gray-600'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
        
        <div className="mb-2">
          <div className="text-4xl font-bold text-blue-600 dark:text-blue-400">{bpm}</div>
          <div className="text-sm text-gray-600 dark:text-gray-400">Compressions per minute</div>
          <div className={`text-xs font-semibold ${recommendation.color}`}>
            {recommendation.text}
          </div>
        </div>
      </div>



      {/* BPM Slider */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-600 dark:text-gray-400">Rate Control</span>
          <span className="font-semibold">{bpm} BPM</span>
        </div>
        
        <div className="flex items-center space-x-3">
          <span className="text-xs text-gray-500 dark:text-gray-400 font-medium">100</span>
          <Slider
            value={[bpm]}
            onValueChange={(value) => setBpm(value[0])}
            min={100}
            max={120}
            step={1}
            disabled={!isEnabled}
            className="flex-1"
          />
          <span className="text-xs text-gray-500 dark:text-gray-400 font-medium">120</span>
        </div>
        
        <div className="text-center">
          <div className="text-xs text-gray-600 dark:text-gray-400">
            {bpm === 120 ? (
              <span className="text-green-600 dark:text-green-400 font-semibold">✓ Optimal rate for CPR</span>
            ) : (
              <span className="text-orange-600 dark:text-orange-400">Below optimal rate</span>
            )}
          </div>
        </div>
      </div>

      {/* Guidelines */}
      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
        <h4 className="text-sm font-semibold text-blue-800 dark:text-blue-200 mb-2">
          UK RC Guidelines 2021
        </h4>
        <ul className="text-xs text-blue-700 dark:text-blue-300 space-y-1">
          <li>• Compression rate: 100-120 per minute</li>
          <li>• Compression depth: 5-6 cm (adults)</li>
          <li>• Allow complete chest recoil</li>
          <li>• Minimize interruptions</li>
        </ul>
      </div>

      {/* CPR Cycle Reminder */}
      {isPlaying && (
        <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-3">
          <div className="text-sm font-semibold text-green-800 dark:text-green-200">
            CPR in Progress
          </div>
          <div className="text-xs text-green-700 dark:text-green-300">
            30:2 ratio • Switch every 2 minutes
          </div>
        </div>
      )}
    </div>
  );
}
