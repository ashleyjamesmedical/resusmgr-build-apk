import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { User, Baby, Lock } from "lucide-react";

interface ProtocolCardProps {
  title: string;
  description: string;
  level: string;
  color: "green" | "blue" | "purple";
  icon: React.ReactNode;
  onAdultSelect: () => void;
  onPaediatricSelect: () => void;
  isLocked?: boolean;
}

export default function ProtocolCard({
  title,
  description,
  level,
  color,
  icon,
  onAdultSelect,
  onPaediatricSelect,
  isLocked = false,
}: ProtocolCardProps) {
  const colorClasses = {
    green: {
      badge: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
      iconBg: "bg-green-100 dark:bg-green-900/30",
      iconColor: "text-green-600",
      button: "btn-medical-green",
    },
    blue: {
      badge: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
      iconBg: "bg-blue-100 dark:bg-blue-900/30",
      iconColor: "text-blue-600",
      button: "btn-medical-blue",
    },
    purple: {
      badge: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400",
      iconBg: "bg-purple-100 dark:bg-purple-900/30",
      iconColor: "text-purple-600",
      button: "btn-medical-purple",
    },
  };

  const classes = colorClasses[color];

  return (
    <Card className={`medical-card relative ${isLocked ? "opacity-75" : ""}`}>
      <CardContent className="pt-6">
        {isLocked && (
          <div className="absolute top-4 right-4">
            <Lock className="w-5 h-5 text-gray-400" />
          </div>
        )}
        
        <div className="flex items-center justify-between mb-4">
          <div className={`w-12 h-12 ${classes.iconBg} rounded-xl flex items-center justify-center`}>
            <div className={classes.iconColor}>
              {icon}
            </div>
          </div>
          <Badge className={classes.badge}>
            {level}
          </Badge>
        </div>
        
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{title}</h3>
        <p className="text-gray-600 dark:text-gray-400 text-sm mb-6">{description}</p>
        
        <div className="space-y-3">
          <Button
            onClick={onAdultSelect}
            disabled={isLocked}
            className={`w-full ${classes.button} py-4 md:py-3 text-base md:text-sm font-semibold transition-all duration-200 mobile-touch-target`}
          >
            <User className="w-5 h-5 md:w-4 md:h-4 mr-2" />
            Adult {title.split(" ")[0]}
          </Button>
          <Button
            onClick={onPaediatricSelect}
            disabled={isLocked}
            className={`w-full ${classes.button} py-4 md:py-3 text-base md:text-sm font-semibold transition-all duration-200 mobile-touch-target`}
          >
            <Baby className="w-5 h-5 md:w-4 md:h-4 mr-2" />
            Paediatric {title.split(" ")[0]}
          </Button>
        </div>

        {isLocked && (
          <div className="mt-4 text-center">
            <p className="text-xs text-gray-500">
              Professional subscription required
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
