import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { AlertTriangle, Shield } from "lucide-react";

interface UnauthorizedParticipationDialogProps {
  isOpen: boolean;
  onClose: () => void;
  sessionId: number;
  teamMemberId?: number;
}

export default function UnauthorizedParticipationDialog({
  isOpen,
  onClose,
  sessionId,
  teamMemberId
}: UnauthorizedParticipationDialogProps) {
  const [reason, setReason] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const reportMutation = useMutation({
    mutationFn: async (data: { sessionId: number; teamMemberId?: number; reason: string }) => {
      const response = await apiRequest("POST", "/api/unauthorized-participation-reports", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Report Submitted",
        description: "Your unauthorized participation report has been submitted to the admin team for review.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      setReason("");
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Submit Report",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    if (!reason.trim()) {
      toast({
        title: "Reason Required",
        description: "Please provide a reason for reporting this unauthorized participation.",
        variant: "destructive",
      });
      return;
    }

    reportMutation.mutate({
      sessionId,
      teamMemberId,
      reason: reason.trim()
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            Report Unauthorized Participation
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex items-start gap-3 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800">
            <Shield className="w-5 h-5 text-amber-600 dark:text-amber-400 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-amber-800 dark:text-amber-200">
                Security Notice
              </p>
              <p className="text-amber-700 dark:text-amber-300 mt-1">
                If you were added to a resuscitation session without your knowledge or consent, 
                please report it immediately for investigation.
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="reason">Reason for Report *</Label>
            <Textarea
              id="reason"
              placeholder="Please explain why this participation was unauthorized (e.g., 'I was not present at this session', 'I did not consent to being added', etc.)"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={4}
              className="resize-none"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={reportMutation.isPending || !reason.trim()}
            className="bg-red-600 hover:bg-red-700 text-white"
          >
            {reportMutation.isPending ? "Submitting..." : "Submit Report"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}