import { Heart } from "lucide-react";

export default function LoadingScreen() {
  return (
    <div className="fixed inset-0 medical-gradient z-50 flex items-center justify-center">
      <div className="text-center text-white">
        <div className="mb-8">
          <div className="w-24 h-24 mx-auto bg-white rounded-full flex items-center justify-center mb-6">
            <Heart className="w-12 h-12 text-blue-600 animate-pulse" />
          </div>
          <h1 className="text-4xl font-bold mb-2">ResusMGR</h1>
          <p className="text-xl opacity-90">Resuscitation Management System</p>
          <p className="text-sm opacity-75 mt-2">Developed by Ashley James Medical</p>
        </div>
        <div className="w-64 bg-white/20 rounded-full h-2 mx-auto">
          <div className="bg-white h-2 rounded-full pulse-medical" style={{ width: "100%" }}></div>
        </div>
      </div>
    </div>
  );
}
