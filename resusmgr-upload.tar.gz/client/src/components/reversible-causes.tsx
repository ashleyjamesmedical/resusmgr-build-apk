import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { 
  AlertTriangle, 
  CheckCircle, 
  Save, 
  RefreshCw,
  Thermometer,
  Droplets,
  Activity,
  Snowflake,
  Zap,
  Wind,
  Heart,
  Pill
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ReversibleCausesProps {
  sessionId: number;
}

interface CausesState {
  // 4 Hs
  hypoxia: boolean;
  hypovolaemia: boolean;
  hypoHyperkalaemia: boolean;
  hypothermia: boolean;
  // 4 Ts
  thrombosis: boolean;
  tensionPneumothorax: boolean;
  tamponade: boolean;
  toxins: boolean;
}

const REVERSIBLE_CAUSES = [
  {
    category: "4 Hs",
    causes: [
      {
        key: "hypoxia" as keyof CausesState,
        label: "Hypoxia",
        icon: <Wind className="w-4 h-4" />,
        description: "Inadequate oxygenation",
        actions: ["High-flow oxygen", "Airway management", "Ventilation support"],
        color: "text-blue-600"
      },
      {
        key: "hypovolaemia" as keyof CausesState,
        label: "Hypovolaemia",
        icon: <Droplets className="w-4 h-4" />,
        description: "Volume depletion",
        actions: ["IV fluid bolus", "Blood products", "Control bleeding"],
        color: "text-red-600"
      },
      {
        key: "hypoHyperkalaemia" as keyof CausesState,
        label: "Hypo/Hyperkalaemia",
        icon: <Activity className="w-4 h-4" />,
        description: "Electrolyte imbalance",
        actions: ["Check VBG/U&Es", "Calcium chloride", "Insulin/glucose"],
        color: "text-purple-600"
      },
      {
        key: "hypothermia" as keyof CausesState,
        label: "Hypothermia",
        icon: <Snowflake className="w-4 h-4" />,
        description: "Core temperature <35°C",
        actions: ["Active rewarming", "Warm fluids", "Consider ECMO"],
        color: "text-cyan-600"
      },
    ]
  },
  {
    category: "4 Ts",
    causes: [
      {
        key: "thrombosis" as keyof CausesState,
        label: "Thrombosis",
        icon: <Heart className="w-4 h-4" />,
        description: "Coronary/Pulmonary",
        actions: ["Thrombolysis", "PCI", "CT-PA", "Embolectomy"],
        color: "text-red-600"
      },
      {
        key: "tensionPneumothorax" as keyof CausesState,
        label: "Tension Pneumothorax",
        icon: <Wind className="w-4 h-4" />,
        description: "Mediastinal shift",
        actions: ["Needle decompression", "Chest drain", "Clinical assessment"],
        color: "text-orange-600"
      },
      {
        key: "tamponade" as keyof CausesState,
        label: "Tamponade",
        icon: <Heart className="w-4 h-4" />,
        description: "Pericardial compression",
        actions: ["Pericardiocentesis", "Thoracotomy", "Echo assessment"],
        color: "text-yellow-600"
      },
      {
        key: "toxins" as keyof CausesState,
        label: "Toxins",
        icon: <Pill className="w-4 h-4" />,
        description: "Poisoning/Overdose",
        actions: ["Specific antidotes", "Enhanced elimination", "Supportive care"],
        color: "text-green-600"
      },
    ]
  }
];

export default function ReversibleCauses({ sessionId }: ReversibleCausesProps) {
  const [causes, setCauses] = useState<CausesState>({
    hypoxia: false,
    hypovolaemia: false,
    hypoHyperkalaemia: false,
    hypothermia: false,
    thrombosis: false,
    tensionPneumothorax: false,
    tamponade: false,
    toxins: false,
  });

  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch existing reversible causes
  const { data: existingCauses, isLoading } = useQuery({
    queryKey: ["/api/sessions", sessionId, "reversible-causes"],
    enabled: !!sessionId,
  });

  // Update state when data loads
  useEffect(() => {
    if (existingCauses) {
      setCauses({
        hypoxia: existingCauses.hypoxia || false,
        hypovolaemia: existingCauses.hypovolaemia || false,
        hypoHyperkalaemia: existingCauses.hypoHyperkalaemia || false,
        hypothermia: existingCauses.hypothermia || false,
        thrombosis: existingCauses.thrombosis || false,
        tensionPneumothorax: existingCauses.tensionPneumothorax || false,
        tamponade: existingCauses.tamponade || false,
        toxins: existingCauses.toxins || false,
      });
    }
  }, [existingCauses]);

  // Update reversible causes mutation
  const updateCausesMutation = useMutation({
    mutationFn: async (causesData: CausesState) => {
      const response = await apiRequest("PUT", `/api/sessions/${sessionId}/reversible-causes`, causesData);
      return response.json();
    },
    onSuccess: () => {
      setHasUnsavedChanges(false);
      toast({
        title: "Reversible Causes Updated",
        description: "Checklist has been saved successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/sessions", sessionId, "reversible-causes"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to update reversible causes",
        variant: "destructive",
      });
    },
  });

  const handleCauseChange = (key: keyof CausesState, checked: boolean) => {
    setCauses(prev => ({
      ...prev,
      [key]: checked,
    }));
    setHasUnsavedChanges(true);
  };

  const handleSave = () => {
    updateCausesMutation.mutate(causes);
  };

  const handleReset = () => {
    setCauses({
      hypoxia: false,
      hypovolaemia: false,
      hypoHyperkalaemia: false,
      hypothermia: false,
      thrombosis: false,
      tensionPneumothorax: false,
      tamponade: false,
      toxins: false,
    });
    setHasUnsavedChanges(true);
  };

  // Calculate completion percentage
  const totalCauses = 8;
  const checkedCauses = Object.values(causes).filter(Boolean).length;
  const completionPercentage = (checkedCauses / totalCauses) * 100;

  // Skip loading for immediate access in emergencies

  return (
    <Card className="medical-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center text-lg">
            <AlertTriangle className="w-5 h-5 mr-2" />
            4Hs & 4Ts Checklist
          </CardTitle>
          <div className="flex items-center space-x-2">
            <Badge variant="outline" className="text-xs">
              {checkedCauses}/{totalCauses} checked
            </Badge>
            {checkedCauses === totalCauses && (
              <Badge className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                <CheckCircle className="w-3 h-3 mr-1" />
                Complete
              </Badge>
            )}
          </div>
        </div>
        
        {/* Progress bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs text-gray-600 dark:text-gray-400">
            <span>Assessment Progress</span>
            <span>{Math.round(completionPercentage)}%</span>
          </div>
          <Progress value={completionPercentage} className="h-2" />
        </div>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Critical Alert */}
        {checkedCauses === 0 && (
          <Alert className="border-red-200 bg-red-50 dark:bg-red-900/20">
            <AlertTriangle className="w-4 h-4 text-red-600" />
            <AlertDescription className="text-red-800 dark:text-red-200">
              <strong>Critical:</strong> Systematically assess all reversible causes. 
              Untreated reversible causes are the most common reason for failed resuscitation.
            </AlertDescription>
          </Alert>
        )}

        {/* Reversible Causes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {REVERSIBLE_CAUSES.map((category) => (
            <div key={category.category} className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white border-b border-gray-200 dark:border-gray-700 pb-2">
                {category.category}
              </h3>
              
              <div className="space-y-3">
                {category.causes.map((cause) => {
                  const isChecked = causes[cause.key];
                  
                  return (
                    <div 
                      key={cause.key}
                      className={`p-4 rounded-lg border transition-all duration-200 ${
                        isChecked 
                          ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' 
                          : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
                      }`}
                    >
                      <div className="flex items-start space-x-3">
                        <Checkbox
                          id={cause.key}
                          checked={isChecked}
                          onCheckedChange={(checked) => handleCauseChange(cause.key, checked as boolean)}
                          className="mt-1"
                        />
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2 mb-2">
                            <div className={cause.color}>
                              {cause.icon}
                            </div>
                            <label 
                              htmlFor={cause.key}
                              className="text-sm font-semibold text-gray-900 dark:text-white cursor-pointer"
                            >
                              {cause.label}
                            </label>
                            {isChecked && (
                              <CheckCircle className="w-4 h-4 text-green-600" />
                            )}
                          </div>
                          
                          <p className="text-xs text-gray-600 dark:text-gray-400 mb-2">
                            {cause.description}
                          </p>
                          
                          <div className="space-y-1">
                            <p className="text-xs font-semibold text-gray-700 dark:text-gray-300">
                              Consider:
                            </p>
                            <ul className="text-xs text-gray-600 dark:text-gray-400 space-y-1">
                              {cause.actions.map((action, index) => (
                                <li key={index} className="flex items-center">
                                  <span className="w-1 h-1 bg-gray-400 rounded-full mr-2"></span>
                                  {action}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-3 pt-4 border-t border-gray-200 dark:border-gray-700">
          <Button
            onClick={handleSave}
            disabled={!hasUnsavedChanges || updateCausesMutation.isPending}
            className="flex-1 btn-medical-blue"
          >
            <Save className="w-4 h-4 mr-2" />
            {updateCausesMutation.isPending ? "Saving..." : "Save Checklist"}
          </Button>
          
          <Button
            onClick={handleReset}
            disabled={updateCausesMutation.isPending}
            variant="outline"
            className="px-6"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Reset
          </Button>
        </div>

        {/* Unsaved changes warning */}
        {hasUnsavedChanges && (
          <Alert className="border-yellow-200 bg-yellow-50 dark:bg-yellow-900/20">
            <AlertTriangle className="w-4 h-4 text-yellow-600" />
            <AlertDescription className="text-yellow-800 dark:text-yellow-200">
              You have unsaved changes. Click "Save Checklist" to preserve your assessment.
            </AlertDescription>
          </Alert>
        )}

        {/* Guidelines Reference */}
        <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
          <h4 className="text-sm font-semibold text-blue-800 dark:text-blue-200 mb-2">
            UK Resuscitation Council Guidelines
          </h4>
          <div className="text-xs text-blue-700 dark:text-blue-300 space-y-1">
            <p>• Systematically consider and treat reversible causes during resuscitation</p>
            <p>• The most treatable causes should be prioritised based on clinical context</p>
            <p>• Some causes require immediate intervention (e.g., tension pneumothorax)</p>
            <p>• Regular reassessment is essential as multiple causes may coexist</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
