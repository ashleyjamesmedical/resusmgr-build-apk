import { useState, useEffect, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { X, Plus, Users, Search, CheckCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import type { User } from "@shared/schema";

interface TeamMemberForm {
  name: string;
  role: string;
  userId?: string;
  isResusMgrUser: boolean;
}

interface PreSessionTeamManagerProps {
  onTeamMembersChange?: (members: TeamMemberForm[]) => void;
  initialMembers?: TeamMemberForm[];
}

export default function PreSessionTeamManager({ onTeamMembersChange, initialMembers = [] }: PreSessionTeamManagerProps) {
  const [teamMembers, setTeamMembers] = useState<TeamMemberForm[]>(
    initialMembers.length > 0 ? initialMembers : [{ name: "", role: "", isResusMgrUser: false }]
  );
  const [searchQuery, setSearchQuery] = useState("");

  // Debounced callback to prevent auto-save on every keystroke
  const debouncedOnTeamMembersChange = useCallback(
    (() => {
      let timeoutId: NodeJS.Timeout;
      return (members: TeamMemberForm[]) => {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
          if (onTeamMembersChange) {
            onTeamMembersChange(members);
          }
        }, 1000); // Wait 1 second after user stops typing
      };
    })(),
    [onTeamMembersChange]
  );

  // Update team members when initialMembers prop changes (but don't overwrite user input)
  useEffect(() => {
    if (initialMembers.length > 0) {
      console.log("PreSessionTeamManager updating with initialMembers:", initialMembers);
      // Only update if local state is empty or if this is the first load
      if (teamMembers.length === 1 && !teamMembers[0].name && !teamMembers[0].role) {
        setTeamMembers(initialMembers);
      }
    }
  }, [initialMembers]);

  // Search ResusMGR users
  const { data: searchResults = [], isLoading: isSearching } = useQuery<User[]>({
    queryKey: [`/api/users/search`, searchQuery],
    enabled: searchQuery.length > 2,
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/users/search?q=${encodeURIComponent(searchQuery)}`);
      return response.json();
    },
  });

  const updateTeamMember = (index: number, field: keyof TeamMemberForm, value: string | boolean) => {
    const updated = [...teamMembers];
    updated[index] = { ...updated[index], [field]: value };
    setTeamMembers(updated);
    debouncedOnTeamMembersChange(updated);
  };

  const addEmptyMember = () => {
    const updated = [...teamMembers, { name: "", role: "", isResusMgrUser: false }];
    setTeamMembers(updated);
    // Don't auto-save when adding empty member
  };

  const removeMember = (index: number) => {
    if (teamMembers.length > 1) {
      const updated = teamMembers.filter((_, i) => i !== index);
      setTeamMembers(updated);
      debouncedOnTeamMembersChange(updated);
    }
  };

  const selectResusMgrUser = (user: User) => {
    // Find first empty member slot or add new one
    const emptyIndex = teamMembers.findIndex(member => !member.name);
    const targetIndex = emptyIndex !== -1 ? emptyIndex : teamMembers.length;
    
    const updated = [...teamMembers];
    if (targetIndex === teamMembers.length) {
      updated.push({
        name: `${user.firstName} ${user.lastName}`,
        role: user.role || "",
        userId: user.id,
        isResusMgrUser: true
      });
    } else {
      updated[targetIndex] = {
        name: `${user.firstName} ${user.lastName}`,
        role: user.role || "",
        userId: user.id,
        isResusMgrUser: true
      };
    }
    setTeamMembers(updated);
    // Immediately save when selecting from search (this is a deliberate action)
    onTeamMembersChange?.(updated);
    setSearchQuery("");
  };

  const validMembers = teamMembers.filter(member => 
    member && 
    member.name && 
    member.role && 
    typeof member.name === 'string' && 
    typeof member.role === 'string' && 
    member.name.trim() && 
    member.role.trim()
  );

  return (
    <Card className="border-blue-200 bg-blue-50 dark:bg-blue-900/20">
      <CardHeader>
        <CardTitle className="text-blue-800 dark:text-blue-200 flex items-center justify-between">
          <div className="flex items-center">
            <Users className="w-5 h-5 mr-2" />
            Resuscitation Team Setup (Required)
          </div>
          <Badge variant="outline" className="text-blue-700 border-blue-300">
            {validMembers.length} member{validMembers.length !== 1 ? 's' : ''}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Search existing ResusMGR users */}
        <div className="space-y-3">
          <div className="border rounded-lg p-4 bg-white dark:bg-slate-800">
            <Label className="text-sm font-medium mb-2 block">Search Existing ResusMGR Users</Label>
            <div className="relative">
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search for ResusMGR users by name..."
                className="pr-8"
              />
              <Search className="absolute right-2 top-2.5 w-4 h-4 text-muted-foreground" />
            </div>
            
            {/* Search results */}
            {searchQuery.length > 2 && (
              <div className="mt-3 max-h-48 overflow-y-auto">
                {isSearching ? (
                  <div className="p-2 text-sm text-muted-foreground">Searching...</div>
                ) : searchResults.length > 0 ? (
                  <div className="space-y-1">
                    {searchResults.map((user) => (
                      <div
                        key={user.id}
                        onClick={() => selectResusMgrUser(user)}
                        className="p-3 hover:bg-blue-50 dark:hover:bg-blue-900/30 cursor-pointer rounded-lg border border-transparent hover:border-blue-200 transition-colors"
                      >
                        <div className="flex items-center">
                          <Avatar className="h-10 w-10 mr-3">
                            <AvatarImage src={user.profileImageUrl || undefined} />
                            <AvatarFallback className="bg-blue-100 dark:bg-blue-800 text-blue-800 dark:text-blue-200 text-sm font-semibold">
                              {user.firstName?.[0]}{user.lastName?.[0]}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium text-gray-900 dark:text-gray-100">
                              {user.firstName} {user.lastName}
                            </div>
                            <div className="text-sm text-gray-500 dark:text-gray-400">
                              {user.role || 'Role not specified'}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-2 text-sm text-muted-foreground">No users found</div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Manual entry for team members */}
        <div className="space-y-3">
          <Label className="text-sm font-medium">Team Members</Label>
          {teamMembers.map((member, index) => (
            <div key={index} className="flex gap-2 items-end p-3 bg-white dark:bg-slate-800 rounded-lg border">
              <div className="flex-1">
                <Label htmlFor={`name-${index}`} className="text-sm">
                  Full Name {member.isResusMgrUser && <Badge variant="secondary" className="ml-1 text-xs">ResusMGR User</Badge>}
                </Label>
                <div className="relative">
                  <Input
                    id={`name-${index}`}
                    value={member.name || ""}
                    onChange={(e) => {
                      console.log(`Updating team member ${index} name to: ${e.target.value}`);
                      updateTeamMember(index, "name", e.target.value);
                      if (member.isResusMgrUser) {
                        updateTeamMember(index, "isResusMgrUser", false);
                        updateTeamMember(index, "userId", "");
                      }
                    }}
                    placeholder="Enter team member name"
                    className={member.isResusMgrUser ? "pr-8" : ""}
                    disabled={false}
                    readOnly={false}
                  />
                  {member.isResusMgrUser && (
                    <CheckCircle className="absolute right-2 top-2.5 w-4 h-4 text-green-600" />
                  )}
                </div>
              </div>
              <div className="flex-1">
                <Label htmlFor={`role-${index}`} className="text-sm">
                  Role
                </Label>
                <Input
                  id={`role-${index}`}
                  value={member.role || ""}
                  onChange={(e) => {
                    console.log(`Updating team member ${index} role to: ${e.target.value}`);
                    updateTeamMember(index, "role", e.target.value);
                  }}
                  placeholder="e.g., Paramedic, EMT, First Aider"
                  disabled={false}
                  readOnly={false}
                />
              </div>
              {teamMembers.length > 1 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => removeMember(index)}
                  className="text-red-600 hover:text-red-700"
                >
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>
          ))}
          
          <Button
            variant="outline"
            onClick={addEmptyMember}
            className="w-full border-blue-300 text-blue-700 hover:bg-blue-100 dark:hover:bg-blue-900/30"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Team Member
          </Button>
        </div>

        {/* Team summary */}
        {validMembers.length > 0 && (
          <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800">
            <div className="flex items-center mb-2">
              <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
              <span className="font-medium text-green-800 dark:text-green-200">
                Team Ready ({validMembers.length} member{validMembers.length !== 1 ? 's' : ''})
              </span>
            </div>
            <div className="space-y-1">
              {validMembers.map((member, index) => (
                <div key={index} className="text-sm text-green-700 dark:text-green-300">
                  • {member.name} - {member.role}
                  {member.isResusMgrUser && " (ResusMGR User)"}
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}