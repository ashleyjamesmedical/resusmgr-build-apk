import { useState } from "react";
import { X, Trash2, AlertTriangle, Info, CheckCircle } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDistanceToNow, format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

import type { Notification } from "@shared/schema";

interface NotificationDetailModalProps {
  notification: Notification | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function NotificationDetailModal({ 
  notification, 
  isOpen, 
  onClose 
}: NotificationDetailModalProps) {
  const { toast } = useToast();
  const [isDeleting, setIsDeleting] = useState(false);

  // Delete notification mutation
  const deleteNotificationMutation = useMutation({
    mutationFn: async (notificationId: number) => {
      const res = await apiRequest("DELETE", `/api/notifications/${notificationId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
      toast({
        title: "Notification Deleted",
        description: "The notification has been removed successfully."
      });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Delete Failed",
        description: error.message || "Failed to delete notification",
        variant: "destructive"
      });
    },
    onSettled: () => {
      setIsDeleting(false);
    }
  });

  // Mark as read mutation
  const markAsReadMutation = useMutation({
    mutationFn: async (notificationId: number) => {
      const res = await apiRequest("POST", `/api/notifications/${notificationId}/read`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
    }
  });

  // Report unauthorized participation mutation
  const reportUnauthorizedMutation = useMutation({
    mutationFn: async () => {
      if (!notification?.sessionId) {
        throw new Error("No session ID available for reporting");
      }
      
      const res = await apiRequest("POST", "/api/unauthorized-participation-reports", {
        sessionId: notification.sessionId,
        teamMemberId: null, // Will be determined by admin during investigation
        reason: "Unauthorized participation notification received - user was not authorized to participate in this resuscitation session"
      });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Report Submitted",
        description: "Your unauthorized participation report has been submitted to administrators for review."
      });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Report Failed",
        description: error.message || "Failed to submit unauthorized participation report",
        variant: "destructive"
      });
    }
  });

  const handleDelete = () => {
    if (!notification) return;
    setIsDeleting(true);
    deleteNotificationMutation.mutate(notification.id);
  };

  const handleMarkAsRead = () => {
    if (!notification || notification.isRead) return;
    markAsReadMutation.mutate(notification.id);
  };

  const handleReportUnauthorized = () => {
    if (!notification) return;
    reportUnauthorizedMutation.mutate();
  };

  if (!notification) return null;

  const getNotificationIcon = () => {
    switch (notification.type) {
      case 'resuscitation_participation':
        return <AlertTriangle className="w-6 h-6 text-amber-500" />;
      case 'investigation_outcome':
        return <CheckCircle className="w-6 h-6 text-green-500" />;
      case 'system':
        return <Info className="w-6 h-6 text-blue-500" />;
      default:
        return <Info className="w-6 h-6 text-blue-500" />;
    }
  };

  const getNotificationTypeLabel = () => {
    switch (notification.type) {
      case 'resuscitation_participation':
        return 'Resuscitation Participation';
      case 'investigation_outcome':
        return 'Investigation Outcome';
      case 'system':
        return 'System Notification';
      default:
        return 'Notification';
    }
  };

  const getBadgeVariant = () => {
    switch (notification.type) {
      case 'resuscitation_participation':
        return 'secondary';
      case 'investigation_outcome':
        return 'default';
      case 'system':
        return 'outline';
      default:
        return 'outline';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {getNotificationIcon()}
              <div>
                <DialogTitle className="text-lg font-semibold">
                  {notification.title}
                </DialogTitle>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant={getBadgeVariant()}>
                    {getNotificationTypeLabel()}
                  </Badge>
                  {!notification.isRead && (
                    <Badge variant="destructive" className="text-xs">
                      Unread
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>
        </DialogHeader>

        <Separator />

        <div className="space-y-4">
          {/* Notification Message */}
          <div className="space-y-2">
            <h4 className="font-medium text-sm text-muted-foreground">Message</h4>
            <div className="bg-muted/50 rounded-lg p-4">
              <p className="text-sm leading-relaxed whitespace-pre-wrap">
                {notification.message}
              </p>
            </div>
          </div>

          {/* Additional Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium text-muted-foreground">Created:</span>
              <div className="mt-1">
                {format(new Date(notification.createdAt), 'PPP p')}
              </div>
              <div className="text-xs text-muted-foreground">
                ({formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })})
              </div>
            </div>

            {notification.sessionId && (
              <div>
                <span className="font-medium text-muted-foreground">Session ID:</span>
                <div className="mt-1 font-mono text-xs bg-muted rounded px-2 py-1 inline-block">
                  {notification.sessionId}
                </div>
              </div>
            )}
          </div>

          {/* Actions for specific notification types */}
          {notification.type === 'resuscitation_participation' && (
            <div className="bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <span className="font-medium text-sm text-amber-800 dark:text-amber-200">
                  Action Required
                </span>
              </div>
              <p className="text-xs text-amber-700 dark:text-amber-300 mb-3">
                If you were not authorized to participate in this resuscitation session, 
                please report it through the security reporting system.
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={handleReportUnauthorized}
                disabled={reportUnauthorizedMutation.isPending}
                className="w-full border-amber-300 text-amber-800 hover:bg-amber-100 dark:border-amber-600 dark:text-amber-200 dark:hover:bg-amber-900"
              >
                <AlertTriangle className="w-4 h-4 mr-2" />
                {reportUnauthorizedMutation.isPending ? "Reporting..." : "Report Unauthorized Participation"}
              </Button>
            </div>
          )}

          {notification.type === 'investigation_outcome' && (
            <div className="bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="font-medium text-sm text-green-800 dark:text-green-200">
                  Investigation Complete
                </span>
              </div>
              <p className="text-xs text-green-700 dark:text-green-300">
                This notification confirms the outcome of an administrative investigation.
              </p>
            </div>
          )}
        </div>

        <Separator />

        {/* Action Buttons */}
        <div className="flex justify-between items-center">
          <div className="flex gap-2">
            {!notification.isRead && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleMarkAsRead}
                disabled={markAsReadMutation.isPending}
              >
                Mark as Read
              </Button>
            )}
          </div>
          
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={onClose}
            >
              Close
            </Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={handleDelete}
              disabled={isDeleting || deleteNotificationMutation.isPending}
              className="flex items-center gap-2"
            >
              <Trash2 className="w-4 h-4" />
              {isDeleting ? "Deleting..." : "Delete"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}