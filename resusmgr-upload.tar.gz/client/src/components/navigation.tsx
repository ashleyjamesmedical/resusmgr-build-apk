import { Bell, Heart, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import NotificationBell from "./notification-bell";

export default function Navigation() {
  const { user, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();

  // Fetch subscription data
  const { data: subscription } = useQuery({
    queryKey: ["/api/subscription"],
    retry: false,
  });

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  };

  const getDisplayName = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "User";
    return `${firstName || ""} ${lastName || ""}`.trim() || "User";
  };

  return (
    <nav className="bg-white dark:bg-gray-900 shadow-sm border-b border-gray-200 dark:border-gray-700 sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16 md:h-16">
          {/* Logo */}
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 medical-gradient rounded-full flex items-center justify-center">
              <Heart className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white">ResusMGR</h1>
              <p className="text-xs text-gray-500 dark:text-gray-400">Resuscitation Manager</p>
            </div>
          </div>
          
          {/* Right side */}
          <div className="flex items-center space-x-2 md:space-x-4">
            {/* Subscription Status - Hidden on small screens */}
            <div className="hidden sm:block">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLocation('/subscription')}
                className="p-1"
              >
                {subscription ? (
                  <Badge className="medical-gradient text-white hover:opacity-90 cursor-pointer">
                    Pro Plan
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-orange-600 border-orange-300 hover:bg-orange-50 cursor-pointer">
                    Free Plan
                  </Badge>
                )}
              </Button>
            </div>

            {/* Notifications */}
            <NotificationBell />

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center space-x-3 hover:bg-gray-100 dark:hover:bg-gray-800">
                  <Avatar className="w-8 h-8">
                    <AvatarImage 
                      src={user?.profileImageUrl || undefined} 
                      alt={getDisplayName(user?.firstName, user?.lastName)}
                    />
                    <AvatarFallback>
                      {getInitials(user?.firstName, user?.lastName)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="hidden sm:block text-left">
                    <p className="text-sm font-semibold text-gray-900 dark:text-white">
                      {getDisplayName(user?.firstName, user?.lastName)}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {user?.email || "No email"}
                    </p>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="px-3 py-2">
                  <p className="text-sm font-medium">{getDisplayName(user?.firstName, user?.lastName)}</p>
                  <p className="text-xs text-gray-500">{user?.email}</p>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => window.location.href = "/profile"}>
                  <Settings className="w-4 h-4 mr-2" />
                  Profile
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => window.location.href = "/subscription"}>
                  <Heart className="w-4 h-4 mr-2" />
                  Subscription
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={() => logoutMutation.mutate()}
                  className="text-red-600 focus:text-red-600"
                  disabled={logoutMutation.isPending}
                >
                  {logoutMutation.isPending ? "Signing Out..." : "Sign Out"}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </nav>
  );
}
