import { useState } from "react";
import ExternalLinkDialog from "./external-link-dialog";
import termsOfServicePdf from "@assets/ResusMGR_UserAgreement_Formatted.pdf";
import privacyPolicyPdf from "@assets/ResusMGR_PrivacyPolicy.pdf";

export default function FooterLinks() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [pendingLink, setPendingLink] = useState<{ url: string; title: string } | null>(null);

  const handleLinkClick = (url: string, title: string) => {
    setPendingLink({ url, title });
    setDialogOpen(true);
  };

  const handleConfirm = () => {
    if (pendingLink) {
      window.open(pendingLink.url, '_blank');
    }
    setDialogOpen(false);
    setPendingLink(null);
  };

  const handleCancel = () => {
    setDialogOpen(false);
    setPendingLink(null);
  };

  return (
    <>
      <div className="mt-8 pt-4 border-t border-gray-200 text-center text-sm text-gray-600">
        <div className="flex justify-center gap-4">
          <button
            onClick={() => handleLinkClick(termsOfServicePdf, "Terms of Service")}
            className="text-blue-600 hover:text-blue-800 underline"
          >
            Terms of Service
          </button>
          <span>|</span>
          <button
            onClick={() => handleLinkClick(privacyPolicyPdf, "Privacy Policy")}
            className="text-blue-600 hover:text-blue-800 underline"
          >
            Privacy Policy
          </button>
        </div>
        <p className="mt-2">© 2025 Ashley James Medical Services Ltd</p>
      </div>

      <ExternalLinkDialog
        isOpen={dialogOpen}
        onClose={handleCancel}
        onConfirm={handleConfirm}
        title={pendingLink?.title || ""}
      />
    </>
  );
}