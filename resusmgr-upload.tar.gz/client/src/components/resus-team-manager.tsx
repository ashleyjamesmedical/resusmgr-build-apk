import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { X, Plus, Users, Search } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ResusTeamMember, User } from "@shared/schema";

interface ResusTeamManagerProps {
  sessionId: number;
}

interface TeamMemberForm {
  name: string;
  role: string;
  userId?: string;
  isResusMgrUser: boolean;
}

export default function ResusTeamManager({ sessionId }: ResusTeamManagerProps) {
  const { toast } = useToast();
  const [teamMembers, setTeamMembers] = useState<TeamMemberForm[]>([
    { name: "", role: "", isResusMgrUser: false },
  ]);
  const [searchQuery, setSearchQuery] = useState("");
  const [openPopover, setOpenPopover] = useState<number | null>(null);

  // Fetch existing team members
  const { data: existingMembers = [] } = useQuery<ResusTeamMember[]>({
    queryKey: [`/api/sessions/${sessionId}/team-members`],
    enabled: !!sessionId,
  });

  // Search ResusMGR users
  const { data: searchResults = [], isLoading: isSearching } = useQuery<User[]>({
    queryKey: [`/api/users/search`, searchQuery],
    enabled: searchQuery.length > 2,
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/users/search?q=${encodeURIComponent(searchQuery)}`);
      return response.json();
    },
  });

  // Add team member mutation
  const addTeamMemberMutation = useMutation({
    mutationFn: async (member: TeamMemberForm) => {
      const response = await apiRequest("POST", `/api/sessions/${sessionId}/team-members`, {
        name: member.name,
        role: member.role,
        userId: member.userId,
        isResusMgrUser: member.isResusMgrUser,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/sessions/${sessionId}/team-members`] });
      toast({
        title: "Team member added",
        description: "Successfully added team member to the resuscitation.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error adding team member",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Remove team member mutation
  const removeTeamMemberMutation = useMutation({
    mutationFn: async (memberId: number) => {
      await apiRequest("DELETE", `/api/team-members/${memberId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/sessions/${sessionId}/team-members`] });
      toast({
        title: "Team member removed",
        description: "Successfully removed team member from the resuscitation.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error removing team member",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Initialize with existing members
  useEffect(() => {
    if (existingMembers.length > 0) {
      const existingForms = existingMembers.map(member => ({
        name: member.name,
        role: member.role,
        userId: member.userId || undefined,
        isResusMgrUser: member.isResusMgrUser || false,
      }));
      setTeamMembers(existingForms);
    }
  }, [existingMembers]);

  const updateTeamMember = (index: number, field: keyof TeamMemberForm, value: string | boolean) => {
    const updated = [...teamMembers];
    updated[index] = { ...updated[index], [field]: value };
    setTeamMembers(updated);
  };

  const addEmptyMember = () => {
    if (teamMembers.length < 5) {
      setTeamMembers([...teamMembers, { name: "", role: "", isResusMgrUser: false }]);
    }
  };

  const removeMember = (index: number) => {
    if (teamMembers.length > 1) {
      const updated = teamMembers.filter((_, i) => i !== index);
      setTeamMembers(updated);
    }
  };

  const selectResusMgrUser = (index: number, user: User) => {
    const identifier = `@${user.firstName}.${user.lastName}`;
    updateTeamMember(index, "name", identifier);
    updateTeamMember(index, "role", user.role || "");
    updateTeamMember(index, "userId", user.id);
    updateTeamMember(index, "isResusMgrUser", true);
    setOpenPopover(null);
    setSearchQuery("");
  };

  const saveTeamMembers = async () => {
    for (const member of teamMembers) {
      if (member.name.trim() && member.role.trim()) {
        await addTeamMemberMutation.mutateAsync(member);
      }
    }
  };

  const getUserInitials = (name: string) => {
    if (name.startsWith("@")) {
      const cleanName = name.substring(1);
      const parts = cleanName.split(".");
      return parts.map(part => part.charAt(0).toUpperCase()).join("");
    }
    const parts = name.split(" ");
    return parts.map(part => part.charAt(0).toUpperCase()).slice(0, 2).join("");
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="w-5 h-5" />
          Resuscitation Team Management
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Existing team members */}
        {existingMembers.length > 0 && (
          <div className="space-y-2">
            <Label className="text-sm font-medium">Current Team</Label>
            <div className="flex flex-wrap gap-2">
              {existingMembers.map((member) => (
                <Badge key={member.id} variant="secondary" className="flex items-center gap-2 p-2">
                  <Avatar className="w-6 h-6">
                    <AvatarFallback className="text-xs">
                      {getUserInitials(member.name)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-sm">{member.name}</span>
                  <span className="text-xs text-muted-foreground">({member.role})</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-4 w-4 p-0 hover:bg-destructive hover:text-destructive-foreground"
                    onClick={() => removeTeamMemberMutation.mutate(member.id)}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Search existing ResusMGR users */}
        <div className="space-y-3">
          <div className="border rounded-lg p-4 bg-slate-50 dark:bg-slate-900">
            <Label className="text-sm font-medium mb-2 block">Search Existing ResusMGR Users</Label>
            <div className="relative">
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search for ResusMGR users by name..."
                className="pr-8"
              />
              <Search className="absolute right-2 top-2.5 w-4 h-4 text-muted-foreground" />
            </div>
            
            {/* Search results */}
            {searchQuery.length > 2 && (
              <div className="mt-3 max-h-48 overflow-y-auto">
                {isSearching ? (
                  <div className="p-2 text-sm text-muted-foreground">Searching...</div>
                ) : searchResults.length > 0 ? (
                  <div className="space-y-1">
                    {searchResults.map((user) => (
                      <div
                        key={user.id}
                        onClick={() => {
                          const newMember = {
                            name: `${user.firstName} ${user.lastName}`,
                            role: user.role || "",
                            userId: user.id,
                            isResusMgrUser: true
                          };
                          setTeamMembers([...teamMembers, newMember]);
                          setSearchQuery("");
                        }}
                        className="flex items-center gap-2 p-2 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={user.profileImageUrl || ""} />
                          <AvatarFallback>
                            {user.firstName?.charAt(0)}{user.lastName?.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex flex-col">
                          <span className="text-sm font-medium">
                            {user.firstName} {user.lastName}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {user.role || 'Role not specified'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-2 text-sm text-muted-foreground">No users found</div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Manual entry for non-ResusMGR users */}
        <div className="space-y-3">
          <Label className="text-sm font-medium">Add Team Members Manually</Label>
          {teamMembers.map((member, index) => (
            <div key={index} className="flex gap-2 items-end">
              <div className="flex-1">
                <Label htmlFor={`firstName-${index}`} className="text-sm">
                  First Name
                </Label>
                <Input
                  id={`firstName-${index}`}
                  value={member.name.split(' ')[0] || ''}
                  onChange={(e) => {
                    const lastName = member.name.split(' ').slice(1).join(' ') || '';
                    const fullName = `${e.target.value} ${lastName}`.trim();
                    updateTeamMember(index, "name", fullName);
                    updateTeamMember(index, "isResusMgrUser", false);
                    updateTeamMember(index, "userId", "");
                  }}
                  placeholder="First name"
                />
              </div>

              <div className="flex-1">
                <Label htmlFor={`lastName-${index}`} className="text-sm">
                  Last Name
                </Label>
                <Input
                  id={`lastName-${index}`}
                  value={member.name.split(' ').slice(1).join(' ') || ''}
                  onChange={(e) => {
                    const firstName = member.name.split(' ')[0] || '';
                    const fullName = `${firstName} ${e.target.value}`.trim();
                    updateTeamMember(index, "name", fullName);
                    updateTeamMember(index, "isResusMgrUser", false);
                    updateTeamMember(index, "userId", "");
                  }}
                  placeholder="Last name"
                />
              </div>

              <div className="flex-1">
                <Label htmlFor={`role-${index}`} className="text-sm">
                  Role
                </Label>
                <Input
                  id={`role-${index}`}
                  value={member.role}
                  onChange={(e) => updateTeamMember(index, "role", e.target.value)}
                  placeholder="e.g., Paramedic, Doctor, Nurse"
                />
              </div>

              {teamMembers.length > 1 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => removeMember(index)}
                  className="h-10"
                >
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>
          ))}
        </div>

        <div className="flex gap-2">
          {teamMembers.length < 5 && (
            <Button variant="outline" onClick={addEmptyMember} size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Add Member
            </Button>
          )}
          
          <Button 
            onClick={saveTeamMembers} 
            size="sm"
            disabled={addTeamMemberMutation.isPending || teamMembers.every(m => !m.name.trim() || !m.role.trim())}
          >
            {addTeamMemberMutation.isPending ? "Saving..." : "Save Team"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}