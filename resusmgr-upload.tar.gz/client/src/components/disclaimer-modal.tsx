import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface DisclaimerModalProps {
  onAccept: () => void;
}

export default function DisclaimerModal({ onAccept }: DisclaimerModalProps) {
  const [isAccepting, setIsAccepting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const acceptDisclaimerMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/accept-disclaimer");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Disclaimer Accepted",
        description: "Welcome to ResusMGR Professional",
      });
      onAccept();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to accept disclaimer. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAccept = async () => {
    setIsAccepting(true);
    acceptDisclaimerMutation.mutate();
  };

  const handleDecline = () => {
    window.location.href = "/api/logout";
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <CardContent className="pt-8 pb-8">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Medical Disclaimer</h2>
          </div>
          
          <div className="space-y-4 text-gray-700 dark:text-gray-300 text-sm leading-relaxed">
            <p><strong>IMPORTANT:</strong> This application is designed as an aid for qualified medical professionals during resuscitation procedures.</p>
            
            <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
              <h3 className="font-semibold text-yellow-800 dark:text-yellow-200 mb-2">Key Points:</h3>
              <ul className="list-disc pl-6 space-y-2 text-yellow-700 dark:text-yellow-300">
                <li>This tool follows UK Resuscitation Council guidelines but should not replace clinical judgment</li>
                <li>Always follow your institution's protocols and local guidelines</li>
                <li>Ensure you are trained and competent in resuscitation procedures</li>
                <li>This app does not provide medical advice or replace proper medical training</li>
                <li>The app is intended for use by qualified healthcare professionals only</li>
              </ul>
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
              <h3 className="font-semibold text-blue-800 dark:text-blue-200 mb-2">Data and Privacy:</h3>
              <ul className="list-disc pl-6 space-y-2 text-blue-700 dark:text-blue-300">
                <li>All session data is encrypted and stored securely</li>
                <li>Patient data should be anonymized and follow local data protection policies</li>
                <li>Regular auditing and compliance with medical record-keeping standards is required</li>
                <li>Users are responsible for ensuring compliance with local privacy regulations</li>
              </ul>
            </div>

            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
              <h3 className="font-semibold text-red-800 dark:text-red-200 mb-2">Professional Responsibility:</h3>
              <p className="text-red-700 dark:text-red-300">
                By continuing, you acknowledge that you are a qualified healthcare professional and understand these limitations. 
                You accept full professional responsibility for patient care decisions and understand that this tool is a support aid only.
              </p>
            </div>

            <div className="text-center mt-6 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <p className="font-semibold text-gray-900 dark:text-white">
                ResusMGR follows UK Resuscitation Council Guidelines 2021
              </p>
              <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                Last updated: {new Date().toLocaleDateString("en-GB")}
              </p>
            </div>
          </div>
          
          <div className="flex gap-4 mt-8">
            <Button 
              onClick={handleDecline}
              variant="outline"
              className="flex-1 py-3"
              disabled={isAccepting}
            >
              Decline & Exit
            </Button>
            <Button 
              onClick={handleAccept}
              className="flex-1 btn-medical-blue py-3"
              disabled={isAccepting}
            >
              {isAccepting ? "Accepting..." : "Accept & Continue"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
