import { Bell, AlertTriangle } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";
import { createNotificationSound } from "@/lib/audio";
import UnauthorizedParticipationDialog from "./unauthorized-participation-dialog";
import NotificationDetailModal from "./notification-detail-modal";

import type { Notification } from "@shared/schema";

export default function NotificationBell() {
  const previousUnreadCount = useRef<number>(0);
  const audioContextRef = useRef<AudioContext | null>(null);
  const [reportDialogOpen, setReportDialogOpen] = useState(false);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [selectedNotification, setSelectedNotification] = useState<Notification | null>(null);

  // Initialize audio context
  useEffect(() => {
    try {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    } catch (error) {
      console.warn("Web Audio API not supported");
    }
  }, []);

  // Fetch unread count using the same pattern as other working queries
  const { data: unreadCount = { count: 0 } } = useQuery({
    queryKey: ["/api/notifications/unread-count"],
    refetchInterval: 2000, // Refetch every 2 seconds for live updates
    retry: false, // Don't retry failed requests to avoid spam
    staleTime: 1000, // Consider data stale after 1 second
  });

  // Play notification sound when new notifications arrive
  useEffect(() => {
    const currentCount = (unreadCount as any)?.count || 0;
    
    // Only play sound if count increased and it's not the initial load
    if (currentCount > previousUnreadCount.current && previousUnreadCount.current > 0) {
      if (audioContextRef.current && audioContextRef.current.state === 'running') {
        try {
          createNotificationSound(audioContextRef.current);
        } catch (error) {
          console.warn("Could not play notification sound:", error);
        }
      } else if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
        // Try to resume audio context if it was suspended
        audioContextRef.current.resume().then(() => {
          try {
            createNotificationSound(audioContextRef.current!);
          } catch (error) {
            console.warn("Could not play notification sound:", error);
          }
        }).catch(() => {
          console.warn("Could not resume audio context");
        });
      }
    }
    
    previousUnreadCount.current = currentCount;
  }, [unreadCount]);

  // Direct fetch approach to bypass routing conflicts
  const [notifications, setNotifications] = useState<Notification[]>([]);
  
  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const response = await fetch('/api/notifications', {
          credentials: 'include',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
          },
        });
        
        if (response.ok) {
          const data = await response.json();
          setNotifications(data);
          console.log('📬 Direct fetch successful:', data.length, 'notifications');
        }
      } catch (error) {
        console.log('Direct fetch - will retry...', error);
      }
    };

    // Initial fetch
    fetchNotifications();
    
    // Set up interval for live updates
    const interval = setInterval(fetchNotifications, 2000);
    
    return () => clearInterval(interval);
  }, []);

  // Mark notification as read mutation
  const markAsReadMutation = useMutation({
    mutationFn: async (notificationId: number) => {
      const res = await apiRequest("POST", `/api/notifications/${notificationId}/read`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
    },
  });

  // Mark all as read mutation
  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/notifications/mark-all-read");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
    },
  });

  // Clear all notifications mutation
  const clearAllNotificationsMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("DELETE", "/api/notifications/clear-all");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
      setNotifications([]);
    },
  });

  const handleNotificationClick = (notification: Notification) => {
    if (!notification.isRead) {
      markAsReadMutation.mutate(notification.id);
    }

    // Open detail modal for all notifications
    setSelectedNotification(notification);
    setDetailModalOpen(true);
  };

  const handleMarkAllAsRead = () => {
    markAllAsReadMutation.mutate();
  };

  const handleClearAll = () => {
    clearAllNotificationsMutation.mutate();
  };

  return (
    <>
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {notifications.filter(n => !n.isRead).length > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
            >
              {notifications.filter(n => !n.isRead).length > 9 ? '9+' : notifications.filter(n => !n.isRead).length}
            </Badge>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <DropdownMenuLabel className="flex justify-between items-center">
          Notifications
          <div className="flex gap-1">
            {notifications.filter(n => !n.isRead).length > 0 && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleMarkAllAsRead}
                className="text-xs h-6"
              >
                Mark all read
              </Button>
            )}
            {notifications.length > 0 && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleClearAll}
                className="text-xs h-6 text-red-600 hover:text-red-700"
              >
                Clear All
              </Button>
            )}
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        
        {(!notifications || notifications.length === 0) ? (
          <DropdownMenuItem disabled>
            <div className="text-center py-4 text-muted-foreground">
              No notifications to view
            </div>
          </DropdownMenuItem>
        ) : (
          notifications.slice(0, 5).map((notification) => (
            <DropdownMenuItem
              key={notification.id}
              className={`cursor-pointer ${
                !notification.isRead 
                  ? notification.type === 'resuscitation_participation'
                    ? 'bg-amber-50 dark:bg-amber-950 border-l-4 border-amber-400'
                    : 'bg-blue-50 dark:bg-blue-950'
                  : ''
              }`}
              onClick={() => handleNotificationClick(notification)}
            >
              <div className="flex flex-col gap-1 w-full">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-2">
                    {notification.type === 'resuscitation_participation' && (
                      <AlertTriangle className="w-4 h-4 text-amber-500" />
                    )}
                    <span className="font-medium text-sm">{notification.title}</span>
                  </div>
                  {!notification.isRead && (
                    <div className={`h-2 w-2 rounded-full flex-shrink-0 mt-1 ${
                      notification.type === 'resuscitation_participation' ? 'bg-amber-500' : 'bg-blue-500'
                    }`} />
                  )}
                </div>
                <p className="text-xs text-muted-foreground line-clamp-2">
                  {notification.message}
                </p>
                <span className="text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}
                </span>
                <span className="text-xs text-blue-600 dark:text-blue-400 font-medium">
                  Click to view details
                </span>
              </div>
            </DropdownMenuItem>
          ))
        )}
        
        {notifications.length > 5 && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-center text-sm text-muted-foreground">
              And {notifications.length - 5} more...
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
    
    {/* Notification Detail Modal */}
    <NotificationDetailModal
      notification={selectedNotification}
      isOpen={detailModalOpen}
      onClose={() => {
        setDetailModalOpen(false);
        setSelectedNotification(null);
      }}
    />
    
    {/* Unauthorized Participation Report Dialog */}
    {selectedNotification && selectedNotification.type === 'resuscitation_participation' && (
      <UnauthorizedParticipationDialog
        isOpen={reportDialogOpen}
        onClose={() => {
          setReportDialogOpen(false);
          setSelectedNotification(null);
        }}
        sessionId={selectedNotification.sessionId!}
      />
    )}
    </>
  );
}