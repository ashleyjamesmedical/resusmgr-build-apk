import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { ResusTeamMember } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { AlertTriangle, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface InterventionConfirmationDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (details: InterventionDetails) => void;
  interventionType: string;
  interventionName: string;
  isAudioEnabled: boolean;
  sessionId?: number;
  teamMembers?: any[];
}

interface InterventionDetails {
  teamMember: string;
  size?: string;
  location?: string;
  dose?: string;
  notes?: string;
}

const airwaySizes = {
  "Oropharyngeal airway": ["000", "00", "0", "1", "2", "3", "4", "5"],
  "OP Airway": ["000", "00", "0", "1", "2", "3", "4", "5"],
  "Nasopharyngeal airway": ["6mm", "7mm", "8mm", "9mm"],
  "NP Airway": ["6mm", "7mm", "8mm", "9mm"],
  "Endotracheal Intubation": ["6.0mm", "6.5mm", "7.0mm", "7.5mm", "8.0mm", "8.5mm", "9.0mm"],
  "Laryngeal Mask Airway": ["Size 3", "Size 4", "Size 5", "Size 6"],
  "iGel Airway": ["Size 3", "Size 4", "Size 5", "Size 6"],
  "Needle Cricothyroidotomy": ["14G", "16G", "18G"],
  "IV Access": ["14G", "16G", "18G", "20G", "22G", "24G"],
  "IO Access": ["15G", "18G"]
};

const accessLocations = {
  "IV Access": ["Left Hand", "Right Hand", "Left ACF", "Right ACF", "Haussmans Left", "Haussmans Right", "Other"],
  "IO Access": ["Proximal Humerus Left", "Proximal Humerus Right", "Distal Femur Left", "Distal Femur Right", "Proximal Tibia Left", "Proximal Tibia Right", "Distal Tibia Left", "Distal Tibia Right"]
};

export default function InterventionConfirmationDialog({
  isOpen,
  onClose,
  onConfirm,
  interventionType,
  interventionName,
  isAudioEnabled,
  sessionId,
  teamMembers = []
}: InterventionConfirmationDialogProps) {
  const { toast } = useToast();
  const [teamMember, setTeamMember] = useState("");
  const [size, setSize] = useState("");
  const [location, setLocation] = useState("");
  const [customLocation, setCustomLocation] = useState("");
  const [dose, setDose] = useState("");
  const [notes, setNotes] = useState("");
  const [isConfirming, setIsConfirming] = useState(false);

  // Only fetch team members if none are provided as props
  const { data: fetchedMembers = [] } = useQuery<ResusTeamMember[]>({
    queryKey: [`/api/sessions/${sessionId}/team-members`],
    enabled: !!sessionId && isOpen && teamMembers.length === 0,
  });

  // Use provided team members or fetched ones (never both)
  const sessionMembers = teamMembers.length > 0 ? teamMembers : fetchedMembers;

  // Only show size options for interventions that actually need them
  const requiresSize = (
    interventionType === 'airway' || 
    interventionName.includes('IV Access') || 
    interventionName.includes('IO Access') ||
    interventionName.includes('Airway') ||
    interventionName.includes('Intubation') ||
    interventionName.includes('Cricothyroidotomy')
  ) && airwaySizes.hasOwnProperty(interventionName);
  
  const requiresLocation = accessLocations.hasOwnProperty(interventionName);
  const requiresDose = interventionType === 'drug';
  const availableSizes = airwaySizes[interventionName as keyof typeof airwaySizes] || [];
  const availableLocations = accessLocations[interventionName as keyof typeof accessLocations] || [];

  // Reset form when dialog closes
  useEffect(() => {
    if (!isOpen) {
      setTeamMember("");
      setSize("");
      setLocation("");
      setCustomLocation("");
      setNotes("");
      setIsConfirming(false);
    }
  }, [isOpen]);

  const handleConfirm = async () => {
    if (!teamMember.trim()) {
      toast({
        title: "Team Member Required",
        description: "Please enter the name of the team member performing this intervention.",
        variant: "destructive",
      });
      return;
    }

    if (requiresSize && !size) {
      toast({
        title: "Size Required",
        description: `Please select the size for ${interventionName}.`,
        variant: "destructive",
      });
      return;
    }

    if (requiresLocation && !location) {
      toast({
        title: "Location Required",
        description: `Please select the access location for ${interventionName}.`,
        variant: "destructive",
      });
      return;
    }

    if (requiresLocation && location === "Other" && !customLocation.trim()) {
      toast({
        title: "Custom Location Required",
        description: "Please specify the custom location.",
        variant: "destructive",
      });
      return;
    }

    if (requiresDose && !dose.trim()) {
      toast({
        title: "Dose Required",
        description: "Please enter the exact dose administered for this drug intervention.",
        variant: "destructive",
      });
      return;
    }

    setIsConfirming(true);

    // Play audio confirmation
    if (isAudioEnabled) {
      const sizeText = size ? `, size ${size}` : "";
      const finalLocation = location === "Other" ? customLocation.trim() : location;
      const locationText = finalLocation ? `, location ${finalLocation}` : "";
      
      let audioMessage = "";
      
      // Special audio messages for IV/IO access
      if (interventionType === 'IV_ACCESS') {
        audioMessage = `I V access established by ${teamMember}${locationText}. Ready for drug administration.`;
      } else if (interventionType === 'IO_ACCESS') {
        audioMessage = `I O access established by ${teamMember}${locationText}. Ready for drug administration.`;
      } else {
        // Fix pronunciation of OP and NP airways to spell out letters
        let audioInterventionName = interventionName;
        if (interventionName === "Oropharyngeal airway") {
          audioInterventionName = "O P airway";
        } else if (interventionName === "Nasopharyngeal airway") {
          audioInterventionName = "N P airway";
        }
        
        const doseText = requiresDose && dose ? `, dose ${dose}` : "";
        audioMessage = `${audioInterventionName} confirmed by ${teamMember}${locationText}${doseText}`;
      }
      
      const utterance = new SpeechSynthesisUtterance(audioMessage);
      utterance.rate = 1.0;
      utterance.volume = 1.0;
      utterance.pitch = 1.1;
      speechSynthesis.speak(utterance);
    }

    // Show confirmation toast
    toast({
      title: "Intervention Confirmed",
      description: `${interventionName} logged for ${teamMember}`,
      duration: 1000,
    });

    // Call onConfirm with details
    onConfirm({
      teamMember,
      size: size || undefined,
      location: location === "Other" ? customLocation.trim() : location || undefined,
      dose: dose.trim() || undefined,
      notes: notes.trim() || undefined
    });

    // Reset form
    setTeamMember("");
    setSize("");
    setLocation("");
    setCustomLocation("");
    setDose("");
    setNotes("");
    setIsConfirming(false);
    onClose();
  };

  const handleClose = () => {
    setTeamMember("");
    setSize("");
    setLocation("");
    setCustomLocation("");
    setDose("");
    setNotes("");
    setIsConfirming(false);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2 text-orange-600" />
            Confirm Intervention
          </DialogTitle>
          <DialogDescription>
            Please confirm the details for: <strong>{interventionName}</strong>
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="teamMember">Team Member Name *</Label>
            <Select value={teamMember} onValueChange={setTeamMember} disabled={isConfirming}>
              <SelectTrigger>
                <SelectValue placeholder="Select a team member" />
              </SelectTrigger>
              <SelectContent>
                {sessionMembers.map((member: any, index: number) => (
                  <SelectItem key={index} value={member.name}>
                    <div className="flex items-center justify-between w-full">
                      <span className="font-medium">{member.name}</span>
                      <span className="text-sm text-muted-foreground ml-2">({member.role})</span>
                    </div>
                  </SelectItem>
                ))}
                {sessionMembers.length === 0 && (
                  <SelectItem value="" disabled>
                    No team members available
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>

          {requiresSize && (
            <div className="space-y-2">
              <Label htmlFor="size">Size *</Label>
              <Select value={size} onValueChange={setSize} disabled={isConfirming}>
                <SelectTrigger>
                  <SelectValue placeholder="Select size" />
                </SelectTrigger>
                <SelectContent>
                  {availableSizes.map((sizeOption) => (
                    <SelectItem key={sizeOption} value={sizeOption}>
                      {sizeOption}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {requiresLocation && (
            <div className="space-y-2">
              <Label htmlFor="location">Access Location *</Label>
              <Select value={location} onValueChange={setLocation} disabled={isConfirming}>
                <SelectTrigger>
                  <SelectValue placeholder="Select access location" />
                </SelectTrigger>
                <SelectContent>
                  {availableLocations.map((locationOption) => (
                    <SelectItem key={locationOption} value={locationOption}>
                      {locationOption}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              {location === "Other" && (
                <div className="mt-2">
                  <Label htmlFor="customLocation">Specify Location *</Label>
                  <Input
                    id="customLocation"
                    placeholder="Enter custom location"
                    value={customLocation}
                    onChange={(e) => setCustomLocation(e.target.value)}
                    disabled={isConfirming}
                  />
                </div>
              )}
            </div>
          )}

          {requiresDose && (
            <div className="space-y-2">
              <Label htmlFor="dose">Dose Given *</Label>
              <Input
                id="dose"
                placeholder="Enter exact dose administered (e.g., 1mg, 300mg, 10ml)"
                value={dose}
                onChange={(e) => setDose(e.target.value)}
                disabled={isConfirming}
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="notes">Additional Notes (Optional)</Label>
            <Input
              id="notes"
              placeholder="Enter any additional notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              disabled={isConfirming}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose} disabled={isConfirming}>
            Cancel
          </Button>
          <Button 
            onClick={handleConfirm} 
            disabled={isConfirming || !teamMember.trim() || (requiresSize && !size) || (requiresLocation && !location)}
            className="bg-green-600 hover:bg-green-700"
          >
            {isConfirming ? (
              <>
                <CheckCircle2 className="w-4 h-4 mr-2 animate-spin" />
                Confirming...
              </>
            ) : (
              "Confirm Intervention"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}