import { useEffect } from 'react';

interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string;
  canonicalUrl?: string;
  ogImage?: string;
  ogType?: string;
  schemaType?: 'WebPage' | 'MedicalApplication' | 'AboutPage' | 'ContactPage';
  additionalSchema?: object;
}

export function SEOHead({
  title = "ResusMGR - Professional Resuscitation Management for UK Emergency Services",
  description = "Advanced resuscitation management platform for UK emergency medicine professionals. Real-time ALS/BLS protocol guidance, team collaboration, and comprehensive audit reporting tools for ambulance crews and healthcare professionals.",
  keywords = "resuscitation management, ALS protocols, BLS protocols, emergency medicine, UK ambulance service, resuscitation council guidelines, cardiac arrest management, emergency protocols, healthcare professionals, paramedic tools",
  canonicalUrl = "https://www.resusmgr.co.uk/",
  ogImage = "https://www.resusmgr.co.uk/icon-512.svg",
  ogType = "website",
  schemaType = "WebPage",
  additionalSchema
}: SEOHeadProps) {
  
  useEffect(() => {
    // Update document title
    document.title = title;
    
    // Update meta tags
    updateMetaTag('description', description);
    updateMetaTag('keywords', keywords);
    updateMetaTag('robots', 'index, follow');
    
    // Update Open Graph tags
    updateMetaProperty('og:title', title);
    updateMetaProperty('og:description', description);
    updateMetaProperty('og:url', canonicalUrl);
    updateMetaProperty('og:image', ogImage);
    updateMetaProperty('og:type', ogType);
    
    // Update Twitter tags
    updateMetaProperty('twitter:title', title);
    updateMetaProperty('twitter:description', description);
    updateMetaProperty('twitter:image', ogImage);
    
    // Update canonical URL
    updateCanonicalLink(canonicalUrl);
    
    // Update structured data
    updateStructuredData(schemaType, {
      title,
      description,
      url: canonicalUrl,
      ...additionalSchema
    });
    
  }, [title, description, keywords, canonicalUrl, ogImage, ogType, schemaType, additionalSchema]);

  return null;
}

function updateMetaTag(name: string, content: string) {
  let meta = document.querySelector(`meta[name="${name}"]`) as HTMLMetaElement;
  if (!meta) {
    meta = document.createElement('meta');
    meta.name = name;
    document.head.appendChild(meta);
  }
  meta.content = content;
}

function updateMetaProperty(property: string, content: string) {
  let meta = document.querySelector(`meta[property="${property}"]`) as HTMLMetaElement;
  if (!meta) {
    meta = document.createElement('meta');
    meta.setAttribute('property', property);
    document.head.appendChild(meta);
  }
  meta.content = content;
}

function updateCanonicalLink(url: string) {
  let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
  if (!canonical) {
    canonical = document.createElement('link');
    canonical.rel = 'canonical';
    document.head.appendChild(canonical);
  }
  canonical.href = url;
}

function updateStructuredData(type: string, data: any) {
  // Remove existing structured data
  const existingSchema = document.querySelector('script[type="application/ld+json"]');
  if (existingSchema) {
    existingSchema.remove();
  }
  
  // Create new structured data
  const script = document.createElement('script');
  script.type = 'application/ld+json';
  
  let schemaData;
  
  switch (type) {
    case 'MedicalApplication':
      schemaData = {
        "@context": "https://schema.org",
        "@type": "SoftwareApplication",
        "name": "ResusMGR",
        "description": data.description,
        "url": data.url,
        "applicationCategory": "MedicalApplication",
        "operatingSystem": "Web Browser, Android, iOS",
        "offers": {
          "@type": "Offer",
          "price": "5.99",
          "priceCurrency": "GBP"
        },
        "creator": {
          "@type": "Organization",
          "name": "Ashley James Medical"
        },
        ...data.additionalSchema
      };
      break;
      
    case 'AboutPage':
      schemaData = {
        "@context": "https://schema.org",
        "@type": "AboutPage",
        "name": data.title,
        "description": data.description,
        "url": data.url,
        "mainEntity": {
          "@type": "Organization",
          "name": "Ashley James Medical",
          "description": "Developer of professional medical emergency tools"
        },
        ...data.additionalSchema
      };
      break;
      
    case 'ContactPage':
      schemaData = {
        "@context": "https://schema.org",
        "@type": "ContactPage",
        "name": data.title,
        "description": data.description,
        "url": data.url,
        ...data.additionalSchema
      };
      break;
      
    default: // WebPage
      schemaData = {
        "@context": "https://schema.org",
        "@type": "WebPage",
        "name": data.title,
        "description": data.description,
        "url": data.url,
        "isPartOf": {
          "@type": "WebSite",
          "name": "ResusMGR",
          "url": "https://www.resusmgr.co.uk"
        },
        "publisher": {
          "@type": "Organization",
          "name": "Ashley James Medical",
          "url": "https://www.resusmgr.co.uk"
        },
        ...data.additionalSchema
      };
  }
  
  script.textContent = JSON.stringify(schemaData);
  document.head.appendChild(script);
}