import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  MessageSquare, 
  Send, 
  Users, 
  Plus,
  X,
  Clock,
  AlertTriangle,
  MoreVertical,
  Trash2,
  Trash
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

interface ChatConversation {
  id: number;
  title: string;
  type: string;
  createdBy: string;
  relatedReportId: number | null;
  createdAt: string;
  updatedAt: string;
}

interface ChatMessage {
  id: number;
  conversationId: number;
  senderId: string;
  content: string;
  messageType: string;
  createdAt: string;
}

interface ChatSystemProps {
  className?: string;
}

export default function ChatSystem({ className }: ChatSystemProps) {
  const { user } = useAuth();
  const [selectedConversation, setSelectedConversation] = useState<number | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const [isExpanded, setIsExpanded] = useState(false);
  const [ws, setWs] = useState<WebSocket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fetch conversations
  const { data: conversations, isLoading: conversationsLoading } = useQuery<ChatConversation[]>({
    queryKey: ["/api/chat/conversations"],
    refetchInterval: 5000, // Refresh more frequently for real-time updates
    staleTime: 0, // Always fetch fresh data
  });

  // Fetch messages for selected conversation
  const { data: messages, isLoading: messagesLoading } = useQuery<ChatMessage[]>({
    queryKey: [`/api/chat/conversations/${selectedConversation}/messages`],
    enabled: !!selectedConversation,
    refetchInterval: 2000, // Refresh every 2 seconds for real-time messaging
    staleTime: 0, // Always fetch fresh data
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async ({ conversationId, content }: { conversationId: number; content: string }) => {
      return await apiRequest("POST", `/api/chat/conversations/${conversationId}/messages`, {
        content: content
      });
    },
    onSuccess: (response) => {
      setNewMessage("");
      // Invalidate the correct query key to refresh messages
      queryClient.invalidateQueries({ queryKey: [`/api/chat/conversations/${selectedConversation}/messages`] });
      queryClient.invalidateQueries({ queryKey: [`/api/chat/conversations/${selectedConversation}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/chat/conversations"] });
    },
    onError: (error) => {
      console.error("Failed to send message:", error);
    }
  });

  // Mark messages as read
  const markAsReadMutation = useMutation({
    mutationFn: async (conversationId: number) => {
      return await apiRequest("PATCH", `/api/chat/conversations/${conversationId}/read`);
    },
  });

  // Delete individual message
  const deleteMessageMutation = useMutation({
    mutationFn: async (messageId: number) => {
      return await apiRequest("DELETE", `/api/chat/messages/${messageId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/conversations", selectedConversation, "messages"] });
    },
  });

  // Clear all messages in conversation
  const clearConversationMutation = useMutation({
    mutationFn: async (conversationId: number) => {
      return await apiRequest("DELETE", `/api/chat/conversations/${conversationId}/messages`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/conversations", selectedConversation, "messages"] });
    },
  });

  // Delete entire conversation
  const deleteConversationMutation = useMutation({
    mutationFn: async (conversationId: number) => {
      return await apiRequest("DELETE", `/api/chat/conversations/${conversationId}`);
    },
    onSuccess: () => {
      setSelectedConversation(null);
      queryClient.invalidateQueries({ queryKey: ["/api/chat/conversations"] });
    },
  });

  // WebSocket connection
  useEffect(() => {
    if (!user) return;

    console.log("🔌 Establishing WebSocket connection for user:", user.id);
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    console.log("🌐 WebSocket URL:", wsUrl);
    
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      console.log("✅ WebSocket connected, authenticating...");
      socket.send(JSON.stringify({
        type: 'authenticate',
        userId: user.id
      }));
    };

    socket.onmessage = (event) => {
      console.log("📩 WebSocket message received:", event.data);
      try {
        const data = JSON.parse(event.data);
        console.log("📧 Parsed message data:", data);
        
        if (data.type === 'authenticated') {
          console.log("🔐 WebSocket authentication successful");
        } else if (data.type === 'new_message') {
          console.log("💬 New message received for conversation:", data.conversationId);
          console.log("📝 Message content:", data.message?.content?.substring(0, 50));
          
          // Refresh messages if we're viewing this conversation
          if (data.conversationId === selectedConversation) {
            console.log("🔄 Refreshing messages for active conversation");
            queryClient.invalidateQueries({ 
              queryKey: ["/api/chat/conversations", selectedConversation, "messages"] 
            });
          }
          // Also refresh the conversations list to update timestamps
          queryClient.invalidateQueries({ queryKey: ["/api/chat/conversations"] });
        }
      } catch (error) {
        console.error("❌ Error parsing WebSocket message:", error);
      }
    };

    socket.onerror = (error) => {
      console.error("💥 WebSocket error:", error);
    };

    socket.onclose = (event) => {
      console.log("🔒 WebSocket connection closed:", event.code, event.reason);
    };

    setWs(socket);

    return () => {
      console.log("🧹 Cleaning up WebSocket connection");
      socket.close();
    };
  }, [user, selectedConversation]);

  // Auto scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Mark conversation as read when selected
  useEffect(() => {
    if (selectedConversation) {
      markAsReadMutation.mutate(selectedConversation);
    }
  }, [selectedConversation]);

  const handleSendMessage = () => {
    if (!selectedConversation || !newMessage.trim()) return;
    
    sendMessageMutation.mutate({
      conversationId: selectedConversation,
      content: newMessage.trim()
    });
  };

  const formatTime = (date: string | Date) => {
    return new Date(date).toLocaleTimeString('en-GB', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDate = (date: string | Date) => {
    const msgDate = new Date(date);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (msgDate.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (msgDate.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    } else {
      return msgDate.toLocaleDateString('en-GB');
    }
  };

  if (!user) return null;

  return (
    <div className={`fixed bottom-4 right-4 z-50 ${className}`}>
      {!isExpanded ? (
        // Minimized chat button
        <Button
          onClick={() => setIsExpanded(true)}
          className="rounded-full h-14 w-14 shadow-lg bg-blue-600 hover:bg-blue-700"
        >
          <MessageSquare className="h-6 w-6 text-white" />
          {conversations && conversations.length > 0 && (
            <Badge className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full h-6 w-6 p-0 flex items-center justify-center text-xs">
              {conversations.length}
            </Badge>
          )}
        </Button>
      ) : (
        // Expanded chat interface
        <Card className="w-96 h-[500px] shadow-xl flex flex-col">
          <CardHeader className="pb-3 flex-shrink-0">
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                ResusMGR Chat
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsExpanded(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </CardTitle>
          </CardHeader>

          <CardContent className="p-0 flex-1 flex flex-col min-h-0">
            {!selectedConversation ? (
              // Conversations list
              <div className="flex-1 p-4">
                <div className="space-y-2">
                  {conversationsLoading ? (
                    <div className="text-center py-8 text-gray-500">Loading conversations...</div>
                  ) : conversations && conversations.length > 0 ? (
                    conversations.map((conv) => (
                      <div
                        key={conv.id}
                        onClick={() => setSelectedConversation(conv.id)}
                        className="p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Users className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">
                              {conv.title || `Conversation ${conv.id}`}
                            </span>
                            {conv.relatedReportId && (
                              <Badge variant="destructive" className="text-xs">
                                <AlertTriangle className="h-3 w-3 mr-1" />
                                Report
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="text-xs text-gray-500 mt-1 flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {formatDate(conv.updatedAt)}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <MessageSquare className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                      <p>No conversations yet.</p>
                      <p className="text-sm mt-1">Messages from admin will appear here.</p>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              // Selected conversation view
              <div className="flex-1 flex flex-col min-h-0">
                {/* Conversation header */}
                <div className="flex items-center gap-2 p-4 border-b flex-shrink-0">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedConversation(null)}
                  >
                    ←
                  </Button>
                  <div className="flex-1">
                    <h3 className="font-medium">
                      {conversations?.find(c => c.id === selectedConversation)?.title || 
                       `Conversation ${selectedConversation}`}
                    </h3>
                    {conversations?.find(c => c.id === selectedConversation)?.relatedReportId && (
                      <Badge variant="destructive" className="text-xs mt-1">
                        <AlertTriangle className="h-3 w-3 mr-1" />
                        Security Report Discussion
                      </Badge>
                    )}
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem
                        onClick={() => {
                          if (selectedConversation && confirm("Clear all messages in this conversation?")) {
                            clearConversationMutation.mutate(selectedConversation);
                          }
                        }}
                        className="text-orange-600"
                      >
                        <Trash className="h-4 w-4 mr-2" />
                        Clear All Messages
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        onClick={() => {
                          if (selectedConversation && confirm("Delete this entire conversation? This action cannot be undone.")) {
                            deleteConversationMutation.mutate(selectedConversation);
                          }
                        }}
                        className="text-red-600"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete Conversation
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                {/* Messages */}
                <ScrollArea className="flex-1 min-h-0 p-4">
                  {messagesLoading ? (
                    <div className="text-center py-8 text-gray-500">Loading messages...</div>
                  ) : messages && messages.length > 0 ? (
                    <div className="space-y-4">
                      {messages.slice().reverse().map((message) => (
                        <div
                          key={message.id}
                          className={`flex group ${message.senderId === user.id ? 'justify-end' : 'justify-start'}`}
                        >
                          <div className="flex items-start gap-2 max-w-[80%]">
                            {message.senderId === user.id && (
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 p-0"
                                  >
                                    <MoreVertical className="h-3 w-3" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem
                                    onClick={() => {
                                      if (confirm("Delete this message?")) {
                                        deleteMessageMutation.mutate(message.id);
                                      }
                                    }}
                                    className="text-red-600"
                                  >
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete Message
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            )}
                            <div
                              className={`p-3 rounded-lg ${
                                message.senderId === user.id
                                  ? 'bg-blue-600 text-white'
                                  : 'bg-gray-100 text-gray-900'
                              }`}
                            >
                              <p className="text-sm">{message.content}</p>
                              <p className={`text-xs mt-1 ${
                                message.senderId === user.id ? 'text-blue-200' : 'text-gray-500'
                              }`}>
                                {formatTime(message.createdAt)}
                              </p>
                            </div>
                            {message.senderId !== user.id && user?.role === 'Administrator' && (
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 p-0"
                                  >
                                    <MoreVertical className="h-3 w-3" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="start">
                                  <DropdownMenuItem
                                    onClick={() => {
                                      if (confirm("Delete this message?")) {
                                        deleteMessageMutation.mutate(message.id);
                                      }
                                    }}
                                    className="text-red-600"
                                  >
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete Message
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            )}
                          </div>
                        </div>
                      ))}
                      <div ref={messagesEndRef} />
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <MessageSquare className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                      <p>No messages yet.</p>
                      <p className="text-sm mt-1">Start the conversation!</p>
                    </div>
                  )}
                </ScrollArea>

                {/* Message input */}
                <div className="p-4 border-t flex-shrink-0">
                  <div className="flex gap-2">
                    <Input
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Type your message..."
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      disabled={sendMessageMutation.isPending}
                    />
                    <Button
                      onClick={handleSendMessage}
                      disabled={!newMessage.trim() || sendMessageMutation.isPending}
                      size="sm"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}