import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Clock, Users, Heart, Activity } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface TwoMinuteSwapDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (action: 'compressions' | 'rhythm_check' | 'both') => void;
  protocolLevel: "BLS" | "ILS" | "ALS";
  isAudioEnabled: boolean;
}

export default function TwoMinuteSwapDialog({
  isOpen,
  onClose,
  onConfirm,
  protocolLevel,
  isAudioEnabled
}: TwoMinuteSwapDialogProps) {
  const { toast } = useToast();
  const [compressionsSwapped, setCompressionsSwapped] = useState(false);
  const [rhythmChecked, setRhythmChecked] = useState(false);
  const [isConfirming, setIsConfirming] = useState(false);

  const isAdvancedProtocol = protocolLevel === "ILS" || protocolLevel === "ALS";

  // Play audio prompt when dialog opens
  useEffect(() => {
    if (isOpen && isAudioEnabled) {
      const message = isAdvancedProtocol 
        ? "Perform 2-minute rhythm check and swap compressions now"
        : "Swap compressions now";
      
      const utterance = new SpeechSynthesisUtterance(message);
      utterance.rate = 1.0;
      utterance.volume = 1.0;
      speechSynthesis.speak(utterance);
    }
  }, [isOpen, isAudioEnabled, isAdvancedProtocol]);

  const handleCompressionSwap = () => {
    setCompressionsSwapped(true);
    
    if (isAudioEnabled) {
      const utterance = new SpeechSynthesisUtterance("Compressions swapped");
      utterance.rate = 1.0;
      utterance.volume = 1.0;
      speechSynthesis.speak(utterance);
    }

    toast({
      title: "Compressions Swapped",
      description: "Team member rotation completed",
      duration: 1500,
    });

    // For BLS, automatically complete after compression swap
    if (!isAdvancedProtocol) {
      setTimeout(() => {
        onConfirm('compressions');
        setCompressionsSwapped(false);
        setRhythmChecked(false);
        setIsConfirming(false);
        onClose();
      }, 500);
    }
  };

  const handleRhythmCheck = () => {
    setRhythmChecked(true);
    
    if (isAudioEnabled) {
      const utterance = new SpeechSynthesisUtterance("Rhythm check completed");
      utterance.rate = 1.0;
      utterance.volume = 1.0;
      speechSynthesis.speak(utterance);
    }

    toast({
      title: "Rhythm Check",
      description: "2-minute analysis completed",
      duration: 1500,
    });
  };

  const handleComplete = () => {
    setIsConfirming(true);

    // Play audio confirmation
    if (isAudioEnabled) {
      const message = isAdvancedProtocol 
        ? "2-minute cycle completed - compressions swapped and rhythm checked"
        : "2-minute compression swap completed";
      
      const utterance = new SpeechSynthesisUtterance(message);
      utterance.rate = 1.0;
      utterance.volume = 1.0;
      utterance.pitch = 1.1;
      speechSynthesis.speak(utterance);
    }

    // Show confirmation toast
    toast({
      title: "2-Minute Swap Confirmed",
      description: isAdvancedProtocol 
        ? "Compression swap and rhythm check completed"
        : "Compression swap completed",
      duration: 2000,
    });

    onConfirm('both');
    resetDialog();
  };

  const resetDialog = () => {
    setCompressionsSwapped(false);
    setRhythmChecked(false);
    setIsConfirming(false);
    onClose();
  };

  const handleClose = () => {
    resetDialog();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Clock className="w-5 h-5 mr-2 text-blue-600" />
            2-Minute Swap Required
          </DialogTitle>
          <DialogDescription>
            Time to perform the 2-minute protocol actions.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="flex items-center space-x-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <Users className="w-5 h-5 text-blue-600" />
            <div>
              <p className="font-medium text-blue-800 dark:text-blue-200">
                Compression Swap
              </p>
              <p className="text-sm text-blue-600 dark:text-blue-300">
                Swap the person performing compressions
              </p>
            </div>
          </div>

          {isAdvancedProtocol && (
            <div className="flex items-center space-x-3 p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
              <Activity className="w-5 h-5 text-orange-600" />
              <div>
                <p className="font-medium text-orange-800 dark:text-orange-200">
                  Rhythm Check
                </p>
                <p className="text-sm text-orange-600 dark:text-orange-300">
                  Assess cardiac rhythm and adjust treatment
                </p>
              </div>
            </div>
          )}

          <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <p className="text-sm text-gray-600 dark:text-gray-300">
              Please confirm when you have completed the required actions.
            </p>
          </div>
        </div>

        <DialogFooter className="flex-col gap-2">
          {/* For BLS: Single button */}
          {!isAdvancedProtocol && (
            <div className="flex gap-2 w-full">
              <Button variant="outline" onClick={handleClose} disabled={isConfirming} className="flex-1">
                Not Yet
              </Button>
              <Button 
                onClick={handleCompressionSwap} 
                disabled={isConfirming || compressionsSwapped}
                className="bg-blue-600 hover:bg-blue-700 flex-1"
              >
                {compressionsSwapped ? (
                  <>
                    <Heart className="w-4 h-4 mr-2" />
                    Completed
                  </>
                ) : (
                  <>
                    <Users className="w-4 h-4 mr-2" />
                    Swap Compressions
                  </>
                )}
              </Button>
            </div>
          )}

          {/* For ILS/ALS: Separate action buttons */}
          {isAdvancedProtocol && (
            <>
              <div className="flex gap-2 w-full">
                <Button 
                  onClick={handleCompressionSwap} 
                  disabled={isConfirming || compressionsSwapped}
                  className={`flex-1 ${compressionsSwapped ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'}`}
                >
                  {compressionsSwapped ? (
                    <>
                      <Heart className="w-4 h-4 mr-2" />
                      Swapped
                    </>
                  ) : (
                    <>
                      <Users className="w-4 h-4 mr-2" />
                      Swap Compressions
                    </>
                  )}
                </Button>
                <Button 
                  onClick={handleRhythmCheck} 
                  disabled={isConfirming || rhythmChecked}
                  className={`flex-1 ${rhythmChecked ? 'bg-green-600 hover:bg-green-700' : 'bg-orange-600 hover:bg-orange-700'}`}
                >
                  {rhythmChecked ? (
                    <>
                      <Heart className="w-4 h-4 mr-2" />
                      Checked
                    </>
                  ) : (
                    <>
                      <Activity className="w-4 h-4 mr-2" />
                      Rhythm Check
                    </>
                  )}
                </Button>
              </div>
              
              <div className="flex gap-2 w-full">
                <Button variant="outline" onClick={handleClose} disabled={isConfirming} className="flex-1">
                  Not Yet
                </Button>
                <Button 
                  onClick={handleComplete} 
                  disabled={isConfirming || !compressionsSwapped || !rhythmChecked}
                  className="bg-green-600 hover:bg-green-700 flex-1"
                >
                  {isConfirming ? (
                    <>
                      <Heart className="w-4 h-4 mr-2 animate-pulse" />
                      Completing...
                    </>
                  ) : (
                    "Complete Cycle"
                  )}
                </Button>
              </div>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}