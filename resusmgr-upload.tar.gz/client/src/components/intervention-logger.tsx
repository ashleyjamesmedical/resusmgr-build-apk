import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { 
  FileText, 
  Stethoscope, 
  Syringe, 
  Pill, 
  Zap, 
  Activity,
  Clock,
  Plus,
  Save,
  Wind
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { playAudioAlert } from "@/lib/audio";

interface InterventionLoggerProps {
  sessionId: number;
  onInterventionLogged?: (intervention: any) => void;
}

const INTERVENTION_TYPES = [
  { 
    value: "airway", 
    label: "Airway Management", 
    icon: <Stethoscope className="w-4 h-4" />,
    color: "green",
    examples: ["Intubation", "LMA insertion", "Oropharyngeal airway", "Nasopharyngeal airway"]
  },
  { 
    value: "iv_io", 
    label: "Vascular Access", 
    icon: <Syringe className="w-4 h-4" />,
    color: "blue",
    examples: ["IV cannulation", "IO insertion", "Central line", "Arterial line"]
  },
  { 
    value: "medication", 
    label: "Medication", 
    icon: <Pill className="w-4 h-4" />,
    color: "purple",
    examples: ["Adrenaline 1mg", "Amiodarone 300mg", "Atropine 0.5mg", "Calcium Chloride 10ml"]
  },
  { 
    value: "shock", 
    label: "Defibrillation", 
    icon: <Zap className="w-4 h-4" />,
    color: "red",
    examples: ["200J biphasic", "150J biphasic", "360J monophasic"]
  },
  { 
    value: "rhythm_check", 
    label: "Rhythm Check", 
    icon: <Activity className="w-4 h-4" />,
    color: "orange",
    examples: ["VF/pVT", "Asystole", "PEA", "ROSC achieved"]
  },
  { 
    value: "other", 
    label: "Other Intervention", 
    icon: <FileText className="w-4 h-4" />,
    color: "gray",
    examples: ["Chest decompression", "Blood sampling", "Temperature management"]
  },
];

export default function InterventionLogger({ sessionId, onInterventionLogged }: InterventionLoggerProps) {
  const [selectedType, setSelectedType] = useState<string>("");
  const [description, setDescription] = useState("");
  const [details, setDetails] = useState("");
  const [isCustom, setIsCustom] = useState(false);
  
  // Airway dialog states
  const [showAirwayDialog, setShowAirwayDialog] = useState(false);
  const [selectedAirwayType, setSelectedAirwayType] = useState("");
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  
  // Oxygen dialog states
  const [showOxygenConfirmDialog, setShowOxygenConfirmDialog] = useState(false);
  const [showOxygenSuccessDialog, setShowOxygenSuccessDialog] = useState(false);
  
  // Shock dialog states
  const [showShockConfirmDialog, setShowShockConfirmDialog] = useState(false);
  const [showShockSuccessDialog, setShowShockSuccessDialog] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Log intervention mutation
  const logInterventionMutation = useMutation({
    mutationFn: async (interventionData: any) => {
      const response = await apiRequest("POST", "/api/interventions", {
        sessionId,
        type: interventionData.type,
        description: interventionData.description,
        details: interventionData.details ? JSON.stringify(interventionData.details) : null,
      });
      return response.json();
    },
    onSuccess: (data) => {
      // Clear form
      setSelectedType("");
      setDescription("");
      setDetails("");
      setIsCustom(false);
      
      // Play audio confirmation
      playAudioAlert("intervention");
      
      // Show success notification
      toast({
        title: "Intervention Logged",
        description: `${data.description} has been recorded with timestamp`,
        duration: 3000,
      });

      // Invalidate queries to refresh intervention list
      queryClient.invalidateQueries({ queryKey: ["/api/sessions", sessionId, "interventions"] });
      
      // Callback to parent component
      if (onInterventionLogged) {
        onInterventionLogged(data);
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to log intervention. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleQuickIntervention = (type: string, description: string, details?: any) => {
    logInterventionMutation.mutate({
      type,
      description,
      details,
    });
  };

  // Handle airway selection flow
  const handleAirwayClick = () => {
    setShowAirwayDialog(true);
  };

  const handleAirwayTypeSelect = (airwayType: string) => {
    setSelectedAirwayType(airwayType);
    setShowAirwayDialog(false);
    setShowConfirmDialog(true);
  };

  const handleConfirmAirway = () => {
    const description = `${selectedAirwayType === 'OP' ? 'Oropharyngeal' : 'Nasopharyngeal'} Airway Secured`;
    logInterventionMutation.mutate({
      type: "airway",
      description,
      details: { method: selectedAirwayType === 'OP' ? 'oropharyngeal' : 'nasopharyngeal' }
    });
    
    setShowConfirmDialog(false);
    setShowSuccessDialog(true);
    
    // Play audio confirmation
    const utterance = new SpeechSynthesisUtterance("Airway Intervention Logged");
    utterance.rate = 1.2;
    utterance.volume = 0.8;
    speechSynthesis.speak(utterance);
    
    // Auto-hide success dialog after 1 second
    setTimeout(() => {
      setShowSuccessDialog(false);
      setSelectedAirwayType("");
    }, 1000);
  };

  // Handle oxygen administration flow
  const handleOxygenClick = () => {
    setShowOxygenConfirmDialog(true);
  };

  const handleConfirmOxygen = () => {
    logInterventionMutation.mutate({
      type: "airway",
      description: "Oxygen 15ltr/min",
      details: { method: "BVM", flow_rate: "15ltr/min" }
    });
    
    setShowOxygenConfirmDialog(false);
    setShowOxygenSuccessDialog(true);
    
    // Play audio confirmation
    const utterance = new SpeechSynthesisUtterance("Oxygen Administration Logged");
    utterance.rate = 1.2;
    utterance.volume = 0.8;
    speechSynthesis.speak(utterance);
    
    // Auto-hide success dialog after 1 second
    setTimeout(() => {
      setShowOxygenSuccessDialog(false);
    }, 1000);
  };

  // Handle shock delivery flow
  const handleShockClick = () => {
    setShowShockConfirmDialog(true);
  };

  const handleConfirmShock = () => {
    logInterventionMutation.mutate({
      type: "shock",
      description: "Shock Delivered 200J",
      details: { energy: "200J", type: "biphasic" }
    });
    
    setShowShockConfirmDialog(false);
    setShowShockSuccessDialog(true);
    
    // Play audio confirmation
    const utterance = new SpeechSynthesisUtterance("Shock Delivery Logged");
    utterance.rate = 1.2;
    utterance.volume = 0.8;
    speechSynthesis.speak(utterance);
    
    // Auto-hide success dialog after 1 second
    setTimeout(() => {
      setShowShockSuccessDialog(false);
    }, 1000);
  };

  const handleCustomIntervention = () => {
    if (!selectedType || !description.trim()) {
      toast({
        title: "Missing Information",
        description: "Please select intervention type and enter description",
        variant: "destructive",
      });
      return;
    }

    const interventionDetails = details.trim() ? { notes: details } : null;

    logInterventionMutation.mutate({
      type: selectedType,
      description: description.trim(),
      details: interventionDetails,
    });
  };

  const getTypeConfig = (type: string) => {
    return INTERVENTION_TYPES.find(t => t.value === type);
  };

  const getColorClasses = (color: string) => {
    const colorMap: Record<string, string> = {
      green: "btn-medical-green",
      blue: "btn-medical-blue", 
      purple: "btn-medical-purple",
      red: "btn-medical-red",
      orange: "bg-gradient-to-r from-orange-600 to-orange-700 text-white hover:from-orange-700 hover:to-orange-800",
      gray: "bg-gradient-to-r from-gray-600 to-gray-700 text-white hover:from-gray-700 hover:to-gray-800",
    };
    return colorMap[color] || "btn-medical-blue";
  };

  return (
    <>
      <Card className="medical-card">
      <CardHeader>
        <CardTitle className="flex items-center text-lg">
          <FileText className="w-5 h-5 mr-2" />
          Intervention Logger
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Quick Intervention Buttons */}
        <div>
          <div className="grid grid-cols-2 gap-3">
            <Button
              onClick={handleAirwayClick}
              disabled={logInterventionMutation.isPending}
              className="btn-medical-green p-4 h-auto flex-col space-y-2"
            >
              <Stethoscope className="w-6 h-6" />
              <span className="text-sm font-semibold">Airway Secured</span>
            </Button>
            
            <Button
              onClick={handleOxygenClick}
              disabled={logInterventionMutation.isPending}
              className="btn-medical-purple p-4 h-auto flex-col space-y-2"
            >
              <Wind className="w-6 h-6" />
              <span className="text-sm font-semibold">Oxygen 15ltr/min</span>
            </Button>
            
            <Button
              onClick={handleShockClick}
              disabled={logInterventionMutation.isPending}
              className="btn-medical-red p-4 h-auto flex-col space-y-2"
            >
              <Zap className="w-6 h-6" />
              <span className="text-sm font-semibold">Shock Delivered</span>
            </Button>
          </div>
        </div>

        <Separator />

        {/* Custom Intervention Form */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300">
              Custom Intervention
            </h4>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsCustom(!isCustom)}
            >
              <Plus className="w-4 h-4 mr-2" />
              {isCustom ? "Hide" : "Add Custom"}
            </Button>
          </div>

          {isCustom && (
            <div className="space-y-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div>
                <Label htmlFor="intervention-type" className="text-sm font-semibold">
                  Intervention Type
                </Label>
                <Select value={selectedType} onValueChange={setSelectedType}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select intervention type" />
                  </SelectTrigger>
                  <SelectContent>
                    {INTERVENTION_TYPES.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        <div className="flex items-center">
                          {type.icon}
                          <span className="ml-2">{type.label}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                {selectedType && (
                  <div className="mt-2">
                    <p className="text-xs text-gray-600 dark:text-gray-400 mb-1">Examples:</p>
                    <div className="flex flex-wrap gap-1">
                      {getTypeConfig(selectedType)?.examples.map((example, index) => (
                        <Badge 
                          key={index} 
                          variant="outline" 
                          className="text-xs cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700"
                          onClick={() => setDescription(example)}
                        >
                          {example}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div>
                <Label htmlFor="intervention-description" className="text-sm font-semibold">
                  Description *
                </Label>
                <Input
                  id="intervention-description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Enter detailed description..."
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="intervention-details" className="text-sm font-semibold">
                  Additional Details (Optional)
                </Label>
                <Textarea
                  id="intervention-details"
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  placeholder="Enter any additional notes, dosages, complications, etc..."
                  className="mt-1"
                  rows={3}
                />
              </div>

              <Button
                onClick={handleCustomIntervention}
                disabled={logInterventionMutation.isPending || !selectedType || !description.trim()}
                className={`w-full py-3 ${selectedType ? getColorClasses(getTypeConfig(selectedType)?.color || "blue") : "btn-medical-blue"}`}
              >
                <Save className="w-4 h-4 mr-2" />
                {logInterventionMutation.isPending ? "Logging..." : "Log Intervention"}
              </Button>
            </div>
          )}
        </div>

        {/* Rhythm Check Buttons */}
        <div className="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-lg p-4">
          <h4 className="text-sm font-semibold text-orange-800 dark:text-orange-200 mb-3">
            <Activity className="w-4 h-4 inline mr-2" />
            Rhythm Assessment
          </h4>
          <div className="grid grid-cols-2 gap-2">
            <Button
              onClick={() => handleQuickIntervention("rhythm_check", "Rhythm Check - VF/pVT", { rhythm: "VF/pVT", shockable: true })}
              disabled={logInterventionMutation.isPending}
              variant="outline"
              size="sm"
              className="text-red-700 border-red-300 hover:bg-red-50"
            >
              VF/pVT
            </Button>
            <Button
              onClick={() => handleQuickIntervention("rhythm_check", "Rhythm Check - Asystole", { rhythm: "Asystole", shockable: false })}
              disabled={logInterventionMutation.isPending}
              variant="outline"
              size="sm"
              className="text-gray-700 border-gray-300 hover:bg-gray-50"
            >
              Asystole
            </Button>
            <Button
              onClick={() => handleQuickIntervention("rhythm_check", "Rhythm Check - PEA", { rhythm: "PEA", shockable: false })}
              disabled={logInterventionMutation.isPending}
              variant="outline"
              size="sm"
              className="text-yellow-700 border-yellow-300 hover:bg-yellow-50"
            >
              PEA
            </Button>
            <Button
              onClick={() => handleQuickIntervention("rhythm_check", "ROSC Achieved", { rhythm: "Organised", rosc: true })}
              disabled={logInterventionMutation.isPending}
              variant="outline"
              size="sm"
              className="text-green-700 border-green-300 hover:bg-green-50"
            >
              ROSC
            </Button>
          </div>
        </div>

        {/* Timing Reminder */}
        <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
          <div className="flex items-center text-sm text-blue-800 dark:text-blue-200">
            <Clock className="w-4 h-4 mr-2" />
            <span className="font-semibold">
              All interventions are automatically timestamped in GMT
            </span>
          </div>
          <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
            Times relative to resuscitation start are also recorded for audit purposes.
          </p>
        </div>
      </CardContent>
    </Card>

    {/* Airway Type Selection Dialog */}
    <Dialog open={showAirwayDialog} onOpenChange={setShowAirwayDialog}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Stethoscope className="w-5 h-5 mr-2" />
            Select Airway Type
          </DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4 py-4">
          <Button
            onClick={() => handleAirwayTypeSelect('OP')}
            className="btn-medical-green p-6 h-auto flex-col space-y-2"
          >
            <span className="text-lg font-bold">OP</span>
            <span className="text-sm">Oropharyngeal Airway</span>
          </Button>
          <Button
            onClick={() => handleAirwayTypeSelect('NP')}
            className="btn-medical-blue p-6 h-auto flex-col space-y-2"
          >
            <span className="text-lg font-bold">NP</span>
            <span className="text-sm">Nasopharyngeal Airway</span>
          </Button>
        </div>
      </DialogContent>
    </Dialog>

    {/* Confirmation Dialog */}
    <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Confirm Intervention</DialogTitle>
        </DialogHeader>
        <div className="py-4">
          <p className="text-center text-lg">
            Log {selectedAirwayType === 'OP' ? 'Oropharyngeal' : 'Nasopharyngeal'} Airway Secured?
          </p>
        </div>
        <DialogFooter className="grid grid-cols-2 gap-4">
          <Button 
            variant="outline" 
            onClick={() => setShowConfirmDialog(false)}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleConfirmAirway}
            className="btn-medical-green"
          >
            Confirm
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>

    {/* Success Dialog */}
    <Dialog open={showSuccessDialog} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md border-green-200 bg-green-50 dark:bg-green-900/20">
        <div className="text-center py-6">
          <div className="mx-auto w-16 h-16 bg-green-100 dark:bg-green-800 rounded-full flex items-center justify-center mb-4">
            <Stethoscope className="w-8 h-8 text-green-600 dark:text-green-400" />
          </div>
          <h3 className="text-lg font-semibold text-green-800 dark:text-green-200">
            Airway Intervention Logged
          </h3>
        </div>
      </DialogContent>
    </Dialog>

    {/* Oxygen Confirmation Dialog */}
    <Dialog open={showOxygenConfirmDialog} onOpenChange={setShowOxygenConfirmDialog}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Confirm Oxygen Administration</DialogTitle>
        </DialogHeader>
        <div className="py-4">
          <p className="text-center text-lg">
            Log Oxygen 15ltr/min via BVM?
          </p>
        </div>
        <DialogFooter className="grid grid-cols-2 gap-4">
          <Button 
            variant="outline" 
            onClick={() => setShowOxygenConfirmDialog(false)}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleConfirmOxygen}
            className="btn-medical-purple"
          >
            Confirm
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>

    {/* Oxygen Success Dialog */}
    <Dialog open={showOxygenSuccessDialog} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md border-purple-200 bg-purple-50 dark:bg-purple-900/20">
        <div className="text-center py-6">
          <div className="mx-auto w-16 h-16 bg-purple-100 dark:bg-purple-800 rounded-full flex items-center justify-center mb-4">
            <Wind className="w-8 h-8 text-purple-600 dark:text-purple-400" />
          </div>
          <h3 className="text-lg font-semibold text-purple-800 dark:text-purple-200">
            Oxygen Administration Logged
          </h3>
        </div>
      </DialogContent>
    </Dialog>

    {/* Shock Confirmation Dialog */}
    <Dialog open={showShockConfirmDialog} onOpenChange={setShowShockConfirmDialog}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Confirm Shock Delivery</DialogTitle>
        </DialogHeader>
        <div className="py-4">
          <p className="text-center text-lg">
            Log Shock Delivered?
          </p>
        </div>
        <DialogFooter className="grid grid-cols-2 gap-4">
          <Button 
            variant="outline" 
            onClick={() => setShowShockConfirmDialog(false)}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleConfirmShock}
            className="btn-medical-red"
          >
            Confirm
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>

    {/* Shock Success Dialog */}
    <Dialog open={showShockSuccessDialog} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md border-red-200 bg-red-50 dark:bg-red-900/20">
        <div className="text-center py-6">
          <div className="mx-auto w-16 h-16 bg-red-100 dark:bg-red-800 rounded-full flex items-center justify-center mb-4">
            <Zap className="w-8 h-8 text-red-600 dark:text-red-400" />
          </div>
          <h3 className="text-lg font-semibold text-red-800 dark:text-red-200">
            Shock Delivery Logged
          </h3>
        </div>
      </DialogContent>
    </Dialog>
    </>
  );
}
