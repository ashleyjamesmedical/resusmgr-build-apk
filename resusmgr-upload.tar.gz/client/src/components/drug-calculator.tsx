import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Calculator, AlertTriangle, Pill, Syringe, Info } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  calculateDrugDose, 
  calculateFluidBolus, 
  calculateDefibrillationEnergy,
  validatePatientWeight,
  getEstimatedWeight,
  RESUSCITATION_DRUGS,
  type DrugDose 
} from "@/lib/drug-calculations";

interface DrugCalculatorProps {
  sessionId?: number;
  patientType?: "Adult" | "Paediatric";
}

export default function DrugCalculator({ sessionId, patientType = "Paediatric" }: DrugCalculatorProps) {
  const [weight, setWeight] = useState<number>(0);
  const [selectedDrug, setSelectedDrug] = useState<string>("Adrenaline");
  const [ageEstimate, setAgeEstimate] = useState<number>(0);
  const [calculatedDose, setCalculatedDose] = useState<DrugDose | null>(null);
  const [fluidBolus, setFluidBolus] = useState<string>("");
  const [defibrillationEnergy, setDefibrillationEnergy] = useState<string>("");
  const [weightError, setWeightError] = useState<string>("");
  
  const { toast } = useToast();
  const isAdult = patientType === "Adult";

  // Log drug dose mutation
  const logDrugDoseMutation = useMutation({
    mutationFn: async (dose: DrugDose) => {
      if (!sessionId) throw new Error("No active session");
      
      const response = await apiRequest("POST", "/api/drug-doses", {
        sessionId,
        drugName: dose.name,
        patientWeight: weight,
        calculatedDose: dose.dose,
        calculatedVolume: dose.volume,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Dose Logged",
        description: `${calculatedDose?.name} dose has been recorded`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to log drug dose",
        variant: "destructive",
      });
    },
  });

  // Calculate doses when weight or drug changes
  useEffect(() => {
    if (weight > 0) {
      const validation = validatePatientWeight(weight, isAdult);
      
      if (!validation.isValid) {
        setWeightError(validation.message || "Invalid weight");
        setCalculatedDose(null);
        return;
      }
      
      setWeightError("");
      
      // Calculate drug dose
      const dose = calculateDrugDose(selectedDrug, weight, isAdult);
      setCalculatedDose(dose);
      
      // Calculate fluid bolus
      const fluid = calculateFluidBolus(weight, isAdult);
      setFluidBolus(fluid);
      
      // Calculate defibrillation energy
      const energy = calculateDefibrillationEnergy(weight, isAdult);
      setDefibrillationEnergy(energy);
    } else {
      setCalculatedDose(null);
      setWeightError("");
    }
  }, [weight, selectedDrug, isAdult]);

  // Update weight from age estimate
  const handleAgeEstimate = (age: number) => {
    setAgeEstimate(age);
    if (age > 0 && !isAdult) {
      const estimatedWeight = getEstimatedWeight(age);
      setWeight(estimatedWeight);
    }
  };

  const handleLogDose = () => {
    if (calculatedDose && sessionId) {
      logDrugDoseMutation.mutate(calculatedDose);
    }
  };

  return (
    <Card className="medical-card">
      <CardHeader>
        <CardTitle className="flex items-center text-lg">
          <Calculator className="w-5 h-5 mr-2" />
          {isAdult ? "Adult" : "Paediatric"} Drug Dose Calculator
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Patient Weight Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="weight" className="text-sm font-semibold">
              Patient Weight (kg) {!isAdult && "*"}
            </Label>
            <Input
              id="weight"
              type="number"
              placeholder="Enter weight"
              value={weight || ""}
              onChange={(e) => setWeight(parseFloat(e.target.value) || 0)}
              className={`mt-1 ${weightError ? 'border-red-500' : ''}`}
              min="0"
              step="0.1"
            />
            {weightError && (
              <p className="text-xs text-red-600 mt-1">{weightError}</p>
            )}
          </div>
          
          {!isAdult && (
            <div>
              <Label htmlFor="age" className="text-sm font-semibold">
                Age Estimate (years)
              </Label>
              <Input
                id="age"
                type="number"
                placeholder="Estimate from age"
                value={ageEstimate || ""}
                onChange={(e) => handleAgeEstimate(parseFloat(e.target.value) || 0)}
                className="mt-1"
                min="0"
                step="0.5"
              />
              <p className="text-xs text-gray-500 mt-1">
                Auto-calculates weight using (age × 2) + 8
              </p>
            </div>
          )}
        </div>

        {/* Drug Selection */}
        <div>
          <Label className="text-sm font-semibold">Drug Selection</Label>
          <Select value={selectedDrug} onValueChange={setSelectedDrug}>
            <SelectTrigger className="mt-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {RESUSCITATION_DRUGS.map((drug) => (
                <SelectItem key={drug.name} value={drug.name}>
                  <div className="flex items-center">
                    <Pill className="w-4 h-4 mr-2" />
                    {drug.name}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Calculated Dose Display */}
        {calculatedDose && (
          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-semibold text-blue-800 dark:text-blue-200">
                {calculatedDose.name}
              </h4>
              <Badge className="medical-gradient text-white">
                Calculated
              </Badge>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <div className="text-sm text-blue-600 dark:text-blue-400 font-semibold">Dose</div>
                <div className="text-2xl font-bold text-blue-800 dark:text-blue-200">
                  {calculatedDose.dose}
                </div>
              </div>
              <div>
                <div className="text-sm text-blue-600 dark:text-blue-400 font-semibold">Volume</div>
                <div className="text-2xl font-bold text-blue-800 dark:text-blue-200">
                  {calculatedDose.volume}
                </div>
              </div>
            </div>
            
            <div className="space-y-2 text-sm">
              <div>
                <span className="font-semibold">Concentration:</span> {calculatedDose.concentration}
              </div>
              <div>
                <span className="font-semibold">Route:</span> {calculatedDose.route}
              </div>
              {calculatedDose.notes && (
                <div className="flex items-start space-x-2 mt-3 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                  <Info className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                  <span className="text-yellow-800 dark:text-yellow-200 text-xs">
                    {calculatedDose.notes}
                  </span>
                </div>
              )}
            </div>

            {sessionId && (
              <Button
                onClick={handleLogDose}
                disabled={logDrugDoseMutation.isPending}
                className="w-full mt-4 btn-medical-blue"
              >
                <Syringe className="w-4 h-4 mr-2" />
                {logDrugDoseMutation.isPending ? "Logging..." : "Log This Dose"}
              </Button>
            )}
          </div>
        )}

        {/* Additional Calculations */}
        {weight > 0 && !weightError && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
              <h4 className="text-sm font-semibold text-green-800 dark:text-green-200 mb-2">
                Fluid Bolus
              </h4>
              <div className="text-xl font-bold text-green-700 dark:text-green-300">
                {fluidBolus}
              </div>
              <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                {isAdult ? "Standard adult bolus" : "20 ml/kg"}
              </p>
            </div>
            
            <div className="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-lg p-4">
              <h4 className="text-sm font-semibold text-orange-800 dark:text-orange-200 mb-2">
                Defibrillation
              </h4>
              <div className="text-xl font-bold text-orange-700 dark:text-orange-300">
                {defibrillationEnergy}
              </div>
              <p className="text-xs text-orange-600 dark:text-orange-400 mt-1">
                {isAdult ? "Standard energy" : "4 J/kg (max 200 J)"}
              </p>
            </div>
          </div>
        )}

        {/* Safety Reminder */}
        <Alert>
          <AlertTriangle className="w-4 h-4" />
          <AlertDescription className="text-sm">
            <strong>Always verify:</strong> Double-check calculations with a colleague. 
            Consider patient-specific factors including renal/hepatic function, allergies, 
            and concurrent medications. Follow local protocols and guidelines.
          </AlertDescription>
        </Alert>

        {/* Quick Reference */}
        {!isAdult && (
          <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
            <h4 className="text-sm font-semibold text-gray-800 dark:text-gray-200 mb-3">
              Quick Age-Weight Reference
            </h4>
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className="text-center p-2 bg-white dark:bg-gray-700 rounded">
                <div className="font-semibold">1 year</div>
                <div className="text-gray-600 dark:text-gray-400">10 kg</div>
              </div>
              <div className="text-center p-2 bg-white dark:bg-gray-700 rounded">
                <div className="font-semibold">5 years</div>
                <div className="text-gray-600 dark:text-gray-400">18 kg</div>
              </div>
              <div className="text-center p-2 bg-white dark:bg-gray-700 rounded">
                <div className="font-semibold">10 years</div>
                <div className="text-gray-600 dark:text-gray-400">28 kg</div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
