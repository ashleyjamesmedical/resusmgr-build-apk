import { useState, useEffect, useRef } from "react";
import { Play, X, Heart, Users, Clock, FileText, Award, Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function IntroVideo() {
  const [showVideo, setShowVideo] = useState(false);
  const [currentScene, setCurrentScene] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const scenes = [
    {
      id: 0,
      title: "ResusMGR",
      subtitle: "Advanced Resuscitation Management",
      duration: 3000,
      icon: Heart,
      content: "Transforming emergency resuscitation through precision technology"
    },
    {
      id: 1,
      title: "Critical Time Savings",
      subtitle: "Every second counts in resuscitation",
      duration: 4000,
      icon: Clock,
      content: "Eliminate time lost searching protocols - instant access to accurate guidance"
    },
    {
      id: 2,
      title: "Enhanced Accuracy",
      subtitle: "Precision-driven resuscitation protocols",
      duration: 4000,
      icon: Award,
      content: "Automated drug calculations and timing reduce human error during critical care"
    },
    {
      id: 3,
      title: "Team Focus",
      subtitle: "Let technology handle the calculations",
      duration: 5000,
      icon: Users,
      content: "Medical teams focus on patient care while ResusMGR manages protocols and timings"
    },
    {
      id: 4,
      title: "Challenging Situations",
      subtitle: "Reliable guidance when it matters most",
      duration: 4000,
      icon: FileText,
      content: "Consistent performance in high-pressure emergency environments"
    },
    {
      id: 5,
      title: "Quality Assurance",
      subtitle: "Evidence-based resuscitation excellence",
      duration: 4000,
      icon: Award,
      content: "UK Resuscitation Council compliant protocols ensure optimal patient outcomes"
    },
    {
      id: 6,
      title: "Save Lives",
      subtitle: "Better resuscitation through better technology",
      duration: 3000,
      icon: Heart,
      content: "Professional-grade tools for life-saving emergency care"
    }
  ];

  // Audio functions
  const initializeAudio = () => {
    if (!audioRef.current) {
      audioRef.current = new Audio('/background-music.mp3');
      audioRef.current.loop = true;
      audioRef.current.volume = isMuted ? 0 : 0.15;
      audioRef.current.preload = 'auto';
      
      // Add event listeners for debugging
      audioRef.current.addEventListener('canplaythrough', () => {
        console.log('Audio can play through');
      });
      
      audioRef.current.addEventListener('error', (e) => {
        console.log('Audio error:', e);
      });
    }
  };

  const stopBackgroundMusic = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0.15 : 0;
    }
  };

  useEffect(() => {
    initializeAudio();
  }, []);

  useEffect(() => {
    if (!isPlaying) {
      stopBackgroundMusic();
      return;
    }

    const timer = setTimeout(() => {
      if (currentScene < scenes.length - 1) {
        setCurrentScene(currentScene + 1);
      } else {
        setIsPlaying(false);
        setCurrentScene(0);
        stopBackgroundMusic();
      }
    }, scenes[currentScene].duration);

    return () => {
      clearTimeout(timer);
    };
  }, [currentScene, isPlaying, scenes]);

  const startVideo = async () => {
    setShowVideo(true);
    setIsPlaying(true);
    setCurrentScene(0);
    
    // Play audio on user interaction to bypass browser restrictions
    try {
      if (!audioRef.current) {
        audioRef.current = new Audio('/background-music.mp3');
        audioRef.current.loop = true;
        audioRef.current.volume = isMuted ? 0 : 0.15;
      }
      
      if (!isMuted) {
        console.log('Attempting to play audio...');
        const playPromise = audioRef.current.play();
        if (playPromise !== undefined) {
          await playPromise;
          console.log('Audio playing successfully');
        }
      }
    } catch (error) {
      console.log('Audio playback failed:', error);
    }
  };

  const closeVideo = () => {
    setShowVideo(false);
    setIsPlaying(false);
    setCurrentScene(0);
  };

  const currentSceneData = scenes[currentScene];
  const Icon = currentSceneData.icon;

  if (!showVideo) {
    return (
      <div className="flex flex-col items-center space-y-4 my-8">
        <div className="relative w-full max-w-2xl aspect-video bg-gradient-to-br from-blue-900 via-purple-900 to-red-900 rounded-xl overflow-hidden shadow-2xl">
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
            <div className="text-center text-white space-y-4">
              <div className="w-20 h-20 mx-auto bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm animate-pulse">
                <Play className="w-8 h-8 ml-1" />
              </div>
              <div>
                <h3 className="text-2xl font-bold mb-2">Watch the Introduction</h3>
                <p className="text-blue-200">Discover how ResusMGR revolutionizes emergency care</p>
              </div>
            </div>
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          
          {/* Animated background elements */}
          <div className="absolute inset-0">
            <div className="absolute top-4 left-4 w-2 h-2 bg-white/30 rounded-full animate-ping"></div>
            <div className="absolute top-12 right-8 w-1 h-1 bg-blue-300/50 rounded-full animate-pulse"></div>
            <div className="absolute bottom-8 left-12 w-3 h-3 bg-red-400/40 rounded-full animate-bounce"></div>
            <div className="absolute bottom-4 right-4 w-2 h-2 bg-green-300/50 rounded-full animate-ping"></div>
          </div>
        </div>
        
        <Button
          onClick={startVideo}
          className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-200 flex items-center gap-2"
        >
          <Play className="w-5 h-5" />
          Watch Introduction Video
        </Button>
      </div>
    );
  }

  return (
    <div className="my-8">
      <div className="relative w-full max-w-4xl mx-auto aspect-video rounded-xl overflow-hidden shadow-2xl bg-gradient-to-br from-blue-900 via-purple-900 to-red-900">
        
        {/* Animated Video Content */}
        <div className="absolute inset-0 flex items-center justify-center text-white">
          <div className="text-center space-y-6 px-8 animate-fade-in">
            
            {/* Animated Icon */}
            <div className="mx-auto w-24 h-24 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm animate-scale-in">
              <Icon className="w-12 h-12" />
            </div>

            {/* Main Title */}
            <div className="space-y-3 animate-slide-up">
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
                {currentSceneData.title}
              </h1>
              <p className="text-xl md:text-2xl text-blue-200 font-medium">
                {currentSceneData.subtitle}
              </p>
              <p className="text-lg text-white/80 max-w-2xl mx-auto leading-relaxed">
                {currentSceneData.content}
              </p>
            </div>

            {/* Feature highlights for specific scenes */}
            {currentScene === 3 && (
              <div className="grid grid-cols-2 gap-4 mt-8 animate-fade-in-delayed">
                <div className="text-left space-y-2">
                  <div className="text-green-300">✓ Instant Drug Dose Calculations</div>
                  <div className="text-green-300">✓ Automatic Timing Management</div>
                </div>
                <div className="text-left space-y-2">
                  <div className="text-green-300">✓ Error-Free Protocol Guidance</div>
                  <div className="text-green-300">✓ Focus on Patient Care</div>
                </div>
              </div>
            )}

            {/* Call to action for final scene */}
            {currentScene === 6 && (
              <div className="space-y-4 animate-bounce-in">
                <div className="text-yellow-300 font-semibold text-lg">£5.99/month for full access</div>
                <p className="text-blue-200">Experience the future of emergency medical care</p>
              </div>
            )}
          </div>
        </div>

        {/* Progress indicator */}
        <div className="absolute bottom-4 left-4 right-4">
          <div className="flex space-x-2 mb-4">
            {scenes.map((_, index) => (
              <div
                key={index}
                className={`h-1 rounded-full transition-all duration-300 ${
                  index === currentScene 
                    ? 'bg-white flex-1' 
                    : index < currentScene 
                      ? 'bg-white/60 w-4' 
                      : 'bg-white/20 w-4'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Controls */}
        <div className="absolute top-4 right-4 flex space-x-2">
          <Button
            onClick={() => setIsPlaying(!isPlaying)}
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/20"
          >
            {isPlaying ? "Pause" : "Play"}
          </Button>
          <Button
            onClick={toggleMute}
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/20"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </Button>
          <Button
            onClick={closeVideo}
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/20"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Video Description */}
      <Card className="mt-6 p-6 bg-white/10 backdrop-blur-sm border-white/20">
        <h3 className="text-xl font-bold text-white mb-3">Resuscitation Excellence Through Technology</h3>
        <p className="text-blue-100 leading-relaxed mb-4">
          ResusMGR eliminates critical delays and calculation errors during resuscitation by providing instant, accurate protocol guidance. 
          Medical teams can focus entirely on delivering high-quality patient care while our technology handles the complex calculations, 
          timing, and documentation required in challenging emergency situations.
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div className="text-center p-3 bg-blue-600/20 rounded-lg">
            <Clock className="w-6 h-6 mx-auto mb-2 text-blue-400" />
            <div className="text-white font-semibold">Time Critical</div>
            <div className="text-blue-200">Speed & Accuracy</div>
          </div>
          <div className="text-center p-3 bg-green-600/20 rounded-lg">
            <Users className="w-6 h-6 mx-auto mb-2 text-green-400" />
            <div className="text-white font-semibold">Team Focus</div>
            <div className="text-blue-200">Patient First</div>
          </div>
          <div className="text-center p-3 bg-purple-600/20 rounded-lg">
            <Heart className="w-6 h-6 mx-auto mb-2 text-purple-400" />
            <div className="text-white font-semibold">Error Prevention</div>
            <div className="text-blue-200">Safe Resuscitation</div>
          </div>
          <div className="text-center p-3 bg-yellow-600/20 rounded-lg">
            <Award className="w-6 h-6 mx-auto mb-2 text-yellow-400" />
            <div className="text-white font-semibold">Evidence Based</div>
            <div className="text-blue-200">UK Standards</div>
          </div>
        </div>
      </Card>

      {/* Custom animations */}
      <style dangerouslySetInnerHTML={{
        __html: `
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes fade-in-delayed {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes slide-up {
          from { transform: translateY(20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        @keyframes scale-in {
          from { transform: scale(0.8); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
        @keyframes bounce-in {
          from { transform: scale(0.9); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
        .animate-fade-in {
          animation: fade-in 0.8s ease-out;
        }
        .animate-fade-in-delayed {
          animation: fade-in-delayed 1.2s ease-out 0.5s both;
        }
        .animate-slide-up {
          animation: slide-up 1s ease-out 0.3s both;
        }
        .animate-scale-in {
          animation: scale-in 0.6s ease-out;
        }
        .animate-bounce-in {
          animation: bounce-in 0.8s ease-out 0.5s both;
        }
        `
      }} />
    </div>
  );
}