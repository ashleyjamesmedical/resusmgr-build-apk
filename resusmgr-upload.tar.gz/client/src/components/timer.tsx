import { Card, CardContent } from "@/components/ui/card";
import { Clock, Play, Pause, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";

interface TimerProps {
  elapsedTime: number;
  isRunning?: boolean;
  onStart?: () => void;
  onPause?: () => void;
  onReset?: () => void;
  showControls?: boolean;
}

export default function Timer({ 
  elapsedTime, 
  isRunning = false, 
  onStart, 
  onPause, 
  onReset,
  showControls = false 
}: TimerProps) {
  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    
    if (hours > 0) {
      return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`;
    }
    
    return `${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`;
  };

  const getTimeStatus = (seconds: number) => {
    if (seconds < 300) return "text-green-600"; // < 5 minutes
    if (seconds < 600) return "text-yellow-600"; // < 10 minutes
    if (seconds < 1200) return "text-orange-600"; // < 20 minutes
    return "text-red-600"; // > 20 minutes
  };

  const getBackgroundGradient = (seconds: number) => {
    if (seconds < 300) return "from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20";
    if (seconds < 600) return "from-yellow-50 to-yellow-100 dark:from-yellow-900/20 dark:to-yellow-800/20";
    if (seconds < 1200) return "from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20";
    return "from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/20";
  };

  return (
    <div className="text-center">
      <div className={`bg-gradient-to-br ${getBackgroundGradient(elapsedTime)} rounded-2xl p-6 md:p-8 mb-4`}>
        <div className="flex items-center justify-center mb-4">
          <Clock className={`w-6 h-6 md:w-6 md:h-6 mr-2 ${getTimeStatus(elapsedTime)}`} />
          <span className="text-base md:text-sm font-semibold text-gray-700 dark:text-gray-300">
            Resuscitation Time
          </span>
        </div>
        
        <div className={`text-5xl md:text-6xl lg:text-7xl font-bold timer-display mb-2 timer-mobile ${getTimeStatus(elapsedTime)}`}>
          {formatTime(elapsedTime)}
        </div>
        
        <div className="text-sm text-gray-600 dark:text-gray-400">
          minutes and seconds elapsed
        </div>


      </div>

      {/* Optional controls */}
      {showControls && (
        <div className="flex justify-center space-x-2">
          {!isRunning ? (
            <Button
              onClick={onStart}
              size="sm"
              className="btn-medical-green"
            >
              <Play className="w-4 h-4 mr-2" />
              Start
            </Button>
          ) : (
            <Button
              onClick={onPause}
              size="sm"
              className="btn-medical-red"
            >
              <Pause className="w-4 h-4 mr-2" />
              Pause
            </Button>
          )}
          
          <Button
            onClick={onReset}
            size="sm"
            variant="outline"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </Button>
        </div>
      )}

      {/* Critical alerts */}
      {elapsedTime > 0 && elapsedTime % 120 === 0 && (
        <div className="mt-4 p-3 bg-orange-100 dark:bg-orange-900/30 border border-orange-200 dark:border-orange-800 rounded-lg">
          <div className="text-sm font-semibold text-orange-800 dark:text-orange-200">
            2-minute cycle complete
          </div>
          <div className="text-xs text-orange-700 dark:text-orange-300">
            Check rhythm • Swap team members
          </div>
        </div>
      )}

      {elapsedTime >= 1200 && elapsedTime % 300 === 0 && (
        <div className="mt-4 p-3 bg-red-100 dark:bg-red-900/30 border border-red-200 dark:border-red-800 rounded-lg">
          <div className="text-sm font-semibold text-red-800 dark:text-red-200">
            Consider termination
          </div>
          <div className="text-xs text-red-700 dark:text-red-300">
            Review reversible causes • Discuss team decision
          </div>
        </div>
      )}
    </div>
  );
}
