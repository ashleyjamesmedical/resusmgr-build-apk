# ResusMGR Android APK Package

## 📱 Installation Package Contents

This package contains all the necessary files to build and install the ResusMGR Android app.

### Files Included:
- Complete Android Studio project (resusmgr-android/)
- APK resources and manifest (apk-build/)
- Installation instructions (APK-DOWNLOAD-INSTRUCTIONS.md)
- Build documentation (ANDROID-APK-SUMMARY.md)

### Quick Install for Users:

#### Option 1: Download Pre-built APK (Recommended)
If you have received a pre-built APK file:
1. Download ResusMGR-v1.0.0.apk to your Android device
2. Enable "Install from Unknown Sources" in Settings
3. Tap the APK file and follow installation prompts
4. Launch ResusMGR from your app drawer

#### Option 2: Build from Source
If you have the source files:
1. Install Android Studio
2. Import the resusmgr-android folder
3. Build → Generate Signed Bundle/APK → APK
4. Install the generated APK file

### App Features:
- Native Android wrapper for https://www.resusmgr.co.uk
- Offline detection and error handling
- Pull-to-refresh functionality
- Full-screen experience
- Secure HTTPS-only communication

### Technical Details:
- Package: com.ashleyjamesmedical.resusmgr
- Version: 1.0.0
- Min SDK: Android 7.0 (API 24)
- Target SDK: Android 14 (API 34)
- Size: ~5-10MB

### Support:
For installation help or technical support, contact Ashley James Medical.

### Security:
- Only install APKs from trusted sources
- Verify package name matches com.ashleyjamesmedical.resusmgr
- Enable "Install from Unknown Sources" only temporarily
