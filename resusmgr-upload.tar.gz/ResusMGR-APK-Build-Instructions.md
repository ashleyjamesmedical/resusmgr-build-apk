# ResusMGR Android App Bundle (AAB) Build Instructions

Your ResusMGR PWA is now ready to be packaged as an Android App Bundle for Google Play Store submission.

## What's Been Created

✅ **Complete Android project structure** in the `android/` folder  
✅ **All PNG icons** in multiple densities (48px-192px)  
✅ **Trusted Web Activity configuration** pointing to www.resusmgr.co.uk  
✅ **Digital asset links template** for domain verification  

## Step-by-Step AAB Build Process

### 1. Install Android Studio
- Download from: https://developer.android.com/studio
- Install with default settings including Android SDK

### 2. Open Your Project
1. Launch Android Studio
2. Choose "Open an existing project"
3. Navigate to and select the `android` folder in your ResusMGR directory
4. Wait for Gradle sync to complete

### 3. Configure Signing Key
1. Go to `Build` → `Generate Signed Bundle/APK`
2. Select "Android App Bundle"
3. Create a new keystore:
   - Choose location and filename (save this safely!)
   - Set keystore password
   - Set key alias and password
   - Fill in certificate information:
     - First and Last Name: Ashley James Medical
     - Organization: Ashley James Medical
     - City: Your city
     - Country: GB

### 4. Generate Release AAB
1. Select your keystore and enter passwords
2. Choose "release" build variant
3. Check "Export encrypted key"
4. Click "Create"
5. AAB file will be created in `android/app/release/`

### 5. Get Your Key Fingerprint
After creating your signed AAB, get the SHA256 fingerprint:

```bash
keytool -list -v -keystore your-keystore-file.jks -alias your-key-alias
```

Copy the SHA256 fingerprint and update the `assetlinks.json` file.

### 6. Upload Digital Asset Links
The `assetlinks.json` file needs to be accessible at:
`https://www.resusmgr.co.uk/.well-known/assetlinks.json`

Replace `YOUR_RELEASE_KEY_SHA256_FINGERPRINT_WILL_GO_HERE` with your actual fingerprint.

## Important Configuration Details

**Package Name**: `com.ashleyjamesmedical.resusmgr`  
**Target URL**: `https://www.resusmgr.co.uk`  
**Min SDK**: 24 (Android 7.0)  
**Target SDK**: 34 (Android 14)  

## Play Store Requirements Met

✅ App Bundle format (AAB)  
✅ 64-bit architecture support  
✅ Target SDK 33+ requirement  
✅ Privacy policy (already have)  
✅ App icons in all densities  
✅ Digital asset links for TWA  

## Troubleshooting

**Build fails**: Ensure you have the latest Android SDK installed  
**Domain verification fails**: Check that assetlinks.json is accessible via HTTPS  
**App doesn't open**: Verify the DEFAULT_URL in AndroidManifest.xml matches your domain  

Your AAB file will be ready for Google Play Console upload once built with Android Studio.