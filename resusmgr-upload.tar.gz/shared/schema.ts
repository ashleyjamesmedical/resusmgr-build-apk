import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
  decimal,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)]
);

// User storage table with secure authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  username: varchar("username", { length: 50 }).unique(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  password: varchar("password", { length: 255 }),
  recoveryPasscode: varchar("recovery_passcode", { length: 10 }),
  firstName: varchar("first_name", { length: 100 }),
  lastName: varchar("last_name", { length: 100 }),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role", { length: 100 }).notNull(),
  organisation: varchar("organisation", { length: 200 }),
  professionalRegistration: varchar("professional_registration", { length: 100 }),
  stripeCustomerId: varchar("stripe_customer_id"),
  stripeSubscriptionId: varchar("stripe_subscription_id"),
  subscriptionActive: boolean("subscription_active").default(false),
  disclaimerAccepted: boolean("disclaimer_accepted").default(false),
  disclaimerAcceptedAt: timestamp("disclaimer_accepted_at"),
  emailVerified: boolean("email_verified").default(true),
  lastLoginAt: timestamp("last_login_at"),
  lastActivityAt: timestamp("last_activity_at"),
  roscCount: integer("rosc_count").default(0).notNull(),
  roleCount: integer("role_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Resuscitation sessions
export const resuscitationSessions = pgTable("resuscitation_sessions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  customSessionId: varchar("custom_session_id"), // CAD number or patient initials
  protocolType: varchar("protocol_type").notNull(), // BLS, ILS, ALS
  patientType: varchar("patient_type").notNull(), // Adult, Paediatric
  startTime: timestamp("start_time").notNull().defaultNow(),
  endTime: timestamp("end_time"),
  duration: integer("duration"), // in seconds
  outcome: varchar("outcome"), // ROSC, ROLE
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Interventions logged during resuscitation
export const interventions = pgTable("interventions", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull().references(() => resuscitationSessions.id),
  type: varchar("type").notNull(), // airway, iv_io, medication, shock, rhythm_check
  description: text("description"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  timeFromStart: integer("time_from_start"), // seconds from session start
  details: jsonb("details"), // additional data like drug dose, shock energy
});

// Reversible causes checklist
export const reversibleCauses = pgTable("reversible_causes", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull().references(() => resuscitationSessions.id),
  hypoxia: boolean("hypoxia").default(false),
  hypovolaemia: boolean("hypovolaemia").default(false),
  hypoHyperkalaemia: boolean("hypo_hyperkalaemia").default(false),
  hypothermia: boolean("hypothermia").default(false),
  thrombosis: boolean("thrombosis").default(false),
  tensionPneumothorax: boolean("tension_pneumothorax").default(false),
  tamponade: boolean("tamponade").default(false),
  toxins: boolean("toxins").default(false),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Drug calculations and doses
export const drugDoses = pgTable("drug_doses", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull().references(() => resuscitationSessions.id),
  drugName: varchar("drug_name").notNull(),
  patientWeight: decimal("patient_weight", { precision: 5, scale: 2 }),
  calculatedDose: varchar("calculated_dose"),
  calculatedVolume: varchar("calculated_volume"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

// Notifications system
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: varchar("type", { length: 50 }).notNull(), // 'session_completed', 'subscription_cancelled', 'subscription_purchased', 'subscription_expiring'
  title: varchar("title", { length: 200 }).notNull(),
  message: text("message").notNull(),
  sessionId: integer("session_id").references(() => resuscitationSessions.id, { onDelete: "cascade" }),
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const resusTeamMembers = pgTable("resus_team_members", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull().references(() => resuscitationSessions.id),
  userId: varchar("user_id").references(() => users.id),
  name: varchar("name", { length: 100 }).notNull(),
  role: varchar("role", { length: 100 }).notNull(),
  isResusMgrUser: boolean("is_resus_mgr_user").default(false).notNull(),
  addedBy: varchar("added_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Admin reports for unauthorized participation
export const unauthorizedParticipationReports = pgTable("unauthorized_participation_reports", {
  id: serial("id").primaryKey(),
  reportedByUserId: varchar("reported_by_user_id").notNull().references(() => users.id),
  sessionId: integer("session_id").notNull().references(() => resuscitationSessions.id),
  teamMemberId: integer("team_member_id").references(() => resusTeamMembers.id),
  reason: text("reason"),
  status: varchar("status", { length: 20 }).default("pending").notNull(), // 'pending', 'reviewed', 'resolved'
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  reviewedAt: timestamp("reviewed_at"),
  reviewedBy: varchar("reviewed_by").references(() => users.id),
});

// Chat system tables
export const chatConversations = pgTable("chat_conversations", {
  id: serial("id").primaryKey(),
  title: varchar("title"),
  type: varchar("type").default("direct").notNull(), // 'direct', 'group', 'support'
  createdBy: varchar("created_by").notNull().references(() => users.id),
  relatedReportId: integer("related_report_id").references(() => unauthorizedParticipationReports.id),
  metadata: jsonb("metadata"), // For storing additional conversation data
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const chatParticipants = pgTable("chat_participants", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull().references(() => chatConversations.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id),
  role: varchar("role").default("user").notNull(), // 'user', 'admin', 'moderator'
  joinedAt: timestamp("joined_at").defaultNow(),
  lastReadAt: timestamp("last_read_at"),
});

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull().references(() => chatConversations.id, { onDelete: "cascade" }),
  senderId: varchar("sender_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  messageType: varchar("message_type").default("text").notNull(), // 'text', 'system'
  deliveredAt: timestamp("delivered_at"),
  readAt: timestamp("read_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Message read receipts tracking
export const messageReadReceipts = pgTable("message_read_receipts", {
  id: serial("id").primaryKey(),
  messageId: integer("message_id").notNull().references(() => chatMessages.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id),
  readAt: timestamp("read_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastLoginAt: true,
});

export const loginUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const registerUserSchema = createInsertSchema(users).pick({
  id: true,
  username: true,
  email: true,
  password: true,
  recoveryPasscode: true,
  firstName: true,
  lastName: true,
  role: true,
  professionalRegistration: true,
});

export const updateUserSchema = createInsertSchema(users).omit({
  id: true,
  password: true,
  createdAt: true,
  updatedAt: true,
  lastLoginAt: true,
}).partial();

export const passwordUpdateSchema = createInsertSchema(users).pick({
  password: true,
});

export const insertResuscitationSessionSchema = createInsertSchema(resuscitationSessions).omit({
  id: true,
  createdAt: true,
});

export const insertInterventionSchema = createInsertSchema(interventions).omit({
  id: true,
  timestamp: true,
});

export const insertReversibleCausesSchema = createInsertSchema(reversibleCauses).omit({
  id: true,
  updatedAt: true,
});

export const insertDrugDoseSchema = createInsertSchema(drugDoses).omit({
  id: true,
  timestamp: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export const insertResusTeamMemberSchema = createInsertSchema(resusTeamMembers).omit({
  id: true,
  createdAt: true,
});

export const insertUnauthorizedParticipationReportSchema = createInsertSchema(unauthorizedParticipationReports).omit({
  id: true,
  createdAt: true,
  reviewedAt: true,
});

export const insertChatConversationSchema = createInsertSchema(chatConversations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertChatParticipantSchema = createInsertSchema(chatParticipants).omit({
  id: true,
  joinedAt: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  deliveredAt: true,
  readAt: true,
});

export const insertMessageReadReceiptSchema = createInsertSchema(messageReadReceipts).omit({
  id: true,
  readAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginUser = z.infer<typeof loginUserSchema>;
export type RegisterUser = z.infer<typeof registerUserSchema>;
export type UpdateUser = z.infer<typeof updateUserSchema>;
export type InsertResuscitationSession = z.infer<typeof insertResuscitationSessionSchema>;
export type ResuscitationSession = typeof resuscitationSessions.$inferSelect;
export type InsertIntervention = z.infer<typeof insertInterventionSchema>;
export type Intervention = typeof interventions.$inferSelect;
export type InsertReversibleCauses = z.infer<typeof insertReversibleCausesSchema>;
export type ReversibleCauses = typeof reversibleCauses.$inferSelect;
export type InsertDrugDose = z.infer<typeof insertDrugDoseSchema>;
export type DrugDose = typeof drugDoses.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertResusTeamMember = z.infer<typeof insertResusTeamMemberSchema>;
export type ResusTeamMember = typeof resusTeamMembers.$inferSelect;
export type InsertUnauthorizedParticipationReport = z.infer<typeof insertUnauthorizedParticipationReportSchema>;
export type UnauthorizedParticipationReport = typeof unauthorizedParticipationReports.$inferSelect;
export type InsertChatConversation = z.infer<typeof insertChatConversationSchema>;
export type ChatConversation = typeof chatConversations.$inferSelect;
export type InsertChatParticipant = z.infer<typeof insertChatParticipantSchema>;
export type ChatParticipant = typeof chatParticipants.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertMessageReadReceipt = z.infer<typeof insertMessageReadReceiptSchema>;
export type MessageReadReceipt = typeof messageReadReceipts.$inferSelect;
